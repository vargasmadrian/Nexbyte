// ============================================================
// Background Service Worker — Auth, comunicación y ejecución
// Bug #5: Token TTL — refresh proactivo antes de expirar
// Bug #9: Retry logic con CONFIG.MAX_RETRIES
// ============================================================

importScripts('config.js');

// Bug #9: Helper de retry para llamadas de red
async function gaulaFetchWithRetry(url, options, retries = CONFIG.MAX_RETRIES) {
  let lastRes;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, options);
      if (res.ok || res.status < 500) return res;
      lastRes = res;
      if (attempt < retries) await new Promise(r => setTimeout(r, CONFIG.RETRY_DELAY));
    } catch (err) {
      if (attempt >= retries) throw err;
      await new Promise(r => setTimeout(r, CONFIG.RETRY_DELAY));
    }
  }
  return lastRes; // Devolver última respuesta en vez de undefined
}

// Escuchar mensajes del popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'LOGIN_GOOGLE') {
    handleGoogleLogin().then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  if (msg.type === 'LOGOUT') {
    handleLogout().then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  if (msg.type === 'GET_SESSION') {
    getSession().then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Solicitar script al backend, verificar créditos, y enviarlo al content script
  if (msg.type === 'EXECUTE_ACTION') {
    executeAction(msg.action, msg.payload, msg.tabId).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Llamar a generate-content desde el background (evita problemas de CORS/token en popup)
  if (msg.type === 'GENERATE_CONTENT') {
    handleGenerateContent(msg.action, msg.payload).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Reenviar mensajes al content script de la pestaña activa
  if (msg.type === 'SEND_TO_TAB') {
    sendToActiveTab(msg.message).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }
});

// ============================================================
// AUTH
// ============================================================

async function handleGoogleLogin() {
  const redirectUrl = chrome.identity.getRedirectURL();
  const authUrl = `${CONFIG.SUPABASE_URL}/auth/v1/authorize?provider=google&redirect_to=${encodeURIComponent(redirectUrl)}`;

  const responseUrl = await chrome.identity.launchWebAuthFlow({
    url: authUrl,
    interactive: true,
  });

  const url = new URL(responseUrl);
  const hashParams = new URLSearchParams(url.hash.substring(1));
  const accessToken = hashParams.get('access_token');
  const refreshToken = hashParams.get('refresh_token');

  if (!accessToken) throw new Error('No se recibió token de acceso');

  await chrome.storage.local.set({
    session: { access_token: accessToken, refresh_token: refreshToken, timestamp: Date.now() }
  });

  const userRes = await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/user`, {
    headers: { 'Authorization': `Bearer ${accessToken}`, 'apikey': CONFIG.SUPABASE_ANON_KEY }
  });
  const user = await userRes.json();
  return { ok: true, user };
}

async function handleLogout() {
  const { session } = await chrome.storage.local.get('session');
  if (session?.access_token) {
    await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/logout`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${session.access_token}`, 'apikey': CONFIG.SUPABASE_ANON_KEY }
    }).catch(() => {});
  }
  await chrome.storage.local.remove('session');
  return { ok: true };
}

async function getSession() {
  const { session } = await chrome.storage.local.get('session');
  if (!session?.access_token) return { ok: false, error: 'No hay sesión' };

  // Bug #5: Refresh proactivo — si el token tiene más de 50 min, refrescar antes de que expire (JWT dura ~1h)
  const TOKEN_TTL = 50 * 60 * 1000; // 50 minutos
  const tokenAge = Date.now() - (session.timestamp || 0);
  if (tokenAge > TOKEN_TTL && session.refresh_token) {
    const refreshRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': CONFIG.SUPABASE_ANON_KEY },
      body: JSON.stringify({ refresh_token: session.refresh_token }),
    });
    if (refreshRes.ok) {
      const data = await refreshRes.json();
      await chrome.storage.local.set({
        session: { access_token: data.access_token, refresh_token: data.refresh_token, timestamp: Date.now() }
      });
      return { ok: true, user: data.user, token: data.access_token };
    }
  }

  // Bug #9: Usar fetch con retry
  const userRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/user`, {
    headers: { 'Authorization': `Bearer ${session.access_token}`, 'apikey': CONFIG.SUPABASE_ANON_KEY }
  });

  if (!userRes.ok) {
    if (session.refresh_token) {
      const refreshRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': CONFIG.SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: session.refresh_token }),
      });
      if (refreshRes.ok) {
        const data = await refreshRes.json();
        await chrome.storage.local.set({
          session: { access_token: data.access_token, refresh_token: data.refresh_token, timestamp: Date.now() }
        });
        return { ok: true, user: data.user, token: data.access_token };
      }
    }
    await chrome.storage.local.remove('session');
    return { ok: false, error: 'Sesión expirada' };
  }

  const user = await userRes.json();
  return { ok: true, user, token: session.access_token };
}

// ============================================================
// EJECUTAR ACCIONES
// ============================================================

async function executeAction(action, payload, tabId) {
  // 1. Obtener sesión
  let session = await getSession();
  if (!session.ok) return { ok: false, error: 'Debes iniciar sesión' };

  // 2. Llamar al backend: verificar suscripción y consumir créditos
  // Bug #9: Retry para edge function
  async function callEdgeFunction(token) {
    return gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/functions/v1/execute-action`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'apikey': CONFIG.SUPABASE_ANON_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action, payload }),
    });
  }

  let res = await callEdgeFunction(session.token);

  // Si devuelve 401, forzar refresh del token y reintentar una vez
  if (res.status === 401) {
    const { session: stored } = await chrome.storage.local.get('session');
    if (stored?.refresh_token) {
      const refreshRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': CONFIG.SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: stored.refresh_token }),
      });
      if (refreshRes.ok) {
        const data = await refreshRes.json();
        await chrome.storage.local.set({
          session: { access_token: data.access_token, refresh_token: data.refresh_token, timestamp: Date.now() }
        });
        res = await callEdgeFunction(data.access_token);
      }
    }
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const msg = err.error || err.message || `Error ${res.status}`;
    return { ok: false, error: `${msg} (${action})` };
  }

  const data = await res.json();
  if (!data.ok) return data;

  // 3. Los scripts de acción están bundleados en la extensión (CSP de Moodle
  //    bloquea new Function/eval). El popup guarda el estado directamente
  //    en gaula_content_state y navega la pestaña. Los content scripts
  //    detectan el estado al cargar y ejecutan la acción correspondiente.

  return {
    ok: true,
    uses_remaining: data.uses_remaining,
    uses_total: data.uses_total,
  };
}

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

async function sendToActiveTab(message) {
  const tabId = await getActiveTabId();
  if (!tabId) return { ok: false, error: 'No hay pestaña activa' };
  return chrome.tabs.sendMessage(tabId, message);
}

// Proxy para generate-content — usa el token fresco del background
async function handleGenerateContent(action, payload) {
  let session = await getSession();
  if (!session.ok) throw new Error('Debes iniciar sesión');

  let res = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/functions/v1/generate-content`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${session.token}`,
      'apikey': CONFIG.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ action, ...payload }),
  });

  // Si 401, forzar refresh y reintentar
  if (res.status === 401) {
    const { session: stored } = await chrome.storage.local.get('session');
    if (stored?.refresh_token) {
      const refreshRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': CONFIG.SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: stored.refresh_token }),
      });
      if (refreshRes.ok) {
        const data = await refreshRes.json();
        await chrome.storage.local.set({
          session: { access_token: data.access_token, refresh_token: data.refresh_token, timestamp: Date.now() }
        });
        res = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/functions/v1/generate-content`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${data.access_token}`,
            'apikey': CONFIG.SUPABASE_ANON_KEY,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ action, ...payload }),
        });
      }
    }
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Error ${res.status}`);
  }

  return res.json();
}
