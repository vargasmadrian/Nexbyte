// ============================================================
// Configuración central — GeneradorAulas 3.0
// Las credenciales se cargan desde chrome.storage (configuradas en primer login)
// El anon key es público por diseño de Supabase, pero centralizado aquí.
// ============================================================
const CONFIG = {
  SUPABASE_URL: 'https://wbgqdrhfvikiciwqrdec.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndiZ3FkcmhmdmlraWNpd3FyZGVjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYxMjEzNjgsImV4cCI6MjA5MTY5NzM2OH0.gB7T0FZrTad_xUnNjPADkptTbDhOQI3DBRNnDsvYNkk',
  // Timeout configurable para conexiones lentas (Bug #8)
  ELEMENT_TIMEOUT: 20000,
  // Máximo de reintentos para llamadas de red (Bug #9)
  MAX_RETRIES: 2,
  RETRY_DELAY: 1500,
  // URL del landing de producto (página de precios)
  PRICING_URL: 'https://nexbyte.pro/planes/',
};
