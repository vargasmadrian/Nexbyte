// ============================================================
// GeneradorAulas 3.0 — Popup Controller
// Bug #2: Restaurar estado de operación activa al reabrir popup
// Bug #7: Validación de tipos de archivo
// Bug #11: Debounce en saveFormState
// Bug #12: Cache TTL para categorías de calificación
// ============================================================

// --- Screens ---
const screenLogin = document.getElementById('screen-login');
const screenNoSub = document.getElementById('screen-no-sub');
const screenMain = document.getElementById('screen-main');

// --- Login elements ---
const btnGoogleLogin = document.getElementById('btnGoogleLogin');
const loginError = document.getElementById('loginError');
const nosubUserName = document.getElementById('nosubUserName');
const btnLogoutNoSub = document.getElementById('btnLogoutNoSub');

// --- Main elements ---
const userName = document.getElementById('userName');
const userAvatar = document.getElementById('userAvatar');
const creditsCount = document.getElementById('creditsCount');
const btnLogout = document.getElementById('btnLogout');
const courseTypeEl = document.getElementById('courseType');
const statusEl = document.getElementById('status');
const btnStop = document.getElementById('btnStop');

// --- RdA data storage ---
function gaulaToday() { return new Date().toISOString().split('T')[0]; }
function gaulaNextWeek() { const d = new Date(); d.setDate(d.getDate() + 7); return d.toISOString().split('T')[0]; }

function createEmptyManualTask() {
  return {
    nombre: '', descripcion: '', pdf: null, pdfName: '', dateFrom: gaulaToday(), dateTo: gaulaNextWeek(),
    rubrica: [{ nombre: '', niveles: [
      { nombre: 'Excelente', puntos: 5, descripcion: '' },
      { nombre: 'Bueno', puntos: 3, descripcion: '' },
      { nombre: 'Regular', puntos: 1, descripcion: '' },
      { nombre: 'Insuficiente', puntos: 0, descripcion: '' }
    ]}]
  };
}

const rdaData = [
  { pdfs: [null,null,null], ppts: [null,null,null], videos: ['','',''], geneallys: ['','',''], tasks: [{},{},{}], evals: [{},{},{}], forumTopic: '', aiAnalyzed: false, pdfText: '', manualTask: createEmptyManualTask(), manualQuiz: { nombre: '', dateFrom: gaulaToday(), dateTo: gaulaToday(), time: 60, password: '', aikenText: '', xmlContent: '' } },
  { pdfs: [null,null,null], ppts: [null,null,null], videos: ['','',''], geneallys: ['','',''], tasks: [{},{},{}], evals: [{},{},{}], forumTopic: '', aiAnalyzed: false, pdfText: '', manualTask: createEmptyManualTask(), manualQuiz: { nombre: '', dateFrom: gaulaToday(), dateTo: gaulaToday(), time: 60, password: '', aikenText: '', xmlContent: '' } },
  { pdfs: [null,null,null], ppts: [null,null,null], videos: ['','',''], geneallys: ['','',''], tasks: [{},{},{}], evals: [{},{},{}], forumTopic: '', aiAnalyzed: false, pdfText: '', manualTask: createEmptyManualTask(), manualQuiz: { nombre: '', dateFrom: gaulaToday(), dateTo: gaulaToday(), time: 60, password: '', aikenText: '', xmlContent: '' } }
];
let activeRda = 0;

// ============================================================
// NAVEGACION DE PANTALLAS
// ============================================================

function showScreen(screen) {
  [screenLogin, screenNoSub, screenMain].forEach(s => s.classList.remove('active'));
  screen.classList.add('active');
}

// ============================================================
// INICIALIZACION
// ============================================================

async function init() {
  const result = await sendMessage({ type: 'GET_SESSION' });
  if (!result.ok) { showScreen(screenLogin); return; }
  await loadUserData(result.user);

  // Bug #2: Restaurar estado de operación activa al reabrir popup
  checkActiveOperation();
}

async function checkActiveOperation() {
  const data = await chrome.storage.local.get(['gaula_content_state', 'gaula_progress']);
  const state = data.gaula_content_state;
  const progress = data.gaula_progress;

  if (state && state.action) {
    // Hay una operación en curso — mostrar barra de progreso
    const wrapper = document.getElementById('progressWrapper');
    const label = document.getElementById('progressLabel');
    wrapper.style.display = 'block';
    btnStop.style.display = 'block';

    if (progress && progress.status === 'running') {
      label.textContent = progress.label || `${state.action} en progreso...`;
      const count = document.getElementById('progressCount');
      const fill = document.getElementById('progressFill');
      if (progress.total > 0) {
        count.textContent = `${progress.current}/${progress.total}`;
        fill.style.width = `${(progress.current / progress.total) * 100}%`;
      }
    } else {
      label.textContent = `${state.action} en progreso...`;
    }
  }
}

let currentUserId = null;
let currentSubId = null;

async function loadUserData(user) {
  const sub = await fetchSubscription(user.id);
  if (!sub) {
    const displayName = user.user_metadata?.full_name || user.user_metadata?.name || user.email;
    nosubUserName.textContent = displayName;
    showScreen(screenNoSub);
    return;
  }

  currentUserId = user.id;
  currentSubId = sub.id;

  const displayName = user.user_metadata?.full_name || user.user_metadata?.name || user.email;
  const avatar = user.user_metadata?.avatar_url || user.user_metadata?.picture || '';

  userName.textContent = displayName.split(' ')[0];
  if (avatar) { userAvatar.src = avatar; userAvatar.style.display = 'block'; }
  else { userAvatar.style.display = 'none'; }

  creditsCount.textContent = 'Mi Plan';

  showScreen(screenMain);
  initUI();
  restoreScrollPosition();
}

// Auto-detectar tipo de aula ejecutando script directo en el frame principal
// autoDetectCourseType eliminado — el popup es genérico, el content script detecta en Moodle

async function fetchSubscription(userId) {
  const session = await sendMessage({ type: 'GET_SESSION' });
  if (!session.ok) return null;

  const url = `${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?user_id=eq.${userId}&status=eq.active&period_end=gte.${new Date().toISOString().split('T')[0]}&order=period_end.desc&limit=1`;
  const res = await fetch(url, {
    headers: { 'Authorization': `Bearer ${session.token}`, 'apikey': CONFIG.SUPABASE_ANON_KEY }
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.length > 0 ? data[0] : null;
}

// ============================================================
// USAGE PANEL (Mi Plan dropdown)
// ============================================================

const ACTION_LIMITS = {
  import_template: { label: 'Importar plantilla', max: 12 },
  generate_no_ai: { label: 'Generar sílabo', max: 12 },
  edit_banner: { label: 'Editar banner', max: 12 },
  upload_resources: { label: 'Subir recursos', max: 140 },
  create_task: { label: 'Crear tarea', max: 90 },
  generate_rubric: { label: 'Rúbrica IA', max: 90, ai: true },
  create_quiz: { label: 'Crear evaluación', max: 30 },
  generate_aiken: { label: 'Preguntas IA', max: 30, ai: true },
};

const usagePanel = document.getElementById('usagePanel');
const creditsBadge = document.getElementById('creditsBadge');

creditsBadge.addEventListener('click', async (e) => {
  e.stopPropagation();
  const isOpen = usagePanel.classList.toggle('open');
  if (isOpen) await loadUsagePanel();
});

document.addEventListener('click', (e) => {
  if (!usagePanel.contains(e.target) && !creditsBadge.contains(e.target)) {
    usagePanel.classList.remove('open');
  }
});

// Botón "Comprar más usos" abre la página de precios en nueva pestaña
document.getElementById('btnBuyMore').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: CONFIG.PRICING_URL });
  usagePanel.classList.remove('open');
});

async function loadUsagePanel() {
  const content = document.getElementById('usagePanelContent');
  if (!currentUserId || !currentSubId) {
    content.innerHTML = '<div style="font-size:11px;color:#94a3b8;">Sin suscripción activa</div>';
    return;
  }

  content.innerHTML = '<div style="font-size:11px;color:#94a3b8;">Cargando...</div>';

  try {
    const session = await sendMessage({ type: 'GET_SESSION' });
    if (!session.ok) return;

    const headers = { 'Authorization': `Bearer ${session.token}`, 'apikey': CONFIG.SUPABASE_ANON_KEY };

    const [usageRes, subRes] = await Promise.all([
      fetch(`${CONFIG.SUPABASE_URL}/rest/v1/action_usage?subscription_id=eq.${currentSubId}`, { headers }),
      fetch(`${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?id=eq.${currentSubId}&select=period_end,plan_name`, { headers }),
    ]);

    const usageData = usageRes.ok ? await usageRes.json() : [];
    const subData = subRes.ok ? await subRes.json() : [];

    const usageMap = {};
    usageData.forEach(u => { usageMap[u.action] = u.uses_count; });

    let html = '';
    for (const [action, info] of Object.entries(ACTION_LIMITS)) {
      const used = usageMap[action] || 0;
      const pct = Math.min((used / info.max) * 100, 100);
      const barClass = pct >= 90 ? 'red' : pct >= 70 ? 'yellow' : 'green';
      const aiTag = info.ai ? '<span class="usage-ai-tag">IA</span>' : '';

      html += `<div class="usage-row">
        <span class="usage-row-label">${info.label}${aiTag}</span>
        <span class="usage-row-count">${used}/${info.max}</span>
      </div>
      <div class="usage-bar"><div class="usage-bar-fill ${barClass}" style="width:${pct}%"></div></div>`;
    }

    if (subData.length > 0) {
      const endDate = new Date(subData[0].period_end).toLocaleDateString('es-EC');
      html += `<div class="usage-panel-period">Válido hasta: ${endDate}</div>`;
    }

    content.innerHTML = html;
  } catch (e) {
    content.innerHTML = '<div style="font-size:11px;color:#ef4444;">Error al cargar uso</div>';
  }
}

// ============================================================
// LOGIN / LOGOUT
// ============================================================

btnGoogleLogin.addEventListener('click', async () => {
  btnGoogleLogin.disabled = true;
  btnGoogleLogin.textContent = 'Conectando...';
  loginError.style.display = 'none';

  const result = await sendMessage({ type: 'LOGIN_GOOGLE' });
  if (result.ok) {
    await loadUserData(result.user);
  } else {
    loginError.textContent = result.error || 'Error al iniciar sesion';
    loginError.style.display = 'block';
    btnGoogleLogin.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 48 48">
        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
      </svg>
      Iniciar sesion con Google`;
    btnGoogleLogin.disabled = false;
  }
});

btnLogout.addEventListener('click', doLogout);
btnLogoutNoSub.addEventListener('click', doLogout);
async function doLogout() {
  await sendMessage({ type: 'LOGOUT' });
  showScreen(screenLogin);
}

// ============================================================
// UTILITIES
// ============================================================

function sendMessage(msg) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage(msg, response => {
      resolve(response || { ok: false, error: 'Sin respuesta' });
    });
  });
}

function formatDate(dateStr) {
  const months = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
  const d = new Date(dateStr + 'T12:00:00');
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function escapeAttr(str) {
  return (str || '').replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

// showStatus: muestra mensaje cerca de un botón o en un contenedor con ID
// - nearBtn: un elemento DOM (botón) junto al cual insertar el mensaje
// - suffix: fallback al elemento #status{suffix}
function showStatus(msg, type, nearBtnOrSuffix) {
  // Limpiar status previos inline
  document.querySelectorAll('.status-inline-dynamic').forEach(el => el.remove());

  let el;
  if (nearBtnOrSuffix instanceof HTMLElement) {
    // Crear un div inline justo después del botón (o su contenedor .btn-row / .subsection)
    el = document.createElement('div');
    el.className = 'status-inline-dynamic status-inline ' + type;
    el.textContent = msg;
    const container = nearBtnOrSuffix.closest('.btn-row') || nearBtnOrSuffix.closest('.uaz-ready') || nearBtnOrSuffix.parentElement;
    container.insertAdjacentElement('afterend', el);
  } else {
    // Fallback: usar elemento con ID
    const suffix = nearBtnOrSuffix || '';
    el = suffix ? document.getElementById(`status${suffix}`) : statusEl;
    if (!el) return;
    el.textContent = msg;
    el.className = 'status-inline ' + type;
  }
  el.style.display = 'block';
  if (type === 'success') setTimeout(() => { el.style.display = 'none'; if (el.classList.contains('status-inline-dynamic')) el.remove(); }, 5000);
}

function hideStatus(suffix = '') {
  document.querySelectorAll('.status-inline-dynamic').forEach(el => el.remove());
  const el = suffix ? document.getElementById(`status${suffix}`) : statusEl;
  if (el) el.style.display = 'none';
}

function updateCredits(text) {
  creditsCount.textContent = text;
}

async function serializeFile(file) {
  return new Promise(resolve => {
    const reader = new FileReader();
    reader.onload = () => resolve({ data: reader.result, name: file.name, type: file.type });
    reader.readAsDataURL(file);
  });
}

// Extract text from PDF using pdf.js (client-side, before sending to backend)
async function extractTextFromPDF(file) {
  const arrayBuffer = await file.arrayBuffer();
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let text = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map(item => item.str).join(' ') + '\n';
  }
  return text;
}

// Extract text from Excel (.xlsx/.xls) using SheetJS — concatena todas las hojas
// como CSV separado por " | ", precedido del nombre de la hoja. Lo entiende bien la IA.
async function extractTextFromExcel(file) {
  if (typeof XLSX === 'undefined') throw new Error('Lib XLSX no cargada');
  const arrayBuffer = await file.arrayBuffer();
  const wb = XLSX.read(arrayBuffer, { type: 'array' });
  let text = '';
  for (const name of wb.SheetNames) {
    text += `\n=== HOJA: ${name} ===\n`;
    text += XLSX.utils.sheet_to_csv(wb.Sheets[name], { FS: ' | ', blankrows: false });
  }
  return text.trim();
}

// Wrapper: detecta tipo del archivo del sílabo y llama al extractor correcto.
// PDF y Excel devuelven texto plano que la IA procesa igual.
async function extractTextFromSyllabus(file) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (ext === 'pdf') return extractTextFromPDF(file);
  if (ext === 'xlsx' || ext === 'xls') return extractTextFromExcel(file);
  throw new Error(`Formato no soportado: .${ext}`);
}

// Execute action via backend (auth + credits)
async function executeAction(action, payload) {
  const result = await sendMessage({ type: 'EXECUTE_ACTION', action, payload });
  if (result.ok && result.uses_remaining != null && result.uses_remaining >= 0) {
    showStatus(`Usos restantes: ${result.uses_remaining}/${result.uses_total}`, 'success');
  }
  return result;
}

// ============================================================
// INIT UI (called after login+subscription verified)
// ============================================================

let uiInitialized = false;

function initUI() {
  if (uiInitialized) return;
  uiInitialized = true;

  initDateRangePickers();
  initQuizTimeSelects();
  initQuizTimeLimitSelect();
  initFileSlotButtons();
  initUploadZones();
  initRdaTabs();
  initAiTabs();
  initCourseType();
  initSchedule();
  initRubric();
  initActionButtons();
  initAikenLoader();
  initUrlValidation();
  initProgressMonitor();
  // Auto-guardar al cambiar cualquier campo de tarea/evaluación
  ['manualTaskName','manualTaskDesc','manualTaskCriterio',
   'manualTaskDateFrom','manualTaskDateTo',
   'manualQuizName','manualQuizPassword','manualQuizTime','manualQuizCriterio',
   'manualQuizDateFrom','manualQuizDateTo',
   'manualQuizHourFrom','manualQuizMinFrom','manualQuizHourTo','manualQuizMinTo'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', () => saveFormState());
  });
  ['manualTaskName','manualTaskDesc','manualQuizName','manualQuizPassword'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', () => saveFormState());
  });
  loadFormState();
}

// ============================================================
// FILE SLOT BUTTONS
// ============================================================

function initFileSlotButtons() {
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.file-slot-btn');
    if (!btn) return;
    const slot = btn.closest('.file-slot');
    const input = slot.querySelector('input[type="file"]');
    if (input) input.click();
  });
  // Bug #7: Validación de tipo de archivo
  const ALLOWED_FILE_TYPES = {
    'pdf-input': { exts: ['.pdf'], mime: ['application/pdf'], label: 'PDF' },
    'ppt-input': { exts: ['.pptx', '.ppt'], mime: ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/vnd.ms-powerpoint'], label: 'PowerPoint' },
  };

  document.addEventListener('change', (e) => {
    if (e.target.type !== 'file' || !e.target.closest('.file-slot')) return;
    const slot = e.target.closest('.file-slot');
    const nameInput = slot.querySelector('.file-slot-name');
    const file = e.target.files[0];

    // Bug #7: Validar tipo de archivo
    if (file) {
      for (const [cls, rule] of Object.entries(ALLOWED_FILE_TYPES)) {
        if (e.target.classList.contains(cls)) {
          const ext = '.' + file.name.split('.').pop().toLowerCase();
          if (!rule.exts.includes(ext)) {
            showStatus(`Solo se permiten archivos ${rule.label} (${rule.exts.join(', ')})`, 'error');
            e.target.value = '';
            return;
          }
          break;
        }
      }
    }

    if (nameInput) {
      if (file) {
        nameInput.value = file.name.replace(/\.[^.]+$/, '');
        nameInput.classList.add('has-file');
        nameInput.removeAttribute('readonly');
      } else {
        nameInput.value = 'Sin archivo';
        nameInput.classList.remove('has-file');
        nameInput.setAttribute('readonly', '');
      }
    }
  });
}

// ============================================================
// UPLOAD ZONES (template + syllabus)
// ============================================================

function initUploadZones() {
  // Template .mbz
  const dropTemplate = document.getElementById('dropZoneTemplate');
  const templateFile = document.getElementById('templateFile');
  const templateFileName = document.getElementById('templateFileName');
  const btnImport = document.getElementById('btnImportTemplate');

  templateFile.addEventListener('change', () => {
    if (templateFile.files[0]) {
      // Bug #7: Validar que sea .mbz
      const ext = templateFile.files[0].name.split('.').pop().toLowerCase();
      if (ext !== 'mbz') {
        showStatus('Solo se permiten archivos .mbz (backup de Moodle)', 'error');
        templateFile.value = '';
        return;
      }
      dropTemplate.classList.add('has-file');
      dropTemplate.querySelector('.uaz-idle').style.display = 'none';
      dropTemplate.querySelector('.uaz-ready').style.display = 'flex';
      templateFileName.textContent = templateFile.files[0].name;
      btnImport.disabled = false;
    }
  });

  templateFileName.addEventListener('click', () => {
    templateFile.value = '';
    dropTemplate.classList.remove('has-file');
    dropTemplate.querySelector('.uaz-idle').style.display = 'flex';
    dropTemplate.querySelector('.uaz-ready').style.display = 'none';
    btnImport.disabled = true;
  });

  // Syllabus PDF
  const dropSyllabus = document.getElementById('dropZoneSyllabus');
  const syllabusFile = document.getElementById('syllabusFile');
  const syllabusFileName = document.getElementById('syllabusFileName');
  const btnGenAI = document.getElementById('btnGenerateAI');
  const btnGenNoAI = document.getElementById('btnGenerateNoAI');

  syllabusFile.addEventListener('change', () => {
    if (syllabusFile.files[0]) {
      // Validar que sea PDF o Excel (.xlsx/.xls)
      const ext = syllabusFile.files[0].name.split('.').pop().toLowerCase();
      if (!['pdf', 'xlsx', 'xls'].includes(ext)) {
        showStatus('Solo se permiten archivos PDF o Excel (.xlsx, .xls) para el sílabo', 'error');
        syllabusFile.value = '';
        return;
      }
      dropSyllabus.classList.add('has-file');
      dropSyllabus.querySelector('.uaz-idle').style.display = 'none';
      dropSyllabus.querySelector('.uaz-ready').style.display = 'flex';
      syllabusFileName.textContent = syllabusFile.files[0].name;
      btnGenAI.disabled = false;
      btnGenNoAI.disabled = false;
    }
  });

  syllabusFileName.addEventListener('click', () => {
    syllabusFile.value = '';
    dropSyllabus.classList.remove('has-file');
    dropSyllabus.querySelector('.uaz-idle').style.display = 'flex';
    dropSyllabus.querySelector('.uaz-ready').style.display = 'none';
    btnGenAI.disabled = true;
    btnGenNoAI.disabled = true;
  });
}

// ============================================================
// RDA TABS
// ============================================================

function initRdaTabs() {
  document.querySelectorAll('.rda-tab, .rda-tab-mini').forEach(tab => {
    tab.addEventListener('click', () => {
      const rdaIndex = parseInt(tab.dataset.rda) - 1;
      switchRda(rdaIndex);
    });
  });
}

function switchRda(index) {
  saveCurrentRdaData();
  activeRda = index;
  document.querySelectorAll('.rda-tab').forEach((tab, i) => {
    tab.classList.toggle('active', i === index);
  });
  document.querySelectorAll('.rda-tab-mini').forEach((tab, i) => {
    tab.classList.toggle('active', i % 3 === index);
  });
  loadRdaData(index);
  saveFormState();
}

function saveCurrentRdaData() {
  const rda = rdaData[activeRda];
  document.querySelectorAll('.pdf-input').forEach((input, i) => { if (input.files[0]) rda.pdfs[i] = input.files[0]; });
  document.querySelectorAll('.ppt-input').forEach((input, i) => { if (input.files[0]) rda.ppts[i] = input.files[0]; });
  document.querySelectorAll('.video-url').forEach((input, i) => { rda.videos[i] = input.value; });
  document.querySelectorAll('.geneally-url').forEach((input, i) => { rda.geneallys[i] = input.value; });
  document.querySelectorAll('#taskPanels .ai-tab-panel').forEach((panel, i) => {
    rda.tasks[i] = {
      ...rda.tasks[i],
      nombre: panel.querySelector('.task-name').value,
      descripcion: panel.querySelector('.task-desc').value,
      dateFrom: panel.querySelector('.task-date-from')?.value || '',
      dateTo: panel.querySelector('.task-date-to')?.value || ''
    };
  });
  document.querySelectorAll('#evalPanels .ai-tab-panel').forEach((panel, i) => {
    rda.evals[i] = {
      ...rda.evals[i],
      dateFrom: panel.querySelector('.eval-date-from')?.value || '',
      dateTo: panel.querySelector('.eval-date-to')?.value || ''
    };
  });
  rda.forumTopic = document.querySelector('.forum-topic')?.value || '';
  saveManualTaskData();
  saveManualQuizData();
}

function loadRdaData(index) {
  const rda = rdaData[index];
  document.querySelectorAll('.pdf-input').forEach((input, i) => {
    const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
    const hasFile = rda.pdfs[i];
    const savedName = rda._pdfNames && rda._pdfNames[i];
    if (hasFile) {
      nameEl.value = hasFile.name.replace(/\.[^.]+$/, '');
      nameEl.classList.add('has-file');
      nameEl.removeAttribute('readonly');
    } else if (savedName) {
      nameEl.value = savedName.replace(/\.[^.]+$/, '') + ' (recargar)';
      nameEl.classList.add('has-file');
      nameEl.setAttribute('readonly', '');
    } else {
      nameEl.value = 'Sin archivo';
      nameEl.classList.remove('has-file');
      nameEl.setAttribute('readonly', '');
    }
  });
  document.querySelectorAll('.ppt-input').forEach((input, i) => {
    const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
    const hasFile = rda.ppts[i];
    const savedName = rda._pptNames && rda._pptNames[i];
    if (hasFile) {
      nameEl.value = hasFile.name.replace(/\.[^.]+$/, '');
      nameEl.classList.add('has-file');
      nameEl.removeAttribute('readonly');
    } else if (savedName) {
      nameEl.value = savedName.replace(/\.[^.]+$/, '') + ' (recargar)';
      nameEl.classList.add('has-file');
      nameEl.setAttribute('readonly', '');
    } else {
      nameEl.value = 'Sin archivo';
      nameEl.classList.remove('has-file');
      nameEl.setAttribute('readonly', '');
    }
  });
  document.querySelectorAll('.video-url').forEach((input, i) => { input.value = rda.videos[i] || ''; });
  document.querySelectorAll('.geneally-url').forEach((input, i) => { input.value = rda.geneallys[i] || ''; });
  document.querySelectorAll('#taskPanels .ai-tab-panel').forEach((panel, i) => {
    panel.querySelector('.task-name').value = rda.tasks[i].nombre || '';
    panel.querySelector('.task-desc').value = rda.tasks[i].descripcion || '';
    const df = panel.querySelector('.task-date-from'); if (df) df.value = rda.tasks[i].dateFrom || '';
    const dt = panel.querySelector('.task-date-to'); if (dt) dt.value = rda.tasks[i].dateTo || '';
  });
  document.querySelectorAll('#evalPanels .ai-tab-panel').forEach((panel, i) => {
    const df = panel.querySelector('.eval-date-from'); if (df) df.value = rda.evals[i]?.dateFrom || '';
    const dt = panel.querySelector('.eval-date-to'); if (dt) dt.value = rda.evals[i]?.dateTo || '';
  });
  document.querySelector('.forum-topic').value = rda.forumTopic || '';
  loadManualTaskData(index);
  loadManualQuizData(index);
  document.querySelectorAll('.date-range-picker').forEach(p => { if (p._drpUpdate) p._drpUpdate(); });
  document.getElementById('stageAiResults').style.display = rda.aiAnalyzed ? 'block' : 'none';

  const hasPdfs = rda.pdfs.some(f => f);
  document.getElementById('btnAnalyzeAi').disabled = !hasPdfs;
  document.getElementById('aiHelpText').textContent = hasPdfs
    ? 'PDFs cargados. Listo para analizar.'
    : 'Sube al menos un PDF para poder analizar con IA.';
}

// ============================================================
// AI TABS (task/eval results)
// ============================================================

function initAiTabs() {
  document.querySelectorAll('.ai-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const tabType = tab.dataset.tab;
      const index = tab.dataset.index;
      document.querySelectorAll(`.ai-tab[data-tab="${tabType}"]`).forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const container = tabType === 'task' ? document.getElementById('taskPanels') : document.getElementById('evalPanels');
      container.querySelectorAll('.ai-tab-panel').forEach(p => p.classList.remove('active'));
      container.querySelector(`.ai-tab-panel[data-index="${index}"]`).classList.add('active');
    });
  });
}

// ============================================================
// COURSE TYPE
// ============================================================

function initCourseType() {
  // Ya no hay autodetección — el popup es genérico
}

function syncCourseTypeUI() {
  // Ya no cambia nada dinámicamente — tabs y criterios son fijos
}

function getRdaLabel() {
  return 'RDA';
}

// ============================================================
// SCHEDULE (dynamic blocks)
// ============================================================

let scheduleBlocks = [];

function initSchedule() {
  document.getElementById('btnAddSchedule').addEventListener('click', () => {
    createScheduleBlock();
    saveFormState();
  });
  createScheduleBlock(); // start with one
}

function createScheduleBlock(data = {}) {
  const id = Date.now() + Math.random();
  scheduleBlocks.push({
    id, dia: data.dia || 'Lunes', horaInicio: data.horaInicio || '08:00',
    horaFin: data.horaFin || '10:00', aula: data.aula || '', modalidad: data.modalidad || 'Presencial'
  });
  renderScheduleBlocks();
}

function removeScheduleBlock(id) {
  scheduleBlocks = scheduleBlocks.filter(b => b.id !== id);
  renderScheduleBlocks();
  saveFormState();
}

function _schTimeOpts(type, selected) {
  const max = type === 'h' ? 24 : 60;
  const step = type === 'h' ? 1 : 5;
  let html = '';
  for (let v = 0; v < max; v += step) {
    const label = String(v).padStart(2, '0');
    html += `<option value="${v}" ${v === selected ? 'selected' : ''}>${label}</option>`;
  }
  return html;
}

function _parseTime(t) { const p = (t || '00:00').split(':'); return { h: parseInt(p[0]) || 0, m: parseInt(p[1]) || 0 }; }

function renderScheduleBlocks() {
  const container = document.getElementById('scheduleList');
  container.innerHTML = scheduleBlocks.map(b => {
    const s = _parseTime(b.horaInicio), e = _parseTime(b.horaFin);
    return `<div class="schedule-block" data-id="${b.id}">
      ${scheduleBlocks.length > 1 ? '<button type="button" class="btn-remove-schedule" title="Quitar">&times;</button>' : ''}
      <div class="config-row">
        <div class="config-item"><label>Dia</label>
          <select class="sch-day">
            ${['Lunes','Martes','Miercoles','Jueves','Viernes','Sabado'].map(d => `<option ${b.dia===d?'selected':''}>${d}</option>`).join('')}
          </select>
        </div>
        <div class="config-item"><label>Horario</label>
          <div class="time-range-picker">
            <input type="hidden" class="sch-start-h" value="${s.h}"><input type="hidden" class="sch-start-m" value="${s.m}">
            <input type="hidden" class="sch-end-h" value="${e.h}"><input type="hidden" class="sch-end-m" value="${e.m}">
            <span class="trp-display">${String(s.h).padStart(2,'0')}:${String(s.m).padStart(2,'0')} - ${String(e.h).padStart(2,'0')}:${String(e.m).padStart(2,'0')}</span>
            <div class="trp-dropdown" style="display:none">
              <div class="trp-section"><span class="trp-label">Inicio</span><div class="trp-selects"><select class="trp-sel trp-sh">${_schTimeOpts('h',s.h)}</select><span class="time-sep">:</span><select class="trp-sel trp-sm">${_schTimeOpts('m',s.m)}</select></div></div>
              <div class="trp-section"><span class="trp-label">Fin</span><div class="trp-selects"><select class="trp-sel trp-eh">${_schTimeOpts('h',e.h)}</select><span class="time-sep">:</span><select class="trp-sel trp-em">${_schTimeOpts('m',e.m)}</select></div></div>
            </div>
          </div>
        </div>
        <div class="config-item"><label>Aula</label><input type="text" class="sch-room" value="${escapeAttr(b.aula)}" placeholder="301"></div>
        <div class="config-item"><label>Modalidad</label>
          <select class="sch-mode">
            ${['Presencial','Virtual','Hibrida'].map(m => `<option ${b.modalidad===m?'selected':''}>${m}</option>`).join('')}
          </select>
        </div>
      </div>
    </div>`;
  }).join('');

  // Remove buttons
  container.querySelectorAll('.btn-remove-schedule').forEach(btn => {
    btn.addEventListener('click', () => removeScheduleBlock(Number(btn.closest('.schedule-block').dataset.id)));
  });

  // Sync on change
  container.querySelectorAll('input, select').forEach(el => {
    el.addEventListener('change', () => { syncScheduleData(); saveFormState(); });
  });

  // Time range pickers in schedule
  container.querySelectorAll('.time-range-picker').forEach(initTimeRangePicker);
}

function initTimeRangePicker(picker) {
  const display = picker.querySelector('.trp-display');
  const dropdown = picker.querySelector('.trp-dropdown');
  const hSH = picker.querySelector('input.sch-start-h') || picker.querySelector('[id$="HourFrom"]');
  const hSM = picker.querySelector('input.sch-start-m') || picker.querySelector('[id$="MinFrom"]');
  const hEH = picker.querySelector('input.sch-end-h') || picker.querySelector('[id$="HourTo"]');
  const hEM = picker.querySelector('input.sch-end-m') || picker.querySelector('[id$="MinTo"]');

  if (!hSH || !display) return;

  function updateDisplay() {
    display.textContent = `${String(hSH.value).padStart(2,'0')}:${String(hSM.value).padStart(2,'0')} - ${String(hEH.value).padStart(2,'0')}:${String(hEM.value).padStart(2,'0')}`;
  }

  display.addEventListener('click', (e) => {
    e.stopPropagation();
    document.querySelectorAll('.trp-dropdown').forEach(d => { if (d !== dropdown) d.style.display = 'none'; });
    dropdown.style.display = dropdown.style.display === 'none' ? 'flex' : 'none';
  });

  picker.querySelectorAll('.trp-sel').forEach(sel => {
    sel.addEventListener('change', () => {
      if (sel.classList.contains('trp-sh')) hSH.value = sel.value;
      if (sel.classList.contains('trp-sm')) hSM.value = sel.value;
      if (sel.classList.contains('trp-eh')) hEH.value = sel.value;
      if (sel.classList.contains('trp-em')) hEM.value = sel.value;
      updateDisplay();
      // Validar horario docente (hora fin > hora inicio)
      const blockEl = picker.closest('.schedule-block');
      if (blockEl) validateScheduleTime(blockEl);
      // Validar quiz dates si es el picker del quiz
      if (picker.id === 'quizTimePicker') validateQuizDates();
      syncScheduleData();
      saveFormState();
    });
  });

  // Exponer función para sincronizar selects visibles desde hidden inputs
  picker._trpUpdate = () => {
    const selSH = picker.querySelector('.trp-sh');
    const selSM = picker.querySelector('.trp-sm');
    const selEH = picker.querySelector('.trp-eh');
    const selEM = picker.querySelector('.trp-em');
    if (selSH) selSH.value = hSH.value;
    if (selSM) selSM.value = hSM.value;
    if (selEH) selEH.value = hEH.value;
    if (selEM) selEM.value = hEM.value;
    updateDisplay();
  };
}

function syncScheduleData() {
  document.querySelectorAll('.schedule-block').forEach((el, i) => {
    if (!scheduleBlocks[i]) return;
    scheduleBlocks[i].dia = el.querySelector('.sch-day').value;
    const sh = String(el.querySelector('input.sch-start-h').value).padStart(2,'0');
    const sm = String(el.querySelector('input.sch-start-m').value).padStart(2,'0');
    scheduleBlocks[i].horaInicio = sh + ':' + sm;
    const eh = String(el.querySelector('input.sch-end-h').value).padStart(2,'0');
    const em = String(el.querySelector('input.sch-end-m').value).padStart(2,'0');
    scheduleBlocks[i].horaFin = eh + ':' + em;
    scheduleBlocks[i].aula = el.querySelector('.sch-room').value;
    scheduleBlocks[i].modalidad = el.querySelector('.sch-mode').value;
  });
}

function getScheduleData() {
  syncScheduleData();
  return scheduleBlocks.map(b => ({ dia: b.dia, horaInicio: b.horaInicio, horaFin: b.horaFin, aula: b.aula, modalidad: b.modalidad }));
}

// Validar que hora fin > hora inicio en horario docente
function validateScheduleTime(blockEl) {
  const picker = blockEl.querySelector('.time-range-picker');
  if (!picker) return;
  const hiddenSH = picker.querySelector('input.sch-start-h');
  const hiddenSM = picker.querySelector('input.sch-start-m');
  const hiddenEH = picker.querySelector('input.sch-end-h');
  const hiddenEM = picker.querySelector('input.sch-end-m');
  const selEH = picker.querySelector('.trp-eh');
  const selEM = picker.querySelector('.trp-em');

  const sh = parseInt(hiddenSH.value) || 0;
  const sm = parseInt(hiddenSM.value) || 0;
  const eh = parseInt(hiddenEH.value) || 0;
  const em = parseInt(hiddenEM.value) || 0;

  // Auto-corregir si hora fin <= hora inicio
  if (eh < sh || (eh === sh && em <= sm)) {
    const correctedH = Math.min(sh + 1, 23);
    hiddenEH.value = String(correctedH);
    hiddenEM.value = String(sm);
    if (selEH) selEH.value = String(correctedH);
    if (selEM) selEM.value = String(sm);
  }

  // Deshabilitar opciones invalidas en hora fin
  if (selEH) {
    [...selEH.options].forEach(o => { o.disabled = parseInt(o.value) < sh; });
  }
  const currentEH = parseInt(hiddenEH.value) || 0;
  if (selEM) {
    [...selEM.options].forEach(o => { o.disabled = currentEH === sh && parseInt(o.value) <= sm; });
  }

  // Actualizar display
  const display = picker.querySelector('.trp-display');
  if (display) {
    const sh = String(hiddenSH.value).padStart(2,'0');
    const sm = String(hiddenSM.value).padStart(2,'0');
    const eh = String(hiddenEH.value).padStart(2,'0');
    const em = String(hiddenEM.value).padStart(2,'0');
    // Quiz picker usa formato descriptivo, horario de clases usa formato corto
    if (picker.id === 'quizTimePicker') {
      display.textContent = `Abre ${sh}:${sm} · Cierra ${eh}:${em}`;
    } else {
      display.textContent = `${sh}:${sm} - ${eh}:${em}`;
    }
  }
}

// Validar fechas/horas de evaluacion (cierre >= apertura + duracion)
function validateQuizDates() {
  const fromDate = document.getElementById('manualQuizDateFrom').value;
  const toEl = document.getElementById('manualQuizDateTo');
  const hiddenHTo = document.getElementById('manualQuizHourTo');
  const hiddenMTo = document.getElementById('manualQuizMinTo');
  const picker = document.getElementById('quizTimePicker');
  const selEH = picker ? picker.querySelector('.trp-eh') : null;
  const selEM = picker ? picker.querySelector('.trp-em') : null;
  if (!fromDate) return;

  const hFrom = parseInt(document.getElementById('manualQuizHourFrom').value) || 0;
  const mFrom = parseInt(document.getElementById('manualQuizMinFrom').value) || 0;
  const quizMinutes = parseInt(document.getElementById('manualQuizTime').value) || 60;

  // Cierre minimo = apertura + duracion del quiz
  const openDT = new Date(fromDate + 'T' + String(hFrom).padStart(2,'0') + ':' + String(mFrom).padStart(2,'0') + ':00');
  const minCloseDT = new Date(openDT.getTime() + quizMinutes * 60000);

  // Si no hay fecha de cierre, auto-poner
  if (!toEl.value) {
    toEl.value = minCloseDT.toISOString().split('T')[0];
  }

  // Si el cierre actual es anterior al minimo, auto-corregir
  const toDate = toEl.value;
  const hTo = parseInt(hiddenHTo.value) || 0;
  const mTo = parseInt(hiddenMTo.value) || 0;
  const closeDT = new Date(toDate + 'T' + String(hTo).padStart(2,'0') + ':' + String(mTo).padStart(2,'0') + ':00');

  if (closeDT < minCloseDT) {
    toEl.value = minCloseDT.toISOString().split('T')[0];
    const correctedH = minCloseDT.getHours();
    const minVal = Math.ceil(minCloseDT.getMinutes() / 5) * 5;
    if (minVal >= 60) {
      hiddenHTo.value = String(correctedH + 1);
      hiddenMTo.value = '0';
    } else {
      hiddenHTo.value = String(correctedH);
      hiddenMTo.value = String(minVal);
    }
  }

  // Deshabilitar opciones invalidas en los selects de hora cierre
  const sameDay = fromDate === toEl.value;
  const minCloseSameDay = minCloseDT.toISOString().split('T')[0] === toEl.value;
  const minHour = minCloseSameDay ? minCloseDT.getHours() : 0;
  const minMin = minCloseSameDay ? Math.ceil(minCloseDT.getMinutes() / 5) * 5 : 0;

  if (selEH) {
    [...selEH.options].forEach(o => { o.disabled = sameDay && parseInt(o.value) < minHour; });
  }
  const currentHTo = parseInt(hiddenHTo.value) || 0;
  if (selEM) {
    [...selEM.options].forEach(o => { o.disabled = sameDay && currentHTo === minHour && parseInt(o.value) < minMin; });
  }

  // Actualizar display y guardar
  if (picker) {
    const display = picker.querySelector('.trp-display');
    if (display) {
      const sh = String(document.getElementById('manualQuizHourFrom').value).padStart(2,'0');
      const sm = String(document.getElementById('manualQuizMinFrom').value).padStart(2,'0');
      const eh = String(hiddenHTo.value).padStart(2,'0');
      const em = String(hiddenMTo.value).padStart(2,'0');
      display.textContent = `Abre ${sh}:${sm} · Cierra ${eh}:${em}`;
    }
  }
  saveManualQuizData();
}

// ============================================================
// DATE RANGE PICKER
// ============================================================

const MONTHS_ES = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
const DAYS_ES = ['Lu','Ma','Mi','Ju','Vi','Sa','Do'];

function initDateRangePickers() {
  document.querySelectorAll('.date-range-picker').forEach(picker => {
    const display = picker.querySelector('.drp-display');
    const fromInput = picker.querySelector('input[type="hidden"]:first-of-type') || picker.querySelector('[class$="date-from"]');
    const toInput = picker.querySelectorAll('input[type="hidden"]')[1] || picker.querySelector('[class$="date-to"]');
    if (!display || !fromInput || !toInput) return;

    let state = { from: fromInput.value || null, to: toInput.value || null, selecting: null, viewMonth: new Date().getMonth(), viewYear: new Date().getFullYear() };
    let calendar = null;

    updateDisplay();
    display.addEventListener('click', (e) => { e.stopPropagation(); if (calendar) { closeCalendar(); return; } openCalendar(); });

    function updateDisplay() {
      if (state.from && state.to) { display.textContent = fmtD(state.from) + '  →  ' + fmtD(state.to); display.classList.add('has-dates'); }
      else if (state.from) { display.textContent = fmtD(state.from) + '  →  ...'; display.classList.add('has-dates'); }
      else { display.textContent = 'Seleccionar fechas'; display.classList.remove('has-dates'); }
    }

    function fmtD(ds) { const d = new Date(ds + 'T12:00:00'); return d.getDate() + ' ' + MONTHS_ES[d.getMonth()] + ' ' + d.getFullYear(); }
    function toISO(y, m, d) { return `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`; }

    function openCalendar() {
      state.selecting = 'from';
      if (state.from) { const d = new Date(state.from + 'T12:00:00'); state.viewMonth = d.getMonth(); state.viewYear = d.getFullYear(); }
      calendar = document.createElement('div'); calendar.className = 'drp-calendar'; picker.appendChild(calendar);
      renderCal();
      setTimeout(() => document.addEventListener('click', outsideClick), 0);
    }
    function closeCalendar() { if (calendar) { calendar.remove(); calendar = null; } document.removeEventListener('click', outsideClick); }
    function outsideClick(e) { if (!picker.contains(e.target)) closeCalendar(); }

    function renderCal() {
      const y = state.viewYear, m = state.viewMonth;
      const firstDay = (new Date(y, m, 1).getDay() + 6) % 7;
      const daysInMonth = new Date(y, m + 1, 0).getDate();
      const todayISO = new Date().toISOString().split('T')[0];

      let html = `<div class="drp-header"><button type="button" class="drp-prev">&lt;</button><span class="drp-month-label">${MONTHS_ES[m]} ${y}</span><button type="button" class="drp-next">&gt;</button></div>`;
      html += `<div class="drp-weekdays">${DAYS_ES.map(d => `<span>${d}</span>`).join('')}</div><div class="drp-days">`;
      for (let i = 0; i < firstDay; i++) html += '<span class="drp-day empty"></span>';
      for (let d = 1; d <= daysInMonth; d++) {
        const iso = toISO(y, m, d);
        const isPast = iso < todayISO;
        let cls = 'drp-day';
        if (isPast) cls += ' past';
        if (iso === todayISO) cls += ' today';
        if (state.from && iso === state.from) cls += ' start';
        if (state.to && iso === state.to) cls += ' end';
        if (state.from && state.to && iso > state.from && iso < state.to) cls += ' in-range';
        html += `<span class="${cls}" data-date="${iso}">${d}</span>`;
      }
      html += '</div>';
      html += `<div class="drp-hint">${state.selecting === 'from' ? 'Selecciona fecha inicio' : 'Selecciona fecha fin'}</div>`;
      calendar.innerHTML = html;

      calendar.querySelector('.drp-prev').addEventListener('click', (e) => { e.stopPropagation(); state.viewMonth--; if (state.viewMonth < 0) { state.viewMonth = 11; state.viewYear--; } renderCal(); });
      calendar.querySelector('.drp-next').addEventListener('click', (e) => { e.stopPropagation(); state.viewMonth++; if (state.viewMonth > 11) { state.viewMonth = 0; state.viewYear++; } renderCal(); });
      calendar.querySelectorAll('.drp-day:not(.empty):not(.past)').forEach(el => {
        el.addEventListener('click', (e) => {
          e.stopPropagation();
          const date = el.dataset.date;
          if (state.selecting === 'from') { state.from = date; state.to = null; state.selecting = 'to'; fromInput.value = date; toInput.value = ''; }
          else { if (date < state.from) { state.to = state.from; state.from = date; } else { state.to = date; } fromInput.value = state.from; toInput.value = state.to; state.selecting = 'from'; closeCalendar(); saveFormState(); }
          updateDisplay();
          if (calendar) renderCal();
        });
      });
    }

    picker._drpUpdate = () => { state.from = fromInput.value || null; state.to = toInput.value || null; updateDisplay(); };
  });
}

// ============================================================
// QUIZ TIME SELECTS
// ============================================================

function initQuizTimeSelects() {
  const picker = document.getElementById('quizTimePicker');
  if (!picker) return;
  // Populate selects
  const selSH = picker.querySelector('.trp-sh');
  const selSM = picker.querySelector('.trp-sm');
  const selEH = picker.querySelector('.trp-eh');
  const selEM = picker.querySelector('.trp-em');
  for (let h = 0; h < 24; h++) { const o = new Option(String(h).padStart(2,'0'), h); selSH.add(o.cloneNode(true)); selEH.add(o); }
  for (let m = 0; m < 60; m += 5) { const o = new Option(String(m).padStart(2,'0'), m); selSM.add(o.cloneNode(true)); selEM.add(o); }
  selSH.value = 8; selSM.value = 0; selEH.value = 23; selEM.value = 55;
  initTimeRangePicker(picker);
}

function initQuizTimeLimitSelect() {
  const sel = document.getElementById('manualQuizTime');
  if (!sel) return;
  [
    [10,'10m'],[15,'15m'],[20,'20m'],[30,'30m'],[45,'45m'],
    [60,'1H'],[90,'1H30'],[120,'2H'],
    [150,'2H30'],[180,'3H'],[240,'4H']
  ].forEach(([v,l]) => { sel.add(new Option(l, v)); });
  sel.value = 120;
}

// ============================================================
// RUBRIC
// ============================================================

function initRubric() {
  document.getElementById('btnAddCriterion').addEventListener('click', () => {
    const mt = rdaData[activeRda].manualTask;
    mt.rubrica.push({ nombre: '', niveles: [
      { nombre: 'Excelente', puntos: 5, descripcion: '' },
      { nombre: 'Bueno', puntos: 3, descripcion: '' },
      { nombre: 'Regular', puntos: 1, descripcion: '' },
      { nombre: 'Insuficiente', puntos: 0, descripcion: '' }
    ]});
    renderRubricCriteria();
    saveFormState();
  });
  renderRubricCriteria();
}

function recalcRubricPoints(mt) {
  const n = mt.rubrica.length || 1;
  const max = Math.round((10 / n) * 100) / 100;
  const ratios = [1, 2/3, 1/3, 0];
  mt.rubrica.forEach(c => { c.niveles.forEach((nv, i) => { nv.puntos = Math.round(max * (ratios[i] || 0) * 100) / 100; }); });
}

function renderRubricCriteria() {
  const mt = rdaData[activeRda].manualTask;
  recalcRubricPoints(mt);
  const container = document.getElementById('rubricCriteria');
  container.innerHTML = mt.rubrica.map((c, ci) => `
    <div class="rubric-block" data-index="${ci}">
      <div style="display:flex;gap:4px;align-items:center">
        <input type="text" class="rubric-name" value="${escapeAttr(c.nombre)}" placeholder="Criterio (ej: Contenido)" style="flex:1">
        ${mt.rubrica.length > 1 ? '<button type="button" class="btn-remove-rubric" title="Quitar">&times;</button>' : ''}
      </div>
      <div class="rubric-levels-grid">
        ${c.niveles.map((nv, ni) => `<div class="rubric-level"><span class="rubric-level-label">${nv.nombre} (${nv.puntos}pts)</span><textarea class="rubric-level-desc" data-nivel="${ni}" rows="2" placeholder="${nv.nombre}">${escapeAttr(nv.descripcion)}</textarea></div>`).join('')}
      </div>
    </div>
  `).join('');

  container.querySelectorAll('.btn-remove-rubric').forEach(btn => {
    btn.addEventListener('click', () => { mt.rubrica.splice(parseInt(btn.closest('.rubric-block').dataset.index), 1); renderRubricCriteria(); saveFormState(); });
  });
  container.querySelectorAll('input, textarea').forEach(el => {
    el.addEventListener('input', () => { syncRubricData(); saveFormState(); });
  });
}

function renderRubricFromJson(rubricaJson) {
  const mt = rdaData[activeRda].manualTask;
  if (!rubricaJson?.criterios) return;
  const nivelNames = ['Excelente', 'Bueno', 'Regular', 'Insuficiente'];
  mt.rubrica = rubricaJson.criterios.map(c => ({
    nombre: c.nombre || '',
    niveles: (c.niveles || []).map((nv, i) => ({
      nombre: nv.nombre || nivelNames[i] || `Nivel ${i + 1}`,
      puntos: nv.puntos ?? 0,
      descripcion: nv.descripcion || ''
    }))
  }));
  renderRubricCriteria();
}

function syncRubricData() {
  const mt = rdaData[activeRda].manualTask;
  document.querySelectorAll('#rubricCriteria .rubric-block').forEach((block, ci) => {
    if (!mt.rubrica[ci]) return;
    mt.rubrica[ci].nombre = block.querySelector('.rubric-name').value;
    block.querySelectorAll('.rubric-level-desc').forEach(input => {
      mt.rubrica[ci].niveles[parseInt(input.dataset.nivel)].descripcion = input.value;
    });
  });
}

function saveManualTaskData() {
  const mt = rdaData[activeRda].manualTask;
  mt.nombre = document.getElementById('manualTaskName').value;
  mt.descripcion = document.getElementById('manualTaskDesc').value;
  mt.dateFrom = document.getElementById('manualTaskDateFrom').value;
  mt.dateTo = document.getElementById('manualTaskDateTo').value;
  mt.criterio = document.getElementById('manualTaskCriterio').value;
  const pdfInput = document.getElementById('manualTaskPdf');
  if (pdfInput.files[0]) mt.pdf = pdfInput.files[0];
  syncRubricData();
}

function loadManualTaskData(index) {
  const mt = rdaData[index].manualTask;
  document.getElementById('manualTaskName').value = mt.nombre || '';
  document.getElementById('manualTaskDesc').value = mt.descripcion || '';
  document.getElementById('manualTaskDateFrom').value = mt.dateFrom || gaulaToday();
  document.getElementById('manualTaskDateTo').value = mt.dateTo || gaulaNextWeek();
  document.getElementById('manualTaskCriterio').value = mt.criterio || '1';
  const mtPdfName = document.getElementById('manualTaskPdfName');
  const hasF = mt.pdf || mt.pdfName;
  mtPdfName.value = hasF ? (mt.pdf ? mt.pdf.name.replace(/\.[^.]+$/, '') : mt.pdfName) : 'Sin archivo';
  mtPdfName.classList.toggle('has-file', !!hasF);
  if (hasF) mtPdfName.removeAttribute('readonly'); else mtPdfName.setAttribute('readonly', '');
  renderRubricCriteria();
}

function saveManualQuizData() {
  const mq = rdaData[activeRda].manualQuiz;
  mq.nombre = document.getElementById('manualQuizName')?.value || '';
  mq.password = document.getElementById('manualQuizPassword')?.value || '';
  mq.dateFrom = document.getElementById('manualQuizDateFrom')?.value || '';
  mq.dateTo = document.getElementById('manualQuizDateTo')?.value || '';
  mq.time = parseInt(document.getElementById('manualQuizTime')?.value) || 60;
  mq.aikenText = document.getElementById('manualQuizAiken')?.value || '';
  mq.criterio = document.getElementById('manualQuizCriterio')?.value || '1';
  mq.hourFrom = document.getElementById('manualQuizHourFrom')?.value || '8';
  mq.minFrom = document.getElementById('manualQuizMinFrom')?.value || '0';
  mq.hourTo = document.getElementById('manualQuizHourTo')?.value || '23';
  mq.minTo = document.getElementById('manualQuizMinTo')?.value || '55';
}

function loadManualQuizData(index) {
  const mq = rdaData[index].manualQuiz;
  const el = (id) => document.getElementById(id);
  if (el('manualQuizName')) el('manualQuizName').value = mq.nombre || '';
  if (el('manualQuizPassword')) el('manualQuizPassword').value = mq.password || '';
  if (el('manualQuizDateFrom')) el('manualQuizDateFrom').value = mq.dateFrom || gaulaToday();
  if (el('manualQuizDateTo')) el('manualQuizDateTo').value = mq.dateTo || gaulaToday();
  if (el('manualQuizTime')) el('manualQuizTime').value = mq.time || 60;
  if (el('manualQuizHourFrom')) el('manualQuizHourFrom').value = mq.hourFrom || '8';
  if (el('manualQuizMinFrom')) el('manualQuizMinFrom').value = mq.minFrom || '0';
  if (el('manualQuizHourTo')) el('manualQuizHourTo').value = mq.hourTo || '23';
  if (el('manualQuizMinTo')) el('manualQuizMinTo').value = mq.minTo || '55';
  if (el('manualQuizCriterio')) el('manualQuizCriterio').value = mq.criterio || '1';
  if (el('manualQuizAiken')) el('manualQuizAiken').value = mq.aikenText || '';

  // Sincronizar selects visibles del time picker con los hidden inputs restaurados
  const quizTimePicker = document.getElementById('quizTimePicker');
  if (quizTimePicker && quizTimePicker._trpUpdate) quizTimePicker._trpUpdate();

  // Actualizar previews al cargar datos
  updateAikenPreview();
  const xmlInfo = el('xmlFileInfo');
  if (xmlInfo) {
    if (mq.xmlText && mq.xmlFileName) {
      const v = validateMoodleXml(mq.xmlText);
      xmlInfo.style.display = 'block';
      xmlInfo.textContent = v.valid
        ? `${mq.xmlFileName} — ${v.count} pregunta(s) detectada(s)`
        : `Error: ${v.error}`;
      xmlInfo.style.background = v.valid ? '#f0fdf4' : '#fef2f2';
      xmlInfo.style.borderColor = v.valid ? '#bbf7d0' : '#fecaca';
      xmlInfo.style.color = v.valid ? '#166534' : '#991b1b';
    } else {
      xmlInfo.style.display = 'none';
    }
  }
}

// ============================================================
// AIKEN FILE LOADER
// ============================================================

// ── Parser Aiken ──
function parseAiken(text) {
  const questions = [];
  const lines = text.split('\n').map(l => l.trimEnd());
  let current = null;

  for (const line of lines) {
    const answerMatch = line.match(/^ANSWER:\s*([A-Z])\s*$/i);
    const optionMatch = line.match(/^([A-Z])[.)]\s+(.+)$/);

    if (answerMatch) {
      if (current) {
        current.answer = answerMatch[1].toUpperCase();
        questions.push(current);
        current = null;
      }
    } else if (optionMatch && current) {
      current.options.push({ letter: optionMatch[1].toUpperCase(), text: optionMatch[2].trim() });
    } else if (line.trim() !== '') {
      if (current && current.options.length === 0) {
        current.text += ' ' + line.trim();
      } else {
        current = { text: line.trim(), options: [], answer: '' };
      }
    }
  }
  return questions;
}

function updateAikenPreview() {
  const text = document.getElementById('manualQuizAiken').value;
  const preview = document.getElementById('aikenPreview');
  const status = document.getElementById('aikenStatus');
  if (!text.trim()) {
    preview.style.display = 'none';
    status.textContent = '';
    return;
  }
  const questions = parseAiken(text);
  if (questions.length > 0) {
    const valid = questions.filter(q => q.options.length >= 2 && q.answer);
    preview.style.display = 'block';
    preview.textContent = `${valid.length} pregunta(s) detectada(s)`;
    preview.style.borderColor = valid.length > 0 ? '#bbf7d0' : '#fecaca';
    preview.style.background = valid.length > 0 ? '#f0fdf4' : '#fef2f2';
    preview.style.color = valid.length > 0 ? '#166534' : '#991b1b';
    status.textContent = '';
  } else {
    preview.style.display = 'block';
    preview.textContent = 'No se detectaron preguntas. Verifica el formato Aiken.';
    preview.style.borderColor = '#fecaca';
    preview.style.background = '#fef2f2';
    preview.style.color = '#991b1b';
  }
}

// ── Validador XML Moodle ──
function validateMoodleXml(xmlText) {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlText, 'text/xml');
    const parseError = doc.querySelector('parsererror');
    if (parseError) return { valid: false, error: 'XML mal formado: ' + parseError.textContent.substring(0, 100) };
    const quiz = doc.querySelector('quiz');
    if (!quiz) return { valid: false, error: 'No se encontró la etiqueta <quiz>. No es un archivo Moodle XML válido.' };
    const questions = [...quiz.querySelectorAll('question')].filter(q => q.getAttribute('type') !== 'category');
    if (questions.length === 0) return { valid: false, error: 'No se encontraron preguntas dentro de <quiz>.' };
    let invalidCount = 0;
    for (const q of questions) {
      const name = q.querySelector('name > text');
      const qtext = q.querySelector('questiontext > text');
      if (!name || !qtext) invalidCount++;
    }
    if (invalidCount > 0) {
      return { valid: false, error: `${invalidCount} pregunta(s) sin nombre o texto. Revise el archivo.` };
    }
    return { valid: true, count: questions.length };
  } catch (err) {
    return { valid: false, error: 'Error al procesar XML: ' + err.message };
  }
}

function initAikenLoader() {
  const btnAiken = document.getElementById('btnLoadAikenFile');
  const aikenInput = document.getElementById('aikenFileInput');
  const btnXml = document.getElementById('btnLoadXmlFile');
  const xmlInput = document.getElementById('xmlFileInput');
  const aikenTextarea = document.getElementById('manualQuizAiken');
  const xmlFileInfo = document.getElementById('xmlFileInfo');

  // Contar preguntas en tiempo real al escribir en el textarea
  aikenTextarea.addEventListener('input', () => {
    rdaData[activeRda].manualQuiz.aikenText = aikenTextarea.value;
    saveFormState();
    updateAikenPreview();
  });

  // Cargar archivo .txt (Aiken)
  btnAiken.addEventListener('click', () => aikenInput.click());
  aikenInput.addEventListener('change', () => {
    const file = aikenInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      aikenTextarea.value = reader.result;
      rdaData[activeRda].manualQuiz.aikenText = reader.result;
      saveFormState();
      updateAikenPreview();
    };
    reader.readAsText(file);
    aikenInput.value = '';
  });

  // Cargar archivo .xml (Moodle)
  btnXml.addEventListener('click', () => xmlInput.click());
  xmlInput.addEventListener('change', () => {
    const file = xmlInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const xmlText = reader.result;
      const validation = validateMoodleXml(xmlText);
      if (validation.valid) {
        rdaData[activeRda].manualQuiz.xmlText = xmlText;
        rdaData[activeRda].manualQuiz.xmlFileName = file.name;
        xmlFileInfo.style.display = 'block';
        xmlFileInfo.textContent = `${file.name} — ${validation.count} pregunta(s) detectada(s)`;
        xmlFileInfo.style.background = '#f0fdf4';
        xmlFileInfo.style.borderColor = '#bbf7d0';
        xmlFileInfo.style.color = '#166534';
        saveFormState();
      } else {
        xmlFileInfo.style.display = 'block';
        xmlFileInfo.textContent = `Error: ${validation.error}`;
        xmlFileInfo.style.background = '#fef2f2';
        xmlFileInfo.style.borderColor = '#fecaca';
        xmlFileInfo.style.color = '#991b1b';
      }
    };
    reader.readAsText(file);
    xmlInput.value = '';
  });

  // --- Generar Aiken con IA desde PDF ---
  let _aikenPdfFile = null;
  const btnGenAiken = document.getElementById('btnGenerateAikenAi');
  const aikenPdfZone = document.getElementById('aikenPdfZone');
  const aikenPdfInput = document.getElementById('aikenPdfInput');

  btnGenAiken.addEventListener('click', () => {
    aikenPdfZone.style.display = aikenPdfZone.style.display === 'none' ? 'block' : 'none';
  });

  aikenPdfInput.addEventListener('change', async () => {
    const file = aikenPdfInput.files[0];
    if (!file) return;
    _aikenPdfFile = file;
    document.getElementById('aikenPdfName').value = file.name;
    await _generateAikenFromPdf();
  });

  async function _generateAikenFromPdf() {
    if (!_aikenPdfFile) return;

    const statusEl = document.getElementById('aikenAiStatus');
    const numPreguntas = document.getElementById('aikenQuestionCount').value;
    const dificultad = document.getElementById('aikenDifficulty').value;

    btnGenAiken.disabled = true;
    btnGenAiken.textContent = 'Generando...';
    statusEl.style.display = 'block';
    statusEl.style.background = '#f5f3ff';
    statusEl.style.borderColor = '#c4b5fd';
    statusEl.style.color = '#7c3aed';
    statusEl.textContent = `Extrayendo texto del PDF...`;

    try {
      const pdfText = await extractTextFromPDF(_aikenPdfFile);
      if (!pdfText.trim()) throw new Error('El PDF está vacío o no se pudo leer.');

      statusEl.textContent = 'Verificando créditos...';
      const creditResult = await executeAction('generate_aiken', { numPreguntas });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const total = parseInt(numPreguntas);
      const BATCH_SIZE = 25;
      const batches = Math.ceil(total / BATCH_SIZE);
      const pdfTruncated = pdfText.substring(0, 100000);
      const aikenParts = [];

      for (let i = 0; i < batches; i++) {
        const batchSize = Math.min(BATCH_SIZE, total - i * BATCH_SIZE);
        const generated = aikenParts.length ? aikenParts.join('\n\n').split('ANSWER:').length - 1 : 0;
        statusEl.textContent = `Generando preguntas (${dificultad})... lote ${i + 1}/${batches} (${generated}/${total} listas)`;

        const result = await callGenerateContent('generate_aiken', {
          pdfText: pdfTruncated,
          numPreguntas: batchSize,
          dificultad,
        });
        if (!result.ok) throw new Error(result.error);
        if (result.aikenText) aikenParts.push(result.aikenText);

        // Guardar progreso parcial
        aikenTextarea.value = aikenParts.join('\n\n');
        rdaData[activeRda].manualQuiz.aikenText = aikenTextarea.value;
        saveFormState();
        updateAikenPreview();
      }

      statusEl.textContent = `${aikenParts.join('\n\n').split('ANSWER:').length - 1} preguntas generadas.`;
      statusEl.style.background = '#f0fdf4';
      statusEl.style.borderColor = '#bbf7d0';
      statusEl.style.color = '#166534';
    } catch (err) {
      statusEl.textContent = `Error: ${err.message}`;
      statusEl.style.background = '#fef2f2';
      statusEl.style.borderColor = '#fecaca';
      statusEl.style.color = '#991b1b';
    } finally {
      btnGenAiken.disabled = false;
      btnGenAiken.textContent = 'Generar con IA';
    }
  }
}

// ============================================================
// ACTION BUTTONS — each sends action to backend
// ============================================================

function initActionButtons() {
  // --- STEP 1: Import Template ---
  document.getElementById('btnImportTemplate').addEventListener('click', async () => {
    const file = document.getElementById('templateFile').files[0];
    if (!file) return;
    const btn = document.getElementById('btnImportTemplate');
    btn.disabled = true;
    showStatus('Importando plantilla...', 'loading', btn);

    try {
      // Verificar que estamos en una página de curso Moodle
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabUrl = tab?.url || '';
      const courseMatch = tabUrl.match(/(.+?)\/course\/view\.php\?id=(\d+)/);
      if (!courseMatch) {
        showStatus('Debes estar en la página del curso en Moodle.', 'error', btn);
        btn.disabled = false;
        return;
      }
      const moodleBase = courseMatch[1];
      const courseId = courseMatch[2];

      // Serializar archivo
      const serialized = await serializeFile(file);

      // Llamar al backend para verificar créditos y obtener el script
      const result = await executeAction('import_template', {
        courseId, moodleBase, fileName: file.name
      });

      if (!result.ok) {
        showStatus(result.error || 'Error al importar', 'error', btn);
        btn.disabled = false;
        return;
      }

      // Guardar estado inicial directamente desde el popup (como v1)
      // Esto evita la race condition: el estado queda guardado ANTES de navegar
      await chrome.storage.local.set({
        gaula_content_state: {
          action: 'import_template',
          step: 'find_restore_link',
          moodleBase,
          courseId,
          fileName: file.name,
          fileSerialized: serialized
        }
      });

      // Navegar al curso para que el executor retome con el script cacheado
      showStatus('Navegando a Restaurar. El archivo se subirá automáticamente.', 'success', btn);
      btn.disabled = false;
      chrome.tabs.update(tab.id, { url: `${moodleBase}/course/view.php?id=${courseId}` });
    } catch (e) {
      showStatus(e.message || 'Error al importar', 'error', btn);
      btn.disabled = false;
    }
  });

  // --- STEP 2: Generate with AI ---
  document.getElementById('btnGenerateAI').addEventListener('click', async () => {
    const file = document.getElementById('syllabusFile').files[0];
    if (!file) return;
    const btn = document.getElementById('btnGenerateAI');
    btn.disabled = true;
    activeProgressStep = 'Step2';
    const fileExt = (file.name.split('.').pop() || '').toLowerCase();
    const fileLabel = fileExt === 'pdf' ? 'PDF' : 'Excel';
    showProgress(0, 4, `Extrayendo texto del ${fileLabel}...`, 'Step2');

    try {
      // 1. Extraer texto del archivo (PDF o Excel) — la IA procesa ambos por igual
      const pdfText = await extractTextFromSyllabus(file);
      if (!pdfText?.trim()) throw new Error(`El ${fileLabel} está vacío o no se pudo leer.`);

      // 2. Consumir créditos
      showProgress(1, 4, 'Verificando créditos...', 'Step2');
      const creditResult = await executeAction('generate_ai', { fileName: file.name });
      if (!creditResult.ok) throw new Error(creditResult.error);

      // 3. Llamar a generate-syllabus-ai (Edge Function nueva, usa Claude)
      // No usa callGenerateContent porque la acción 'generate_ai' nunca se
      // implementó en generate-content. Fetch directo con la sesión actual.
      showProgress(2, 4, 'IA generando contenido con Claude (puede tardar ~30s)...', 'Step2');
      const _aiSession = await sendMessage({ type: 'GET_SESSION' });
      if (!_aiSession?.ok) throw new Error('Sesión expirada — vuelve a iniciar sesión');
      const _aiResp = await fetch(`${CONFIG.SUPABASE_URL}/functions/v1/generate-syllabus-ai`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${_aiSession.token}`,
          'apikey': CONFIG.SUPABASE_ANON_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pdfText,
          teacher: { name: document.getElementById('teacherName').value, title: document.getElementById('teacherTitle').value, email: document.getElementById('teacherEmail').value, desc: document.getElementById('teacherDesc').value },
          subject: { name: document.getElementById('subjectName').value, career: document.getElementById('careerName').value },
          schedule: getScheduleData(),
          notebookLmLink: document.getElementById('notebookLmLink').value,
        }),
      });
      const result = await _aiResp.json().catch(() => ({}));
      if (!_aiResp.ok || !result.ok) throw new Error(result.error || `HTTP ${_aiResp.status}`);

      // 4. Mostrar panel de edición — el inyect ocurre cuando el usuario aprueba
      showStatus('Contenido generado. Revisa, edita si quieres y aprueba abajo.', 'info', btn);
      showStep2EditPanel(result, btn);
      return;
    } catch (e) {
      showStatus(e.message || 'Error al generar', 'error', btn);
      hideProgress('Step2');
    } finally {
      btn.disabled = false;
      activeProgressStep = null;
    }
  });

  // --- STEP 2: Generate without AI (parser) ---
  document.getElementById('btnGenerateNoAI').addEventListener('click', async () => {
    const file = document.getElementById('syllabusFile').files[0];
    if (!file) return;
    const btn = document.getElementById('btnGenerateNoAI');
    // El parser sin IA está afinado para PDF — Excel rompería sus regex.
    // Para Excel, el docente debe usar "Generar con IA".
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (ext !== 'pdf') {
      showStatus('El parser sin IA solo soporta PDF. Para Excel, usa "Generar con IA".', 'error');
      return;
    }
    btn.disabled = true;
    activeProgressStep = 'Step2';
    showProgress(0, 4, 'Extrayendo texto del PDF...', 'Step2');

    try {
      // 1. Extraer texto del PDF (client-side)
      const pdfText = await extractTextFromPDF(file);
      if (!pdfText?.trim()) throw new Error('El PDF está vacío o no se pudo leer.');

      // 2. Consumir créditos
      showProgress(1, 4, 'Verificando créditos...', 'Step2');
      const creditResult = await executeAction('generate_no_ai', { fileName: file.name });
      if (!creditResult.ok) throw new Error(creditResult.error);

      // 3. Enviar texto al backend para parsear y generar HTMLs
      showProgress(2, 4, 'Parseando sílabo y generando contenido...', 'Step2');
      const result = await callGenerateContent('generate_no_ai', {
        pdfText,
        teacher: { name: document.getElementById('teacherName').value, title: document.getElementById('teacherTitle').value, email: document.getElementById('teacherEmail').value, desc: document.getElementById('teacherDesc').value },
        subject: { name: document.getElementById('subjectName').value, career: document.getElementById('careerName').value },
        schedule: getScheduleData(),
        notebookLmLink: document.getElementById('notebookLmLink').value,
      });
      if (!result.ok) throw new Error(result.error);

      // Auto-rellenar campos del formulario si el parser encontró datos
      if (result.parsedData) {
        const pd = result.parsedData;
        const fill = (id, val) => { const el = document.getElementById(id); if (el && !el.value && val) el.value = val; };
        fill('teacherName', pd.docente?.nombre);
        fill('teacherTitle', pd.docente?.titulo);
        fill('teacherEmail', pd.docente?.email);
        fill('teacherDesc', pd.docente?.resena);
        fill('subjectName', pd.asignatura);
        fill('careerName', pd.carrera);
      }

      // 4. Mostrar panel de edición — el inyect ocurre cuando el usuario aprueba
      const fmt = result.parsedData?.formato === 'A' ? 'Nuevo (DATOS INFORMATIVOS)' : 'Clásico (DATOS ACADÉMICOS)';
      showStatus(`Formato detectado: ${fmt}. Revisa, edita si quieres y aprueba abajo.`, 'info', btn);
      showStep2EditPanel(result, btn);
      return;
    } catch (e) {
      showStatus(e.message || 'Error al generar', 'error', btn);
      hideProgress('Step2');
    } finally {
      btn.disabled = false;
      activeProgressStep = null;
    }
  });

  // --- Helper: obtener tab activa y verificar que estamos en Moodle ---
  async function requireMoodleTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes('/course/view.php')) {
      throw new Error('Debes estar en la página del curso en Moodle.');
    }
    return tab;
  }

  // --- STEP 3: Upload Videos (misma lógica v1: pestañas + colapsable + mover) ---
  document.getElementById('btnUploadVideos').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const validVideos = rda.videos.filter(v => v.trim());
    const btn = document.getElementById('btnUploadVideos');
    if (validVideos.length === 0) { showStatus('Agrega al menos un link de YouTube.', 'error', btn); return; }
    const badVideoIdx = rda.videos.findIndex(v => v.trim() && !isYoutubeUrl(v));
    if (badVideoIdx !== -1) {
      const inputs = document.querySelectorAll('.video-url');
      if (inputs[badVideoIdx]) { inputs[badVideoIdx].value = ''; rda.videos[badVideoIdx] = ''; }
      saveFormState();
      showStatus('Se eliminó un link que no es de YouTube.', 'error', btn);
      return;
    }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('upload_resources', { type: 'videos' });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const label = getRdaLabel();
      const sectionIdx = activeRda + 1;

      // Generar HTML con pestañas CSS-only (como v1)
      const tabbedHtml = generateTabbedHTML(
        validVideos.map((url, i) => ({
          label: `Video ${i + 1}`,
          content: generateYoutubeIframeHTML(url, `Video ${i + 1} - ${label} ${sectionIdx}`)
        })),
        `videos_rda${sectionIdx}`
      );

      const videoTarget = 'RECURSOS'; // Auto-detectado por el content script si no existe
      showStatus('Creando videos en Moodle...', 'loading', btn);
      await sendToContentScript(tab.id, {
        action: 'edit_section_batch',
        queue: [{
          sectionType: 'video',
          htmlContent: wrapCollapsible('🎬 Videos', tabbedHtml),
          pageName: `Videos - ${label} ${sectionIdx}`,
          sectionIndex: sectionIdx,
          targetSection: videoTarget
        }],
        courseUrl: tab.url
      });
      showStatus('Videos enviados a Moodle en pestañas.', 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Upload Geneallys (misma lógica v1: pestañas + colapsable + mover) ---
  document.getElementById('btnUploadGeneallys').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const valid = rda.geneallys.filter(v => v.trim());
    const btn = document.getElementById('btnUploadGeneallys');
    if (valid.length === 0) { showStatus('Agrega al menos un link de Genially.', 'error', btn); return; }
    const badGeniallyIdx = rda.geneallys.findIndex(v => v.trim() && !isGeniallyUrl(v));
    if (badGeniallyIdx !== -1) {
      const inputs = document.querySelectorAll('.geneally-url');
      if (inputs[badGeniallyIdx]) { inputs[badGeniallyIdx].value = ''; rda.geneallys[badGeniallyIdx] = ''; }
      saveFormState();
      showStatus('Se eliminó un link que no es de Genially.', 'error', btn);
      return;
    }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('upload_resources', { type: 'geneallys' });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const label = getRdaLabel();
      const sectionIdx = activeRda + 1;

      const tabbedHtml = generateTabbedHTML(
        valid.map((url, i) => ({
          label: `Geneally ${i + 1}`,
          content: generateGeniallyIframeHTML(url, `Geneally ${i + 1} - ${label} ${sectionIdx}`)
        })),
        `geneallys_rda${sectionIdx}`
      );

      const geneallyTarget = 'RECURSOS'; // Auto-detectado por el content script si no existe
      showStatus('Creando geneallys en Moodle...', 'loading', btn);
      await sendToContentScript(tab.id, {
        action: 'edit_section_batch',
        queue: [{
          sectionType: 'geneally',
          htmlContent: wrapCollapsible('📊 Geneallys', tabbedHtml),
          pageName: `Geneallys - ${label} ${sectionIdx}`,
          sectionIndex: sectionIdx,
          targetSection: geneallyTarget
        }],
        courseUrl: tab.url
      });
      showStatus('Geneallys enviados a Moodle en pestañas.', 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Upload PPTs (lógica v1) ---
  document.getElementById('btnUploadPpts').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const validPpts = rda.ppts.filter(f => f);
    const btn = document.getElementById('btnUploadPpts');
    if (validPpts.length === 0) { showStatus('Agrega al menos un PowerPoint.', 'error', btn); return; }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('upload_resources', { type: 'ppts' });
      if (!creditResult.ok) throw new Error(creditResult.error);

      showStatus('Subiendo presentaciones...', 'loading', btn);
      const serializedFiles = await Promise.all(validPpts.map(f => serializeFile(f)));
      const editedNames = getPptEditedNames();
      const names = editedNames.map((n, i) => `Diapositiva - ${n}`);
      const sectionIdx = activeRda + 1;

      // Limpiar archivos de memoria ANTES de enviar (el popup puede cerrarse al navegar)
      rda.ppts = [null, null, null];
      rda._pptNames = [];
      clearFileSlotUI('.ppt-input');
      await saveFormState();

      await sendToContentScript(tab.id, {
        action: 'upload_resource',
        resourceType: 'ppt',
        files: serializedFiles,
        names,
        sectionIndex: sectionIdx
      });
      showStatus(`${validPpts.length} presentaciones subidas.`, 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Upload PDFs (lógica v1: extraer texto + subir) ---
  document.getElementById('btnUploadPdfs').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const validPdfs = rda.pdfs.filter(f => f);
    const btn = document.getElementById('btnUploadPdfs');
    if (validPdfs.length === 0) { showStatus('Agrega al menos un PDF.', 'error', btn); return; }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('upload_resources', { type: 'pdfs' });
      if (!creditResult.ok) throw new Error(creditResult.error);

      // Extraer texto ANTES de subir (para IA después)
      showStatus('Extrayendo texto de PDFs...', 'loading', btn);
      let allPdfText = '';
      for (const pdf of validPdfs) {
        try {
          const text = await extractTextFromPDF(pdf);
          allPdfText += text + '\n\n';
        } catch (_) {}
      }
      rda.pdfText = allPdfText;

      showStatus('Subiendo PDFs a Moodle...', 'loading', btn);
      const serializedPdfs = await Promise.all(validPdfs.map(f => serializeFile(f)));
      const names = getPdfEditedNames().map(n => 'PDF - ' + n);
      const sectionIdx = activeRda + 1;

      // Limpiar archivos de memoria ANTES de enviar (el popup puede cerrarse al navegar)
      rda.pdfsUploaded = true;
      rda.pdfs = [null, null, null];
      rda._pdfNames = [];
      clearFileSlotUI('.pdf-input');
      document.getElementById('btnAnalyzeAi').disabled = false;
      document.getElementById('aiHelpText').textContent = `${validPdfs.length} PDFs subidos. Listo para analizar.`;
      await saveFormState();

      await sendToContentScript(tab.id, {
        action: 'upload_resource',
        resourceType: 'pdf',
        files: serializedPdfs,
        names,
        sectionIndex: sectionIdx
      });
      showStatus(`${validPdfs.length} PDFs subidos a Moodle.`, 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- Delete buttons (lógica v1: confirmación + bulk_delete) ---
  ['btnDeleteVideos', 'btnDeleteGeneallys', 'btnDeletePpts', 'btnDeletePdfs'].forEach(id => {
    const btn = document.getElementById(id);
    if (!btn) return;
    const labelMap = { btnDeleteVideos: ['video','Videos'], btnDeleteGeneallys: ['geneally','Geneallys'], btnDeletePpts: ['ppt','Diapositivas'], btnDeletePdfs: ['pdf','PDFs'] };
    btn.addEventListener('click', async () => {
      const [type, label] = labelMap[id];
      if (!confirm(`¿Borrar TODOS los "${label}" del aula actual?\nEsta acción no se puede deshacer.`)) return;
      btn.disabled = true;
      try {
        const tab = await requireMoodleTab();
        showStatus(`Borrando ${label}...`, 'loading', btn);
        const response = await sendToContentScript(tab.id, { action: 'bulk_delete', resourceType: type });
        showStatus(`${response.deleted || 0} ${label} borrados del aula.`, 'success', btn);
      } catch (e) {
        showStatus(e.message || 'Error', 'error', btn);
      }
      btn.disabled = false;
    });
  });

  // --- STEP 3: Create Manual Task (lógica v1: descripción HTML + rúbrica visible + PDF) ---
  document.getElementById('btnCreateManualTask').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const mt = rda.manualTask;
    const btn = document.getElementById('btnCreateManualTask');
    if (!mt.nombre) { showStatus('Escribe un nombre para la tarea.', 'error', btn); return; }
    if (mt.dateFrom >= mt.dateTo) {
      showStatus('La fecha "Disponible hasta" debe ser posterior a "Disponible desde".', 'error', btn);
      return;
    }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('create_task', { nombre: mt.nombre });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const label = getRdaLabel();
      const sectionIdx = activeRda + 1;
      const gradeCatValue = await getGradeCategoryForRda(activeRda);

      // Construir rubrica JSON
      const rubricaJson = { criterios: mt.rubrica.filter(c => c.nombre).map(c => ({
        nombre: c.nombre,
        niveles: c.niveles.map(n => ({ nombre: n.nombre, puntos: n.puntos, descripcion: n.descripcion || n.nombre }))
      }))};

      // Construir HTML de descripción + rúbrica visible
      let descHtml = '';
      const detailsParts = [];
      if (mt.descripcion) {
        detailsParts.push(`<p style="margin:0 0 12px 0;font-size:14px;color:#1e293b;">${mt.descripcion.replace(/\n/g, '<br>')}</p>`);
      }
      const validCriteria = mt.rubrica.filter(c => c.nombre);
      if (validCriteria.length > 0) {
        const colors = { 'Excelente': '#059669', 'Bueno': '#2563eb', 'Regular': '#d97706', 'Insuficiente': '#dc2626' };
        const bgColors = { 'Excelente': '#ecfdf5', 'Bueno': '#eff6ff', 'Regular': '#fffbeb', 'Insuficiente': '#fef2f2' };
        let rubricHtml = `<div style="margin-top:8px;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden;font-family:sans-serif;">
          <div style="background:#1e40af;color:#fff;padding:8px 12px;font-size:13px;font-weight:700;">Rúbrica de Evaluación</div>
          <table style="width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed;word-wrap:break-word;">
            <thead><tr style="background:#f1f5f9;">
              <th style="padding:6px 8px;text-align:left;border-bottom:2px solid #cbd5e1;font-size:11px;color:#475569;width:18%;">Criterio</th>
              ${validCriteria[0].niveles.map(n => `<th style="padding:6px 8px;text-align:center;border-bottom:2px solid #cbd5e1;font-size:11px;color:${colors[n.nombre] || '#475569'};">${n.nombre}<br><span style="font-weight:400;font-size:10px;">(${n.puntos} pts)</span></th>`).join('')}
            </tr></thead>
            <tbody>
              ${validCriteria.map((c, i) => `<tr style="background:${i % 2 === 0 ? '#fff' : '#f8fafc'};">
                <td style="padding:6px 8px;font-weight:600;border-bottom:1px solid #e2e8f0;color:#1e293b;">${c.nombre}</td>
                ${c.niveles.map(n => `<td style="padding:6px 8px;text-align:center;border-bottom:1px solid #e2e8f0;font-size:11px;color:#334155;background:${bgColors[n.nombre] || 'transparent'}22;">${n.descripcion || '-'}</td>`).join('')}
              </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
        detailsParts.push(rubricHtml);
      }
      if (detailsParts.length > 0) {
        descHtml = `<div style="font-family:sans-serif;padding:10px;">
          <details style="border:1px solid #e2e8f0;border-radius:8px;overflow:hidden;">
            <summary style="cursor:pointer;padding:10px 14px;background:#f1f5f9;font-size:13px;font-weight:600;color:#1e40af;list-style:none;display:flex;align-items:center;gap:6px;">
              <span style="font-size:16px;">&#9654;</span> Ver descripción y rúbrica de evaluación
            </summary>
            <div style="padding:12px 14px;">${detailsParts.join('')}</div>
          </details>
        </div>`;
      }

      // Serializar PDF adjunto
      let pdfSerialized = null;
      if (mt.pdf) pdfSerialized = await serializeFile(mt.pdf);

      // Limpiar PDF adjunto de memoria ANTES de enviar
      mt.pdf = null;
      mt.pdfName = '';
      clearTaskPdfUI();
      await saveFormState();

      showStatus('Creando tarea en Moodle...', 'loading', btn);
      await sendToContentScript(tab.id, {
        action: 'create_assignment',
        assignments: [{
          nombre: mt.nombre,
          descripcionHtml: descHtml,
          rubricaJson: rubricaJson.criterios.length > 0 ? rubricaJson : null,
          instrucciones: mt.descripcion,
          pdfSerialized: pdfSerialized,
          dateFrom: mt.dateFrom,
          dateTo: mt.dateTo
        }],
        rdaIndex: activeRda,
        sectionIndex: sectionIdx,
        gradeCategoryValue: gradeCatValue,
        criterioIndex: parseInt(document.getElementById('manualTaskCriterio').value),

      });
      showStatus(`Tarea "${mt.nombre}" creada en ${label} ${sectionIdx}.`, 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Create Manual Quiz (lógica v1: fechas, horas, Aiken, XML, categoría) ---
  document.getElementById('btnCreateManualQuiz').addEventListener('click', async () => {
    saveCurrentRdaData();
    saveManualQuizData();
    const mq = rdaData[activeRda].manualQuiz;
    const btn = document.getElementById('btnCreateManualQuiz');
    if (!mq.nombre) { showStatus('Escribe un nombre para la evaluacion.', 'error', btn); return; }

    // Validar fechas/horas
    const qHourFrom = mq.hourFrom || '0';
    const qMinFrom = mq.minFrom || '0';
    const qHourTo = mq.hourTo || '23';
    const qMinTo = mq.minTo || '55';
    if (mq.dateFrom && mq.dateTo) {
      const openDT = new Date(mq.dateFrom + 'T' + String(qHourFrom).padStart(2,'0') + ':' + String(qMinFrom).padStart(2,'0'));
      const closeDT = new Date(mq.dateTo + 'T' + String(qHourTo).padStart(2,'0') + ':' + String(qMinTo).padStart(2,'0'));
      const diffMin = (closeDT - openDT) / 60000;
      if (diffMin <= 0) { showStatus('La fecha/hora de cierre debe ser posterior a la de apertura.', 'error', btn); return; }
      if (mq.time > 0 && diffMin < mq.time) { showStatus(`La ventana disponible (${Math.floor(diffMin)} min) es menor al tiempo del quiz (${mq.time} min).`, 'error', btn); return; }
    }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('create_quiz', { nombre: mq.nombre });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const sectionIdx = activeRda + 1;
      const gradeCatValue = await getGradeCategoryForRda(activeRda);

      showStatus('Creando evaluacion en Moodle...', 'loading', btn);
      await sendToContentScript(tab.id, {
        action: 'create_quiz',
        quizName: mq.nombre,
        dateFrom: mq.dateFrom,
        dateTo: mq.dateTo,
        hourFrom: qHourFrom,
        minFrom: qMinFrom,
        hourTo: qHourTo,
        minTo: qMinTo,
        timeLimit: mq.time || 60,
        quizPassword: mq.password || '',
        rdaIndex: activeRda,
        sectionIndex: sectionIdx,
        gradeCategoryValue: gradeCatValue,
        criterioIndex: parseInt(document.getElementById('manualQuizCriterio').value),
        aikenText: mq.aikenText || '',
        xmlText: mq.xmlContent || '',
        xmlFileName: mq.xmlFileName || ''
      });
      showStatus(`Evaluacion "${mq.nombre}" creada.`, 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Analyze with AI (backend Edge Function) ---
  document.getElementById('btnAnalyzeAi').addEventListener('click', async () => {
    const btn = document.getElementById('btnAnalyzeAi');
    btn.disabled = true;
    saveCurrentRdaData();

    try {
      const rda = rdaData[activeRda];
      const validPdfs = rda.pdfs.filter(f => f);

      // Usar texto ya extraído o extraer ahora
      let allPdfText = rda.pdfText || '';
      if (!allPdfText.trim() && validPdfs.length > 0) {
        showStatus('Extrayendo texto de PDFs...', 'loading', btn);
        for (const pdf of validPdfs) {
          try { allPdfText += await extractTextFromPDF(pdf) + '\n\n'; } catch (_) {}
        }
        rda.pdfText = allPdfText;
      }
      if (!allPdfText.trim()) throw new Error('Sube al menos un PDF primero.');

      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('analyze_ai', { rdaIndex: activeRda + 1 });
      if (!creditResult.ok) throw new Error(creditResult.error);

      showStatus('IA analizando contenido (puede tardar ~30s)...', 'loading', btn);
      const numQuestions = parseInt(document.getElementById('questionsPerQuiz')?.value) || 10;
      const result = await callGenerateContent('analyze_ai', { pdfText: allPdfText, questionsPerQuiz: numQuestions });
      if (!result.ok) throw new Error(result.error);

      // Rellenar tareas sugeridas
      if (result.tasks && result.tasks.length > 0) {
        document.querySelectorAll('#taskPanels .ai-tab-panel').forEach((panel, i) => {
          if (!result.tasks[i]) return;
          const nameInput = panel.querySelector('.task-name');
          const descInput = panel.querySelector('.task-desc');
          if (nameInput) nameInput.value = result.tasks[i].nombre || '';
          if (descInput) descInput.value = result.tasks[i].descripcion || '';
          rda.tasks[i] = { nombre: result.tasks[i].nombre || '', descripcion: result.tasks[i].descripcion || '' };
        });
      }

      // Rellenar evaluaciones
      if (result.evals && result.evals.length > 0) {
        result.evals.forEach((ev, i) => {
          rda.evals[i] = ev;
          const preview = document.getElementById(`evalPreview${i}`);
          if (preview && ev.questions && ev.questions.length > 0) {
            preview.innerHTML = ev.questions.map((q, qi) => {
              const opts = (q.opciones || q.options || []).map((opt, j) => {
                const isCorrect = j === (q.correcta || q.correct || 0);
                return `<span style="color:${isCorrect ? '#059669' : '#64748b'}">${isCorrect ? '✓ ' : '• '}${opt}</span>`;
              }).join('<br>');
              return `<div style="margin-bottom:8px"><div style="font-weight:600;font-size:11px">${qi + 1}. ${q.pregunta || q.question || ''}</div>${opts}</div>`;
            }).join('');
          } else if (preview) {
            preview.innerHTML = `<span style="color:#dc2626">Error: ${ev.error || 'Sin preguntas'}</span>`;
          }
        });
      }

      rda.aiAnalyzed = true;
      document.getElementById('stageAiResults').style.display = 'block';
      showStatus('Análisis completo. Revisa tareas y evaluaciones, ajusta fechas y crea en Moodle.', 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Create AI Tasks + Quizzes + Forum ---
  document.getElementById('btnCreateTasksQuizzes').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const btn = document.getElementById('btnCreateTasksQuizzes');
    btn.disabled = true;

    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('create_ai_content', { rdaIndex: activeRda + 1 });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const sectionIdx = activeRda + 1;
      const gradeCatValue = await getGradeCategoryForRda(activeRda);

      // Recopilar tareas desde la UI
      const taskPanels = document.querySelectorAll('#taskPanels .ai-tab-panel');
      const assignments = [];
      taskPanels.forEach(panel => {
        const name = panel.querySelector('.task-name')?.value?.trim();
        if (!name) return;
        const desc = panel.querySelector('.task-desc')?.value || '';
        const dateFrom = panel.querySelector('.task-date-from')?.value || '';
        const dateTo = panel.querySelector('.task-date-to')?.value || '';
        assignments.push({ nombre: name, descripcionHtml: desc, instrucciones: desc, dateFrom, dateTo });
      });

      // Crear primera tarea (el content script maneja multi-página)
      if (assignments.length > 0) {
        showStatus('Creando tareas en Moodle...', 'loading', btn);
        await sendToContentScript(tab.id, {
          action: 'create_assignment',
          assignments: [assignments[0]],
          rdaIndex: activeRda,
          sectionIndex: sectionIdx,
          gradeCategoryValue: gradeCatValue,
          criterioIndex: parseInt(document.getElementById('manualTaskCriterio').value)
        });
      }

      showStatus('Tareas creándose. La extensión navegará automáticamente.', 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- Generate Rubric with AI (backend Edge Function) ---
  document.getElementById('btnGenerateRubricAi').addEventListener('click', async () => {
    const btn = document.getElementById('btnGenerateRubricAi');
    btn.disabled = true;
    saveCurrentRdaData();

    try {
      let pdfText = rdaData[activeRda].pdfText || '';
      if (!pdfText.trim()) {
        const files = rdaData[activeRda].pdfs.filter(f => f);
        for (const file of files) {
          try { pdfText += await extractTextFromPDF(file) + '\n'; } catch (_) {}
        }
      }

      const taskName = document.getElementById('manualTaskName')?.value || 'Tarea';
      const numCriterios = parseInt(document.getElementById('rubricCriteriaCount')?.value || '4');
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('generate_rubric', { taskName });
      if (!creditResult.ok) throw new Error(creditResult.error);

      showStatus('Generando rúbrica con IA...', 'loading', btn);
      const result = await callGenerateContent('generate_rubric', { taskName, pdfText, numCriterios });
      if (!result.ok) throw new Error(result.error);

      if (result.rubricaJson && result.rubricaJson.criterios) {
        renderRubricFromJson(result.rubricaJson);
        saveFormState();
        showStatus('Rúbrica generada.', 'success', btn);
      } else {
        showStatus('No se pudo generar la rúbrica.', 'error', btn);
      }
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- Quiz date/time validation ---
  ['manualQuizDateFrom', 'manualQuizDateTo', 'manualQuizHourFrom', 'manualQuizMinFrom', 'manualQuizHourTo', 'manualQuizMinTo', 'manualQuizTime'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', () => { saveManualQuizData(); validateQuizDates(); saveFormState(); });
      el.addEventListener('input', () => { saveManualQuizData(); saveFormState(); });
    }
  });

  // --- Global Stop ---
  btnStop.addEventListener('click', () => {
    sendMessage({ type: 'SEND_TO_TAB', message: { action: 'gaula_stop' } });
    btnStop.style.display = 'none';
    showStatus('Operacion detenida.', 'error');
  });

  // Stop button for Step 2
  document.getElementById('btnStopStep2')?.addEventListener('click', () => {
    sendMessage({ type: 'SEND_TO_TAB', message: { action: 'gaula_stop' } });
    document.getElementById('btnStopStep2').style.display = 'none';
    showStatus('Operacion detenida.', 'error', 'Step2');
  });
}

// ============================================================
// URL VALIDATORS
// ============================================================

function isYoutubeUrl(url) {
  return /^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(url.trim());
}

function isGeniallyUrl(url) {
  return /^https?:\/\/(view\.)?genial(\.ly|ly\.com)\//i.test(url.trim());
}

function initUrlValidation() {
  function validate(input) {
    const val = input.value.trim();
    if (!val) { input.classList.remove('url-invalid', 'url-valid'); return; }
    const isVideo = input.classList.contains('video-url');
    const ok = isVideo ? isYoutubeUrl(val) : isGeniallyUrl(val);
    input.classList.toggle('url-invalid', !ok);
    input.classList.toggle('url-valid', ok);
  }
  document.addEventListener('input', (e) => {
    if (e.target.matches('.video-url, .geneally-url')) validate(e.target);
  });
  document.addEventListener('paste', (e) => {
    if (e.target.matches('.video-url, .geneally-url')) {
      setTimeout(() => validate(e.target), 0);
    }
  });
}

// ============================================================
// HELPERS FOR FILE NAMES
// ============================================================

function truncateName(name, maxLen = 50) {
  return name.length > maxLen ? name.substring(0, maxLen) : name;
}

function getPptEditedNames() {
  const names = [];
  document.querySelectorAll('.ppt-input').forEach(input => {
    if (input.files[0]) {
      const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
      names.push(truncateName(nameEl.value || input.files[0].name.replace(/\.[^.]+$/, '')));
    }
  });
  return names;
}

function getPdfEditedNames() {
  const names = [];
  document.querySelectorAll('.pdf-input').forEach(input => {
    if (input.files[0]) {
      const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
      names.push(truncateName(nameEl.value || input.files[0].name.replace(/\.[^.]+$/, '')));
    }
  });
  return names;
}

// Limpiar visualmente los file slots (.ppt-input o .pdf-input)
function clearFileSlotUI(selector) {
  document.querySelectorAll(selector).forEach(input => {
    input.value = '';
    const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
    if (nameEl) {
      nameEl.value = 'Sin archivo';
      nameEl.classList.remove('has-file');
      nameEl.setAttribute('readonly', '');
    }
  });
}

// Limpiar visualmente el PDF adjunto de la tarea manual
function clearTaskPdfUI() {
  const pdfInput = document.getElementById('manualTaskPdf');
  if (pdfInput) pdfInput.value = '';
  const nameEl = document.getElementById('manualTaskPdfName');
  if (nameEl) {
    nameEl.value = 'Sin archivo';
    nameEl.classList.remove('has-file');
    nameEl.setAttribute('readonly', '');
  }
}

// ============================================================
// PROGRESS MONITOR
// ============================================================

function initProgressMonitor() {
  // Listen for progress updates from content script via storage
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.gaula_progress) {
      const p = changes.gaula_progress.newValue;
      if (!p) return;

      if (p.status === 'done' || p.status === 'error') {
        hideAllProgress();
        if (p.status === 'error') showStatus(p.error || 'Error', 'error');
        return;
      }

      // Show progress
      const wrapper = document.getElementById('progressWrapper');
      const label = document.getElementById('progressLabel');
      const count = document.getElementById('progressCount');
      const fill = document.getElementById('progressFill');

      wrapper.style.display = 'block';
      label.textContent = p.label || 'Procesando...';
      if (p.total > 0) {
        count.textContent = `${p.current}/${p.total}`;
        fill.style.width = `${(p.current / p.total) * 100}%`;
      }

      btnStop.style.display = 'block';
    }
  });
}

function hideAllProgress() {
  document.getElementById('progressWrapper').style.display = 'none';
  document.getElementById('progressStep2').style.display = 'none';
  document.getElementById('progressStep3').style.display = 'none';
  btnStop.style.display = 'none';
}

// ============================================================
// FORM STATE PERSISTENCE
// ============================================================

// Bug #11: Debounce para evitar escrituras excesivas a chrome.storage
let _saveFormTimeout = null;
function saveFormState() {
  if (_saveFormTimeout) clearTimeout(_saveFormTimeout);
  _saveFormTimeout = setTimeout(_saveFormStateImmediate, 300);
}

function _saveFormStateImmediate() {
  // Guardar datos del RdA activo antes de serializar
  saveCurrentRdaData();

  // Serializar rdaData sin archivos (File objects no se pueden guardar en storage)
  const rdaSerialized = rdaData.map(rda => ({
    videos: rda.videos,
    geneallys: rda.geneallys,
    forumTopic: rda.forumTopic,
    aiAnalyzed: rda.aiAnalyzed,
    pdfText: rda.pdfText,
    tasks: rda.tasks,
    evals: rda.evals,
    // Guardar nombres de archivos para mostrar al reabrir (los File objects se pierden)
    pdfNames: rda.pdfs.map(f => f ? f.name : ''),
    pptNames: rda.ppts.map(f => f ? f.name : ''),
    manualTask: {
      nombre: rda.manualTask.nombre,
      descripcion: rda.manualTask.descripcion,
      dateFrom: rda.manualTask.dateFrom,
      dateTo: rda.manualTask.dateTo,
      criterio: rda.manualTask.criterio || '1',
      pdfName: rda.manualTask.pdf ? rda.manualTask.pdf.name : (rda.manualTask.pdfName || ''),
      rubrica: rda.manualTask.rubrica,
    },
    manualQuiz: {
      nombre: rda.manualQuiz.nombre,
      password: rda.manualQuiz.password,
      dateFrom: rda.manualQuiz.dateFrom,
      dateTo: rda.manualQuiz.dateTo,
      criterio: rda.manualQuiz.criterio || '1',
      time: rda.manualQuiz.time,
      hourFrom: rda.manualQuiz.hourFrom || '8',
      minFrom: rda.manualQuiz.minFrom || '0',
      hourTo: rda.manualQuiz.hourTo || '23',
      minTo: rda.manualQuiz.minTo || '55',
      aikenText: rda.manualQuiz.aikenText,
      xmlContent: rda.manualQuiz.xmlContent || '',
    },
  }));

  const state = {
    teacherName: document.getElementById('teacherName')?.value || '',
    teacherTitle: document.getElementById('teacherTitle')?.value || '',
    teacherEmail: document.getElementById('teacherEmail')?.value || '',
    teacherDesc: document.getElementById('teacherDesc')?.value || '',
    subjectName: document.getElementById('subjectName')?.value || '',
    careerName: document.getElementById('careerName')?.value || '',
    notebookLmLink: document.getElementById('notebookLmLink')?.value || '',
    schedule: scheduleBlocks.map(b => ({ dia: b.dia, horaInicio: b.horaInicio, horaFin: b.horaFin, aula: b.aula, modalidad: b.modalidad })),
    activeRda,
    rdaData: rdaSerialized,
  };
  return new Promise(resolve => chrome.storage.local.set({ gaula_form_state: state }, resolve));
}

function loadFormState() {
  chrome.storage.local.get('gaula_form_state', (result) => {
    const s = result.gaula_form_state;

    // Ya no hay autodetección de tipo de curso

    if (!s) return;

    // Paso 2: datos basicos
    if (s.teacherName) document.getElementById('teacherName').value = s.teacherName;
    if (s.teacherTitle) document.getElementById('teacherTitle').value = s.teacherTitle;
    if (s.teacherEmail) document.getElementById('teacherEmail').value = s.teacherEmail;
    if (s.teacherDesc) document.getElementById('teacherDesc').value = s.teacherDesc;
    if (s.subjectName) document.getElementById('subjectName').value = s.subjectName;
    if (s.careerName) document.getElementById('careerName').value = s.careerName;
    if (s.notebookLmLink) document.getElementById('notebookLmLink').value = s.notebookLmLink;
    // courseType ya no se restaura — popup es genérico

    // Horario
    if (s.schedule && s.schedule.length > 0) {
      scheduleBlocks = [];
      s.schedule.forEach(b => createScheduleBlock(b));
    }

    // Datos por RdA
    if (s.rdaData) {
      s.rdaData.forEach((saved, i) => {
        if (!rdaData[i]) return;
        rdaData[i].videos = saved.videos || ['','',''];
        rdaData[i].geneallys = saved.geneallys || ['','',''];
        rdaData[i].forumTopic = saved.forumTopic || '';
        rdaData[i].aiAnalyzed = saved.aiAnalyzed || false;
        rdaData[i].pdfText = saved.pdfText || '';
        rdaData[i].tasks = saved.tasks || [{},{},{}];
        rdaData[i].evals = saved.evals || [{},{},{}];

        // Restaurar nombres de archivos (los File objects se pierden al cerrar popup)
        if (saved.pdfNames) rdaData[i]._pdfNames = saved.pdfNames;
        if (saved.pptNames) rdaData[i]._pptNames = saved.pptNames;

        // Manual task
        if (saved.manualTask) {
          rdaData[i].manualTask.nombre = saved.manualTask.nombre || '';
          rdaData[i].manualTask.descripcion = saved.manualTask.descripcion || '';
          rdaData[i].manualTask.dateFrom = saved.manualTask.dateFrom || gaulaToday();
          rdaData[i].manualTask.dateTo = saved.manualTask.dateTo || gaulaNextWeek();
          rdaData[i].manualTask.pdfName = saved.manualTask.pdfName || '';
          rdaData[i].manualTask.criterio = saved.manualTask.criterio || '1';
          if (saved.manualTask.rubrica) rdaData[i].manualTask.rubrica = saved.manualTask.rubrica;
        }

        // Manual quiz
        if (saved.manualQuiz) {
          rdaData[i].manualQuiz.nombre = saved.manualQuiz.nombre || '';
          rdaData[i].manualQuiz.password = saved.manualQuiz.password || '';
          rdaData[i].manualQuiz.dateFrom = saved.manualQuiz.dateFrom || gaulaToday();
          rdaData[i].manualQuiz.dateTo = saved.manualQuiz.dateTo || gaulaToday();
          rdaData[i].manualQuiz.time = saved.manualQuiz.time || 60;
          rdaData[i].manualQuiz.hourFrom = saved.manualQuiz.hourFrom || '8';
          rdaData[i].manualQuiz.minFrom = saved.manualQuiz.minFrom || '0';
          rdaData[i].manualQuiz.hourTo = saved.manualQuiz.hourTo || '23';
          rdaData[i].manualQuiz.minTo = saved.manualQuiz.minTo || '55';
          rdaData[i].manualQuiz.criterio = saved.manualQuiz.criterio || '1';
          rdaData[i].manualQuiz.aikenText = saved.manualQuiz.aikenText || '';
          rdaData[i].manualQuiz.xmlContent = saved.manualQuiz.xmlContent || '';
        }
      });
    }

    // Restaurar RdA activo y cargar sus datos en la UI
    if (s.activeRda != null) {
      activeRda = s.activeRda;
      document.querySelectorAll('.rda-tab').forEach((tab, i) => tab.classList.toggle('active', i === activeRda));
      document.querySelectorAll('.rda-tab-mini').forEach((tab) => tab.classList.toggle('active', parseInt(tab.dataset.rda) - 1 === activeRda));
    }
    loadRdaData(activeRda);
  });
}

// Save form on input changes (debounced)
let saveTimeout = null;
document.addEventListener('input', () => {
  clearTimeout(saveTimeout);
  saveTimeout = setTimeout(saveFormState, 500);
});

// Close time pickers on outside click
document.addEventListener('click', (e) => {
  if (!e.target.closest('.time-range-picker')) {
    document.querySelectorAll('.trp-dropdown').forEach(d => d.style.display = 'none');
  }
});

// ============================================================
// GENERATION HELPERS
// ============================================================

let activeProgressStep = null;

function showProgress(current, total, label, step) {
  const s = step || activeProgressStep;
  const wrapper = s ? document.getElementById(`progress${s}`) : null;
  const labelEl = s ? document.getElementById(`progressLabel${s}`) : null;
  const countEl = s ? document.getElementById(`progressCount${s}`) : null;
  const fillEl = s ? document.getElementById(`progressFill${s}`) : null;
  if (!wrapper) return;
  wrapper.style.display = 'block';
  if (labelEl) labelEl.textContent = label;
  if (countEl) countEl.textContent = `${current}/${total}`;
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;
  if (fillEl) fillEl.style.width = pct + '%';
}

function hideProgress(step) {
  const s = step || activeProgressStep;
  const wrapper = s ? document.getElementById(`progress${s}`) : null;
  const fillEl = s ? document.getElementById(`progressFill${s}`) : null;
  if (wrapper) wrapper.style.display = 'none';
  if (fillEl) fillEl.style.width = '0%';
}

function markProgressDone(step) {
  const s = step || activeProgressStep;
  const fillEl = s ? document.getElementById(`progressFill${s}`) : null;
  if (fillEl) { fillEl.style.width = '100%'; fillEl.classList.add('done'); }
}

function saveGenerated(key, data) {
  chrome.storage.local.set({ [`gaula_gen_${key}`]: data });
}

// Bug #12: Grade categories cache with TTL (30 min)
const GRADE_CAT_TTL = 30 * 60 * 1000;

async function getGradeCategoryForRda(rdaIndex) {
  return new Promise(resolve => {
    chrome.storage.local.get('gaula_grade_categories', (result) => {
      const cats = result.gaula_grade_categories || {};
      // Invalidar cache si es más viejo que TTL
      if (cats._ts && (Date.now() - cats._ts) > GRADE_CAT_TTL) {
        chrome.storage.local.remove('gaula_grade_categories');
        resolve(null);
        return;
      }
      resolve(cats[rdaIndex] || null);
    });
  });
}

function sendToContentScript(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error('No se pudo conectar con Moodle. Recarga la página (F5).'));
        return;
      }
      if (response && response.ok) {
        resolve(response);
      } else {
        reject(new Error(response?.error || 'Error en la operación'));
      }
    });
  });
}

// Call backend generate-content Edge Function via background (maneja token y retry)
async function callGenerateContent(action, payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'GENERATE_CONTENT', action, payload }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error('No se pudo conectar con el servicio.'));
        return;
      }
      if (response?.error) {
        reject(new Error(response.error));
      } else {
        resolve(response);
      }
    });
  });
}

function generateYoutubeIframeHTML(url, title) {
  let videoId = '';
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
  if (match) videoId = match[1];
  else videoId = url;
  const embedUrl = `https://www.youtube.com/embed/${videoId}`;
  return `<iframe width="640" height="360" src="${embedUrl}" title="${title}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen=""></iframe>`;
}

function generateGeniallyIframeHTML(url, title) {
  const cleanUrl = url.trim();
  return `<iframe width="640" height="480" src="${cleanUrl}" title="${title}" frameborder="0" allow="autoplay; fullscreen" allowfullscreen="" style="max-width:100%"></iframe>`;
}

function wrapCollapsible(title, innerHtml) {
  const id = 'gaula_' + Math.random().toString(36).substr(2, 8);
  return `<div style="margin:10px auto;width:100%;max-width:100%;border:1px solid #e0e0e0;border-radius:10px;overflow:hidden">
  <div onclick="var c=document.getElementById('${id}');var b=this.querySelector('span:last-child');if(c.style.display==='none'){c.style.display='block';b.textContent='▲';}else{c.style.display='none';b.textContent='▼';}" style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;background:#1a237e;color:#fff;cursor:pointer;user-select:none">
    <span style="font-weight:bold;font-size:15px">${title}</span>
    <span style="font-size:13px">▲</span>
  </div>
  <div id="${id}" style="display:block;padding:0">
    ${innerHtml}
  </div>
</div>`;
}

function generateTabbedHTML(tabs, groupId) {
  groupId = groupId + '_' + Math.random().toString(36).substr(2, 6);
  const tabInputsAndLabels = tabs.map((t, i) =>
    `<input type="radio" name="${groupId}" id="${groupId}_${i}" ${i === 0 ? 'checked' : ''}><label for="${groupId}_${i}">${t.label}</label>`
  ).join('');
  const tabContents = tabs.map((t, i) =>
    `<div class="gtc gtc-${i}">${t.content}</div>`
  ).join('\n');
  let checkedRules = '';
  tabs.forEach((_, i) => {
    checkedRules += `.gt-${groupId} #${groupId}_${i}:checked + label { color:#1e293b; border-bottom-color:#2563eb; }\n`;
    checkedRules += `.gt-${groupId} #${groupId}_${i}:checked ~ .gtc-${i} { display:block !important; }\n`;
  });
  return `<style>
.gt-${groupId} { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; }
.gt-${groupId} input[type="radio"] { position:absolute; opacity:0; pointer-events:none; }
.gt-${groupId} > label { display:inline-block; padding:10px 20px; font-weight:600; font-size:14px; color:#94a3b8; cursor:pointer; transition:all 0.2s; border-bottom:2px solid transparent; margin-bottom:0; }
.gt-${groupId} > label:hover { color:#475569; }
.gt-${groupId} > .gtc { display:none; padding:20px 16px; border-top:2px solid #e2e8f0; }
${checkedRules}
</style>
<div class="gt-${groupId}">
${tabInputsAndLabels}
${tabContents}
</div>`;
}

// Inject Step 2 results (HTMLs from backend) into Moodle
// ============================================================
// PANEL DE REVISIÓN/EDICIÓN PRE-INYECCIÓN (Paso 2)
// ============================================================
// Llamado tras generar (con o sin IA). Muestra preview editable de cada
// HTML y, al aprobar, llama a injectStep2Results con el contenido editado.
// La función injectStep2Results NO se modifica.
function showStep2EditPanel(result, originBtn) {
  const panel = document.getElementById('step2-edit-panel');
  const tabsEl = document.getElementById('step2-edit-tabs');
  const previewEl = document.getElementById('step2-edit-preview');
  const cancelBtn = document.getElementById('btn-edit-cancel');
  const approveBtn = document.getElementById('btn-edit-approve');

  if (!panel || !tabsEl || !previewEl || !cancelBtn || !approveBtn) {
    // Sin panel, fallback al comportamiento legacy: inyectar directo
    return injectStep2Results(result).catch((e) => showStatus('Error: ' + e.message, 'error', originBtn));
  }

  // Estado mutable de cada HTML — se irá actualizando con las ediciones
  const editedState = {
    bannerHtml: result.bannerHtml || '',
    syllabusHtml: result.syllabusHtml || '',
    subjectHtml: result.subjectHtml || '',
    teacherHtml: result.teacherHtml || '',
    scheduleHtml: result.scheduleHtml || '',
    tutorHtml: result.tutorHtml || null,
  };

  const tabs = [
    { key: 'syllabusHtml', label: 'Sílabo' },
    { key: 'subjectHtml', label: 'Materia' },
    { key: 'teacherHtml', label: 'Docente' },
    { key: 'scheduleHtml', label: 'Horario' },
  ];
  if (editedState.tutorHtml) tabs.push({ key: 'tutorHtml', label: 'Tutor' });
  if (editedState.bannerHtml) tabs.push({ key: 'bannerHtml', label: 'Banner' });

  let activeKey = tabs[0].key;

  function captureCurrentEdit() {
    const c = document.getElementById('step2-edit-content');
    if (c) editedState[activeKey] = c.innerHTML;
  }

  function renderTabs() {
    tabsEl.innerHTML = '';
    tabs.forEach((t) => {
      const tab = document.createElement('button');
      tab.type = 'button';
      tab.textContent = t.label;
      const isActive = t.key === activeKey;
      tab.style.cssText =
        'padding:8px 14px;border:none;background:' + (isActive ? '#fff' : 'transparent') +
        ';color:' + (isActive ? '#1d4ed8' : '#4b5563') +
        ';font-size:12px;font-weight:' + (isActive ? '600' : '500') +
        ';cursor:pointer;border-bottom:2px solid ' + (isActive ? '#1d4ed8' : 'transparent') +
        ';white-space:nowrap;transition:background 0.15s';
      tab.addEventListener('click', () => {
        captureCurrentEdit();
        activeKey = t.key;
        renderTabs();
        renderPreview();
      });
      tabsEl.appendChild(tab);
    });
  }

  function renderPreview() {
    const html = editedState[activeKey] || '<em style="color:#9ca3af">(sin contenido para esta sección)</em>';
    previewEl.innerHTML = '<div contenteditable="true" id="step2-edit-content" spellcheck="true" style="outline:none;min-height:180px;line-height:1.5">' + html + '</div>';
  }

  function hidePanel() {
    captureCurrentEdit();
    panel.style.display = 'none';
    cancelBtn.removeEventListener('click', onCancel);
    approveBtn.removeEventListener('click', onApprove);
  }

  function onCancel() {
    hidePanel();
    if (originBtn) originBtn.disabled = false;
    showStatus('Inyección cancelada. Puedes generar de nuevo cuando quieras.', 'info', originBtn);
  }

  async function onApprove() {
    captureCurrentEdit();
    panel.style.display = 'none';
    cancelBtn.removeEventListener('click', onCancel);
    approveBtn.removeEventListener('click', onApprove);
    try {
      activeProgressStep = 'Step2';
      showProgress(3, 4, 'Inyectando a Moodle...', 'Step2');
      await injectStep2Results(editedState);
      markProgressDone('Step2');
      showStatus('Contenido inyectado en Moodle.', 'success', originBtn);
    } catch (e) {
      showStatus('Error inyectando: ' + (e.message || 'desconocido'), 'error', originBtn);
    } finally {
      if (originBtn) originBtn.disabled = false;
    }
  }

  cancelBtn.addEventListener('click', onCancel);
  approveBtn.addEventListener('click', onApprove);
  renderTabs();
  renderPreview();
  panel.style.display = 'block';
  panel.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

async function injectStep2Results(result) {
  const { bannerHtml, syllabusHtml, subjectHtml, teacherHtml, scheduleHtml, tutorHtml } = result;

  // Guardar HTMLs generados en storage
  saveGenerated('banner_html', bannerHtml);
  saveGenerated('syllabus_html', syllabusHtml);
  saveGenerated('subject_html', subjectHtml);
  saveGenerated('teacher_html', teacherHtml);
  saveGenerated('schedule_html', scheduleHtml);
  if (tutorHtml) saveGenerated('tutor_html', tutorHtml);

  // Armar página con pestañas
  const presentationTabs = [
    { label: 'Sílabo', content: syllabusHtml },
    { label: 'Docente', content: teacherHtml },
    { label: 'Materia', content: subjectHtml },
    { label: 'Horario', content: scheduleHtml },
  ];
  if (tutorHtml) {
    presentationTabs.push({ label: 'Tutor', content: tutorHtml });
  }
  const tabbedHtml = wrapCollapsible('Información del Curso', generateTabbedHTML(presentationTabs, 'gaula_pres'));

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) throw new Error('No se encontró pestaña activa.');
  if (!tab.url?.includes('/course/view.php')) {
    throw new Error('Debes estar en la página del curso en Moodle.');
  }

  const queue = [{
    sectionType: 'presentations',
    htmlContent: tabbedHtml,
    pageName: 'Información del Curso',
    sectionIndex: 0
  }];

  // Enviar al content script: editar banner + crear página
  const response = await new Promise((resolve) => {
    chrome.tabs.sendMessage(tab.id, {
      action: 'edit_banner',
      bannerHtml,
      pendingQueue: queue,
      courseUrl: tab.url
    }, (resp) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(resp || { ok: false, error: 'Sin respuesta' });
      }
    });
  });

  if (!response.ok) throw new Error(response.error);
}

// ============================================================
// SCROLL PERSISTENCE
// ============================================================
// ---- Scroll persistence (usa localStorage síncrono) ----
// El popup se destruye al cerrarlo, así que chrome.storage.local.set (async)
// no alcanza a guardar. localStorage es síncrono y persiste entre aperturas.

function saveScrollPos() {
  const pos = document.body.scrollTop || document.documentElement.scrollTop;
  localStorage.setItem('gaula_scroll_pos', String(pos));
}

// Guardar en cada scroll (debounced) + al cerrar el popup
let _scrollT = null;
document.body.addEventListener('scroll', () => {
  clearTimeout(_scrollT);
  _scrollT = setTimeout(saveScrollPos, 100);
});
document.documentElement.addEventListener('scroll', () => {
  clearTimeout(_scrollT);
  _scrollT = setTimeout(saveScrollPos, 100);
});
window.addEventListener('beforeunload', saveScrollPos);
window.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') saveScrollPos();
});

function restoreScrollPosition() {
  const pos = parseInt(localStorage.getItem('gaula_scroll_pos') || '0', 10);
  if (pos > 0) {
    requestAnimationFrame(() => {
      document.body.scrollTop = pos;
      document.documentElement.scrollTop = pos;
      // Fallback para contenido que aún se está renderizando
      setTimeout(() => {
        document.body.scrollTop = pos;
        document.documentElement.scrollTop = pos;
      }, 150);
    });
  }
}

// ============================================================
// ZOOM
// ============================================================
const ZOOM_STEPS = [80, 90, 100, 110, 120, 130, 150];
let currentZoomIdx = 2; // 100%

const BASE_WIDTH = 750; // ancho original del popup
const MAX_POPUP_WIDTH = 800; // límite máximo de Chrome

function applyZoom(level) {
  document.body.style.zoom = level + '%';
  // Ajustar ancho para que el contenido zoomeado siga cabiendo en el popup
  if (level > 100) {
    const adjusted = Math.floor(MAX_POPUP_WIDTH / (level / 100));
    document.body.style.width = adjusted + 'px';
  } else {
    document.body.style.width = BASE_WIDTH + 'px';
  }
  chrome.storage.local.set({ gaula_zoom: level });
}

document.getElementById('btnZoomIn')?.addEventListener('click', () => {
  if (currentZoomIdx < ZOOM_STEPS.length - 1) {
    currentZoomIdx++;
    applyZoom(ZOOM_STEPS[currentZoomIdx]);
  }
});

document.getElementById('btnZoomOut')?.addEventListener('click', () => {
  if (currentZoomIdx > 0) {
    currentZoomIdx--;
    applyZoom(ZOOM_STEPS[currentZoomIdx]);
  }
});

// Restaurar zoom guardado
chrome.storage.local.get('gaula_zoom', (res) => {
  if (res.gaula_zoom) {
    const idx = ZOOM_STEPS.indexOf(res.gaula_zoom);
    if (idx !== -1) {
      currentZoomIdx = idx;
      applyZoom(res.gaula_zoom);
    }
  }
});

// ============================================================
// INIT
// ============================================================
init();

// Sincroniza la versión visible en el header y en el footer del login con
// la versión real del manifest. Se actualiza solo en cada bump (3.2.0, 3.2.1…).
(function syncVersionFromManifest() {
  try {
    const v = chrome.runtime.getManifest().version;
    document.querySelectorAll('.version-tag, .version-tag-header').forEach((el) => {
      el.textContent = 'v' + v;
    });
  } catch (_) { /* fallback: deja lo que esté en el HTML */ }
})();

// ============================================================
// CHAT DE SOPORTE (docente <-> admin NEXBYTE)
// ============================================================
// Botón se inyecta en .header-right (a la izquierda de la campana).
// Click → abre panel fijo abajo a la derecha. Lee/escribe en
// support_messages. Imágenes via paste se suben a bucket support-images.
// Polling cada 5s mientras el panel esté abierto (sin realtime para no
// añadir complejidad). Aditivo, no toca lo existente.
(function initSupportChat() {
  let userId = null;
  let cachedToken = null;
  let pollIntervalId = null;
  let pendingImageBlob = null;
  let pendingImageName = null;
  let lastMessageCount = 0;

  function decodeJwtSub(token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return payload.sub || null;
    } catch { return null; }
  }

  // Cliente "Supabase ligero" basado en fetch directo a la API REST/Storage.
  // No depende de supabase-js (la UMD usa eval/new Function que el CSP de
  // Manifest V3 bloquea). Las RLS funcionan igual usando el JWT en
  // Authorization header.
  async function ensureSession() {
    if (!window.CONFIG?.SUPABASE_URL || !window.CONFIG?.SUPABASE_ANON_KEY) {
      console.warn('[support] CONFIG incompleta');
      return null;
    }
    const session = await sendMessage({ type: 'GET_SESSION' });
    if (!session?.ok || !session.token) {
      console.warn('[support] sesión no disponible', session);
      return null;
    }
    cachedToken = session.token;
    userId = session.user?.id || decodeJwtSub(session.token);
    if (!userId) {
      console.warn('[support] no se pudo determinar userId del JWT');
      return null;
    }
    return {
      url: window.CONFIG.SUPABASE_URL,
      anonKey: window.CONFIG.SUPABASE_ANON_KEY,
      token: session.token,
    };
  }

  function authHeaders(ctx, extra) {
    return Object.assign({
      'apikey': ctx.anonKey,
      'Authorization': `Bearer ${ctx.token}`,
    }, extra || {});
  }

  async function dbSelect(ctx, table, query) {
    const url = `${ctx.url}/rest/v1/${table}?${query}`;
    const res = await fetch(url, { headers: authHeaders(ctx, { 'Accept': 'application/json' }) });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`SELECT ${table} ${res.status}: ${text.slice(0, 200)}`);
    }
    return res.json();
  }

  async function dbCount(ctx, table, query) {
    const url = `${ctx.url}/rest/v1/${table}?${query}&select=id`;
    const res = await fetch(url, {
      headers: authHeaders(ctx, { 'Accept': 'application/json', 'Prefer': 'count=exact', 'Range-Unit': 'items', 'Range': '0-0' }),
    });
    if (!res.ok) return 0;
    const range = res.headers.get('content-range') || '*/0';
    const total = parseInt(range.split('/')[1], 10);
    return Number.isFinite(total) ? total : 0;
  }

  async function dbInsert(ctx, table, row) {
    const url = `${ctx.url}/rest/v1/${table}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: authHeaders(ctx, { 'Content-Type': 'application/json', 'Prefer': 'return=representation' }),
      body: JSON.stringify(row),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`INSERT ${table} ${res.status}: ${text.slice(0, 300)}`);
    }
    return res.json();
  }

  async function dbPatch(ctx, table, query, patch) {
    const url = `${ctx.url}/rest/v1/${table}?${query}`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: authHeaders(ctx, { 'Content-Type': 'application/json' }),
      body: JSON.stringify(patch),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`UPDATE ${table} ${res.status}: ${text.slice(0, 200)}`);
    }
  }

  async function storageUpload(ctx, bucket, path, blob) {
    const url = `${ctx.url}/storage/v1/object/${bucket}/${encodeURIComponent(path).replace(/%2F/g, '/')}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: authHeaders(ctx, { 'Content-Type': blob.type || 'application/octet-stream', 'x-upsert': 'false' }),
      body: blob,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`UPLOAD ${res.status}: ${text.slice(0, 200)}`);
    }
    return res.json().catch(() => ({}));
  }

  async function storageSign(ctx, bucket, path, expiresIn) {
    const url = `${ctx.url}/storage/v1/object/sign/${bucket}/${encodeURIComponent(path).replace(/%2F/g, '/')}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: authHeaders(ctx, { 'Content-Type': 'application/json' }),
      body: JSON.stringify({ expiresIn: expiresIn || 3600 }),
    });
    if (!res.ok) return null;
    const data = await res.json().catch(() => null);
    if (!data?.signedURL) return null;
    return ctx.url + data.signedURL;
  }

  function injectSupportButton() {
    const headerRight = document.querySelector('.header-right');
    if (!headerRight || document.getElementById('support-bell-btn')) return;
    const wrap = document.createElement('div');
    wrap.id = 'support-bell-wrap';
    wrap.style.cssText = 'display:inline-flex;align-items:center;margin-right:8px';
    wrap.innerHTML = `
      <button id="support-bell-btn" type="button" aria-label="Soporte" title="Soporte NEXBYTE" style="position:relative;background:rgba(255,255,255,0.12);border:1px solid rgba(255,255,255,0.18);border-radius:50%;width:32px;height:32px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
        </svg>
        <span id="support-badge" style="display:none;position:absolute;top:-2px;right:-2px;background:#ef4444;color:#fff;font-size:10px;font-weight:700;line-height:1;padding:3px 5px;border-radius:10px;min-width:16px;text-align:center;border:2px solid rgba(15,23,42,1)"></span>
      </button>
    `;
    headerRight.insertBefore(wrap, headerRight.firstChild);
    document.getElementById('support-bell-btn').addEventListener('click', toggleSupportPanel);
  }

  async function refreshUnreadBadge() {
    const ctx = await ensureSession();
    if (!ctx) return;
    try {
      const count = await dbCount(ctx, 'support_messages',
        `user_id=eq.${userId}&sender=eq.admin&read_by_user=eq.false`);
      const badge = document.getElementById('support-badge');
      if (!badge) return;
      if (count > 0) {
        badge.textContent = count > 9 ? '9+' : String(count);
        badge.style.display = 'block';
      } else {
        badge.style.display = 'none';
      }
    } catch (e) {
      console.warn('[support] badge error', e);
    }
  }

  async function loadMessages() {
    const ctx = await ensureSession();
    const list = document.getElementById('support-messages');
    if (!ctx || !list) return;
    let data;
    try {
      data = await dbSelect(ctx, 'support_messages',
        `user_id=eq.${userId}&order=created_at.asc&limit=200&select=id,sender,body,image_url,created_at,read_by_user`);
    } catch (e) {
      list.innerHTML = '<div style="color:#dc2626;text-align:center;padding:20px;font-size:12px">Error cargando mensajes: ' + escapeHtml(e.message) + '</div>';
      return;
    }
    if (!data || data.length === 0) {
      list.innerHTML = '<div style="color:#6b7280;text-align:center;padding:30px 20px;font-size:12px">No hay mensajes todavía.<br>Escribe abajo para iniciar la conversación.</div>';
      lastMessageCount = 0;
      return;
    }

    const isNew = data.length > lastMessageCount;
    lastMessageCount = data.length;

    list.innerHTML = '';
    let lastDate = '';
    for (const m of data) {
      const date = new Date(m.created_at);
      const dayStr = date.toLocaleDateString('es-EC', { day: 'numeric', month: 'short' });
      if (dayStr !== lastDate) {
        const sep = document.createElement('div');
        sep.style.cssText = 'text-align:center;margin:8px 0;font-size:10px;color:#9ca3af';
        sep.textContent = dayStr;
        list.appendChild(sep);
        lastDate = dayStr;
      }
      const isUser = m.sender === 'user';
      const bubble = document.createElement('div');
      bubble.style.cssText = 'display:flex;margin:4px 0;' + (isUser ? 'justify-content:flex-end' : 'justify-content:flex-start');
      const inner = document.createElement('div');
      inner.style.cssText = 'max-width:78%;padding:6px 10px;border-radius:12px;font-size:12px;line-height:1.4;' +
        (isUser ? 'background:#1d4ed8;color:#fff;border-bottom-right-radius:4px' : 'background:#fff;color:#111827;border:1px solid #e5e7eb;border-bottom-left-radius:4px');
      if (m.body) {
        const txt = document.createElement('div');
        txt.textContent = m.body;
        inner.appendChild(txt);
      }
      if (m.image_url) {
        const signedUrl = await storageSign(ctx, 'support-images', m.image_url, 3600);
        if (signedUrl) {
          const img = document.createElement('img');
          img.src = signedUrl;
          img.style.cssText = 'max-width:100%;border-radius:6px;margin-top:4px;cursor:pointer';
          img.addEventListener('click', () => chrome.tabs.create({ url: signedUrl }));
          inner.appendChild(img);
        }
      }
      const time = document.createElement('div');
      time.style.cssText = 'font-size:9px;opacity:0.7;margin-top:2px;text-align:right';
      time.textContent = date.toLocaleTimeString('es-EC', { hour: '2-digit', minute: '2-digit' });
      inner.appendChild(time);
      bubble.appendChild(inner);
      list.appendChild(bubble);
    }
    if (isNew) list.scrollTop = list.scrollHeight;

    const unreadAdminIds = data.filter((m) => m.sender === 'admin' && !m.read_by_user).map((m) => m.id);
    if (unreadAdminIds.length > 0) {
      try {
        await dbPatch(ctx, 'support_messages', `id=in.(${unreadAdminIds.join(',')})`, { read_by_user: true });
        refreshUnreadBadge();
      } catch (e) { console.warn('[support] mark-read error', e); }
    }
  }

  async function uploadImage(ctx, blob) {
    const ext = (blob.type || 'image/png').split('/')[1] || 'png';
    const path = `${userId}/${Date.now()}.${ext}`;
    try {
      await storageUpload(ctx, 'support-images', path, blob);
      console.log('[support] upload ok', path);
      return path;
    } catch (e) {
      console.error('[support] upload error', e);
      showChatError('Upload imagen: ' + e.message);
      return null;
    }
  }

  function showChatError(msg) {
    const list = document.getElementById('support-messages');
    if (!list) return;
    const err = document.createElement('div');
    err.style.cssText = 'background:#fee2e2;color:#991b1b;padding:8px 10px;margin:6px 0;border-radius:6px;font-size:11px;border:1px solid #fca5a5';
    err.textContent = '⚠ ' + msg;
    list.appendChild(err);
    list.scrollTop = list.scrollHeight;
  }

  async function sendMessageNow(body, imageBlob) {
    console.log('[support] sendMessageNow', { body, hasImage: !!imageBlob });
    const ctx = await ensureSession();
    if (!ctx) {
      showChatError('No hay sesión activa. Recarga la extensión y vuelve a iniciar sesión.');
      return false;
    }
    let image_url = null;
    if (imageBlob) {
      image_url = await uploadImage(ctx, imageBlob);
      if (!image_url) return false;
    }
    const payload = { user_id: userId, sender: 'user', body: body || null, image_url };
    console.log('[support] insert payload', payload);
    try {
      const data = await dbInsert(ctx, 'support_messages', payload);
      console.log('[support] insert ok', data);
      return true;
    } catch (e) {
      console.error('[support] insert error', e);
      showChatError('Error enviando: ' + e.message);
      return false;
    }
  }

  function clearPendingImage() {
    pendingImageBlob = null;
    pendingImageName = null;
    const preview = document.getElementById('support-image-preview');
    if (preview) preview.style.display = 'none';
  }

  function showPendingImage(blob, name) {
    pendingImageBlob = blob;
    pendingImageName = name || 'imagen.png';
    const preview = document.getElementById('support-image-preview');
    const nameEl = document.getElementById('support-image-name');
    if (preview && nameEl) {
      nameEl.textContent = pendingImageName + ' (' + Math.round(blob.size / 1024) + ' KB)';
      preview.style.display = 'flex';
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function startPolling() {
    if (pollIntervalId) return;
    pollIntervalId = setInterval(loadMessages, 5000);
  }
  function stopPolling() {
    if (pollIntervalId) { clearInterval(pollIntervalId); pollIntervalId = null; }
  }

  async function toggleSupportPanel() {
    const panel = document.getElementById('support-panel');
    if (!panel) return;
    const isOpen = panel.style.display === 'flex';
    if (isOpen) {
      panel.style.display = 'none';
      stopPolling();
    } else {
      panel.style.display = 'flex';
      await loadMessages();
      startPolling();
      const input = document.getElementById('support-input');
      if (input) input.focus();
    }
  }

  function setupPanelHandlers() {
    const closeBtn = document.getElementById('support-close');
    const form = document.getElementById('support-form');
    const input = document.getElementById('support-input');
    const removeImgBtn = document.getElementById('support-image-remove');
    if (!closeBtn || !form || !input || !removeImgBtn) return;

    closeBtn.addEventListener('click', () => {
      document.getElementById('support-panel').style.display = 'none';
      stopPolling();
    });

    removeImgBtn.addEventListener('click', clearPendingImage);

    input.addEventListener('paste', (e) => {
      const items = e.clipboardData?.items || [];
      for (const item of items) {
        if (item.type && item.type.indexOf('image') === 0) {
          const blob = item.getAsFile();
          if (blob) {
            showPendingImage(blob, blob.name || 'pegada.png');
            e.preventDefault();
            return;
          }
        }
      }
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        form.dispatchEvent(new Event('submit', { cancelable: true }));
      }
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const text = input.value.trim();
      if (!text && !pendingImageBlob) return;
      const sendBtn = document.getElementById('support-send');
      sendBtn.disabled = true;
      sendBtn.textContent = '...';
      const ok = await sendMessageNow(text, pendingImageBlob);
      sendBtn.disabled = false;
      sendBtn.textContent = 'Enviar';
      if (ok) {
        input.value = '';
        clearPendingImage();
        await loadMessages();
      }
    });
  }

  // Inicialización: solo cuando el usuario esté logueado y exista el header.
  // Reintentamos hasta que aparezca .header-right (carga asíncrona del init).
  let attempts = 0;
  const tryInit = setInterval(async () => {
    attempts++;
    const headerRight = document.querySelector('.header-right');
    if (headerRight) {
      injectSupportButton();
      setupPanelHandlers();
      await refreshUnreadBadge();
      clearInterval(tryInit);
    } else if (attempts > 30) {
      // 30 intentos × 200ms = 6s. Si aún no hay header, abortar (probablemente login).
      clearInterval(tryInit);
    }
  }, 200);
})();

// ============================================================
// FOOTER DE CRÉDITOS + ANUNCIO REMOTO
// ============================================================
// Carga datos editables (créditos, anuncio) desde nexbyte.pro/extension-info.json
// Esto permite cambiar textos, links y promociones sin re-publicar la extensión.
// Si el fetch falla, los elementos quedan ocultos: el popup funciona igual que antes.
(async function loadExtensionInfoFooter() {
  try {
    const url = 'https://nexbyte.pro/extension-info.json?t=' + Math.floor(Date.now() / 60000); // cache-bust 1 min
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) return;
    const info = await res.json();

    // Anuncio (banner azul). Si announcement es null/undefined, no aparece.
    if (info.announcement && typeof info.announcement === 'string' && info.announcement.trim()) {
      const ann = document.getElementById('ext-announcement');
      if (ann) {
        ann.textContent = info.announcement;
        ann.style.display = 'block';
        if (info.product_url) {
          ann.addEventListener('click', () => chrome.tabs.create({ url: info.product_url }));
        }
      }
    }

    // Footer de créditos. Solo se muestra si hay datos válidos.
    const footer = document.getElementById('ext-credits-footer');
    const line1 = document.getElementById('ext-credits-line1');
    const line2 = document.getElementById('ext-credits-line2');
    const links = document.getElementById('ext-credits-links');
    if (!footer || !line1 || !line2 || !links) return;

    const company = info.company?.name || 'NEXBYTE';
    const author = info.author?.name || '';
    const role = info.author?.role || '';
    // Versión: SIEMPRE del manifest (única fuente de verdad), nunca del JSON
    // remoto. El campo info.version_visible queda como fallback histórico.
    let version = '';
    try { version = chrome.runtime.getManifest().version; } catch (_) {}
    if (!version) version = info.version_visible || '';
    const productUrl = info.product_url || info.company?.url || 'https://nexbyte.pro';
    const supportUrl = info.support_url || 'https://nexbyte.pro';

    line1.textContent = `Generador de Aulas ${version ? 'v' + version : ''} · ${company}`.trim();
    line2.textContent = author ? `Por ${author}${role ? ' · ' + role : ''}` : '';

    // Links abren en nueva pestaña usando chrome.tabs.create (la extension no tiene CSP de target=_blank)
    links.innerHTML = '';
    const mkLink = (label, url) => {
      const a = document.createElement('a');
      a.textContent = label;
      a.href = url;
      a.style.color = '#1d4ed8';
      a.style.textDecoration = 'none';
      a.style.cursor = 'pointer';
      a.addEventListener('click', (e) => {
        e.preventDefault();
        chrome.tabs.create({ url });
      });
      return a;
    };
    links.appendChild(mkLink('Producto ↗', productUrl));
    if (supportUrl && supportUrl !== productUrl) {
      const sep = document.createElement('span');
      sep.textContent = '·';
      sep.style.color = '#9ca3af';
      links.appendChild(sep);
      links.appendChild(mkLink('Soporte ↗', supportUrl));
    }

    footer.style.display = 'block';
  } catch (_) {
    // Silencio absoluto: si falla el fetch, el popup funciona idéntico al anterior.
  }
})();

// ============================================================
// CAMPANA DE NOTIFICACIONES
// ============================================================
// Carga `nexbyte.pro/notifications.json`, muestra badge con no-leídas,
// dropdown estilo Instagram. Estado de leídas en chrome.storage.local.
// Si el fetch falla o no hay items, la campana no aparece.
(async function loadNotificationsBell() {
  const NOTIF_URL = 'https://nexbyte.pro/notifications.json?t=' + Math.floor(Date.now() / 60000);
  const STORAGE_KEY = 'gaula_notif_read_ids';

  function getReadIds() {
    return new Promise((resolve) => {
      chrome.storage.local.get(STORAGE_KEY, (res) => {
        resolve(Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY] : []);
      });
    });
  }

  function setReadIds(ids) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [STORAGE_KEY]: ids }, resolve);
    });
  }

  function fmtDate(s) {
    try {
      const d = new Date(s);
      return d.toLocaleDateString('es-EC', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch { return s || ''; }
  }

  try {
    const res = await fetch(NOTIF_URL, { cache: 'no-store' });
    if (!res.ok) return;
    const data = await res.json();
    const items = Array.isArray(data?.items) ? data.items : [];
    if (items.length === 0) return;

    const wrap = document.getElementById('notif-bell-wrap');
    const btn = document.getElementById('notif-bell-btn');
    const badge = document.getElementById('notif-badge');
    const dropdown = document.getElementById('notif-dropdown');
    const list = document.getElementById('notif-list');
    const markAllBtn = document.getElementById('notif-mark-all');
    if (!wrap || !btn || !badge || !dropdown || !list || !markAllBtn) return;

    // Reubicar el bell DENTRO del header-right del popup (post-login) para que
    // no choque con foto/perfil/cerrar sesión. Si no existe el header-right
    // (pantalla de login o no-sub), queda como fixed top-right (fallback).
    const headerRight = document.querySelector('.header-right');
    if (headerRight && headerRight.parentNode) {
      // Convertir el wrapper de fixed a inline-block dentro del header
      wrap.style.position = 'static';
      wrap.style.top = 'auto';
      wrap.style.right = 'auto';
      wrap.style.marginRight = '8px';
      wrap.style.display = 'inline-flex';
      wrap.style.alignItems = 'center';
      // Botón un poco más pequeño para integrarse al header
      btn.style.width = '32px';
      btn.style.height = '32px';
      btn.style.background = 'rgba(255,255,255,0.12)';
      btn.style.borderColor = 'rgba(255,255,255,0.18)';
      btn.querySelectorAll('svg').forEach(s => s.setAttribute('stroke', '#ffffff'));
      // Insertar al inicio del header-right (a la izquierda del resto)
      headerRight.insertBefore(wrap, headerRight.firstChild);
    }

    let readIds = await getReadIds();

    function render() {
      const unread = items.filter((it) => it && it.id && !readIds.includes(it.id));
      // Badge
      if (unread.length > 0) {
        badge.textContent = unread.length > 9 ? '9+' : String(unread.length);
        badge.style.display = 'block';
      } else {
        badge.style.display = 'none';
      }
      // Lista (ordenada: no-leídas primero, luego más recientes por fecha)
      const sorted = [...items].sort((a, b) => {
        const aRead = readIds.includes(a.id) ? 1 : 0;
        const bRead = readIds.includes(b.id) ? 1 : 0;
        if (aRead !== bRead) return aRead - bRead;
        return (b.date || '').localeCompare(a.date || '');
      });
      list.innerHTML = '';
      sorted.forEach((it) => {
        if (!it?.id) return;
        const isRead = readIds.includes(it.id);
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 12px;border-bottom:1px solid #f3f4f6;cursor:pointer;background:' + (isRead ? '#fff' : '#eff6ff') + ';transition:background 0.15s';
        item.onmouseenter = () => { item.style.background = '#f3f4f6'; };
        item.onmouseleave = () => { item.style.background = isRead ? '#fff' : '#eff6ff'; };

        const typeBadge = it.type === 'promo' ? '<span style="display:inline-block;font-size:9px;background:#fef3c7;color:#92400e;padding:1px 6px;border-radius:6px;margin-right:4px;text-transform:uppercase;letter-spacing:0.5px">Promo</span>'
          : it.type === 'release' ? '<span style="display:inline-block;font-size:9px;background:#dbeafe;color:#1e40af;padding:1px 6px;border-radius:6px;margin-right:4px;text-transform:uppercase;letter-spacing:0.5px">Versión</span>'
          : '';

        const titleEl = document.createElement('div');
        titleEl.style.cssText = 'font-size:13px;font-weight:600;color:#111827;margin-bottom:2px;display:flex;align-items:center;gap:4px';
        titleEl.innerHTML = (isRead ? '' : '<span style="display:inline-block;width:6px;height:6px;background:#1d4ed8;border-radius:50%;flex-shrink:0"></span>') +
          typeBadge + '<span>' + escapeHtml(it.title || '') + '</span>';

        const bodyEl = document.createElement('div');
        bodyEl.style.cssText = 'font-size:12px;color:#4b5563;line-height:1.4;margin-bottom:4px';
        bodyEl.textContent = it.body || '';

        const dateEl = document.createElement('div');
        dateEl.style.cssText = 'font-size:10px;color:#9ca3af';
        dateEl.textContent = fmtDate(it.date);

        item.appendChild(titleEl);
        item.appendChild(bodyEl);
        item.appendChild(dateEl);

        item.addEventListener('click', async () => {
          if (!isRead) {
            readIds = [...readIds, it.id];
            await setReadIds(readIds);
            render();
          }
          if (it.url) chrome.tabs.create({ url: it.url });
        });
        list.appendChild(item);
      });
    }

    function escapeHtml(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = dropdown.style.display !== 'none' && dropdown.style.display !== '';
      dropdown.style.display = open ? 'none' : 'block';
    });

    document.addEventListener('click', (e) => {
      if (!wrap.contains(e.target)) dropdown.style.display = 'none';
    });

    markAllBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      readIds = items.map((it) => it.id).filter(Boolean);
      await setReadIds(readIds);
      render();
    });

    render();
    wrap.style.display = 'block';
  } catch (_) {
    // Silencio absoluto: sin notificaciones, el popup funciona idéntico.
  }
})();
