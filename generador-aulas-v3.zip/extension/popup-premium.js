/**
 * Generador de cursos Premium — orquesta la generación de 9 PPT con prime+burst
 * y materializa los .pptx en cliente. NO modifica código existente.
 *
 * Flujo:
 *   1. Verifica sesión + plan_name='premium'
 *   2. Recolecta inputs (datos curso, sílabo, libros)
 *   3. Valida que los PDFs tengan texto extraíble (rechaza escaneados)
 *   4. Prime+burst: 1 llamada inicial (crea cache) → 8 paralelas (leen cache)
 *   5. Renderiza tarjetas de resultado con preview/descarga
 *   6. Materializa .pptx con pptxgenjs cuando el usuario lo descarga
 */

// ============================================================
// Estado global
// ============================================================
const state = {
  syllabusFile: null,
  syllabusText: '',
  syllabusPages: 0,
  bookFiles: [],   // [{file, text, pages}]
  generations: {}, // key: "rda{i}-slot{s}" → { status, content, cost, error }
  session: null,
  userId: null,
  courseKey: null, // hash del input para cache server-side
};

const MAX_PPTS = 9;            // 3 RdA × 3 slots = full curso
const MAX_BOOKS = 3;
const MAX_TOTAL_PAGES = 100;
const MIN_TEXT_PER_PAGE = 50;  // chars/página mínimo para considerar "no escaneado"
const COST_PER_PPT = 0.055;    // estimado USD por PPT — ajusta cuando midas real

// ============================================================
// Utilidades
// ============================================================
function $(id) { return document.getElementById(id); }
function show(id) { const e = $(id); if (e) e.style.display = 'block'; }
function hide(id) { const e = $(id); if (e) e.style.display = 'none'; }

function decodeJwtSub(token) {
  try {
    const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    return payload.sub || null;
  } catch { return null; }
}

async function getSessionFromStorage() {
  const stored = await new Promise((res) => chrome.storage.local.get('session', res));
  if (!stored?.session?.access_token) return null;
  return {
    token: stored.session.access_token,
    userId: decodeJwtSub(stored.session.access_token),
  };
}

function showAlert(target, msg, type) {
  const el = $(target);
  if (!el) return;
  el.className = 'alert alert-' + (type || 'info');
  el.textContent = msg;
  el.style.display = 'block';
}

async function fnv1aHash(str) {
  // Hash simple para courseKey (cache stable)
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16);
}

// ============================================================
// PDF text extraction & validation (no escaneados)
// ============================================================
async function extractPdfText(file) {
  const ab = await file.arrayBuffer();
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  const pdf = await pdfjsLib.getDocument({ data: ab }).promise;
  let allText = '';
  let pageStats = [];  // {page, charCount}
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const pageText = content.items.map((it) => it.str).join(' ');
    allText += pageText + '\n';
    pageStats.push({ page: i, chars: pageText.length });
  }
  // Detectar escaneado: si el promedio de chars/página es muy bajo
  const totalChars = pageStats.reduce((s, p) => s + p.chars, 0);
  const avgPerPage = totalChars / Math.max(pdf.numPages, 1);
  const isScanned = avgPerPage < MIN_TEXT_PER_PAGE;
  return { text: allText, pages: pdf.numPages, isScanned, avgPerPage };
}

// ============================================================
// Auth check + premium gate
// ============================================================
async function initAuth() {
  state.session = await getSessionFromStorage();
  if (!state.session?.token || !state.session.userId) {
    show('auth-warning');
    return false;
  }
  state.userId = state.session.userId;

  // Verificar plan
  try {
    const today = new Date().toISOString().split('T')[0];
    const url = `${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?user_id=eq.${state.userId}&status=eq.active&period_end=gte.${today}&select=plan_name&order=created_at.desc&limit=1`;
    const res = await fetch(url, {
      headers: { 'apikey': CONFIG.SUPABASE_ANON_KEY, 'Authorization': `Bearer ${state.session.token}` },
    });
    if (!res.ok) throw new Error('No se pudo verificar suscripción');
    const rows = await res.json();
    const planName = rows?.[0]?.plan_name;
    if (planName !== 'premium') {
      $('auth-warning').textContent = `Tu plan actual es "${planName || 'ninguno'}". Esta función requiere plan Premium.`;
      show('auth-warning');
      return false;
    }
    return true;
  } catch (e) {
    $('auth-warning').textContent = 'Error verificando plan: ' + e.message;
    show('auth-warning');
    return false;
  }
}

// ============================================================
// Form handlers
// ============================================================
function getSelectedCount() {
  const sel = $('i-ppt-count');
  const n = parseInt(sel?.value || '9', 10);
  return Math.max(1, Math.min(MAX_PPTS, n));
}

function updateCostEstimate() {
  const n = getSelectedCount();
  const minutes = Math.max(1, Math.ceil(n * 0.7));
  const cost = (n * COST_PER_PPT).toFixed(2);
  const hint = $('gen-hint');
  const btn = $('btn-generate');
  const costEl = $('cost-estimate');
  if (hint) hint.textContent = `${n} PPT · ~${minutes} min · costo estimado ~$${cost}`;
  if (btn && !btn.disabled) btn.textContent = `🚀 Generar ${n} PPT con IA`;
  else if (btn) btn.textContent = `🚀 Generar ${n} PPT con IA`;
  if (costEl) costEl.textContent = `≈ $${cost}`;
}

function setupFormHandlers() {
  // Sílabo
  const dropSyllabus = $('drop-syllabus');
  const fileSyllabus = $('file-syllabus');
  dropSyllabus.addEventListener('click', () => fileSyllabus.click());
  dropSyllabus.addEventListener('dragover', (e) => { e.preventDefault(); dropSyllabus.classList.add('dragover'); });
  dropSyllabus.addEventListener('dragleave', () => dropSyllabus.classList.remove('dragover'));
  dropSyllabus.addEventListener('drop', (e) => {
    e.preventDefault(); dropSyllabus.classList.remove('dragover');
    if (e.dataTransfer.files[0]) handleSyllabus(e.dataTransfer.files[0]);
  });
  fileSyllabus.addEventListener('change', () => fileSyllabus.files[0] && handleSyllabus(fileSyllabus.files[0]));

  // Libros
  const dropBooks = $('drop-books');
  const fileBooks = $('file-books');
  dropBooks.addEventListener('click', () => fileBooks.click());
  dropBooks.addEventListener('dragover', (e) => { e.preventDefault(); dropBooks.classList.add('dragover'); });
  dropBooks.addEventListener('dragleave', () => dropBooks.classList.remove('dragover'));
  dropBooks.addEventListener('drop', (e) => {
    e.preventDefault(); dropBooks.classList.remove('dragover');
    [...e.dataTransfer.files].forEach(handleBook);
  });
  fileBooks.addEventListener('change', () => [...fileBooks.files].forEach(handleBook));

  // Inputs de datos
  ['i-asignatura', 'i-docente', 'i-carrera', 'i-repotenciada'].forEach((id) => {
    const el = $(id);
    if (el) el.addEventListener('change', updateButtonState);
    if (el && el.type === 'text') el.addEventListener('input', updateButtonState);
  });

  // Selector de cantidad PPTs (modo prueba) — recalcula costo y label
  const countSel = $('i-ppt-count');
  if (countSel) {
    countSel.addEventListener('change', updateCostEstimate);
    updateCostEstimate();
  }

  // Botón generar
  $('btn-generate').addEventListener('click', startGeneration);
}

async function handleSyllabus(file) {
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    alert('El sílabo debe ser PDF');
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    alert('PDF muy grande (>10 MB)');
    return;
  }
  const list = $('file-list-syllabus');
  list.innerHTML = `<div class="file-item"><span>⏳</span><span class="file-name">${file.name}</span><span class="file-meta">analizando...</span></div>`;
  try {
    const result = await extractPdfText(file);
    if (result.isScanned) {
      list.innerHTML = `<div class="file-item error"><span>⚠</span><span class="file-name">${file.name}</span><span class="file-meta">PDF escaneado (${Math.round(result.avgPerPage)} chars/pág) — sube uno con texto extraíble</span></div>`;
      state.syllabusFile = null;
      state.syllabusText = '';
      updateButtonState();
      return;
    }
    state.syllabusFile = file;
    state.syllabusText = result.text;
    state.syllabusPages = result.pages;
    list.innerHTML = `<div class="file-item"><span>✓</span><span class="file-name">${file.name}</span><span class="file-meta">${result.pages} págs · ${Math.round(result.text.length/1000)}K chars</span><button class="file-remove" id="rm-syllabus">×</button></div>`;
    $('rm-syllabus').addEventListener('click', () => {
      state.syllabusFile = null; state.syllabusText = '';
      list.innerHTML = '';
      $('file-syllabus').value = '';
      updateButtonState();
    });
    $('step-syllabus').classList.add('complete');
    updateButtonState();
  } catch (e) {
    list.innerHTML = `<div class="file-item error"><span>⚠</span><span class="file-name">${file.name}</span><span class="file-meta">Error: ${e.message}</span></div>`;
  }
}

async function handleBook(file) {
  if (state.bookFiles.length >= MAX_BOOKS) {
    alert(`Máximo ${MAX_BOOKS} libros`);
    return;
  }
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    alert('Solo PDF');
    return;
  }
  if (file.size > 20 * 1024 * 1024) {
    alert(`${file.name} muy grande (>20 MB)`);
    return;
  }
  const idx = state.bookFiles.length;
  state.bookFiles.push({ file, text: '', pages: 0, status: 'analyzing' });
  renderBookList();
  try {
    const result = await extractPdfText(file);
    if (result.isScanned) {
      state.bookFiles[idx] = { file, text: '', pages: result.pages, status: 'scanned', avgPerPage: result.avgPerPage };
      renderBookList();
      return;
    }
    state.bookFiles[idx] = { file, text: result.text, pages: result.pages, status: 'ok' };
    renderBookList();
    updateButtonState();
  } catch (e) {
    state.bookFiles[idx].status = 'error';
    state.bookFiles[idx].error = e.message;
    renderBookList();
  }
}

function renderBookList() {
  const list = $('file-list-books');
  list.innerHTML = '';
  let totalPages = 0;
  state.bookFiles.forEach((b, i) => {
    if (b.status === 'ok') totalPages += b.pages;
    const cls = b.status === 'ok' ? '' : 'error';
    let meta = '';
    if (b.status === 'analyzing') meta = 'analizando...';
    else if (b.status === 'ok') meta = `${b.pages} págs · ${Math.round(b.text.length/1000)}K chars`;
    else if (b.status === 'scanned') meta = `escaneado (${Math.round(b.avgPerPage)} c/pág) — rechazado`;
    else meta = b.error || 'error';
    const div = document.createElement('div');
    div.className = `file-item ${cls}`;
    div.innerHTML = `<span>${b.status === 'ok' ? '✓' : '⚠'}</span><span class="file-name">${b.file.name}</span><span class="file-meta">${meta}</span><button class="file-remove" data-idx="${i}">×</button>`;
    list.appendChild(div);
  });
  list.querySelectorAll('.file-remove').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const idx = parseInt(e.currentTarget.dataset.idx);
      state.bookFiles.splice(idx, 1);
      renderBookList();
      updateButtonState();
    });
  });
  if (totalPages > MAX_TOTAL_PAGES) {
    const warn = document.createElement('div');
    warn.className = 'alert alert-warning';
    warn.textContent = `${totalPages} páginas en total. Solo se usarán las primeras ${MAX_TOTAL_PAGES} (truncado por la IA).`;
    list.appendChild(warn);
  }
  if (state.bookFiles.some((b) => b.status === 'ok')) {
    $('step-books').classList.add('complete');
  } else {
    $('step-books').classList.remove('complete');
  }
}

function updateButtonState() {
  const asignatura = $('i-asignatura').value.trim();
  const docente = $('i-docente').value.trim();
  if (asignatura && docente) $('step-info').classList.add('complete');
  else $('step-info').classList.remove('complete');

  const ready = !!(asignatura && docente && state.syllabusFile && state.syllabusText);
  $('btn-generate').disabled = !ready;
  // Refrescar label con el N actual
  if (typeof updateCostEstimate === 'function') updateCostEstimate();
}

// ============================================================
// Generación: prime + burst
// ============================================================
async function callGenerateCourseResource(payload) {
  const url = `${CONFIG.SUPABASE_URL}/functions/v1/generate-course-resource`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${state.session.token}`,
      'apikey': CONFIG.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.ok) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data;
}

async function consumeCredit() {
  // Llama a execute-action para consumir un crédito de 'generate_course_ppt'
  const url = `${CONFIG.SUPABASE_URL}/functions/v1/execute-action`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${state.session.token}`,
      'apikey': CONFIG.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ action: 'generate_course_ppt', payload: {} }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.ok) {
    throw new Error(data.error || `Crédito no disponible (HTTP ${res.status})`);
  }
  return data;
}

function buildBookText() {
  return state.bookFiles
    .filter((b) => b.status === 'ok')
    .map((b) => `===== ${b.file.name} =====\n${b.text}`)
    .join('\n\n');
}

function setProgress(done, total, label) {
  $('gen-progress-count').textContent = `${done}/${total}`;
  $('gen-progress-fill').style.width = `${(done / total) * 100}%`;
  if (label) $('gen-progress-label').textContent = label;
}

function updateResultCard(key, status, content, error) {
  state.generations[key] = { status, content, error };
  let card = $(`card-${key}`);
  const grid = $('results-grid');
  if (!card) {
    card = document.createElement('div');
    card.id = `card-${key}`;
    card.className = 'result-card';
    grid.appendChild(card);
  }
  const [rdaPart, slotPart] = key.split('-');
  const rda = parseInt(rdaPart.replace('rda', ''));
  const slot = parseInt(slotPart.replace('slot', ''));
  card.classList.remove('done', 'pending', 'error');
  card.classList.add(status);
  let inner = `<div class="result-status ${status}">${status === 'done' ? '✓ Listo' : status === 'pending' ? '⏳ Generando' : '⚠ Error'}</div>`;
  inner += `<div class="result-title">RdA ${rda + 1} · PPT ${slot + 1}</div>`;
  if (status === 'done' && content) {
    const slidesCount = (content.slides || []).length;
    inner += `<div class="result-meta">${slidesCount} slides · "${(content.meta?.title || 'PPT').slice(0, 50)}"</div>`;
    inner += `<div class="result-actions"><button class="btn-secondary" data-key="${key}" data-action="download">Descargar .pptx</button></div>`;
  } else if (status === 'error') {
    inner += `<div class="result-meta" style="color:#991b1b">${error || 'Error'}</div>`;
    inner += `<div class="result-actions"><button class="btn-secondary" data-key="${key}" data-action="retry">Reintentar</button></div>`;
  } else {
    inner += `<div class="result-meta">Esperando IA...</div>`;
  }
  card.innerHTML = inner;
  card.querySelectorAll('button[data-action]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const k = e.currentTarget.dataset.key;
      const act = e.currentTarget.dataset.action;
      if (act === 'download') downloadPpt(k);
      else if (act === 'retry') retrySingle(k);
    });
  });
}

async function generateOne(rdaIndex, resourceSlot) {
  const key = `rda${rdaIndex}-slot${resourceSlot}`;
  updateResultCard(key, 'pending');
  try {
    const data = await callGenerateCourseResource({
      courseKey: state.courseKey,
      courseLabel: $('i-asignatura').value.trim(),
      repotenciada: $('i-repotenciada').checked,
      teacherName: $('i-docente').value.trim(),
      rdaIndex,
      resourceType: 'ppt',
      resourceSlot,
      criterio: resourceSlot + 1,
      syllabusText: state.syllabusText,
      booksText: buildBookText(),
    });
    updateResultCard(key, 'done', data.content);
    return true;
  } catch (e) {
    updateResultCard(key, 'error', null, e.message);
    return false;
  }
}

// Construye lista de N pares (rda, slot) en orden secuencial:
// rda0-slot0 → rda0-slot1 → rda0-slot2 → rda1-slot0 → ... → rda2-slot2
function buildJobList(n) {
  const jobs = [];
  for (let r = 0; r < 3; r++) {
    for (let s = 0; s < 3; s++) {
      if (jobs.length >= n) return jobs;
      jobs.push({ r, s });
    }
  }
  return jobs;
}

async function startGeneration() {
  const total = getSelectedCount();
  $('btn-generate').disabled = true;
  hide('gen-status');
  show('gen-progress');
  setProgress(0, total, 'Verificando crédito...');

  // Hash estable del input para que el backend reuse cache
  const inputForHash = state.syllabusText.slice(0, 5000) + '|' + buildBookText().slice(0, 5000) + '|' + $('i-asignatura').value;
  state.courseKey = 'course-' + (await fnv1aHash(inputForHash));

  // 1. Consumir crédito (gate). Para modo prueba (1 PPT) igual consume 1 crédito.
  try {
    await consumeCredit();
  } catch (e) {
    showAlert('gen-status', 'Error de crédito: ' + e.message, 'error');
    hide('gen-progress');
    $('btn-generate').disabled = false;
    return;
  }

  const jobs = buildJobList(total);

  // 2. Prime: primera llamada sola (escribe cache de Claude). Solo si total >= 2;
  // si solo es 1 PPT, no hay burst, todo se hace en el "prime".
  setProgress(0, total, 'Iniciando IA (creando caché)...');
  const first = jobs[0];
  const primeOk = await generateOne(first.r, first.s);
  if (!primeOk) {
    showAlert('gen-status', 'Falló la primera generación. Revisa el panel y reintenta.', 'error');
    hide('gen-progress');
    $('btn-generate').disabled = false;
    return;
  }

  if (total === 1) {
    setProgress(1, 1, '✓ Generación completa');
    showAlert('gen-status', 'PPT generado. Descárgalo desde la tarjeta.', 'info');
    $('btn-generate').disabled = false;
    $('btn-generate').textContent = '🔄 Re-generar';
    return;
  }

  setProgress(1, total, `Primera lista — generando ${total - 1} restantes en paralelo...`);

  // 3. Burst: las restantes en paralelo (leen cache)
  const remaining = jobs.slice(1);
  let done = 1;
  await Promise.all(remaining.map(async ({ r, s }) => {
    await generateOne(r, s);
    done++;
    setProgress(done, total, `Generando paralelo... (${done}/${total})`);
  }));

  setProgress(total, total, '✓ Generación completa');
  showAlert('gen-status', `${total} PPT generados. Descarga los .pptx desde cada tarjeta. Revisa antes de inyectar a Moodle (próxima versión).`, 'info');
  $('btn-generate').disabled = false;
  $('btn-generate').textContent = '🔄 Re-generar';
}

async function retrySingle(key) {
  const m = key.match(/rda(\d)-slot(\d)/);
  if (!m) return;
  await generateOne(parseInt(m[1]), parseInt(m[2]));
}

// ============================================================
// Materialización a .pptx con pptxgenjs
// ============================================================
function downloadPpt(key) {
  const gen = state.generations[key];
  if (!gen || !gen.content) return;
  const content = gen.content;
  const meta = content.meta || {};
  const PptxGenJS = window.PptxGenJS;
  if (!PptxGenJS) { alert('pptxgenjs no cargó'); return; }
  const pres = new PptxGenJS();
  pres.layout = 'LAYOUT_WIDE';
  pres.title = meta.title || 'PPT';
  pres.author = meta.teacher || 'NEXBYTE';
  pres.company = 'PUCESE';

  const COLORS = { primary: '1A237E', accent: '1565C0', light: 'E3F2FD', text: '1F2937', white: 'FFFFFF', muted: '4B5563' };

  for (const s of (content.slides || [])) {
    const slide = pres.addSlide();
    const layout = (s.layout || 'content').toLowerCase();
    if (layout === 'title') {
      slide.background = { color: COLORS.primary };
      slide.addText(s.title || '', { x: 0.5, y: 2.4, w: 12.3, h: 1.5, fontSize: 36, bold: true, color: COLORS.white, align: 'center' });
      if (s.subtitle) slide.addText(s.subtitle, { x: 0.5, y: 4.1, w: 12.3, h: 1.5, fontSize: 16, color: COLORS.light, align: 'center' });
    } else if (layout === 'two-column' || layout === 'twocolumn') {
      slide.background = { color: COLORS.white };
      slide.addShape('rect', { x: 0, y: 0, w: 13.33, h: 0.9, fill: { color: COLORS.primary } });
      slide.addText(s.title || '', { x: 0.4, y: 0.15, w: 12.5, h: 0.6, fontSize: 22, bold: true, color: COLORS.white });
      if (s.leftTitle) slide.addText(s.leftTitle, { x: 0.5, y: 1.1, w: 6, h: 0.5, fontSize: 16, bold: true, color: COLORS.accent });
      if (s.rightTitle) slide.addText(s.rightTitle, { x: 6.8, y: 1.1, w: 6, h: 0.5, fontSize: 16, bold: true, color: COLORS.accent });
      slide.addText((s.leftBullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 14, color: COLORS.text, paraSpaceAfter: 4 } })), { x: 0.5, y: 1.7, w: 6, h: 5 });
      slide.addText((s.rightBullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 14, color: COLORS.text, paraSpaceAfter: 4 } })), { x: 6.8, y: 1.7, w: 6, h: 5 });
      if (s.notes) slide.addNotes(s.notes);
    } else {
      slide.background = { color: COLORS.white };
      slide.addShape('rect', { x: 0, y: 0, w: 13.33, h: 0.9, fill: { color: COLORS.primary } });
      slide.addText(s.title || '', { x: 0.4, y: 0.15, w: 12.5, h: 0.6, fontSize: 22, bold: true, color: COLORS.white });
      const bullets = (s.bullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 16, color: COLORS.text, paraSpaceAfter: 6 } }));
      slide.addText(bullets.length ? bullets : [{ text: '(sin bullets)', options: { italic: true, color: COLORS.muted } }], { x: 0.5, y: 1.1, w: s.imageHint ? 8.2 : 12.4, h: 5.5 });
      if (s.imageHint) {
        slide.addShape('rect', { x: 9, y: 1.3, w: 3.9, h: 4, fill: { color: COLORS.light }, line: { color: COLORS.accent, width: 1, dashType: 'dash' } });
        slide.addText('IMAGEN SUGERIDA:\n' + s.imageHint, { x: 9.1, y: 1.5, w: 3.7, h: 3.6, fontSize: 11, italic: true, color: COLORS.muted, align: 'center', valign: 'middle' });
      }
      if (s.notes) slide.addNotes(s.notes);
    }
  }

  const fileName = `${($('i-asignatura').value || 'curso').replace(/[^a-zA-Z0-9_-]/g, '_')}_${key}.pptx`;
  pres.writeFile({ fileName });
}

// ============================================================
// Init
// ============================================================
(async function init() {
  setupFormHandlers();
  const ok = await initAuth();
  if (!ok) {
    document.querySelectorAll('.step-card').forEach((c) => c.classList.add('disabled'));
  }
})();
