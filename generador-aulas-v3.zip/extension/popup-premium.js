/**
 * Generador de cursos Premium — orquesta el flujo map-reduce + plan-with-contrast.
 *
 * Flujo nuevo (v3.6.4+):
 *   1. Verifica sesión + plan_name='premium'
 *   2. Recolecta inputs (datos curso, sílabo, libros) — libros completos hasta 1500 págs
 *   3. Click "Procesar y proponer plan":
 *      a) Resume cada libro vía summarize-book (Haiku, cache global por hash)
 *      b) Llama plan-course (Sonnet) con sílabo + resúmenes → plan + coverage_matrix
 *      c) Renderiza UI de aprobación: plan primero, gaps banner arriba, matriz colapsable
 *   4. Click "Aprobar y generar PPTs":
 *      a) Por cada slot: consume_action_v2 + render-course-slot (Haiku)
 *      b) Renderiza tarjetas de resultado
 *   5. Materializa .pptx con pptxgenjs cuando el usuario descarga.
 *
 * Costos típicos (validados con Haiku 4.5 + Sonnet 4.6 en Etapa PLAN):
 *   - Resumen libro 700 págs nuevo: ~$0.05 (gratis si otro docente ya lo subió)
 *   - Plan + contraste: ~$0.04
 *   - Render por PPT: ~$0.008
 *   - Curso 9 PPTs end-to-end: ~$0.16
 */

// ============================================================
// Estado global
// ============================================================
const state = {
  syllabusFile: null,
  syllabusText: '',
  syllabusPages: 0,
  bookFiles: [],          // [{file, text, pages, hash, status}]
  generations: {},        // key: "rda{i}-slot{s}" → { status, content, error }
  session: null,
  userId: null,
  courseKey: null,
  bookHashes: [],         // sha256 del texto de cada libro (post summarize-book)
  plan: null,             // { syllabus_extracted, coverage_matrix, gaps, surplus, plan }
  planId: null,
  cost: { summarize: 0, plan: 0, render: 0 },
};

const MAX_PPTS = 9;
const MAX_BOOKS = 3;
const MAX_TOTAL_PAGES = 1500;
const MIN_TEXT_PER_PAGE = 50;

// Estimaciones de costo (real-time se actualiza a medida que llegan respuestas)
const EST_COST_SUMMARIZE = 0.05;   // un libro promedio
const EST_COST_PLAN = 0.04;
const EST_COST_PER_PPT = 0.008;

// ============================================================
// Utilidades
// ============================================================
function $(id) { return document.getElementById(id); }
function show(id) { const e = $(id); if (e) e.style.display = 'block'; }
function hide(id) { const e = $(id); if (e) e.style.display = 'none'; }

function decodeJwtSub(token) {
  try {
    const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    return payload.sub || null;
  } catch { return null; }
}

async function getSessionFromStorage() {
  const stored = await new Promise((res) => chrome.storage.local.get('session', res));
  if (!stored?.session?.access_token) return null;
  return {
    token: stored.session.access_token,
    userId: decodeJwtSub(stored.session.access_token),
  };
}

function showAlert(target, msg, type) {
  const el = $(target);
  if (!el) return;
  el.className = 'alert alert-' + (type || 'info');
  el.textContent = msg;
  el.style.display = 'block';
}

async function fnv1aHash(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16);
}

async function sha256Hex(text) {
  const buf = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function escHtml(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ============================================================
// Costo en vivo
// ============================================================
function costFmt(usd) { return '$' + (usd || 0).toFixed(4); }

function refreshCostTicker() {
  const total = state.cost.summarize + state.cost.plan + state.cost.render;
  const ct = $('cost-ticker');
  if (ct) ct.style.display = 'block';
  if ($('ct-summarize')) $('ct-summarize').textContent = costFmt(state.cost.summarize);
  if ($('ct-plan')) $('ct-plan').textContent = costFmt(state.cost.plan);
  if ($('ct-render')) $('ct-render').textContent = costFmt(state.cost.render);
  if ($('ct-total')) $('ct-total').textContent = costFmt(total);
}

// ============================================================
// PDF text extraction
// ============================================================
async function extractPdfText(file) {
  const ab = await file.arrayBuffer();
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  const pdf = await pdfjsLib.getDocument({ data: ab }).promise;
  let allText = '';
  let pageStats = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const pageText = content.items.map((it) => it.str).join(' ');
    allText += pageText + '\n';
    pageStats.push({ page: i, chars: pageText.length });
  }
  const totalChars = pageStats.reduce((s, p) => s + p.chars, 0);
  const avgPerPage = totalChars / Math.max(pdf.numPages, 1);
  const isScanned = avgPerPage < MIN_TEXT_PER_PAGE;
  return { text: allText, pages: pdf.numPages, isScanned, avgPerPage };
}

// ============================================================
// Auth + premium gate
// ============================================================
async function initAuth() {
  state.session = await getSessionFromStorage();
  if (!state.session?.token || !state.session.userId) {
    show('auth-warning');
    return false;
  }
  state.userId = state.session.userId;

  try {
    const today = new Date().toISOString().split('T')[0];
    const url = `${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?user_id=eq.${state.userId}&status=eq.active&period_end=gte.${today}&select=plan_name&order=created_at.desc&limit=1`;
    const res = await fetch(url, {
      headers: { 'apikey': CONFIG.SUPABASE_ANON_KEY, 'Authorization': `Bearer ${state.session.token}` },
    });
    if (!res.ok) throw new Error('No se pudo verificar suscripción');
    const rows = await res.json();
    const planName = rows?.[0]?.plan_name;
    if (planName !== 'premium') {
      $('auth-warning').textContent = `Tu plan actual es "${planName || 'ninguno'}". Esta función requiere plan Premium.`;
      show('auth-warning');
      return false;
    }
    return true;
  } catch (e) {
    $('auth-warning').textContent = 'Error verificando plan: ' + e.message;
    show('auth-warning');
    return false;
  }
}

// ============================================================
// Form handlers
// ============================================================
function getSelectedCount() {
  const sel = $('i-ppt-count');
  const n = parseInt(sel?.value || '9', 10);
  return Math.max(1, Math.min(MAX_PPTS, n));
}

function updateCostEstimate() {
  const n = getSelectedCount();
  const minutes = Math.max(1, Math.ceil(2 + n * 0.2));
  // Estimación: resumen libro (si hay) + plan + n × render
  const hasBooks = state.bookFiles.some((b) => b.status === 'ok');
  const est = (hasBooks ? EST_COST_SUMMARIZE : 0) + EST_COST_PLAN + n * EST_COST_PER_PPT;
  const hint = $('gen-hint');
  const btn = $('btn-plan');
  const costEl = $('cost-estimate');
  if (hint) hint.textContent = `${n} PPT · ~${minutes} min · costo estimado ~$${est.toFixed(2)}`;
  if (btn) btn.textContent = `🧭 Procesar y proponer plan`;
  if (costEl) costEl.textContent = `≈ $${est.toFixed(2)}`;
}

function setupFormHandlers() {
  // Sílabo
  const dropSyllabus = $('drop-syllabus');
  const fileSyllabus = $('file-syllabus');
  dropSyllabus.addEventListener('click', () => fileSyllabus.click());
  dropSyllabus.addEventListener('dragover', (e) => { e.preventDefault(); dropSyllabus.classList.add('dragover'); });
  dropSyllabus.addEventListener('dragleave', () => dropSyllabus.classList.remove('dragover'));
  dropSyllabus.addEventListener('drop', (e) => {
    e.preventDefault(); dropSyllabus.classList.remove('dragover');
    if (e.dataTransfer.files[0]) handleSyllabus(e.dataTransfer.files[0]);
  });
  fileSyllabus.addEventListener('change', () => fileSyllabus.files[0] && handleSyllabus(fileSyllabus.files[0]));

  // Libros
  const dropBooks = $('drop-books');
  const fileBooks = $('file-books');
  dropBooks.addEventListener('click', () => fileBooks.click());
  dropBooks.addEventListener('dragover', (e) => { e.preventDefault(); dropBooks.classList.add('dragover'); });
  dropBooks.addEventListener('dragleave', () => dropBooks.classList.remove('dragover'));
  dropBooks.addEventListener('drop', (e) => {
    e.preventDefault(); dropBooks.classList.remove('dragover');
    [...e.dataTransfer.files].forEach(handleBook);
  });
  fileBooks.addEventListener('change', () => [...fileBooks.files].forEach(handleBook));

  ['i-asignatura', 'i-docente', 'i-carrera', 'i-repotenciada'].forEach((id) => {
    const el = $(id);
    if (el) el.addEventListener('change', updateButtonState);
    if (el && el.type === 'text') el.addEventListener('input', updateButtonState);
  });

  const countSel = $('i-ppt-count');
  if (countSel) {
    countSel.addEventListener('change', updateCostEstimate);
    updateCostEstimate();
  }

  $('btn-plan').addEventListener('click', startPlanning);
  $('btn-approve').addEventListener('click', approveAndGenerate);
  $('btn-reject').addEventListener('click', rejectPlan);

  // Banner de gaps colapsable
  $('gaps-banner').addEventListener('click', () => {
    const detail = $('gaps-detail');
    detail.style.display = detail.style.display === 'block' ? 'none' : 'block';
  });
}

async function handleSyllabus(file) {
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    alert('El sílabo debe ser PDF');
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    alert('PDF muy grande (>10 MB)');
    return;
  }
  const list = $('file-list-syllabus');
  list.innerHTML = `<div class="file-item"><span>⏳</span><span class="file-name">${escHtml(file.name)}</span><span class="file-meta">analizando...</span></div>`;
  try {
    const result = await extractPdfText(file);
    if (result.isScanned) {
      list.innerHTML = `<div class="file-item error"><span>⚠</span><span class="file-name">${escHtml(file.name)}</span><span class="file-meta">PDF escaneado (${Math.round(result.avgPerPage)} chars/pág) — sube uno con texto extraíble</span></div>`;
      state.syllabusFile = null;
      state.syllabusText = '';
      updateButtonState();
      return;
    }
    state.syllabusFile = file;
    state.syllabusText = result.text;
    state.syllabusPages = result.pages;
    list.innerHTML = `<div class="file-item"><span>✓</span><span class="file-name">${escHtml(file.name)}</span><span class="file-meta">${result.pages} págs · ${Math.round(result.text.length/1000)}K chars</span><button class="file-remove" id="rm-syllabus">×</button></div>`;
    $('rm-syllabus').addEventListener('click', () => {
      state.syllabusFile = null; state.syllabusText = '';
      list.innerHTML = '';
      $('file-syllabus').value = '';
      updateButtonState();
    });
    $('step-syllabus').classList.add('complete');
    updateButtonState();
  } catch (e) {
    list.innerHTML = `<div class="file-item error"><span>⚠</span><span class="file-name">${escHtml(file.name)}</span><span class="file-meta">Error: ${escHtml(e.message)}</span></div>`;
  }
}

async function handleBook(file) {
  if (state.bookFiles.length >= MAX_BOOKS) {
    alert(`Máximo ${MAX_BOOKS} libros`);
    return;
  }
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    alert('Solo PDF');
    return;
  }
  if (file.size > 50 * 1024 * 1024) {
    alert(`${file.name} muy grande (>50 MB)`);
    return;
  }
  const idx = state.bookFiles.length;
  state.bookFiles.push({ file, text: '', pages: 0, hash: null, status: 'analyzing' });
  renderBookList();
  try {
    const result = await extractPdfText(file);
    if (result.isScanned) {
      state.bookFiles[idx] = { file, text: '', pages: result.pages, hash: null, status: 'scanned', avgPerPage: result.avgPerPage };
      renderBookList();
      return;
    }
    state.bookFiles[idx] = { file, text: result.text, pages: result.pages, hash: null, status: 'ok' };
    renderBookList();
    updateButtonState();
  } catch (e) {
    state.bookFiles[idx].status = 'error';
    state.bookFiles[idx].error = e.message;
    renderBookList();
  }
}

function renderBookList() {
  const list = $('file-list-books');
  list.innerHTML = '';
  let totalPages = 0;
  state.bookFiles.forEach((b, i) => {
    if (b.status === 'ok') totalPages += b.pages;
    const cls = b.status === 'ok' ? '' : 'error';
    let meta = '';
    if (b.status === 'analyzing') meta = 'analizando...';
    else if (b.status === 'ok') meta = `${b.pages} págs · ${Math.round(b.text.length/1000)}K chars`;
    else if (b.status === 'scanned') meta = `escaneado (${Math.round(b.avgPerPage)} c/pág) — rechazado`;
    else meta = b.error || 'error';
    const div = document.createElement('div');
    div.className = `file-item ${cls}`;
    div.innerHTML = `<span>${b.status === 'ok' ? '✓' : '⚠'}</span><span class="file-name">${escHtml(b.file.name)}</span><span class="file-meta">${escHtml(meta)}</span><button class="file-remove" data-idx="${i}">×</button>`;
    list.appendChild(div);
  });
  list.querySelectorAll('.file-remove').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const idx = parseInt(e.currentTarget.dataset.idx);
      state.bookFiles.splice(idx, 1);
      renderBookList();
      updateButtonState();
    });
  });
  if (totalPages > MAX_TOTAL_PAGES) {
    const warn = document.createElement('div');
    warn.className = 'alert alert-warning';
    warn.textContent = `${totalPages} páginas en total. Reduce a ${MAX_TOTAL_PAGES} o menos para procesar.`;
    list.appendChild(warn);
  }
  if (state.bookFiles.some((b) => b.status === 'ok')) {
    $('step-books').classList.add('complete');
  } else {
    $('step-books').classList.remove('complete');
  }
}

function updateButtonState() {
  const asignatura = $('i-asignatura').value.trim();
  const docente = $('i-docente').value.trim();
  if (asignatura && docente) $('step-info').classList.add('complete');
  else $('step-info').classList.remove('complete');

  const totalBookPages = state.bookFiles.filter((b) => b.status === 'ok').reduce((s, b) => s + b.pages, 0);
  const ready = !!(asignatura && docente && state.syllabusFile && state.syllabusText && totalBookPages <= MAX_TOTAL_PAGES);
  const btn = $('btn-plan');
  if (btn) btn.disabled = !ready;
  if (typeof updateCostEstimate === 'function') updateCostEstimate();
}

// ============================================================
// API helpers
// ============================================================
async function callFn(path, payload) {
  const url = `${CONFIG.SUPABASE_URL}/functions/v1/${path}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${state.session.token}`,
      'apikey': CONFIG.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.ok) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data;
}

async function consumeCredit() {
  return callFn('execute-action', { action: 'generate_course_ppt', payload: {} });
}

// ============================================================
// FASE 1: planificar (resumir libros + plan-course)
// ============================================================
async function startPlanning() {
  $('btn-plan').disabled = true;
  hide('gen-status');
  show('gen-progress');
  show('cost-ticker');

  // Reset estado de costos y plan previo
  state.cost = { summarize: 0, plan: 0, render: 0 };
  state.plan = null;
  state.planId = null;
  state.bookHashes = [];
  refreshCostTicker();

  // Compute courseKey estable (sílabo + libros + docente)
  const inputForHash = state.syllabusText.slice(0, 5000) +
    '|' + state.bookFiles.filter((b) => b.status === 'ok').map((b) => b.text.slice(0, 2000)).join('|') +
    '|' + $('i-asignatura').value;
  state.courseKey = 'course-' + (await fnv1aHash(inputForHash));

  try {
    // 1) Resumir cada libro (si hay)
    const okBooks = state.bookFiles.filter((b) => b.status === 'ok');
    if (okBooks.length > 0) {
      setProgress(0, 1, `Resumiendo ${okBooks.length} libro(s)...`);
      const bookHashes = [];
      for (let i = 0; i < okBooks.length; i++) {
        const b = okBooks[i];
        setProgress(i, okBooks.length, `Resumiendo libro ${i + 1}/${okBooks.length}: ${b.file.name}`);
        const summary = await callFn('summarize-book', {
          bookText: b.text,
          totalPages: b.pages,
          bookTitle: b.file.name,
        });
        bookHashes.push(summary.bookHash);
        state.cost.summarize += summary.cost_usd || 0;
        refreshCostTicker();
      }
      state.bookHashes = bookHashes;
      setProgress(okBooks.length, okBooks.length, '✓ Libros resumidos');
    } else {
      // Sin libros → plan basado solo en sílabo
      state.bookHashes = [];
    }

    // 2) Plan + contraste
    setProgress(0, 1, 'Generando plan + matriz de cobertura...');
    const planRes = await callFn('plan-course', {
      courseKey: state.courseKey,
      courseLabel: $('i-asignatura').value.trim(),
      repotenciada: $('i-repotenciada').checked,
      teacherName: $('i-docente').value.trim(),
      syllabusText: state.syllabusText,
      bookHashes: state.bookHashes,
    });
    state.plan = planRes.plan;
    state.planId = planRes.planId;
    state.cost.plan += planRes.cost_usd || 0;
    refreshCostTicker();

    setProgress(1, 1, '✓ Plan listo');
    hide('gen-progress');
    showAlert('gen-status', 'Plan generado. Revísalo abajo y aprueba para crear los PPTs.', 'info');

    renderPlanApproval();
    show('step-approve');
    $('step-approve').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (e) {
    showAlert('gen-status', 'Error: ' + e.message, 'error');
    hide('gen-progress');
    $('btn-plan').disabled = false;
  }
}

// ============================================================
// Render UI de aprobación del plan (Opción B)
// ============================================================
function renderPlanApproval() {
  const plan = state.plan;
  if (!plan) return;

  // Banner de gaps
  const gaps = Array.isArray(plan.gaps) ? plan.gaps : [];
  if (gaps.length > 0) {
    $('gaps-count').textContent = `⚠ ${gaps.length} contenido${gaps.length > 1 ? 's' : ''} del sílabo sin cobertura completa en tu libro`;
    show('gaps-banner');
    const detailHtml = gaps.map((g) => `
      <div style="padding:6px 0;border-bottom:1px dotted #fde68a">
        <strong>${escHtml(g.contenido)}</strong> — RdA ${(g.rda_index ?? 0) + 1} · Criterio ${g.criterio || 1}<br>
        <span style="color:#a16207">Sugerencia: ${escHtml(g.suggestion || '—')}</span>
      </div>`).join('');
    $('gaps-detail').innerHTML = detailHtml;
  } else {
    hide('gaps-banner');
  }

  // Lista del plan (9 cards compactas)
  const slots = Array.isArray(plan.plan) ? plan.plan : [];
  const planList = $('plan-list');
  planList.innerHTML = slots.map((s, i) => {
    const slot = s.slot || {};
    const refs = Array.isArray(s.chapter_refs) ? s.chapter_refs : [];
    const refsHtml = refs.length === 0
      ? '<span style="color:#dc2626;font-style:italic">⚠ Sin material en el libro — solo sílabo</span>'
      : refs.map((r) => `📖 cap ${r.chapter_idx} · pp ${escHtml(r.page_range || '')}${r.relevance ? ' (' + escHtml(r.relevance) + ')' : ''}`).join('<br>');
    const types = Array.isArray(s.slide_types) ? s.slide_types : [];
    return `
      <div style="border:1px solid #e5e7eb;border-radius:8px;padding:10px 12px;margin-bottom:8px;background:#fff">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
          <div style="flex:1">
            <div style="font-size:11px;color:#7c3aed;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">
              RdA ${(slot.rda_index ?? 0) + 1} · Criterio ${slot.criterio || (i % 3) + 1} · PPT ${(slot.resource_slot ?? 0) + 1}
            </div>
            <div style="font-size:14px;font-weight:600;color:#0f172a;margin:2px 0">${escHtml(s.titulo_propuesto || '(sin título)')}</div>
            <div style="font-size:11px;color:#64748b;margin-top:4px">${refsHtml}</div>
            <div style="font-size:10px;color:#94a3b8;margin-top:4px">Slides: ${types.map(escHtml).join(' · ') || '(default)'}</div>
          </div>
        </div>
      </div>`;
  }).join('');

  // Coverage matrix
  const matrix = Array.isArray(plan.coverage_matrix) ? plan.coverage_matrix : [];
  const cm = $('coverage-matrix');
  if (matrix.length === 0) {
    cm.textContent = '(matriz no disponible)';
  } else {
    const rows = matrix.map((m) => {
      const icon = m.coverage === 'alta' ? '✅' : m.coverage === 'media' ? '⚠️ ' : '❌';
      const refs = Array.isArray(m.chapter_refs) && m.chapter_refs.length > 0
        ? m.chapter_refs.map((r) => `cap ${r.chapter_idx}`).join(', ')
        : '—';
      return `${icon} ${escHtml((m.contenido || '').padEnd(40).slice(0, 40))} → ${escHtml(refs)}`;
    });
    cm.textContent = rows.join('\n');
  }
}

function rejectPlan() {
  hide('step-approve');
  state.plan = null;
  state.planId = null;
  $('btn-plan').disabled = false;
  $('btn-plan').textContent = '🔄 Re-generar plan';
}

// ============================================================
// FASE 2: aprobar y generar PPTs
// ============================================================
async function approveAndGenerate() {
  if (!state.plan) return;
  const total = getSelectedCount();

  $('btn-approve').disabled = true;
  $('btn-reject').disabled = true;
  show('step-results');
  $('results-grid').innerHTML = '';
  show('gen-progress');
  hide('gen-status');
  setProgress(0, total, 'Verificando crédito...');

  // 1) Consumir N créditos (uno por cada slot a generar)
  for (let i = 0; i < total; i++) {
    try { await consumeCredit(); }
    catch (e) {
      showAlert('gen-status', `Error de crédito (${i + 1}/${total}): ${e.message}`, 'error');
      hide('gen-progress');
      $('btn-approve').disabled = false;
      $('btn-reject').disabled = false;
      return;
    }
  }

  // 2) Render por slot — paralelo con concurrencia 4
  setProgress(0, total, 'Generando PPTs...');
  let done = 0;
  const slots = Array.from({ length: total }, (_, i) => i);
  const CONCURRENCY = 4;

  async function processSlot(slotIdx) {
    const planSlot = state.plan.plan[slotIdx];
    const slotMeta = planSlot?.slot || {};
    const key = `rda${slotMeta.rda_index ?? 0}-slot${slotMeta.resource_slot ?? slotIdx}`;
    updateResultCard(key, 'pending');
    try {
      const data = await callFn('render-course-slot', {
        courseKey: state.courseKey,
        slotIdx,
      });
      state.cost.render += data.cost_usd || 0;
      refreshCostTicker();
      updateResultCard(key, 'done', data.content);
    } catch (e) {
      updateResultCard(key, 'error', null, e.message);
    } finally {
      done++;
      setProgress(done, total, `Generando PPTs... (${done}/${total})`);
    }
  }

  // Worker pool
  let nextIdx = 0;
  async function worker() {
    while (true) {
      const my = nextIdx++;
      if (my >= slots.length) return;
      await processSlot(slots[my]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, total) }, () => worker()));

  setProgress(total, total, '✓ Todos los PPTs generados');
  showAlert('gen-status', `${total} PPT generados. Descarga los .pptx desde cada tarjeta.`, 'info');
  $('btn-approve').disabled = false;
  $('btn-reject').disabled = false;
  $('btn-approve').textContent = '🔄 Re-generar PPTs';
}

// ============================================================
// Tarjetas de resultado
// ============================================================
function setProgress(done, total, label) {
  $('gen-progress-count').textContent = `${done}/${total}`;
  $('gen-progress-fill').style.width = `${(done / total) * 100}%`;
  if (label) $('gen-progress-label').textContent = label;
}

function updateResultCard(key, status, content, error) {
  state.generations[key] = { status, content, error };
  let card = $(`card-${key}`);
  const grid = $('results-grid');
  if (!card) {
    card = document.createElement('div');
    card.id = `card-${key}`;
    card.className = 'result-card';
    grid.appendChild(card);
  }
  const m = key.match(/rda(\d+)-slot(\d+)/);
  const rda = m ? parseInt(m[1]) : 0;
  const slot = m ? parseInt(m[2]) : 0;
  card.classList.remove('done', 'pending', 'error');
  card.classList.add(status);
  let inner = `<div class="result-status ${status}">${status === 'done' ? '✓ Listo' : status === 'pending' ? '⏳ Generando' : '⚠ Error'}</div>`;
  inner += `<div class="result-title">RdA ${rda + 1} · PPT ${slot + 1}</div>`;
  if (status === 'done' && content) {
    const slidesCount = (content.slides || []).length;
    inner += `<div class="result-meta">${slidesCount} slides · "${escHtml((content.meta?.title || 'PPT').slice(0, 50))}"</div>`;
    inner += `<div class="result-actions"><button class="btn-secondary" data-key="${key}" data-action="download">Descargar .pptx</button> <button class="btn-secondary" data-key="${key}" data-action="retry">Re-generar</button></div>`;
  } else if (status === 'error') {
    inner += `<div class="result-meta" style="color:#991b1b">${escHtml(error || 'Error')}</div>`;
    inner += `<div class="result-actions"><button class="btn-secondary" data-key="${key}" data-action="retry">Reintentar</button></div>`;
  } else {
    inner += `<div class="result-meta">Esperando IA...</div>`;
  }
  card.innerHTML = inner;
  card.querySelectorAll('button[data-action]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const k = e.currentTarget.dataset.key;
      const act = e.currentTarget.dataset.action;
      if (act === 'download') downloadPpt(k);
      else if (act === 'retry') retrySingle(k);
    });
  });
}

async function retrySingle(key) {
  const m = key.match(/rda(\d+)-slot(\d+)/);
  if (!m || !state.plan) return;
  const slots = state.plan.plan;
  // Encontrar slotIdx que matchea (rda, slot)
  const targetRda = parseInt(m[1]);
  const targetSlot = parseInt(m[2]);
  const slotIdx = slots.findIndex((s) => {
    const sm = s.slot || {};
    return Number(sm.rda_index) === targetRda && Number(sm.resource_slot) === targetSlot;
  });
  if (slotIdx < 0) return;

  updateResultCard(key, 'pending');
  try {
    await consumeCredit();
    const data = await callFn('render-course-slot', {
      courseKey: state.courseKey,
      slotIdx,
      forceRegenerate: true,
    });
    state.cost.render += data.cost_usd || 0;
    refreshCostTicker();
    updateResultCard(key, 'done', data.content);
  } catch (e) {
    updateResultCard(key, 'error', null, e.message);
  }
}

// ============================================================
// Materialización a .pptx con pptxgenjs
// ============================================================
function downloadPpt(key) {
  const gen = state.generations[key];
  if (!gen || !gen.content) return;
  const content = gen.content;
  const meta = content.meta || {};
  const PptxGenJS = window.PptxGenJS;
  if (!PptxGenJS) { alert('pptxgenjs no cargó'); return; }
  const pres = new PptxGenJS();
  pres.layout = 'LAYOUT_WIDE';
  pres.title = meta.title || 'PPT';
  pres.author = meta.teacher || 'NEXBYTE';
  pres.company = 'PUCESE';

  const COLORS = { primary: '1A237E', accent: '1565C0', light: 'E3F2FD', text: '1F2937', white: 'FFFFFF', muted: '4B5563' };

  for (const s of (content.slides || [])) {
    const slide = pres.addSlide();
    const layout = (s.layout || 'content').toLowerCase();
    if (layout === 'title') {
      slide.background = { color: COLORS.primary };
      slide.addText(s.title || '', { x: 0.5, y: 2.4, w: 12.3, h: 1.5, fontSize: 36, bold: true, color: COLORS.white, align: 'center' });
      if (s.subtitle) slide.addText(s.subtitle, { x: 0.5, y: 4.1, w: 12.3, h: 1.5, fontSize: 16, color: COLORS.light, align: 'center' });
    } else if (layout === 'two-column' || layout === 'twocolumn') {
      slide.background = { color: COLORS.white };
      slide.addShape('rect', { x: 0, y: 0, w: 13.33, h: 0.9, fill: { color: COLORS.primary } });
      slide.addText(s.title || '', { x: 0.4, y: 0.15, w: 12.5, h: 0.6, fontSize: 22, bold: true, color: COLORS.white });
      if (s.leftTitle) slide.addText(s.leftTitle, { x: 0.5, y: 1.1, w: 6, h: 0.5, fontSize: 16, bold: true, color: COLORS.accent });
      if (s.rightTitle) slide.addText(s.rightTitle, { x: 6.8, y: 1.1, w: 6, h: 0.5, fontSize: 16, bold: true, color: COLORS.accent });
      slide.addText((s.leftBullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 14, color: COLORS.text, paraSpaceAfter: 4 } })), { x: 0.5, y: 1.7, w: 6, h: 5 });
      slide.addText((s.rightBullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 14, color: COLORS.text, paraSpaceAfter: 4 } })), { x: 6.8, y: 1.7, w: 6, h: 5 });
      if (s.notes) slide.addNotes(s.notes);
    } else {
      slide.background = { color: COLORS.white };
      slide.addShape('rect', { x: 0, y: 0, w: 13.33, h: 0.9, fill: { color: COLORS.primary } });
      slide.addText(s.title || '', { x: 0.4, y: 0.15, w: 12.5, h: 0.6, fontSize: 22, bold: true, color: COLORS.white });
      const bullets = (s.bullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 16, color: COLORS.text, paraSpaceAfter: 6 } }));
      slide.addText(bullets.length ? bullets : [{ text: '(sin bullets)', options: { italic: true, color: COLORS.muted } }], { x: 0.5, y: 1.1, w: s.imageHint ? 8.2 : 12.4, h: 5.5 });
      if (s.imageHint) {
        slide.addShape('rect', { x: 9, y: 1.3, w: 3.9, h: 4, fill: { color: COLORS.light }, line: { color: COLORS.accent, width: 1, dashType: 'dash' } });
        slide.addText('IMAGEN SUGERIDA:\n' + s.imageHint, { x: 9.1, y: 1.5, w: 3.7, h: 3.6, fontSize: 11, italic: true, color: COLORS.muted, align: 'center', valign: 'middle' });
      }
      if (s.notes) slide.addNotes(s.notes);
    }
  }

  const fileName = `${($('i-asignatura').value || 'curso').replace(/[^a-zA-Z0-9_-]/g, '_')}_${key}.pptx`;
  pres.writeFile({ fileName });
}

// ============================================================
// Init
// ============================================================
(async function init() {
  setupFormHandlers();
  const ok = await initAuth();
  if (!ok) {
    document.querySelectorAll('.step-card').forEach((c) => c.classList.add('disabled'));
  }
})();
