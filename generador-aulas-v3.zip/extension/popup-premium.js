/**
 * Generador de cursos Premium — orquesta el flujo map-reduce + plan-with-contrast.
 *
 * Flujo nuevo (v3.6.4+):
 *   1. Verifica sesión + plan_name='premium'
 *   2. Recolecta inputs (datos curso, sílabo, libros) — libros completos hasta 1500 págs
 *   3. Click "Procesar y proponer plan":
 *      a) Resume cada libro vía summarize-book (Haiku, cache global por hash)
 *      b) Llama plan-course (Sonnet) con sílabo + resúmenes → plan + coverage_matrix
 *      c) Renderiza UI de aprobación: plan primero, gaps banner arriba, matriz colapsable
 *   4. Click "Aprobar y generar PPTs":
 *      a) Por cada slot: consume_action_v2 + render-course-slot (Haiku)
 *      b) Renderiza tarjetas de resultado
 *   5. Materializa .pptx con pptxgenjs cuando el usuario descarga.
 *
 * Costos típicos (validados con Haiku 4.5 + Sonnet 4.6 en Etapa PLAN):
 *   - Resumen libro 700 págs nuevo: ~$0.05 (gratis si otro docente ya lo subió)
 *   - Plan + contraste: ~$0.04
 *   - Render por PPT: ~$0.008
 *   - Curso 9 PPTs end-to-end: ~$0.16
 */

// ============================================================
// Estado global
// ============================================================
const state = {
  syllabusFile: null,
  syllabusText: '',
  syllabusPages: 0,
  bookFiles: [],          // [{file, text, pages, hash, status}]
  generations: {},        // key: "rda{i}-slot{s}" → { status, content, error }
  session: null,
  userId: null,
  courseKey: null,
  bookHashes: [],         // sha256 del texto de cada libro (post summarize-book)
  plan: null,             // { syllabus_extracted, coverage_matrix, gaps, surplus, plan }
  planId: null,
  editedTitles: {},       // slotIdx → título editado por el docente (override)
  slotOrder: [0,1,2,3,4,5,6,7,8],  // mapea posición visual → slotIdx original
  useExternalSources: false,
  previews: {},           // slotIdx → preview content (cover + 1 sample slide)
  cost: { summarize: 0, plan: 0, render: 0 },
};

const MAX_PPTS = 9;
const MAX_BOOKS = 3;
const MAX_TOTAL_PAGES = 1500;
const MIN_TEXT_PER_PAGE = 50;

// Estimaciones de costo (real-time se actualiza a medida que llegan respuestas)
const EST_COST_SUMMARIZE = 0.05;   // un libro promedio
const EST_COST_PLAN = 0.04;
const EST_COST_PER_PPT = 0.008;

// ============================================================
// Utilidades
// ============================================================
function $(id) { return document.getElementById(id); }
function show(id) { const e = $(id); if (e) e.style.display = 'block'; }
function hide(id) { const e = $(id); if (e) e.style.display = 'none'; }

function decodeJwtSub(token) {
  try {
    const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    return payload.sub || null;
  } catch { return null; }
}

async function getSessionFromStorage() {
  const stored = await new Promise((res) => chrome.storage.local.get('session', res));
  if (!stored?.session?.access_token) return null;
  return {
    token: stored.session.access_token,
    userId: decodeJwtSub(stored.session.access_token),
  };
}

function showAlert(target, msg, type) {
  const el = $(target);
  if (!el) return;
  el.className = 'alert alert-' + (type || 'info');
  el.textContent = msg;
  el.style.display = 'block';
}

async function fnv1aHash(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16);
}

async function sha256Hex(text) {
  const buf = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function escHtml(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ============================================================
// Costo en vivo
// ============================================================
function costFmt(usd) { return '$' + (usd || 0).toFixed(4); }

function refreshCostTicker() {
  const total = state.cost.summarize + state.cost.plan + state.cost.render;
  const ct = $('cost-ticker');
  if (ct) ct.style.display = 'block';
  if ($('ct-summarize')) $('ct-summarize').textContent = costFmt(state.cost.summarize);
  if ($('ct-plan')) $('ct-plan').textContent = costFmt(state.cost.plan);
  if ($('ct-render')) $('ct-render').textContent = costFmt(state.cost.render);
  if ($('ct-total')) $('ct-total').textContent = costFmt(total);
}

// ============================================================
// PDF text extraction
// ============================================================
async function extractPdfText(file) {
  const ab = await file.arrayBuffer();
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  const pdf = await pdfjsLib.getDocument({ data: ab }).promise;
  let allText = '';
  let pageStats = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const pageText = content.items.map((it) => it.str).join(' ');
    allText += pageText + '\n';
    pageStats.push({ page: i, chars: pageText.length });
  }
  const totalChars = pageStats.reduce((s, p) => s + p.chars, 0);
  const avgPerPage = totalChars / Math.max(pdf.numPages, 1);
  const isScanned = avgPerPage < MIN_TEXT_PER_PAGE;
  return { text: allText, pages: pdf.numPages, isScanned, avgPerPage };
}

// ============================================================
// Auth + premium gate
// ============================================================
async function initAuth() {
  state.session = await getSessionFromStorage();
  if (!state.session?.token || !state.session.userId) {
    show('auth-warning');
    return false;
  }
  state.userId = state.session.userId;

  try {
    const today = new Date().toISOString().split('T')[0];
    const url = `${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?user_id=eq.${state.userId}&status=eq.active&period_end=gte.${today}&select=plan_name&order=created_at.desc&limit=1`;
    const res = await fetch(url, {
      headers: { 'apikey': CONFIG.SUPABASE_ANON_KEY, 'Authorization': `Bearer ${state.session.token}` },
    });
    if (!res.ok) throw new Error('No se pudo verificar suscripción');
    const rows = await res.json();
    const planName = rows?.[0]?.plan_name;
    if (planName !== 'premium') {
      $('auth-warning').textContent = `Tu plan actual es "${planName || 'ninguno'}". Esta función requiere plan Premium.`;
      show('auth-warning');
      return false;
    }
    return true;
  } catch (e) {
    $('auth-warning').textContent = 'Error verificando plan: ' + e.message;
    show('auth-warning');
    return false;
  }
}

// ============================================================
// Form handlers
// ============================================================
function getSelectedCount() {
  const sel = $('i-ppt-count');
  const n = parseInt(sel?.value || '9', 10);
  return Math.max(1, Math.min(MAX_PPTS, n));
}

function updateCostEstimate() {
  const n = getSelectedCount();
  const minutes = Math.max(1, Math.ceil(2 + n * 0.2));
  // Estimación: resumen libro (si hay) + plan + n × render
  const hasBooks = state.bookFiles.some((b) => b.status === 'ok');
  const est = (hasBooks ? EST_COST_SUMMARIZE : 0) + EST_COST_PLAN + n * EST_COST_PER_PPT;
  const hint = $('gen-hint');
  const btn = $('btn-plan');
  const costEl = $('cost-estimate');
  if (hint) hint.textContent = `${n} PPT · ~${minutes} min · costo estimado ~$${est.toFixed(2)}`;
  if (btn) btn.textContent = `🧭 Procesar y proponer plan`;
  if (costEl) costEl.textContent = `≈ $${est.toFixed(2)}`;
}

function setupFormHandlers() {
  // Sílabo
  const dropSyllabus = $('drop-syllabus');
  const fileSyllabus = $('file-syllabus');
  dropSyllabus.addEventListener('click', () => fileSyllabus.click());
  dropSyllabus.addEventListener('dragover', (e) => { e.preventDefault(); dropSyllabus.classList.add('dragover'); });
  dropSyllabus.addEventListener('dragleave', () => dropSyllabus.classList.remove('dragover'));
  dropSyllabus.addEventListener('drop', (e) => {
    e.preventDefault(); dropSyllabus.classList.remove('dragover');
    if (e.dataTransfer.files[0]) handleSyllabus(e.dataTransfer.files[0]);
  });
  fileSyllabus.addEventListener('change', () => fileSyllabus.files[0] && handleSyllabus(fileSyllabus.files[0]));

  // Libros
  const dropBooks = $('drop-books');
  const fileBooks = $('file-books');
  dropBooks.addEventListener('click', () => fileBooks.click());
  dropBooks.addEventListener('dragover', (e) => { e.preventDefault(); dropBooks.classList.add('dragover'); });
  dropBooks.addEventListener('dragleave', () => dropBooks.classList.remove('dragover'));
  dropBooks.addEventListener('drop', (e) => {
    e.preventDefault(); dropBooks.classList.remove('dragover');
    [...e.dataTransfer.files].forEach(handleBook);
  });
  fileBooks.addEventListener('change', () => [...fileBooks.files].forEach(handleBook));

  ['i-asignatura', 'i-docente', 'i-carrera', 'i-repotenciada'].forEach((id) => {
    const el = $(id);
    if (el) el.addEventListener('change', updateButtonState);
    if (el && el.type === 'text') el.addEventListener('input', updateButtonState);
  });

  const countSel = $('i-ppt-count');
  if (countSel) {
    countSel.addEventListener('change', updateCostEstimate);
    updateCostEstimate();
  }

  $('btn-plan').addEventListener('click', startPlanning);
  $('btn-approve').addEventListener('click', approveAndGenerate);
  $('btn-reject').addEventListener('click', rejectPlan);
  if ($('btn-preview')) $('btn-preview').addEventListener('click', startPreview);

  // Toggle de fuentes externas
  const extToggle = $('i-external-sources');
  if (extToggle) {
    extToggle.addEventListener('change', (e) => {
      state.useExternalSources = e.target.checked;
    });
  }
}

async function handleSyllabus(file) {
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    alert('El sílabo debe ser PDF');
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    alert('PDF muy grande (>10 MB)');
    return;
  }
  const list = $('file-list-syllabus');
  list.innerHTML = `<div class="file-item"><span>⏳</span><span class="file-name">${escHtml(file.name)}</span><span class="file-meta">analizando...</span></div>`;
  try {
    const result = await extractPdfText(file);
    if (result.isScanned) {
      list.innerHTML = `<div class="file-item error"><span>⚠</span><span class="file-name">${escHtml(file.name)}</span><span class="file-meta">PDF escaneado (${Math.round(result.avgPerPage)} chars/pág) — sube uno con texto extraíble</span></div>`;
      state.syllabusFile = null;
      state.syllabusText = '';
      updateButtonState();
      return;
    }
    state.syllabusFile = file;
    state.syllabusText = result.text;
    state.syllabusPages = result.pages;
    list.innerHTML = `<div class="file-item"><span>✓</span><span class="file-name">${escHtml(file.name)}</span><span class="file-meta">${result.pages} págs · ${Math.round(result.text.length/1000)}K chars</span><button class="file-remove" id="rm-syllabus">×</button></div>`;
    $('rm-syllabus').addEventListener('click', () => {
      state.syllabusFile = null; state.syllabusText = '';
      list.innerHTML = '';
      $('file-syllabus').value = '';
      updateButtonState();
    });
    $('step-syllabus').classList.add('complete');
    updateButtonState();
  } catch (e) {
    list.innerHTML = `<div class="file-item error"><span>⚠</span><span class="file-name">${escHtml(file.name)}</span><span class="file-meta">Error: ${escHtml(e.message)}</span></div>`;
  }
}

async function handleBook(file) {
  if (state.bookFiles.length >= MAX_BOOKS) {
    alert(`Máximo ${MAX_BOOKS} libros`);
    return;
  }
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    alert('Solo PDF');
    return;
  }
  if (file.size > 50 * 1024 * 1024) {
    alert(`${file.name} muy grande (>50 MB)`);
    return;
  }
  const idx = state.bookFiles.length;
  state.bookFiles.push({ file, text: '', pages: 0, hash: null, status: 'analyzing' });
  renderBookList();
  try {
    const result = await extractPdfText(file);
    if (result.isScanned) {
      state.bookFiles[idx] = { file, text: '', pages: result.pages, hash: null, status: 'scanned', avgPerPage: result.avgPerPage };
      renderBookList();
      return;
    }
    state.bookFiles[idx] = { file, text: result.text, pages: result.pages, hash: null, status: 'ok' };
    renderBookList();
    updateButtonState();
  } catch (e) {
    state.bookFiles[idx].status = 'error';
    state.bookFiles[idx].error = e.message;
    renderBookList();
  }
}

function renderBookList() {
  const list = $('file-list-books');
  list.innerHTML = '';
  let totalPages = 0;
  state.bookFiles.forEach((b, i) => {
    if (b.status === 'ok') totalPages += b.pages;
    const cls = b.status === 'ok' ? '' : 'error';
    let meta = '';
    if (b.status === 'analyzing') meta = 'analizando...';
    else if (b.status === 'ok') meta = `${b.pages} págs · ${Math.round(b.text.length/1000)}K chars`;
    else if (b.status === 'scanned') meta = `escaneado (${Math.round(b.avgPerPage)} c/pág) — rechazado`;
    else meta = b.error || 'error';
    const div = document.createElement('div');
    div.className = `file-item ${cls}`;
    div.innerHTML = `<span>${b.status === 'ok' ? '✓' : '⚠'}</span><span class="file-name">${escHtml(b.file.name)}</span><span class="file-meta">${escHtml(meta)}</span><button class="file-remove" data-idx="${i}">×</button>`;
    list.appendChild(div);
  });
  list.querySelectorAll('.file-remove').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const idx = parseInt(e.currentTarget.dataset.idx);
      state.bookFiles.splice(idx, 1);
      renderBookList();
      updateButtonState();
    });
  });
  if (totalPages > MAX_TOTAL_PAGES) {
    const warn = document.createElement('div');
    warn.className = 'alert alert-warning';
    warn.textContent = `${totalPages} páginas en total. Reduce a ${MAX_TOTAL_PAGES} o menos para procesar.`;
    list.appendChild(warn);
  }
  if (state.bookFiles.some((b) => b.status === 'ok')) {
    $('step-books').classList.add('complete');
  } else {
    $('step-books').classList.remove('complete');
  }
}

function updateButtonState() {
  const asignatura = $('i-asignatura').value.trim();
  const docente = $('i-docente').value.trim();
  if (asignatura && docente) $('step-info').classList.add('complete');
  else $('step-info').classList.remove('complete');

  const totalBookPages = state.bookFiles.filter((b) => b.status === 'ok').reduce((s, b) => s + b.pages, 0);
  const ready = !!(asignatura && docente && state.syllabusFile && state.syllabusText && totalBookPages <= MAX_TOTAL_PAGES);
  const btn = $('btn-plan');
  if (btn) btn.disabled = !ready;
  if (typeof updateCostEstimate === 'function') updateCostEstimate();
}

// ============================================================
// API helpers
// ============================================================
async function callFn(path, payload) {
  const url = `${CONFIG.SUPABASE_URL}/functions/v1/${path}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${state.session.token}`,
      'apikey': CONFIG.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.ok) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data;
}

async function consumeCredit() {
  return callFn('execute-action', { action: 'generate_course_ppt', payload: {} });
}

// ============================================================
// FASE 1: planificar (resumir libros + plan-course)
// ============================================================
async function startPlanning() {
  $('btn-plan').disabled = true;
  hide('gen-status');
  show('gen-progress');
  show('cost-ticker');

  // Reset estado de costos y plan previo
  state.cost = { summarize: 0, plan: 0, render: 0 };
  state.plan = null;
  state.planId = null;
  state.bookHashes = [];
  refreshCostTicker();

  // Compute courseKey estable (sílabo + libros + docente)
  const inputForHash = state.syllabusText.slice(0, 5000) +
    '|' + state.bookFiles.filter((b) => b.status === 'ok').map((b) => b.text.slice(0, 2000)).join('|') +
    '|' + $('i-asignatura').value;
  state.courseKey = 'course-' + (await fnv1aHash(inputForHash));

  try {
    // 1) Resumir cada libro (si hay)
    const okBooks = state.bookFiles.filter((b) => b.status === 'ok');
    if (okBooks.length > 0) {
      setProgress(0, 1, `Resumiendo ${okBooks.length} libro(s)...`);
      const bookHashes = [];
      for (let i = 0; i < okBooks.length; i++) {
        const b = okBooks[i];
        setProgress(i, okBooks.length, `Resumiendo libro ${i + 1}/${okBooks.length}: ${b.file.name}`);
        const summary = await callFn('summarize-book', {
          bookText: b.text,
          totalPages: b.pages,
          bookTitle: b.file.name,
        });
        bookHashes.push(summary.bookHash);
        state.cost.summarize += summary.cost_usd || 0;
        refreshCostTicker();
      }
      state.bookHashes = bookHashes;
      setProgress(okBooks.length, okBooks.length, '✓ Libros resumidos');
    } else {
      // Sin libros → plan basado solo en sílabo
      state.bookHashes = [];
    }

    // 2) Plan + contraste
    setProgress(0, 1, 'Generando plan + matriz de cobertura...');
    const planRes = await callFn('plan-course', {
      courseKey: state.courseKey,
      courseLabel: $('i-asignatura').value.trim(),
      repotenciada: $('i-repotenciada').checked,
      teacherName: $('i-docente').value.trim(),
      syllabusText: state.syllabusText,
      bookHashes: state.bookHashes,
    });
    state.plan = planRes.plan;
    state.planId = planRes.planId;
    state.cost.plan += planRes.cost_usd || 0;
    refreshCostTicker();

    setProgress(1, 1, planRes.fromCache ? '✓ Plan reutilizado de generación previa (sin costo)' : '✓ Plan listo');
    hide('gen-progress');
    showAlert('gen-status', 'Plan generado. Revísalo abajo y aprueba para crear los PPTs.', 'info');

    renderPlanApproval();
    show('step-approve');
    $('step-approve').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (e) {
    showAlert('gen-status', 'Error: ' + e.message, 'error');
    hide('gen-progress');
    $('btn-plan').disabled = false;
  }
}

// ============================================================
// Render UI de aprobación del plan
// Diseño compacto: 1 línea por PPT, expandible al click, título editable
// ============================================================
function renderPlanApproval() {
  const plan = state.plan;
  if (!plan) return;

  state.editedTitles = {};  // reset si re-renderiza

  // ── Resumen ejecutivo ─────────────────────────────────────
  const matrix = Array.isArray(plan.coverage_matrix) ? plan.coverage_matrix : [];
  const total = matrix.length;
  const covered = matrix.filter((m) => m.coverage === 'alta' || m.coverage === 'media').length;
  const gaps = Array.isArray(plan.gaps) ? plan.gaps : [];

  const pct = total > 0 ? Math.round((covered / total) * 100) : 0;
  $('analysis-coverage').textContent = state.bookHashes.length > 0
    ? `${covered} de ${total} contenidos cubiertos (${pct}%)`
    : 'Sin libro de referencia · plan basado solo en sílabo';
  $('analysis-gaps').textContent = gaps.length === 0
    ? '✅ Ninguno'
    : `⚠ ${gaps.length} contenido${gaps.length > 1 ? 's' : ''} sin cobertura`;

  // Mostrar toggle de fuentes externas solo si hay gaps
  if (gaps.length > 0) {
    $('external-toggle-wrap').style.display = 'block';
  } else {
    $('external-toggle-wrap').style.display = 'none';
    state.useExternalSources = false;
    $('i-external-sources').checked = false;
  }

  // Detalle de gaps (en <details>)
  if (gaps.length > 0) {
    $('gaps-detail').innerHTML = gaps.map((g) => `
      <div style="padding:5px 0;border-bottom:1px dotted #fde68a">
        <strong>${escHtml(g.contenido)}</strong>
        <span style="color:#a16207"> — RdA ${(g.rda_index ?? 0) + 1} · Criterio ${g.criterio || 1}</span><br>
        <span style="color:#78350f">${escHtml(g.suggestion || '—')}</span>
      </div>`).join('');
  } else {
    $('gaps-detail').innerHTML = '<em style="color:#65a30d">Tu libro cubre todos los contenidos del sílabo. ✓</em>';
  }

  // Coverage matrix (en <details>)
  const cm = $('coverage-matrix');
  if (matrix.length === 0) {
    cm.textContent = '(matriz no disponible)';
  } else {
    cm.innerHTML = matrix.map((m) => {
      const icon = m.coverage === 'alta' ? '✅' : m.coverage === 'media' ? '🟡' : '❌';
      const refs = Array.isArray(m.chapter_refs) && m.chapter_refs.length > 0
        ? m.chapter_refs.map((r) => `cap ${r.chapter_idx}`).join(', ')
        : '—';
      return `<div>${icon} <strong>${escHtml(m.contenido || '')}</strong> <span style="color:#94a3b8">→ ${escHtml(refs)}</span></div>`;
    }).join('');
  }

  // ── Lista del plan: 9 cards de 1 línea, expandibles, draggable ───────
  // state.slotOrder mapea posición visual → slotIdx original. La estructura
  // académica (RdA·Criterio) NO cambia con el reorden — solo la secuencia
  // visual y de generación.
  const slots = Array.isArray(plan.plan) ? plan.plan : [];
  if (state.slotOrder.length !== slots.length) {
    state.slotOrder = slots.map((_, i) => i);
  }
  const planList = $('plan-list');
  planList.innerHTML = '<div style="font-size:11px;color:#94a3b8;margin-bottom:6px">Arrastra ⋮⋮ para reordenar la secuencia · click para expandir · ✏️ para editar título</div>' +
    state.slotOrder.map((origIdx, visualPos) => {
    const s = slots[origIdx];
    if (!s) return '';
    const slot = s.slot || {};
    const refs = Array.isArray(s.chapter_refs) ? s.chapter_refs : [];
    const types = Array.isArray(s.slide_types) ? s.slide_types : [];
    const noBookCoverage = refs.length === 0;
    const tint = noBookCoverage ? 'background:#fffbeb;border-color:#fde68a' : 'background:#fff;border-color:#e5e7eb';
    const refsHtml = refs.length === 0
      ? '<span style="color:#dc2626">⚠ Sin material en el libro</span>'
      : refs.map((r) => `📖 cap ${r.chapter_idx} · pp ${escHtml(r.page_range || '')}${r.relevance ? ' (' + escHtml(r.relevance) + ')' : ''}`).join(' · ');
    const editedTitle = state.editedTitles[origIdx];
    const displayTitle = editedTitle || s.titulo_propuesto || '(sin título)';

    return `
      <div class="plan-row" draggable="true" data-orig="${origIdx}" data-pos="${visualPos}" style="border:1px solid;border-radius:8px;padding:10px 12px;margin-bottom:6px;${tint};transition:all 0.15s">
        <div style="display:flex;align-items:center;gap:8px">
          <span class="drag-handle" style="cursor:grab;color:#94a3b8;font-size:14px;user-select:none;padding:0 4px" title="Arrastrar para reordenar">⋮⋮</span>
          <div style="background:#7c3aed;color:#fff;font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;white-space:nowrap;letter-spacing:0.3px">
            #${visualPos + 1} · RdA ${(slot.rda_index ?? 0) + 1}·C${slot.criterio || ((origIdx % 3) + 1)}
          </div>
          <div style="flex:1;cursor:pointer" data-toggle="${origIdx}">
            <div style="font-size:13px;color:#0f172a;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" id="title-display-${origIdx}">
              ${escHtml(displayTitle)}
            </div>
          </div>
          <button type="button" class="btn-icon" data-edit="${origIdx}" title="Editar título" style="background:none;border:none;cursor:pointer;font-size:14px;padding:2px 6px;color:#64748b">✏️</button>
          <span style="color:#94a3b8;font-size:14px;transition:transform 0.15s;cursor:pointer" id="caret-${origIdx}" data-toggle="${origIdx}">▾</span>
        </div>

        <div id="detail-${origIdx}" style="display:none;margin-top:10px;padding-top:10px;border-top:1px dashed #cbd5e1;font-size:11px;color:#64748b">
          <div style="margin-bottom:4px"><strong>Fuentes:</strong> ${refsHtml}</div>
          <div style="margin-bottom:4px"><strong>Slides:</strong> ${types.map(escHtml).join(' → ') || '(default)'}</div>
          <div><strong>Contenidos:</strong> ${(Array.isArray(s.contenidos_que_cubre) ? s.contenidos_que_cubre : []).map(escHtml).join(', ') || '—'}</div>
        </div>

        <div id="edit-${origIdx}" style="display:none;margin-top:8px">
          <input type="text" id="title-input-${origIdx}" maxlength="200" value="${escHtml(displayTitle)}" style="width:100%;padding:6px 8px;border:1px solid #d1d5db;border-radius:6px;font-size:13px">
          <div style="display:flex;gap:6px;margin-top:6px">
            <button type="button" class="btn-secondary" data-save="${origIdx}" style="font-size:11px;padding:4px 10px">Guardar</button>
            <button type="button" class="btn-secondary" data-cancel="${origIdx}" style="font-size:11px;padding:4px 10px">Cancelar</button>
          </div>
        </div>

        <div id="preview-${origIdx}" style="display:none;margin-top:10px;padding:10px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:6px;font-size:11px;color:#475569"></div>
      </div>`;
  }).join('');

  // Wire-up drag-and-drop
  let dragSrcOrig = null;
  planList.querySelectorAll('.plan-row').forEach((row) => {
    row.addEventListener('dragstart', (e) => {
      dragSrcOrig = parseInt(row.dataset.orig);
      row.style.opacity = '0.5';
      e.dataTransfer.effectAllowed = 'move';
    });
    row.addEventListener('dragend', () => { row.style.opacity = '1'; dragSrcOrig = null; });
    row.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      row.style.borderTop = '2px solid #7c3aed';
    });
    row.addEventListener('dragleave', () => { row.style.borderTop = ''; });
    row.addEventListener('drop', (e) => {
      e.preventDefault();
      row.style.borderTop = '';
      const targetOrig = parseInt(row.dataset.orig);
      if (dragSrcOrig === null || dragSrcOrig === targetOrig) return;
      // Reordenar slotOrder: mover dragSrcOrig a la posición visual de targetOrig
      const srcVisualPos = state.slotOrder.indexOf(dragSrcOrig);
      const tgtVisualPos = state.slotOrder.indexOf(targetOrig);
      if (srcVisualPos < 0 || tgtVisualPos < 0) return;
      state.slotOrder.splice(srcVisualPos, 1);
      state.slotOrder.splice(tgtVisualPos, 0, dragSrcOrig);
      renderPlanApproval();  // re-render con nuevo orden
    });
  });

  // Wire up de cada card (toggle expand)
  planList.querySelectorAll('[data-toggle]').forEach((el) => {
    el.addEventListener('click', (e) => {
      if (e.target.closest('[data-edit]')) return;
      const origIdx = el.dataset.toggle;
      const detail = $(`detail-${origIdx}`);
      const caret = $(`caret-${origIdx}`);
      const isOpen = detail.style.display === 'block';
      detail.style.display = isOpen ? 'none' : 'block';
      if (caret) caret.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
    });
  });
  planList.querySelectorAll('[data-edit]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const i = btn.dataset.edit;
      $(`title-display-${i}`).style.display = 'none';
      $(`edit-${i}`).style.display = 'block';
      btn.style.display = 'none';
      $(`title-input-${i}`).focus();
    });
  });
  planList.querySelectorAll('[data-save]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const i = btn.dataset.save;
      const newTitle = $(`title-input-${i}`).value.trim();
      if (newTitle.length === 0) { alert('El título no puede estar vacío'); return; }
      state.editedTitles[i] = newTitle;
      $(`title-display-${i}`).textContent = newTitle;
      $(`title-display-${i}`).style.display = 'block';
      $(`edit-${i}`).style.display = 'none';
      planList.querySelector(`[data-edit="${i}"]`).style.display = 'inline-block';
    });
  });
  planList.querySelectorAll('[data-cancel]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const i = btn.dataset.cancel;
      $(`title-display-${i}`).style.display = 'block';
      $(`edit-${i}`).style.display = 'none';
      planList.querySelector(`[data-edit="${i}"]`).style.display = 'inline-block';
    });
  });

  // Banner "qué pasa al aprobar"
  const n = getSelectedCount();
  $('approve-count-label').textContent = String(n);
  $('approve-cost-label').textContent = (n * EST_COST_PER_PPT).toFixed(2);
  $('approve-time-label').textContent = `~${Math.max(1, Math.ceil(n * 0.3))} min`;
}

// ============================================================
// Vista previa rápida (2 slides por slot, sin crédito)
// ============================================================
async function startPreview() {
  if (!state.plan) return;
  const total = getSelectedCount();
  $('btn-preview').disabled = true;
  $('btn-approve').disabled = true;

  const slots = state.slotOrder.slice(0, total);
  let done = 0;

  // Mostrar contenedores de preview
  for (const origIdx of slots) {
    const previewBox = $(`preview-${origIdx}`);
    if (previewBox) {
      previewBox.style.display = 'block';
      previewBox.innerHTML = '<em style="color:#94a3b8">⏳ Generando preview...</em>';
    }
  }

  async function previewSlot(origIdx) {
    try {
      const data = await callFn('preview-course-slot', {
        courseKey: state.courseKey,
        slotIdx: origIdx,
        titleOverride: state.editedTitles[origIdx] || undefined,
      });
      state.previews[origIdx] = data.content;
      state.cost.render += data.cost_usd || 0;
      refreshCostTicker();
      renderPreviewBox(origIdx, data.content);
    } catch (e) {
      const previewBox = $(`preview-${origIdx}`);
      if (previewBox) previewBox.innerHTML = `<span style="color:#dc2626">⚠ ${escHtml(e.message)}</span>`;
    } finally {
      done++;
    }
  }

  // Concurrencia 4
  const CONCURRENCY = 4;
  let nextIdx = 0;
  async function worker() {
    while (true) {
      const my = nextIdx++;
      if (my >= slots.length) return;
      await previewSlot(slots[my]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, slots.length) }, () => worker()));

  $('btn-preview').disabled = false;
  $('btn-approve').disabled = false;
  $('btn-preview').textContent = '🔄 Re-generar previews';
  showAlert('gen-status', `${done} previews listos. Si te gustan, aprueba para generar las presentaciones completas.`, 'info');
}

function renderPreviewBox(origIdx, content) {
  const box = $(`preview-${origIdx}`);
  if (!box) return;
  const slides = Array.isArray(content?.slides) ? content.slides : [];
  if (slides.length === 0) {
    box.innerHTML = '<em style="color:#94a3b8">(preview vacío)</em>';
    return;
  }
  const html = slides.map((s, idx) => {
    const layout = (s.layout || 'content').toLowerCase();
    if (layout === 'title') {
      return `
        <div style="background:#003B7A;color:#fff;padding:14px;border-radius:6px;margin-bottom:6px;border-left:4px solid #FFC72C">
          <div style="font-size:9px;color:#FFC72C;letter-spacing:2px;font-weight:700">PORTADA · SLIDE ${idx + 1}</div>
          <div style="font-size:14px;font-weight:700;margin-top:4px">${escHtml(s.title || '')}</div>
          ${s.subtitle ? `<div style="font-size:11px;color:#FFC72C;margin-top:2px">${escHtml(s.subtitle)}</div>` : ''}
        </div>`;
    }
    const bullets = Array.isArray(s.bullets) ? s.bullets : [];
    return `
      <div style="background:#fff;padding:10px 12px;border-radius:6px;border:1px solid #cbd5e1;border-top:3px solid #003B7A">
        <div style="font-size:9px;color:#94a3b8;letter-spacing:1px;font-weight:700">SLIDE ${idx + 1}</div>
        <div style="font-size:13px;font-weight:600;color:#0f172a;margin-top:2px">${escHtml(s.title || '')}</div>
        <ul style="margin:6px 0 0 14px;padding:0;font-size:11px;color:#475569">
          ${bullets.slice(0, 4).map((b) => `<li>${escHtml(b)}</li>`).join('')}
        </ul>
        ${s.notes ? `<div style="font-size:10px;color:#94a3b8;font-style:italic;margin-top:6px;border-top:1px dotted #e5e7eb;padding-top:4px">📝 ${escHtml(s.notes.slice(0, 200))}${s.notes.length > 200 ? '...' : ''}</div>` : ''}
      </div>`;
  }).join('');
  box.innerHTML = html;
}

function rejectPlan() {
  hide('step-approve');
  state.plan = null;
  state.planId = null;
  $('btn-plan').disabled = false;
  $('btn-plan').textContent = '🔄 Re-generar plan';
}

// ============================================================
// FASE 2: aprobar y generar PPTs
// ============================================================
async function approveAndGenerate() {
  if (!state.plan) return;
  const total = getSelectedCount();

  $('btn-approve').disabled = true;
  $('btn-reject').disabled = true;
  show('step-results');
  $('results-grid').innerHTML = '';
  show('gen-progress');
  hide('gen-status');
  setProgress(0, total, 'Verificando crédito...');

  // 1) Consumir N créditos (uno por cada slot a generar)
  for (let i = 0; i < total; i++) {
    try { await consumeCredit(); }
    catch (e) {
      showAlert('gen-status', `Error de crédito (${i + 1}/${total}): ${e.message}`, 'error');
      hide('gen-progress');
      $('btn-approve').disabled = false;
      $('btn-reject').disabled = false;
      return;
    }
  }

  // 2) Render por slot — paralelo con concurrencia 4
  // Iteramos en el orden visual elegido por el docente (state.slotOrder)
  setProgress(0, total, 'Generando PPTs...');
  let done = 0;
  const slots = state.slotOrder.slice(0, total);
  const CONCURRENCY = 4;

  async function processSlot(slotIdx) {
    const planSlot = state.plan.plan[slotIdx];
    const slotMeta = planSlot?.slot || {};
    const key = `rda${slotMeta.rda_index ?? 0}-slot${slotMeta.resource_slot ?? slotIdx}`;
    updateResultCard(key, 'pending');
    try {
      const data = await callFn('render-course-slot', {
        courseKey: state.courseKey,
        slotIdx,
        titleOverride: state.editedTitles[slotIdx] || undefined,
        useExternalSources: state.useExternalSources,
      });
      state.cost.render += data.cost_usd || 0;
      refreshCostTicker();
      updateResultCard(key, 'done', data.content);
    } catch (e) {
      updateResultCard(key, 'error', null, e.message);
    } finally {
      done++;
      setProgress(done, total, `Generando PPTs... (${done}/${total})`);
    }
  }

  // Worker pool
  let nextIdx = 0;
  async function worker() {
    while (true) {
      const my = nextIdx++;
      if (my >= slots.length) return;
      await processSlot(slots[my]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, total) }, () => worker()));

  setProgress(total, total, '✓ Todos los PPTs generados');
  showAlert('gen-status', `${total} PPT generados. Descarga los .pptx desde cada tarjeta.`, 'info');
  $('btn-approve').disabled = false;
  $('btn-reject').disabled = false;
  $('btn-approve').textContent = '🔄 Re-generar PPTs';
}

// ============================================================
// Tarjetas de resultado
// ============================================================
function setProgress(done, total, label) {
  $('gen-progress-count').textContent = `${done}/${total}`;
  $('gen-progress-fill').style.width = `${(done / total) * 100}%`;
  if (label) $('gen-progress-label').textContent = label;
}

function updateResultCard(key, status, content, error) {
  state.generations[key] = { status, content, error };
  let card = $(`card-${key}`);
  const grid = $('results-grid');
  if (!card) {
    card = document.createElement('div');
    card.id = `card-${key}`;
    card.className = 'result-card';
    grid.appendChild(card);
  }
  const m = key.match(/rda(\d+)-slot(\d+)/);
  const rda = m ? parseInt(m[1]) : 0;
  const slot = m ? parseInt(m[2]) : 0;
  card.classList.remove('done', 'pending', 'error');
  card.classList.add(status);
  let inner = `<div class="result-status ${status}">${status === 'done' ? '✓ Listo' : status === 'pending' ? '⏳ Generando' : '⚠ Error'}</div>`;
  inner += `<div class="result-title">RdA ${rda + 1} · PPT ${slot + 1}</div>`;
  if (status === 'done' && content) {
    const slidesCount = (content.slides || []).length;
    inner += `<div class="result-meta">${slidesCount} slides · "${escHtml((content.meta?.title || 'PPT').slice(0, 50))}"</div>`;
    inner += `<div class="result-actions"><button class="btn-secondary" data-key="${key}" data-action="download">Descargar .pptx</button> <button class="btn-secondary" data-key="${key}" data-action="retry">Re-generar</button></div>`;
  } else if (status === 'error') {
    inner += `<div class="result-meta" style="color:#991b1b">${escHtml(error || 'Error')}</div>`;
    inner += `<div class="result-actions"><button class="btn-secondary" data-key="${key}" data-action="retry">Reintentar</button></div>`;
  } else {
    inner += `<div class="result-meta">Esperando IA...</div>`;
  }
  card.innerHTML = inner;
  card.querySelectorAll('button[data-action]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const k = e.currentTarget.dataset.key;
      const act = e.currentTarget.dataset.action;
      if (act === 'download') downloadPpt(k);
      else if (act === 'retry') retrySingle(k);
    });
  });
}

async function retrySingle(key) {
  const m = key.match(/rda(\d+)-slot(\d+)/);
  if (!m || !state.plan) return;
  const slots = state.plan.plan;
  // Encontrar slotIdx que matchea (rda, slot)
  const targetRda = parseInt(m[1]);
  const targetSlot = parseInt(m[2]);
  const slotIdx = slots.findIndex((s) => {
    const sm = s.slot || {};
    return Number(sm.rda_index) === targetRda && Number(sm.resource_slot) === targetSlot;
  });
  if (slotIdx < 0) return;

  updateResultCard(key, 'pending');
  try {
    await consumeCredit();
    const data = await callFn('render-course-slot', {
      courseKey: state.courseKey,
      slotIdx,
      forceRegenerate: true,
      titleOverride: state.editedTitles[slotIdx] || undefined,
      useExternalSources: state.useExternalSources,
    });
    state.cost.render += data.cost_usd || 0;
    refreshCostTicker();
    updateResultCard(key, 'done', data.content);
  } catch (e) {
    updateResultCard(key, 'error', null, e.message);
  }
}

// ============================================================
// Materialización a .pptx con pptxgenjs
// ============================================================
async function downloadPpt(key) {
  const gen = state.generations[key];
  if (!gen || !gen.content) return;
  const content = gen.content;
  const meta = content.meta || {};
  const PptxGenJS = window.PptxGenJS;
  if (!PptxGenJS) { alert('pptxgenjs no cargó'); return; }

  // Pre-rasterizar todos los iconos únicos del PPT para no bloquear el loop
  const iconCache = {};
  if (window.iconSvgToPng && window.ICONS_BUNDLE) {
    const uniqueIcons = [...new Set((content.slides || []).map((s) => s.iconName).filter(Boolean))];
    for (const name of uniqueIcons) {
      try { iconCache[name] = await window.iconSvgToPng(name, '#003B7A'); }
      catch { /* si falla un icono, seguimos sin él */ }
    }
  }

  const pres = new PptxGenJS();
  pres.layout = 'LAYOUT_WIDE';
  pres.title = meta.title || 'PPT';
  pres.author = meta.teacher || 'NEXBYTE';
  pres.company = 'PUCESE';

  // Paleta institucional PUCE: azul profundo + dorado de acento
  const COLORS = {
    primary: '003B7A',     // azul PUCE
    accent: 'FFC72C',      // dorado PUCE (titulares secundarios)
    deep: '00264D',        // azul oscuro para portada
    light: 'E8F1FA',       // azul muy claro para fondos suaves
    text: '1F2937',
    white: 'FFFFFF',
    muted: '6B7280',
    rule: 'D4A017',        // línea acento más sobria
  };

  const courseLabel = (meta.course || $('i-asignatura').value || '').slice(0, 60);
  const rdaCriterio = `RdA ${(meta.rdaIndex ?? 0) + 1} · Criterio ${meta.criterio || 1}`;
  const dateStr = new Date().toLocaleDateString('es-EC', { day: '2-digit', month: 'short', year: 'numeric' });
  const footerText = `PUCESE · ${courseLabel || 'Asignatura'} · ${rdaCriterio} · ${dateStr}`;

  // Helper: header band + footer en cada slide de contenido
  function decorateContentSlide(slide, title) {
    // Header con franja azul
    slide.addShape('rect', { x: 0, y: 0, w: 13.33, h: 0.9, fill: { color: COLORS.primary } });
    // Línea dorada bajo el header
    slide.addShape('rect', { x: 0, y: 0.9, w: 13.33, h: 0.05, fill: { color: COLORS.accent } });
    if (title) {
      slide.addText(title, { x: 0.4, y: 0.15, w: 12.5, h: 0.6, fontSize: 22, bold: true, color: COLORS.white });
    }
    // Footer institucional
    slide.addText(footerText, {
      x: 0.4, y: 7.0, w: 12.5, h: 0.3,
      fontSize: 9, color: COLORS.muted, align: 'left', italic: true,
    });
    // Línea dorada superior al footer
    slide.addShape('rect', { x: 0.4, y: 6.97, w: 12.5, h: 0.02, fill: { color: COLORS.rule } });
  }

  for (const s of (content.slides || [])) {
    const slide = pres.addSlide();
    const layout = (s.layout || 'content').toLowerCase();

    if (layout === 'title') {
      // Portada: degradado simulado con bloque azul oscuro + acento dorado
      slide.background = { color: COLORS.deep };
      // Banda dorada lateral izquierda
      slide.addShape('rect', { x: 0, y: 0, w: 0.4, h: 7.5, fill: { color: COLORS.accent } });
      // Etiqueta institucional pequeña
      slide.addText('PONTIFICIA UNIVERSIDAD CATÓLICA DEL ECUADOR · SEDE ESMERALDAS',
        { x: 0.7, y: 0.5, w: 12, h: 0.3, fontSize: 10, color: COLORS.accent, bold: true, charSpacing: 4 });
      // Asignatura
      if (courseLabel) slide.addText(courseLabel,
        { x: 0.7, y: 1.0, w: 12, h: 0.4, fontSize: 14, color: COLORS.white, italic: true });
      // Título principal
      slide.addText(s.title || '',
        { x: 0.7, y: 2.4, w: 12, h: 1.8, fontSize: 36, bold: true, color: COLORS.white });
      // Subtítulo (RdA / Criterio)
      slide.addText(s.subtitle || rdaCriterio,
        { x: 0.7, y: 4.4, w: 12, h: 0.6, fontSize: 18, color: COLORS.accent });
      // Docente + fecha
      const docente = meta.teacher || $('i-docente').value || '';
      slide.addText(`${docente}${docente ? ' · ' : ''}${dateStr}`,
        { x: 0.7, y: 6.6, w: 12, h: 0.4, fontSize: 12, color: COLORS.light });
    } else if (layout === 'two-column' || layout === 'twocolumn') {
      slide.background = { color: COLORS.white };
      decorateContentSlide(slide, s.title || '');
      if (s.leftTitle) slide.addText(s.leftTitle, { x: 0.5, y: 1.2, w: 6, h: 0.4, fontSize: 16, bold: true, color: COLORS.primary });
      if (s.rightTitle) slide.addText(s.rightTitle, { x: 6.8, y: 1.2, w: 6, h: 0.4, fontSize: 16, bold: true, color: COLORS.primary });
      slide.addText((s.leftBullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 14, color: COLORS.text, paraSpaceAfter: 4 } })), { x: 0.5, y: 1.75, w: 6, h: 5.0 });
      slide.addText((s.rightBullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 14, color: COLORS.text, paraSpaceAfter: 4 } })), { x: 6.8, y: 1.75, w: 6, h: 5.0 });
      if (s.iconName && iconCache[s.iconName]) {
        slide.addImage({ data: iconCache[s.iconName], x: 12.5, y: 0.15, w: 0.6, h: 0.6 });
      }
      if (s.notes) slide.addNotes(s.notes);
    } else {
      slide.background = { color: COLORS.white };
      decorateContentSlide(slide, s.title || '');
      const bullets = (s.bullets || []).map((b) => ({ text: b, options: { bullet: true, fontSize: 16, color: COLORS.text, paraSpaceAfter: 6 } }));
      slide.addText(bullets.length ? bullets : [{ text: '(sin bullets)', options: { italic: true, color: COLORS.muted } }], { x: 0.5, y: 1.2, w: s.imageHint ? 8.2 : 12.4, h: 5.6 });
      if (s.iconName && iconCache[s.iconName]) {
        slide.addImage({ data: iconCache[s.iconName], x: 12.5, y: 0.15, w: 0.6, h: 0.6 });
      }
      if (s.imageHint) {
        slide.addShape('rect', { x: 9, y: 1.4, w: 3.9, h: 4, fill: { color: COLORS.light }, line: { color: COLORS.primary, width: 1, dashType: 'dash' } });
        slide.addText('IMAGEN SUGERIDA:\n' + s.imageHint, { x: 9.1, y: 1.6, w: 3.7, h: 3.6, fontSize: 11, italic: true, color: COLORS.muted, align: 'center', valign: 'middle' });
      }
      if (s.notes) slide.addNotes(s.notes);
    }
  }

  const fileName = `${($('i-asignatura').value || 'curso').replace(/[^a-zA-Z0-9_-]/g, '_')}_${key}.pptx`;
  pres.writeFile({ fileName });
}

// ============================================================
// Cursos guardados (reutilización entre semestres)
// ============================================================
async function loadSavedCourses() {
  if (!state.session?.token || !state.userId) return;
  try {
    const url = `${CONFIG.SUPABASE_URL}/rest/v1/course_plans?user_id=eq.${state.userId}&select=id,course_key,course_label,repotenciada,teacher_name,book_hashes,gaps,plan,coverage_matrix,syllabus_extracted,surplus,created_at,updated_at&order=updated_at.desc&limit=20`;
    const res = await fetch(url, {
      headers: { 'apikey': CONFIG.SUPABASE_ANON_KEY, 'Authorization': `Bearer ${state.session.token}` },
    });
    if (!res.ok) return;
    const rows = await res.json();
    if (!Array.isArray(rows) || rows.length === 0) return;

    const wrap = $('saved-courses');
    const list = $('saved-courses-list');
    list.innerHTML = rows.map((row) => {
      const date = new Date(row.updated_at || row.created_at);
      const dateStr = date.toLocaleDateString('es-EC', { day: '2-digit', month: 'short', year: 'numeric' });
      const gapsCount = Array.isArray(row.gaps) ? row.gaps.length : 0;
      const slotsCount = Array.isArray(row.plan) ? row.plan.length : 0;
      return `
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px 12px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:6px">
          <div style="flex:1;min-width:0">
            <div style="font-size:13px;font-weight:600;color:#0f172a;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(row.course_label || '(sin nombre)')}</div>
            <div style="font-size:11px;color:#64748b;margin-top:2px">${slotsCount} PPTs · ${gapsCount} gaps · ${dateStr}${row.teacher_name ? ' · ' + escHtml(row.teacher_name) : ''}</div>
          </div>
          <button type="button" class="btn-secondary" data-load="${row.course_key}" style="font-size:11px;padding:6px 12px">Reutilizar →</button>
        </div>`;
    }).join('');

    list.querySelectorAll('[data-load]').forEach((btn) => {
      btn.addEventListener('click', () => loadSavedPlan(btn.dataset.load, rows));
    });

    wrap.style.display = 'block';
  } catch (_) { /* silencio */ }
}

function loadSavedPlan(courseKey, allRows) {
  const row = allRows.find((r) => r.course_key === courseKey);
  if (!row) return;

  state.courseKey = courseKey;
  state.plan = {
    syllabus_extracted: row.syllabus_extracted || [],
    coverage_matrix: row.coverage_matrix || [],
    gaps: row.gaps || [],
    surplus: row.surplus || [],
    plan: row.plan || [],
  };
  state.planId = row.id;
  state.bookHashes = Array.isArray(row.book_hashes) ? row.book_hashes : [];
  state.editedTitles = {};
  state.slotOrder = (row.plan || []).map((_, i) => i);

  // Pre-llenar inputs (visualmente)
  if (row.course_label) $('i-asignatura').value = row.course_label;
  if (row.teacher_name) $('i-docente').value = row.teacher_name;
  if (typeof row.repotenciada === 'boolean') $('i-repotenciada').checked = row.repotenciada;

  // Mostrar paso de aprobación directamente
  renderPlanApproval();
  show('step-approve');
  showAlert('gen-status', '✓ Plan reutilizado · sin costo de planificación · solo pagas el render de PPTs.', 'info');
  hide('gen-progress');
  show('cost-ticker');
  refreshCostTicker();

  $('step-approve').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ============================================================
// Init
// ============================================================
(async function init() {
  setupFormHandlers();
  const ok = await initAuth();
  if (!ok) {
    document.querySelectorAll('.step-card').forEach((c) => c.classList.add('disabled'));
  } else {
    await loadSavedCourses();
  }
})();
