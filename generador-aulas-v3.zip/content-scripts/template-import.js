/**
 * Generador de Aulas - Importar plantilla .mbz en Moodle.
 * Selectores de: importar_plantilla.py
 *
 * Flujo multi-pagina:
 * 1. Popup navega a /backup/restorefile.php
 * 2. Content script detecta la pagina y busca el contextid correcto
 * 3. Automatiza: subir archivo, configurar restauracion, ejecutar
 *
 * El archivo .mbz NO se puede transferir desde el popup (limitacion de Chrome).
 * El content script abre el file picker y el usuario re-selecciona el archivo.
 */

(async function checkImportState() {
  const state = await gaulaGetState();
  if (!state || state.action !== 'import_template') return;

  const url = window.location.href;

  try {

    // ============================================================
    // PASO 1: Estamos en alguna pagina del curso - buscar contextid y navegar a restore
    // ============================================================
    if (state.step === 'navigate_to_restore') {
      await gaulaWait(2000);
      gaulaReportProgress(0, 5, 'running', { step: 'Buscando página de restauración...' });

      // Si la URL tiene contextid=auto, necesitamos encontrar el real
      if (url.includes('contextid=auto') || url.includes('restorefile.php')) {
        // Buscar el contextid correcto en la pagina
        // Opcion 1: Ya estamos en restorefile.php con el contextid correcto
        const currentContextMatch = url.match(/contextid=(\d+)/);
        if (currentContextMatch && currentContextMatch[1] !== 'auto') {
          // Ya tenemos el contextid, avanzar al paso de upload
          await gaulaSaveState({ ...state, step: 'upload' });
          window.location.reload();
          return;
        }

        // Opcion 2: Buscar via la navegacion del curso
        // Ir al curso primero, luego navegar via menu
        const courseUrl = `${state.moodleBase}/course/view.php?id=${state.courseId}`;
        await gaulaSaveState({ ...state, step: 'find_restore_link' });
        window.location.href = courseUrl;
        return;
      }
    }

    // ============================================================
    // PASO 1b: Estamos en el curso - navegar a Restaurar via menu
    // ============================================================
    if (state.step === 'find_restore_link' && url.includes('/course/view.php')) {
      await gaulaWait(2000);
      gaulaReportProgress(0, 5, 'running', { step: 'Navegando a Restaurar...' });

      // Click en "Más" del menu del curso
      const moreMenu = gaulaByRole('menuitem', 'Más');
      if (moreMenu) {
        gaulaClick(moreMenu);
        await gaulaWait(1000);
      }

      // Click en "Reutilización de curso"
      const reuseLink = gaulaByRole('menuitem', 'Reutilización de curso');
      if (reuseLink) {
        await gaulaSaveState({ ...state, step: 'select_restore' });
        gaulaClick(reuseLink);
        return;
      }

      // Fallback: buscar link directo a restaurar en la pagina
      const restoreLink = document.querySelector('a[href*="restorefile.php"]');
      if (restoreLink) {
        await gaulaSaveState({ ...state, step: 'upload' });
        gaulaClick(restoreLink);
        return;
      }

      throw new Error('No se encontró el menú de Reutilización de curso.');
    }

    // ============================================================
    // PASO 1c: Estamos en Reutilizacion de curso - seleccionar "Restaurar"
    // ============================================================
    if (state.step === 'select_restore') {
      await gaulaWait(2000);
      gaulaReportProgress(0, 5, 'running', { step: 'Seleccionando Restaurar...' });

      // Buscar el select de administracion
      const adminSelect = gaulaByLabel('Explorar la administración');
      if (adminSelect) {
        const restoreOption = [...adminSelect.options].find(o =>
          o.value.includes('restorefile.php')
        );
        if (restoreOption) {
          await gaulaSaveState({ ...state, step: 'upload' });
          gaulaSetSelect(adminSelect, restoreOption.value);
          // El select suele navegar automaticamente, pero por si acaso:
          await gaulaWait(500);
          window.location.href = state.moodleBase + restoreOption.value;
          return;
        }
      }

      // Fallback: buscar link directo
      const restoreLink = document.querySelector('a[href*="restorefile.php"]');
      if (restoreLink) {
        await gaulaSaveState({ ...state, step: 'upload' });
        gaulaClick(restoreLink);
        return;
      }

      throw new Error('No se encontró la opción de Restaurar.');
    }

    // ============================================================
    // PASO 2: Pagina de restauracion - subir archivo .mbz automáticamente
    // ============================================================
    if (url.includes('restorefile.php') && (state.step === 'upload' || state.step === 'wait_for_file')) {
      await gaulaWait(2000);
      gaulaReportProgress(1, 5, 'running', { step: `Subiendo ${state.fileName}...` });

      // Si tenemos el archivo serializado, subirlo automáticamente
      if (state.fileSerialized) {
        const file = gaulaDeserializeFile(state.fileSerialized);

        // 1. Click "Seleccione un archivo..."
        const selectFileBtn = gaulaByRole('button', 'Seleccione un archivo') ||
                              gaulaByText('Seleccione un archivo', 'button');
        if (selectFileBtn) {
          gaulaClick(selectFileBtn);
          await gaulaWait(1500);
        }

        // 2. Click "Subir un archivo" en el file picker
        const uploadLink = gaulaByRole('link', 'Subir un archivo');
        if (uploadLink) {
          gaulaClick(uploadLink);
          await gaulaWait(800);
        }

        // 3. Buscar input[type=file] y asignar archivo
        const fileInput = document.querySelector('input[type="file"][name="repo_upload_file"]') ||
                          document.querySelector('.fp-upload-form input[type="file"]') ||
                          document.querySelector('.file-picker input[type="file"]') ||
                          document.querySelector('input[type="file"]');
        if (fileInput) {
          gaulaUploadFile(fileInput, file);
          await gaulaWait(2000);

          // 4. Click "Subir este archivo"
          const uploadBtn = gaulaByRole('button', 'Subir este archivo');
          if (uploadBtn) {
            gaulaClick(uploadBtn);
            await gaulaWait(3000);
          }
        }

        // Limpiar archivo serializado del state para ahorrar memoria
        await gaulaSaveState({ ...state, fileSerialized: null, step: 'wait_restore_btn' });
      }

      // Esperar a que aparezca el botón "Restaurar"
      gaulaReportProgress(2, 5, 'running', { step: 'Esperando confirmación...' });

      const checkRestore = async () => {
        const restoreBtn = gaulaByRole('button', 'Restaurar');
        if (restoreBtn) {
          gaulaReportProgress(2, 5, 'running', { step: 'Restaurando...' });
          await gaulaSaveState({ ...state, fileSerialized: null, step: 'configure_step1' });
          gaulaClick(restoreBtn);
          return true;
        }
        return false;
      };

      // Verificar inmediatamente
      if (await checkRestore()) return;

      // Observar cambios para detectar el botón
      const observer = new MutationObserver(async () => {
        if (await checkRestore()) observer.disconnect();
      });
      observer.observe(document.body, { childList: true, subtree: true });
      return;
    }

    // Paso intermedio: ya subimos pero esperamos botón Restaurar
    if (url.includes('restorefile.php') && state.step === 'wait_restore_btn') {
      await gaulaWait(1500);
      const restoreBtn = gaulaByRole('button', 'Restaurar');
      if (restoreBtn) {
        gaulaReportProgress(2, 5, 'running', { step: 'Restaurando...' });
        await gaulaSaveState({ ...state, step: 'configure_step1' });
        gaulaClick(restoreBtn);
        return;
      }
      // Seguir observando
      const observer = new MutationObserver(async () => {
        const btn = gaulaByRole('button', 'Restaurar');
        if (btn) {
          observer.disconnect();
          await gaulaSaveState({ ...state, step: 'configure_step1' });
          gaulaClick(btn);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      return;
    }

    // ============================================================
    // PASO 3a: Primer "Continuar" (confirmacion del backup)
    // Flujo real: Restaurar → Continuar → [Borrar contenido] → Continuar → Siguiente → [Roles] → Siguiente → Ejecutar
    // ============================================================
    if (url.includes('/backup/restore.php') &&
        (state.step === 'restore_click' || state.step === 'configure_step1')) {
      await gaulaWait(2000);
      gaulaReportProgress(3, 7, 'running', { step: 'Confirmando backup...' });

      const continueBtn = gaulaByRole('button', 'Continuar');
      if (continueBtn) {
        await gaulaSaveState({ ...state, step: 'configure_step2' });
        gaulaClick(continueBtn);
        return;
      }
    }

    // ============================================================
    // PASO 3b: Marcar "Borrar contenido del curso" → Continuar
    // ============================================================
    if (url.includes('/backup/restore.php') && state.step === 'configure_step2') {
      await gaulaWait(2000);
      gaulaReportProgress(4, 7, 'running', { step: 'Borrando contenido anterior...' });

      const deleteCheck = gaulaByLabel('Borrar el contenido del curso');
      if (deleteCheck && !deleteCheck.checked) {
        gaulaClick(deleteCheck);
        await gaulaWait(500);
      }

      // En esta pagina es "Continuar" (no "Siguiente")
      const continueBtn = gaulaByRole('button', 'Continuar');
      if (continueBtn) {
        await gaulaSaveState({ ...state, step: 'configure_step3' });
        gaulaClick(continueBtn);
        return;
      }
    }

    // ============================================================
    // PASO 3c: Pagina de esquema → "Siguiente"
    // ============================================================
    if (url.includes('/backup/restore.php') && state.step === 'configure_step3') {
      await gaulaWait(2000);
      gaulaReportProgress(5, 7, 'running', { step: 'Configurando esquema...' });

      const nextBtn = gaulaByRole('button', 'Siguiente');
      if (nextBtn) {
        await gaulaSaveState({ ...state, step: 'configure_step4' });
        gaulaClick(nextBtn);
        return;
      }
    }

    // ============================================================
    // PASO 3d: "Mantener los roles y" → Sí (1) → "Siguiente"
    // ============================================================
    if (url.includes('/backup/restore.php') && state.step === 'configure_step4') {
      await gaulaWait(2000);
      gaulaReportProgress(6, 7, 'running', { step: 'Configurando roles y matrículas...' });

      // Mantener los roles y matriculaciones → "Sí" (valor "1")
      const rolesSelect = gaulaByLabel('Mantener los roles y');
      if (rolesSelect) {
        gaulaSetSelect(rolesSelect, '1');
        await gaulaWait(300);
      }

      // Mantener los grupos (si existe en esta pagina)
      const groupsSelect = gaulaByLabel('Mantener los grupos y');
      if (groupsSelect) {
        gaulaSetSelect(groupsSelect, '1');
        await gaulaWait(300);
      }

      const nextBtn = gaulaByRole('button', 'Siguiente');
      if (nextBtn) {
        await gaulaSaveState({ ...state, step: 'execute' });
        gaulaClick(nextBtn);
        return;
      }
    }

    // ============================================================
    // PASO 4: Ejecutar restauracion
    // ============================================================
    if (url.includes('/backup/restore.php') && state.step === 'execute') {
      await gaulaWait(2000);
      gaulaReportProgress(4, 5, 'running', { step: 'Ejecutando restauración...' });

      const executeBtn = gaulaByRole('button', 'Ejecutar restauración');
      if (executeBtn) {
        await gaulaSaveState({ ...state, step: 'finish' });
        gaulaClick(executeBtn);
        return;
      }

      // Si no hay ejecutar, buscar Siguiente o Continuar
      const nextBtn = gaulaByRole('button', 'Siguiente') || gaulaByRole('button', 'Continuar');
      if (nextBtn) {
        gaulaClick(nextBtn);
        return;
      }
    }

    // ============================================================
    // PASO 5: Finalizar
    // ============================================================
    if (state.step === 'finish') {
      await gaulaWait(3000);

      const continueBtn = gaulaByRole('button', 'Continuar');
      if (continueBtn) {
        gaulaClearState();
        gaulaReportProgress(5, 5, 'done', { step: 'Plantilla importada exitosamente' });
        gaulaClick(continueBtn);
        return;
      }

      // Si ya estamos en el curso, terminamos
      if (url.includes('/course/view.php')) {
        gaulaClearState();
        gaulaReportProgress(5, 5, 'done', { step: 'Plantilla importada exitosamente' });
      }
    }

  } catch (err) {
    gaulaClearState();
    gaulaReportProgress(0, 0, 'error', { step: 'import_template', error: err.message });
  }
})();

// Handler para recibir mensajes del popup (fallback si se usa directamente)
gaulaRegisterHandler('import_template', async (msg, sendResponse) => {
  try {
    await gaulaAcquireLock('import_template');
  } catch (e) {
    sendResponse({ ok: false, error: e.message });
    return;
  }
  sendResponse({ ok: true, message: 'Usa el botón del popup para iniciar la importación.' });
});
