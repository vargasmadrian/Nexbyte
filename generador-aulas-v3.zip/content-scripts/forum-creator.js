/**
 * Generador de Aulas - Crear foros de discusion en Moodle.
 * Selectores de: crear_foro.py
 *
 * Flujo:
 * 1. Crear actividad "Foro"
 * 2. Nombre, descripcion, fechas de disponibilidad
 * 3. Guardar
 * 4. Mover a seccion "Foro Académico"
 */

gaulaRegisterHandler('create_forum', async (msg, sendResponse) => {
  try {
    await gaulaAcquireLock('create_forum');
    const { forumName, forumDescription, sectionIndex } = msg;
    gaulaReportProgress(0, 4, 'running', { step: 'create_forum' });

    // Paso 1 - Activar edicion
    await gaulaEnableEditing();
    gaulaCheckStop();
    gaulaReportProgress(1, 4, 'running', { step: 'create_forum' });

    // Paso 2 - Abrir dialogo y seleccionar "Foro"
    await gaulaOpenActivityChooser(sectionIndex || 1);
    await gaulaWait(500);

    const forumLink = await gaulaWaitForRole('link', 'Foro', { exact: true });
    gaulaClick(forumLink);
    await gaulaWait(2000);
    gaulaCheckStop();
    gaulaReportProgress(2, 4, 'running', { step: 'create_forum' });

    // Paso 3 - Nombre y descripcion
    const nameInput = await gaulaWaitForRole('textbox', 'Nombre del foro');
    gaulaSetValue(nameInput, forumName);
    await gaulaWait(300);

    // Descripcion en el editor Atto
    const descEditor = document.querySelector('.editor_atto_content[contenteditable="true"]');
    if (descEditor) {
      descEditor.innerHTML = forumDescription;
      descEditor.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      const descInput = gaulaByRole('textbox', 'Descripción');
      if (descInput) {
        if (descInput.contentEditable === 'true') {
          descInput.innerHTML = forumDescription;
        } else {
          gaulaSetValue(descInput, forumDescription);
        }
      }
    }

    // Mostrar descripcion en la pagina
    const showDescCheck = gaulaByLabel('Muestra la descripción en la');
    if (showDescCheck && !showDescCheck.checked) {
      gaulaClick(showDescCheck);
    }

    // Paso 4 - Disponibilidad (fechas opcionales)
    if (msg.fechaEntrega || msg.fechaLimite) {
      const dispBtn = gaulaByRole('button', '# Disponibilidad') || gaulaByText('Disponibilidad', 'button');
      if (dispBtn) {
        gaulaClick(dispBtn);
        await gaulaWait(500);
      }

      if (msg.fechaEntrega) {
        // Habilitar fecha de entrega
        const entregaGroup = gaulaByText('Fecha de entrega', 'fieldset');
        if (entregaGroup) {
          const enableCheck = entregaGroup.querySelector('input[type="checkbox"]');
          if (enableCheck && !enableCheck.checked) gaulaClick(enableCheck);
          await gaulaWait(300);

          const daySelect = entregaGroup.querySelector('select[name*="day"]');
          if (daySelect && msg.fechaEntrega.dia) gaulaSetSelect(daySelect, msg.fechaEntrega.dia);
          const hourSelect = entregaGroup.querySelector('select[name*="hour"]');
          if (hourSelect && msg.fechaEntrega.hora) gaulaSetSelect(hourSelect, msg.fechaEntrega.hora);
          const minSelect = entregaGroup.querySelector('select[name*="minute"]');
          if (minSelect) gaulaSetSelect(minSelect, msg.fechaEntrega.minuto || '0');
        }
      }

      if (msg.fechaLimite) {
        const limiteGroup = gaulaByText('Fecha límite', 'fieldset');
        if (limiteGroup) {
          const daySelect = limiteGroup.querySelector('select[name*="day"]');
          if (daySelect && msg.fechaLimite.dia) gaulaSetSelect(daySelect, msg.fechaLimite.dia);
          const hourSelect = limiteGroup.querySelector('select[name*="hour"]');
          if (hourSelect && msg.fechaLimite.hora) gaulaSetSelect(hourSelect, msg.fechaLimite.hora);
          const minSelect = limiteGroup.querySelector('select[name*="minute"]');
          if (minSelect) gaulaSetSelect(minSelect, msg.fechaLimite.minuto || '0');
        }
      }
    }

    gaulaCheckStop();
    gaulaReportProgress(3, 4, 'running', { step: 'create_forum' });

    // Paso 5 - Guardar
    const saveBtn = gaulaByRole('button', 'Guardar cambios y regresar al');
    if (saveBtn) {
      gaulaClick(saveBtn);
      await gaulaWait(3000);
    }

    // Paso 6 - Mover a "Foro Académico"
    await gaulaMoveLastResource('Foro Académico');

    await gaulaReleaseLock();
    gaulaReportProgress(4, 4, 'done', { step: 'create_forum' });
    sendResponse({ ok: true });

  } catch (err) {
    if (err.message === 'STOPPED') {
      gaulaReportProgress(0, 0, 'stopped', { step: 'create_forum' });
    } else {
      gaulaReportProgress(0, 0, 'error', { step: 'create_forum', error: err.message });
    }
    sendResponse({ ok: false, error: err.message });
  }
});
