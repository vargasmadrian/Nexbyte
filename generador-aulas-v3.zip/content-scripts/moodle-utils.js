/**
 * GeneradorAulas 3.0 - Utilidades compartidas para Moodle DOM.
 * Fixes aplicados:
 * - Bug #1: gaulaSaveState siempre retorna Promise (await obligatorio)
 * - Bug #3: Lock de operación para evitar concurrencia
 * - Bug #8: Timeout configurable (CONFIG.ELEMENT_TIMEOUT)
 * - Bug #11: saveFormState con debounce
 * - Bug #14: Logs persistentes de errores
 * - Bug #15: Limpieza de estados huérfanos
 */

window.__gaulaStopFlag = false;

// ============================================================
// Bug #3: Lock de operación — previene ejecuciones concurrentes
// ============================================================
const GAULA_LOCK_KEY = 'gaula_operation_lock';

async function gaulaAcquireLock(operationName) {
  const { [GAULA_LOCK_KEY]: lock } = await chrome.storage.local.get(GAULA_LOCK_KEY);
  // Si hay un lock activo de menos de 5 minutos, rechazar
  if (lock && lock.active && (Date.now() - lock.ts) < 300000) {
    throw new Error(`Operación "${lock.operation}" en progreso. Espera a que termine.`);
  }
  await chrome.storage.local.set({
    [GAULA_LOCK_KEY]: { active: true, operation: operationName, ts: Date.now() }
  });
}

async function gaulaReleaseLock() {
  await chrome.storage.local.remove(GAULA_LOCK_KEY);
}

// Auto-liberar lock cuando se limpia el estado
const _originalClearState = typeof gaulaClearState === 'function' ? gaulaClearState : null;

// ============================================================
// Bug #15: Limpieza de estados huérfanos al cargar
// ============================================================
(async function gaulaCleanOrphanState() {
  const state = await new Promise(resolve => {
    chrome.storage.local.get('gaula_content_state', result => {
      resolve(result.gaula_content_state || null);
    });
  });
  if (!state) return;

  // Si el estado tiene más de 10 minutos sin actualización, es huérfano
  const stateAge = Date.now() - (state.ts || 0);
  if (stateAge > 600000) { // 10 minutos
    console.warn('[GAULA 3.0] Limpiando estado huérfano:', state.action, state.step);
    chrome.storage.local.remove('gaula_content_state');
    chrome.storage.local.remove(GAULA_LOCK_KEY);
    // Limpiar archivos huérfanos
    chrome.storage.local.get(null, (all) => {
      const orphanKeys = Object.keys(all).filter(k => k.startsWith('gaula_file_'));
      if (orphanKeys.length > 0) chrome.storage.local.remove(orphanKeys);
    });
  }
})();

// ============================================================
// Utilidades base
// ============================================================

function gaulaWait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function gaulaCheckStop() { if (window.__gaulaStopFlag) throw new Error('STOPPED'); }

// Bug #8: Timeout configurable desde CONFIG (default 20s en vez de 10s)
function gaulaWaitForElement(selector, timeout, parent = document) {
  timeout = timeout || (typeof CONFIG !== 'undefined' ? CONFIG.ELEMENT_TIMEOUT : 20000);
  return new Promise((resolve, reject) => {
    const el = parent.querySelector(selector);
    if (el) return resolve(el);
    const observer = new MutationObserver(() => {
      const el = parent.querySelector(selector);
      if (el) { observer.disconnect(); resolve(el); }
    });
    observer.observe(parent, { childList: true, subtree: true });
    setTimeout(() => { observer.disconnect(); reject(new Error(`Timeout esperando: ${selector}`)); }, timeout);
  });
}

function gaulaClick(element) {
  element.scrollIntoView({ behavior: 'instant', block: 'center' });
  element.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
  element.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
  element.click();
}

function gaulaSetValue(element, value) {
  element.focus(); element.value = value;
  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
  element.dispatchEvent(new Event('blur', { bubbles: true }));
}

function gaulaSetSelect(element, value) {
  element.value = value;
  element.dispatchEvent(new Event('change', { bubbles: true }));
}

function gaulaSetEditor(editorId, htmlContent) {
  if (typeof tinymce !== 'undefined') {
    const editor = tinymce.get(editorId);
    if (editor) { editor.setContent(htmlContent); editor.fire('change'); return true; }
  }
  const attoEditor = document.querySelector(`[data-fieldtype="editor"] .editor_atto_content[contenteditable="true"]`);
  if (attoEditor) { attoEditor.innerHTML = htmlContent; attoEditor.dispatchEvent(new Event('input', { bubbles: true })); return true; }
  const textarea = document.getElementById(editorId);
  if (textarea) { textarea.value = htmlContent; textarea.dispatchEvent(new Event('change', { bubbles: true })); return true; }
  return false;
}

function gaulaUploadFile(fileInput, file) {
  const dt = new DataTransfer(); dt.items.add(file);
  fileInput.files = dt.files;
  fileInput.dispatchEvent(new Event('change', { bubbles: true }));
}

function gaulaByRole(role, name, opts = {}) {
  const parent = opts.parent || document;
  const exact = opts.exact || false;
  const roleToSelector = {
    button: 'button, input[type="button"], input[type="submit"], [role="button"]',
    link: 'a, [role="link"]',
    textbox: 'input[type="text"], input[type="password"], input[type="email"], input[type="url"], input[type="number"], input[type="search"], textarea, [contenteditable="true"], [role="textbox"]',
    menuitem: '[role="menuitem"], .dropdown-item',
    checkbox: 'input[type="checkbox"]',
    option: 'option',
    group: 'fieldset, [role="group"]',
    cell: 'td, th, [role="cell"], [role="gridcell"]',
    searchbox: 'input[type="search"], [role="searchbox"]',
  };
  const selector = roleToSelector[role] || `[role="${role}"]`;
  const elements = [...parent.querySelectorAll(selector)];
  return elements.find(el => {
    const text = (el.textContent || '').trim();
    const ariaLabel = el.getAttribute('aria-label') || '';
    const attrName = el.getAttribute('name') || '';
    const title = el.getAttribute('title') || '';
    const value = el.getAttribute('value') || '';
    let labelText = '';
    const elId = el.id;
    if (elId) { const assocLabel = parent.querySelector(`label[for="${elId}"]`); if (assocLabel) labelText = assocLabel.textContent.trim(); }
    if (!labelText) { const parentLabel = el.closest('label'); if (parentLabel) labelText = parentLabel.textContent.trim(); }
    const combined = `${text} ${ariaLabel} ${attrName} ${title} ${value} ${labelText}`;
    if (exact) return text === name || ariaLabel === name || labelText === name;
    return combined.toLowerCase().includes(name.toLowerCase());
  });
}

function gaulaByLabel(labelText, opts = {}) {
  const parent = opts.parent || document;
  const exact = opts.exact || false;
  const labels = [...parent.querySelectorAll('label')];
  const label = labels.find(l => { const t = l.textContent.trim(); return exact ? t === labelText : t.toLowerCase().includes(labelText.toLowerCase()); });
  if (label) { const forId = label.getAttribute('for'); if (forId) return parent.querySelector(`#${forId}`); return label.querySelector('input, select, textarea'); }
  return parent.querySelector(`[aria-label*="${labelText}"]`);
}

function gaulaByText(text, tag = '*', parent = document) {
  const elements = [...parent.querySelectorAll(tag)];
  return elements.find(el => el.textContent.trim().includes(text));
}

// Bug #8: Timeout configurable
async function gaulaWaitForRole(role, name, opts = {}) {
  const timeout = opts.timeout || (typeof CONFIG !== 'undefined' ? CONFIG.ELEMENT_TIMEOUT : 20000);
  const interval = 300; const maxAttempts = Math.ceil(timeout / interval);
  for (let i = 0; i < maxAttempts; i++) { const el = gaulaByRole(role, name, opts); if (el) return el; await gaulaWait(interval); }
  throw new Error(`Timeout esperando ${role}: "${name}"`);
}

async function gaulaWaitForLabel(labelText, opts = {}) {
  const timeout = opts.timeout || (typeof CONFIG !== 'undefined' ? CONFIG.ELEMENT_TIMEOUT : 20000);
  const interval = 300; const maxAttempts = Math.ceil(timeout / interval);
  for (let i = 0; i < maxAttempts; i++) { const el = gaulaByLabel(labelText, opts); if (el) return el; await gaulaWait(interval); }
  throw new Error(`Timeout esperando label: "${labelText}"`);
}

async function gaulaEnableEditing() {
  const editSwitch = document.querySelector('[id$="-editingswitch"]');
  if (editSwitch && !editSwitch.checked) { gaulaClick(editSwitch); await gaulaWait(1500); }
}

async function gaulaOpenActivityChooser(sectionIndex) {
  const section = document.querySelector(`#coursecontentcollapse${sectionIndex}`);
  if (!section) throw new Error(`Seccion ${sectionIndex} no encontrada`);
  const addBtn = gaulaByRole('button', 'Crear una Actividad o Recurso', { parent: section });
  if (!addBtn) throw new Error('Boton "Crear una Actividad o Recurso" no encontrado');
  gaulaClick(addBtn); await gaulaWait(1000);
}

async function gaulaSearchAndClickActivity(searchTerm, linkName) {
  linkName = linkName || searchTerm;
  const searchInput = gaulaByRole('textbox', 'Buscar actividades por nombre') || document.querySelector('input[id^="searchinput"]') || document.querySelector('input[role="searchbox"]');
  if (!searchInput) throw new Error('No se encontró la barra de búsqueda del selector de actividades');
  searchInput.value = ''; searchInput.focus();
  gaulaSetValue(searchInput, searchTerm);
  searchInput.dispatchEvent(new Event('input', { bubbles: true }));
  await gaulaWait(1000);
  const allOptions = document.querySelectorAll('a[data-action="add-chooser-option"]');
  const activityLink = [...allOptions].find(a => { const nameEl = a.querySelector('.optionname'); return nameEl && nameEl.textContent.trim().toLowerCase().includes(linkName.toLowerCase()); });
  if (!activityLink) throw new Error(`No se encontró la actividad "${linkName}" en el selector`);
  gaulaClick(activityLink);
}

// Bug #1: gaulaSaveState SIEMPRE retorna Promise y agrega timestamp
function gaulaSaveState(state) {
  state.ts = Date.now(); // Timestamp para detección de huérfanos (Bug #15)
  return chrome.storage.local.set({ gaula_content_state: state });
}

function gaulaGetState() { return new Promise(resolve => { chrome.storage.local.get('gaula_content_state', result => { resolve(result.gaula_content_state || null); }); }); }

// Bug #3: gaulaClearState también libera el lock
function gaulaClearState() {
  chrome.storage.local.remove('gaula_content_state');
  chrome.storage.local.remove(GAULA_LOCK_KEY);
}

// Auto-detectar tipo de aula leyendo las secciones del DOM
function gaulaDetectCourseType() {
  const rdaPattern = /^RDA\s+\d+$/i;
  const elements = document.querySelectorAll('a, h3, h4, .sectionname, [data-for="section_title"], .inplaceeditable');
  for (const el of elements) {
    const t = el.textContent.trim();
    if (rdaPattern.test(t)) return 'repotenciada';
    if (t === 'RECURSOS' || t === 'PRODUCTOS Y ACTIVIDADES') return 'repotenciada';
  }
  const allText = document.body?.innerText || '';
  if (/\bRDA\s+\d+\b/i.test(allText)) return 'repotenciada';
  if (/\bRECURSOS\b/.test(allText) || /\bPRODUCTOS Y ACTIVIDADES\b/.test(allText)) return 'repotenciada';
  return 'normal';
}

// Fallbacks inteligentes según tipo de recurso
function gaulaFindFallbackSection(targetName, resourceType) {
  const key = targetName.toLowerCase();
  const t = (resourceType || '').toLowerCase();
  if (key === 'recursos') {
    if (t === 'video' || t === 'geneally') return ['recursos opcionales', 'recursos principales'];
    if (t === 'pdf' || t === 'ppt') return ['recursos principales', 'recursos opcionales'];
    return ['recursos principales', 'recursos opcionales'];
  }
  if (key === 'productos y actividades') {
    if (t === 'quiz') return ['evaluacion [bg-etiqueta', 'actividades'];
    if (t === 'assignment') return ['actividades'];
    return ['actividades', 'evaluacion [bg-etiqueta'];
  }
  if (key === 'recursos principales' || key === 'recursos opcionales') return ['recursos'];
  if (key === 'actividades') return ['productos y actividades'];
  if (key.startsWith('evaluacion')) return ['productos y actividades', 'actividades'];
  return [];
}

function gaulaDismissMoveModal() {
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
  const modal = document.querySelector('.modal.show, .modal[style*="display: block"]');
  if (modal) {
    const closeBtn = modal.querySelector('button.close, [data-dismiss="modal"], [data-action="hide"]');
    if (closeBtn) gaulaClick(closeBtn); else modal.style.display = 'none';
  }
  const backdrop = document.querySelector('.modal-backdrop');
  if (backdrop) backdrop.remove();
}

function gaulaSectionMatch(linkText, target) {
  const lt = linkText.replace(/[\u00A0\s]+/g, ' ').trim().toLowerCase();
  const t = target.toLowerCase();
  if (lt === t) return true;
  if (lt.includes(t)) return true;
  return false;
}

function gaulaFindTargetLink(targetSectionName, sectionIndex) {
  const allTargetLinks = [...document.querySelectorAll('a')].filter(a =>
    gaulaSectionMatch(a.textContent, targetSectionName) && a.offsetParent !== null
  );
  console.log('[GAULA] findTargetLink: target="' + targetSectionName + '", secIdx=' + sectionIndex + ', matches=' + allTargetLinks.length);
  let targetLink = null;
  if (allTargetLinks.length > 1 && sectionIndex != null) {
    const cleanText = t => t.replace(/[\u00A0\s]+/g, ' ').trim();
    const sectionHeaders = [...document.querySelectorAll('a')].filter(a =>
      a.offsetParent !== null &&
      new RegExp(`^(RDA|Tema)\\s+${sectionIndex}$`, 'i').test(cleanText(a.textContent))
    );
    if (sectionHeaders.length > 0) {
      const sectionHeader = sectionHeaders[0];
      const allLinks = [...document.querySelectorAll('a')];
      const headerIdx = allLinks.indexOf(sectionHeader);
      const nextHeaderIdx = allLinks.findIndex((a, i) => i > headerIdx && a.offsetParent !== null && /^(RDA|Tema)\s+\d+$/i.test(a.textContent.trim()));
      const endIdx = nextHeaderIdx > 0 ? nextHeaderIdx : allLinks.length;
      for (let i = headerIdx + 1; i < endIdx; i++) {
        if (gaulaSectionMatch(allLinks[i].textContent, targetSectionName) && allLinks[i].offsetParent !== null) {
          targetLink = allLinks[i]; break;
        }
      }
    }
    if (!targetLink) targetLink = allTargetLinks[sectionIndex - 1] || allTargetLinks[allTargetLinks.length - 1];
  } else {
    targetLink = allTargetLinks[0] || null;
  }
  return targetLink;
}

async function gaulaMoveLastResource(targetSectionName, resourceName, sectionIndex, resourceType) {
  try {
    await gaulaEnableEditing(); await gaulaWait(500);
    let actionMenuBtn = null;
    const searchScope = sectionIndex != null ? document.querySelector(`#coursecontentcollapse${sectionIndex}`) : document;
    if (resourceName && searchScope) {
      const allActivities = [...searchScope.querySelectorAll('[data-activityname]')];
      const matches = allActivities.filter(el => el.dataset.activityname === resourceName || el.dataset.activityname.toLowerCase().includes(resourceName.toLowerCase()));
      if (matches.length > 0) { const activityEl = matches[matches.length - 1]; actionMenuBtn = activityEl.querySelector('[id^="action-menu-toggle-"]'); }
    }
    if (!actionMenuBtn && searchScope) { const sectionMenus = searchScope.querySelectorAll('[id^="action-menu-toggle-"]'); if (sectionMenus.length > 0) actionMenuBtn = sectionMenus[sectionMenus.length - 1]; }
    if (!actionMenuBtn) { const allMenus = document.querySelectorAll('[id^="action-menu-toggle-"]'); if (allMenus.length === 0) return; actionMenuBtn = allMenus[allMenus.length - 1]; }
    gaulaClick(actionMenuBtn); await gaulaWait(500);
    const menuId = actionMenuBtn.getAttribute('aria-controls');
    let moveItem = null;
    if (menuId) { const dropdown = document.getElementById(menuId); if (dropdown) moveItem = [...dropdown.querySelectorAll('[role="menuitem"]')].find(el => el.textContent.trim() === 'Mover'); }
    if (!moveItem) moveItem = await gaulaWaitForRole('menuitem', 'Mover', { exact: true });
    gaulaClick(moveItem); await gaulaWait(1000);

    let targetLink = gaulaFindTargetLink(targetSectionName, sectionIndex);

    if (!targetLink) {
      console.warn(`[GAULA 3.0] Sección "${targetSectionName}" no encontrada, buscando alternativas...`);
      const fallbacks = gaulaFindFallbackSection(targetSectionName, resourceType);
      for (const fb of fallbacks) {
        targetLink = gaulaFindTargetLink(fb, sectionIndex);
        if (targetLink) {
          console.log(`[GAULA 3.0] Usando sección alternativa: "${fb}"`);
          break;
        }
      }
    }

    if (targetLink) {
      gaulaClick(targetLink); await gaulaWait(2000);
      gaulaDismissMoveModal(); await gaulaWait(300);
    } else {
      console.warn(`[GAULA 3.0] No se encontró sección destino para "${targetSectionName}" ni alternativas. Cerrando modal.`);
      gaulaDismissMoveModal(); await gaulaWait(300);
    }
  } catch (e) { console.warn('Gaula 3.0: No se pudo mover el recurso:', e.message); }
}

// Bug #14: Log persistente de errores para diagnóstico
function gaulaReportProgress(current, total, status, extra = {}) {
  const state = { current, total, status, ts: Date.now(), ...extra };
  chrome.storage.local.set({ gaula_progress: state });
  // Bug #14: Si es error, guardarlo en historial persistente
  if (status === 'error') {
    chrome.storage.local.get('gaula_error_log', (result) => {
      const log = result.gaula_error_log || [];
      log.push({ ...state, url: window.location.href });
      // Mantener solo los últimos 20 errores
      if (log.length > 20) log.splice(0, log.length - 20);
      chrome.storage.local.set({ gaula_error_log: log });
    });
  }
  try { chrome.runtime.sendMessage({ action: 'gaula_progress', ...state }); } catch (e) { /* popup cerrado */ }
}

function gaulaDeserializeFile(serialized) {
  const { data, name, type } = serialized;
  const byteString = atob(data.split(',')[1]);
  const ab = new ArrayBuffer(byteString.length);
  const ia = new Uint8Array(ab);
  for (let i = 0; i < byteString.length; i++) ia[i] = byteString.charCodeAt(i);
  return new File([ab], name, { type });
}

// Handler registry
const gaulaHandlers = {};
function gaulaRegisterHandler(action, handler) { gaulaHandlers[action] = handler; }
