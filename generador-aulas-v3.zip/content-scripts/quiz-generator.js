/**
 * Generador de Aulas - Crear cuestionarios/evaluaciones en Moodle.
 * Selectores verificados con Playwright Codegen (2026-04-08 / 2026-04-09).
 *
 * Flujo con maquina de estados:
 *   1. course/view.php → handler guarda estado, click "Cuestionario" → NAVEGA a modedit.php
 *   2. modedit.php (step: fill_quiz_form) → Llenar nombre, fechas, tiempo, etc. → Guardar → NAVEGA
 *   3. mod/quiz/view.php (step: goto_import) → "Mas" → "Banco de preguntas" → select import
 *   4. importquestions (step: fill_import_form) → Formato Aiken, subir archivo, Importar
 *   5. (step: after_import) → Click "Continuar"
 *   6. (step: goto_quiz_edit) → Click "Preguntas" para ir a quiz/edit.php
 *   7. mod/quiz/edit.php (step: add_questions) → Agregar del banco, seleccionar todas, añadir
 *   8. (step: navigate_course) → Volver al curso
 *   9. course/view.php (step: move_quiz) → Mover a seccion "Evaluacion"
 */

// ============================================================
// MAQUINA DE ESTADOS — se ejecuta al cargar cada pagina
// ============================================================
(async function checkQuizState() {
  if (window !== window.top) return;

  const state = await gaulaGetState();
  if (!state || state.action !== 'create_quiz') return;

  const url = window.location.href;

  // ──────────────────────────────────────────────────────────
  // STEP: fill_quiz_form — Estamos en modedit.php, llenar formulario
  // ──────────────────────────────────────────────────────────
  if (url.includes('/modedit.php') && state.step === 'fill_quiz_form') {
    try {
      const quiz = state.quizData;
      await gaulaWait(1500);

      const nameInput = await gaulaWaitForRole('textbox', 'Nombre');
      if (nameInput) {
        gaulaClick(nameInput);
        await gaulaWait(200);
        gaulaSetValue(nameInput, quiz.nombre);
      }
      await gaulaWait(300);

      // ── Temporalizacion ──
      const timeBtn = gaulaByRole('button', 'Temporalización') ||
                      gaulaByText('Temporalización', 'button');
      if (timeBtn) {
        gaulaClick(timeBtn);
        await gaulaWait(500);
      }

      if (quiz.dateFrom || quiz.dateTo) {
        const hFrom = String(quiz.hourFrom || 0).padStart(2, '0');
        const mFrom = String(quiz.minFrom || 0).padStart(2, '0');
        const hTo = String(quiz.hourTo || 23).padStart(2, '0');
        const mTo = String(quiz.minTo || 55).padStart(2, '0');
        const fromDate = quiz.dateFrom ? new Date(quiz.dateFrom + 'T' + hFrom + ':' + mFrom + ':00') : null;
        const toDate = quiz.dateTo ? new Date(quiz.dateTo + 'T' + hTo + ':' + mTo + ':00') : null;

        if (fromDate) {
          const openGroup = gaulaFindDateGroup('id_timeopen', 'Abrir cuestionario');
          if (openGroup) {
            const enableCheck = openGroup.querySelector('input[type="checkbox"]');
            if (enableCheck && !enableCheck.checked) {
              gaulaClick(enableCheck);
              await gaulaWait(300);
            }
            gaulaSetDateGroup(openGroup, fromDate);
            await gaulaWait(200);
          }
        }

        if (toDate) {
          const closeGroup = gaulaFindDateGroup('id_timeclose', 'Cerrar cuestionario');
          if (closeGroup) {
            const enableCheck = closeGroup.querySelector('input[type="checkbox"]');
            if (enableCheck && !enableCheck.checked) {
              gaulaClick(enableCheck);
              await gaulaWait(300);
            }
            gaulaSetDateGroup(closeGroup, toDate);
            await gaulaWait(200);
          }
        }
      }

      // Limite de tiempo
      if (quiz.timeLimit) {
        const timeLimitGroup = gaulaFindDateGroup('id_timelimit', 'Límite de tiempo');
        if (timeLimitGroup) {
          const enableCheck = timeLimitGroup.querySelector('input[type="checkbox"]');
          if (enableCheck && !enableCheck.checked) {
            gaulaClick(enableCheck);
            await gaulaWait(300);
          }
          const timeInput = timeLimitGroup.querySelector('input[type="text"]') ||
                            timeLimitGroup.querySelector('input[type="number"]');
          if (timeInput) gaulaSetValue(timeInput, String(quiz.timeLimit));
        }
      }

      // ── Calificacion ──
      const gradeBtn = gaulaByRole('button', 'Calificación') ||
                       gaulaByText('Calificación', 'button');
      if (gradeBtn) {
        gaulaClick(gradeBtn);
        await gaulaWait(500);
      }

      const catSelect = gaulaByLabel('Categoría de calificaciones');
      if (catSelect) {
        if (state.gradeCategoryValue) {
          gaulaSetSelect(catSelect, state.gradeCategoryValue);
        } else if (state.rdaIndex != null) {
          const num = state.rdaIndex + 1;
          const isRepo = state.courseType === 'repotenciada';
          const option = [...catSelect.options].find(o => {
            const txt = o.textContent.trim();
            if (isRepo) {
              return /^RDA\s+\d+$/i.test(txt) && txt.includes(String(num));
            }
            return txt.toLowerCase().includes(`parcial ${num}`);
          });
          if (option) gaulaSetSelect(catSelect, option.value);
        }
      }

      const gradePassInput = gaulaByLabel('Calificación para aprobar');
      if (gradePassInput) gaulaSetValue(gradePassInput, '');

      const attemptsSelect = gaulaByLabel('Intentos permitidos');
      if (attemptsSelect) gaulaSetSelect(attemptsSelect, '1');

      // ── Esquema ──
      const schemaBtn = gaulaByRole('button', 'Esquema') ||
                        gaulaByText('Esquema', 'button');
      if (schemaBtn) {
        gaulaClick(schemaBtn);
        await gaulaWait(300);
        const moreBtn = gaulaByRole('button', 'Mostrar más');
        if (moreBtn) {
          gaulaClick(moreBtn);
          await gaulaWait(300);
        }
        const navSelect = gaulaByLabel('Método de navegación');
        if (navSelect) gaulaSetSelect(navSelect, 'sequential');
      }

      // ── Restricciones: Contrasena ──
      if (quiz.password) {
        const restrictBtn = gaulaByRole('button', 'Restricciones extra sobre') ||
                            gaulaByText('Restricciones extra', 'button');
        if (restrictBtn) {
          gaulaClick(restrictBtn);
          await gaulaWait(300);
        }
        const pwReveal = gaulaByRole('link', 'Haz click para insertar texto');
        if (pwReveal) {
          gaulaClick(pwReveal);
          await gaulaWait(300);
        }
        const pwInput = gaulaByRole('textbox', 'Se requiere contraseña') ||
                        gaulaByLabel('Se requiere contraseña');
        if (pwInput) gaulaSetValue(pwInput, quiz.password);
      }

      await gaulaWait(300);

      // Decidir siguiente paso
      const hasAiken = state.aikenText && state.aikenText.trim().length > 0;
      const hasXml = state.xmlText && state.xmlText.trim().length > 0;
      const hasQuestions = hasAiken || hasXml;
      const nextStep = hasQuestions ? 'goto_import' : 'navigate_course';

      await gaulaSaveState({
        action: 'create_quiz',
        step: nextStep,
        quizName: quiz.nombre,
        sectionIndex: state.sectionIndex,
        taskIndex: state.taskIndex,
        totalTasks: state.totalTasks,
        courseType: state.courseType || '',
        aikenText: state.aikenText || '',
        xmlText: state.xmlText || '',
        xmlFileName: state.xmlFileName || ''
      });

      // Codegen: getByRole('button', { name: 'Guardar cambios y mostrar' }).click()
      const saveBtn = gaulaByRole('button', 'Guardar cambios y mostrar');
      if (saveBtn) gaulaClick(saveBtn);

      gaulaReportProgress(state.taskIndex + 1, state.totalTasks, 'running', { step: 'create_quiz' });

    } catch (err) {
      gaulaClearState();
      gaulaReportProgress(0, 0, 'error', { step: 'create_quiz', error: err.message });
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: goto_import — Desde quiz view, navegar a importar preguntas
  // Codegen: "Mas" → "Banco de preguntas" → select import option
  // ──────────────────────────────────────────────────────────
  if (state.step === 'goto_import' && url.includes('/mod/quiz/view.php')) {
    try {
      await gaulaWait(1000);

      // Extraer cmid del quiz desde la URL
      const quizCmid = new URL(url).searchParams.get('id') || '';

      // Navegar directamente a la URL de importacion (mas confiable que los menus)
      await gaulaSaveState({
        ...state,
        step: 'fill_import_form',
        quizCmid: quizCmid
      });

      const baseUrl = window.location.origin;
      window.location.href = `${baseUrl}/question/bank/importquestions/import.php?cmid=${quizCmid}`;

    } catch (err) {
      // Si falla, continuar sin importar
      await gaulaSaveState({ ...state, step: 'navigate_course', aikenText: '' });
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: fill_import_form — En pagina de importar preguntas
  // Codegen: Formato Aiken → Seleccione archivo → Adjunto → setInputFiles → Subir → Importar
  // ──────────────────────────────────────────────────────────
  if (url.includes('/importquestions/') && state.step === 'fill_import_form') {
    try {
      await gaulaWait(1500);

      const useXml = !!(state.xmlText);
      const formatValue = useXml ? 'xml' : 'aiken';
      const formatLabel = useXml ? 'Formato XML de Moodle' : 'Formato Aiken';

      // 1. Seleccionar formato (Aiken o XML de Moodle)
      const formatRadio = [...document.querySelectorAll('input[type="radio"]')].find(r =>
        r.value === formatValue
      );
      if (formatRadio) {
        gaulaClick(formatRadio);
        await gaulaWait(500);
      } else {
        const fmtLabel = [...document.querySelectorAll('label, span')].find(el =>
          el.textContent.trim() === formatLabel
        );
        if (fmtLabel) {
          gaulaClick(fmtLabel);
          await gaulaWait(500);
        }
      }

      // 2. Codegen: getByRole('button', { name: '# General' }).click()
      //    Expandir seccion General para ver la categoria
      const generalBtn = gaulaByRole('button', 'General') ||
                         [...document.querySelectorAll('button, a')].find(el =>
                           el.textContent.trim().includes('General') && el.getAttribute('aria-expanded') !== undefined
                         );
      if (generalBtn) {
        gaulaClick(generalBtn);
        await gaulaWait(500);
      }

      // 3. Codegen: getByLabel('Categoría a donde importar').selectOption(...)
      //    Seleccionar la categoria del quiz, no la del curso
      const catSelect = gaulaByLabel('Categoría a donde importar') ||
                        document.getElementById('id_category');
      if (catSelect && state.quizName) {
        const quizCatOption = [...catSelect.options].find(o =>
          o.textContent.trim().toLowerCase().includes(state.quizName.toLowerCase())
        );
        if (quizCatOption) {
          gaulaSetSelect(catSelect, quizCatOption.value);
          await gaulaWait(300);
        }
      }

      // 4. Codegen: getByRole('button', { name: 'Seleccione un archivo...' }).click()
      const selectFileBtn = gaulaByRole('button', 'Seleccione un archivo') ||
                            [...document.querySelectorAll('a, button')].find(el =>
                              el.textContent.trim().includes('Seleccione un archivo')
                            );
      if (selectFileBtn) {
        gaulaClick(selectFileBtn);
        await gaulaWait(1000);
      }

      // 5. Codegen: getByRole('button', { name: 'Adjunto' }).click()
      const attachBtn = gaulaByRole('button', 'Adjunto') ||
                        [...document.querySelectorAll('.fp-repo-area .fp-repo button, .fp-repo-area .fp-repo span, .file-picker .fp-repo')].find(el =>
                          el.textContent.trim().includes('Adjunto') || el.textContent.trim().includes('Subir un archivo')
                        );
      if (attachBtn) {
        gaulaClick(attachBtn);
        await gaulaWait(800);
      }

      // 6. Crear archivo y subirlo (Aiken .txt o Moodle XML .xml)
      let fileContent, fileName, fileMime;
      if (useXml) {
        fileContent = state.xmlText;
        fileName = state.xmlFileName || 'preguntas.xml';
        fileMime = 'text/xml';
      } else {
        fileContent = state.aikenText || '';
        fileName = 'preguntas.txt';
        fileMime = 'text/plain';
      }
      const blob = new Blob([fileContent], { type: fileMime });
      const file = new File([blob], fileName, { type: fileMime });

      const fileInput = document.querySelector('.filepicker-container input[type="file"]') ||
                        document.querySelector('.fp-upload-form input[type="file"]') ||
                        document.querySelector('.file-picker input[type="file"]') ||
                        document.querySelector('input[type="file"][name="repo_upload_file"]') ||
                        document.querySelector('input[type="file"]');

      if (fileInput) {
        const dt = new DataTransfer();
        dt.items.add(file);
        fileInput.files = dt.files;
        fileInput.dispatchEvent(new Event('change', { bubbles: true }));
        await gaulaWait(1000);
      }

      // 7. Codegen: getByRole('button', { name: 'Subir este archivo' }).click()
      const uploadBtn = gaulaByRole('button', 'Subir este archivo') ||
                        [...document.querySelectorAll('button')].find(el =>
                          el.textContent.trim().includes('Subir este archivo')
                        );
      if (uploadBtn) {
        gaulaClick(uploadBtn);
        await gaulaWait(2000);
      }

      // 8. Guardar estado y hacer click en Importar
      await gaulaSaveState({
        ...state,
        step: 'after_import'
      });

      const importBtn = document.getElementById('id_submitbutton') ||
                        gaulaByRole('button', 'Importar');
      if (importBtn) {
        gaulaClick(importBtn);
      }

    } catch (err) {
      console.warn('[GAULA] Error en importacion:', err.message);
      await gaulaSaveState({ ...state, step: 'navigate_course', aikenText: '' });
      const courseLink = document.querySelector('a[href*="/course/view.php"]');
      if (courseLink) window.location.href = courseLink.href;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: after_import — Pagina de resultados, click "Continuar"
  // Codegen: getByRole('button', { name: 'Continuar' }).click()
  // ──────────────────────────────────────────────────────────
  if (state.step === 'after_import') {
    await gaulaWait(1500);

    await gaulaSaveState({ ...state, step: 'goto_quiz_edit' });

    const continueBtn = gaulaByRole('button', 'Continuar') ||
                        [...document.querySelectorAll('a, button')].find(el =>
                          el.textContent.trim().toLowerCase() === 'continuar'
                        );
    if (continueBtn) {
      gaulaClick(continueBtn);
    } else {
      // Si no hay boton, navegar directo al quiz edit
      const baseUrl = window.location.origin;
      window.location.href = `${baseUrl}/mod/quiz/edit.php?cmid=${state.quizCmid}`;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: goto_quiz_edit — Navegar a editar preguntas del quiz
  // Codegen: getByRole('menuitem', { name: 'Preguntas', exact: true }).click()
  // ──────────────────────────────────────────────────────────
  if (state.step === 'goto_quiz_edit') {
    await gaulaWait(1000);

    await gaulaSaveState({ ...state, step: 'add_questions' });

    // Intentar click en "Preguntas" en la nav secundaria
    const questionsLink = gaulaByRole('menuitem', 'Preguntas') ||
                          [...document.querySelectorAll('a')].find(a =>
                            a.textContent.trim() === 'Preguntas' &&
                            a.href && a.href.includes('/mod/quiz/edit.php')
                          );
    if (questionsLink) {
      gaulaClick(questionsLink);
    } else {
      // Navegar directo
      const baseUrl = window.location.origin;
      window.location.href = `${baseUrl}/mod/quiz/edit.php?cmid=${state.quizCmid}`;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: add_questions — En quiz/edit.php, agregar preguntas del banco
  // Codegen: Agregar → "del banco de preguntas" → seleccionar todos → Añadir
  // ──────────────────────────────────────────────────────────
  if (url.includes('/mod/quiz/edit.php') && state.step === 'add_questions') {
    try {
      await gaulaWait(2000);

      // Codegen: getByRole('button', { name: 'Agregar' }).click()
      // IMPORTANTE: En Moodle es un <a> con data-toggle="dropdown" que abre un menu.
      // NO confundir con links de navegacion al banco de preguntas.
      // Buscar especificamente el dropdown toggle dentro del area de edicion del quiz.
      const addBtn = document.querySelector('.mod_quiz-edit-action-buttons [data-toggle="dropdown"]') ||
                     document.querySelector('.slots [data-toggle="dropdown"]') ||
                     document.querySelector('a.btn[data-toggle="dropdown"]') ||
                     [...document.querySelectorAll('a[data-toggle="dropdown"], button[data-toggle="dropdown"]')].find(el =>
                       el.textContent.trim().toLowerCase().includes('agregar')
                     );

      if (!addBtn) {
        console.warn('[GAULA] No se encontró dropdown Agregar');
        throw new Error('Dropdown Agregar no encontrado');
      }

      gaulaClick(addBtn);
      await gaulaWait(1000);

      // Codegen: getByRole('menuitem', { name: 'del banco de preguntas' }).click()
      // Buscar dentro del dropdown-menu que se acaba de abrir
      let fromBankItem = null;
      for (let attempt = 0; attempt < 8; attempt++) {
        // Buscar en dropdown-menus visibles
        const visibleMenus = document.querySelectorAll('.dropdown-menu.show, .dropdown-menu[style*="display: block"]');
        for (const menu of visibleMenus) {
          fromBankItem = [...menu.querySelectorAll('a, [role="menuitem"]')].find(el =>
            el.textContent.trim().toLowerCase().includes('banco de preguntas')
          );
          if (fromBankItem) break;
        }
        // Fallback global
        if (!fromBankItem) {
          fromBankItem = [...document.querySelectorAll('[role="menuitem"], .dropdown-item')].find(el =>
            el.textContent.trim().toLowerCase().includes('banco de preguntas') &&
            el.offsetParent !== null // visible
          );
        }
        if (fromBankItem) break;
        await gaulaWait(500);
      }

      if (!fromBankItem) {
        console.warn('[GAULA] No se encontró opción "del banco de preguntas"');
        throw new Error('Opción banco de preguntas no encontrada');
      }

      gaulaClick(fromBankItem);
      await gaulaWait(3000);

      // Codegen: getByLabel('Seleccionar una categoría:').selectOption(...)
      // Seleccionar la categoria del quiz para ver solo sus preguntas
      const catFilterSelect = gaulaByLabel('Seleccionar una categoría') ||
                              gaulaByLabel('Seleccionar una categoría:') ||
                              document.querySelector('select[name="category"]');
      if (catFilterSelect && state.quizName) {
        const quizCatOption = [...catFilterSelect.options].find(o =>
          o.textContent.trim().toLowerCase().includes(state.quizName.toLowerCase())
        );
        if (quizCatOption) {
          gaulaSetSelect(catFilterSelect, quizCatOption.value);
          catFilterSelect.dispatchEvent(new Event('change', { bubbles: true }));
          await gaulaWait(2000);
        }
      }

      // Codegen: getByLabel('Seleccionar todos').check()
      let selectAllCb = null;
      for (let attempt = 0; attempt < 10; attempt++) {
        selectAllCb = gaulaByLabel('Seleccionar todos') ||
                      document.querySelector('input[type="checkbox"][id*="selectall"]') ||
                      document.querySelector('th input[type="checkbox"]');
        if (selectAllCb) break;
        await gaulaWait(500);
      }

      if (selectAllCb && !selectAllCb.checked) {
        gaulaClick(selectAllCb);
        await gaulaWait(500);
      }

      // Codegen: getByRole('link', { name: 'Mostrar 50' }).click()
      const showAllLink = [...document.querySelectorAll('a')].find(a =>
        /mostrar\s+\d+/i.test(a.textContent.trim()) ||
        /show\s+\d+/i.test(a.textContent.trim())
      );
      if (showAllLink) {
        gaulaClick(showAllLink);
        await gaulaWait(2000);

        // Re-seleccionar todos despues de mostrar todas
        const selectAllCb2 = gaulaByLabel('Seleccionar todos') ||
                             document.querySelector('input[type="checkbox"][id*="selectall"]') ||
                             document.querySelector('th input[type="checkbox"]');
        if (selectAllCb2) {
          if (selectAllCb2.checked) selectAllCb2.checked = false;
          gaulaClick(selectAllCb2);
          await gaulaWait(500);
        }
      }

      // Codegen: getByRole('button', { name: 'Añadir preguntas' }).click()
      const addQuestionsBtn = gaulaByRole('button', 'Añadir preguntas') ||
                              gaulaByRole('button', 'Agregar preguntas seleccionadas') ||
                              [...document.querySelectorAll('button, input[type="submit"]')].find(el =>
                                (el.textContent || el.value || '').toLowerCase().includes('añadir pregunta') ||
                                (el.textContent || el.value || '').toLowerCase().includes('add selected')
                              );

      // IMPORTANTE: Guardar estado ANTES de click — el click recarga la pagina
      await gaulaSaveState({ ...state, step: 'finish_quiz_edit', aikenText: '' });

      if (addQuestionsBtn) {
        gaulaClick(addQuestionsBtn);
      }

    } catch (err) {
      console.warn('[GAULA] Error agregando preguntas:', err.message);
      await gaulaSaveState({ ...state, step: 'navigate_course', aikenText: '' });
      const courseLink = document.querySelector('a[href*="/course/view.php"]');
      if (courseLink) window.location.href = courseLink.href;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: finish_quiz_edit — Preguntas ya agregadas, check shuffle y salir
  // ──────────────────────────────────────────────────────────
  if (url.includes('/mod/quiz/edit.php') && state.step === 'finish_quiz_edit') {
    await gaulaWait(1500);

    // Codegen: getByLabel('Reordenar las preguntas al').check()
    const shuffleCb = gaulaByLabel('Reordenar las preguntas al') ||
                      gaulaByLabel('Barajar');
    if (shuffleCb && !shuffleCb.checked) {
      gaulaClick(shuffleCb);
      await gaulaWait(500);
    }

    // Navegar al curso
    await gaulaSaveState({ ...state, step: 'navigate_course' });
    const courseLink = document.querySelector('.breadcrumb a[href*="/course/view.php"]') ||
                       document.querySelector('a[href*="/course/view.php"]');
    if (courseLink) window.location.href = courseLink.href;
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: navigate_course — Volver al curso desde cualquier pagina
  // ──────────────────────────────────────────────────────────
  if (state.step === 'navigate_course' && !url.includes('/course/view.php')) {
    const courseLink = document.querySelector('.breadcrumb a[href*="/course/view.php"]') ||
                       document.querySelector('a[href*="/course/view.php"]');
    if (courseLink) {
      window.location.href = courseLink.href;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: move_quiz — Mover a seccion "Evaluacion"
  // ──────────────────────────────────────────────────────────
  if (url.includes('/course/view.php') && (state.step === 'move_quiz' || state.step === 'navigate_course')) {
    try {
      await gaulaWait(1000);
      const quizName = state.quizName;
      const totalTasks = state.totalTasks;
      const secIdx = state.sectionIndex;
      const moveTarget = state.courseType === 'repotenciada' ? 'PRODUCTOS Y ACTIVIDADES' : 'Evaluacion [bg-etiqueta';
      gaulaClearState();
      gaulaReportProgress(totalTasks, totalTasks, 'done', { step: 'create_quiz' });
      await gaulaMoveLastResource(moveTarget, quizName, secIdx, 'quiz');
    } catch (err) {
      // Estado ya limpio
    }
    return;
  }
})();

// ============================================================
// HANDLER: recibe mensaje del popup para iniciar creacion
// ============================================================
gaulaRegisterHandler('create_quiz', async (msg, sendResponse) => {
  if (window !== window.top) {
    sendResponse({ ok: true });
    return;
  }

  try {
    await gaulaAcquireLock('create_quiz');
    const { quizName, dateFrom, dateTo, timeLimit, quizPassword,
            rdaIndex, sectionIndex, questions, gradeCategoryValue, aikenText,
            xmlText, xmlFileName } = msg;
    const courseType = gaulaDetectCourseType();

    gaulaReportProgress(0, 1, 'running', { step: 'create_quiz', rdaIndex });

    await gaulaSaveState({
      action: 'create_quiz',
      step: 'fill_quiz_form',
      quizData: {
        nombre: quizName,
        dateFrom: dateFrom || '',
        dateTo: dateTo || '',
        hourFrom: msg.hourFrom || '0',
        minFrom: msg.minFrom || '0',
        hourTo: msg.hourTo || '23',
        minTo: msg.minTo || '55',
        timeLimit: timeLimit || 0,
        password: quizPassword || ''
      },
      gradeCategoryValue: gradeCategoryValue || null,
      rdaIndex: rdaIndex,
      sectionIndex: sectionIndex || 1,
      aikenText: aikenText || '',
      xmlText: xmlText || '',
      xmlFileName: xmlFileName || '',
      courseType: courseType || '',
      questions: questions || [],
      taskIndex: 0,
      totalTasks: 1
    });

    await gaulaEnableEditing();

    await gaulaOpenActivityChooser(sectionIndex || 1);
    await gaulaWait(500);
    await gaulaSearchAndClickActivity('cuestionario', 'Cuestionario');

    sendResponse({ ok: true });

  } catch (err) {
    gaulaClearState();
    if (err.message === 'STOPPED') {
      gaulaReportProgress(0, 0, 'stopped', { step: 'create_quiz' });
    } else {
      gaulaReportProgress(0, 0, 'error', { step: 'create_quiz', error: err.message });
    }
    sendResponse({ ok: false, error: err.message });
  }
});
