/**
 * Generador de Aulas - Subir recursos (PDFs y PowerPoints) a Moodle.
 * Flujo multi-página: clic en "Archivo" navega a /course/modedit.php.
 *
 * Los archivos serializados se guardan en keys individuales
 * (gaula_file_0, gaula_file_1, ...) para no exceder el límite de
 * chrome.storage.local (5MB). El estado solo guarda metadatos.
 */

// Helper: guardar archivo en key individual
function gaulaSaveFile(index, serialized) {
  return chrome.storage.local.set({ [`gaula_file_${index}`]: serialized });
}

// Helper: leer archivo de key individual
function gaulaGetFile(index) {
  return new Promise(resolve => {
    chrome.storage.local.get(`gaula_file_${index}`, result => {
      resolve(result[`gaula_file_${index}`] || null);
    });
  });
}

// Helper: limpiar todos los archivos temporales
function gaulaClearFiles(totalFiles) {
  const keys = [];
  for (let i = 0; i < totalFiles; i++) keys.push(`gaula_file_${i}`);
  chrome.storage.local.remove(keys);
}

// Helper: limpiar archivos huérfanos (si una subida anterior falló)
function gaulaClearOrphanFiles() {
  chrome.storage.local.get(null, (all) => {
    const orphanKeys = Object.keys(all).filter(k => k.startsWith('gaula_file_'));
    if (orphanKeys.length > 0) {
      console.log('[GAULA] Limpiando', orphanKeys.length, 'archivos huérfanos');
      chrome.storage.local.remove(orphanKeys);
    }
  });
}

// ============================================================
// MAQUINA DE ESTADOS MULTI-PAGINA
// ============================================================
(async function checkUploadState() {
  const state = await gaulaGetState();
  if (!state || state.action !== 'upload_resource') return;

  const url = window.location.href;

  try {
    // ============================================================
    // PASO A: modedit.php → llenar formulario, subir archivo, guardar
    // ============================================================
    if (url.includes('/course/modedit.php') && state.step === 'fill_form') {
      await gaulaWait(2500);
      const { resourceType, fileName, fileIndex, totalFiles } = state;
      gaulaReportProgress(fileIndex + 1, totalFiles, 'running', { step: `Subiendo ${fileName}...` });

      // --- Nombre del recurso ---
      const nameInput = gaulaByRole('textbox', 'Nombre') || document.querySelector('#id_name');
      if (nameInput) {
        gaulaSetValue(nameInput, fileName);
        await gaulaWait(300);
      }

      // --- Marcar "Muestra la descripción en la página del curso" ---
      const showDescCheck = gaulaByLabel('Muestra la descripción en la') ||
                            document.querySelector('#id_showdescription');
      if (showDescCheck && !showDescCheck.checked) {
        gaulaClick(showDescCheck);
        await gaulaWait(300);
      }

      // --- Subir archivo (leer de key individual) ---
      const fileSerialized = await gaulaGetFile(fileIndex);
      if (fileSerialized) {
        const file = gaulaDeserializeFile(fileSerialized);
        let uploaded = false;

        // MÉTODO 1: Drag & Drop directo al file manager (más confiable)
        const dropZone = document.querySelector('.filemanager .filepicker-filelist') ||
                         document.querySelector('.filemanager') ||
                         document.querySelector('.fm-content-wrapper');
        if (dropZone) {
          const dt = new DataTransfer();
          dt.items.add(file);
          const dropEvent = new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt });
          dropZone.dispatchEvent(new DragEvent('dragenter', { bubbles: true, dataTransfer: dt }));
          dropZone.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt }));
          dropZone.dispatchEvent(dropEvent);
          await gaulaWait(3000);

          // Verificar si se subió (buscar el archivo en el file manager)
          const fileIcon = document.querySelector('.filemanager .fp-file') ||
                           document.querySelector('.filemanager .fp-filename-icon');
          if (fileIcon) {
            uploaded = true;
            console.log('[GAULA] Archivo subido por drag & drop');
          }
        }

        // MÉTODO 2: Fallback — Modal "Agregar..." → "Subir un archivo"
        if (!uploaded) {
          console.log('[GAULA] Drag & drop falló, intentando modal...');
          for (let attempt = 0; attempt < 3 && !uploaded; attempt++) {
            // 1. Clic en "Agregar..."
            const addEl = gaulaByText('Agregar...', 'span') || gaulaByText('Agregar...', 'a') ||
                          gaulaByText('Agregar', 'span') || gaulaByText('Agregar', 'a');
            if (addEl) {
              const addBtn = addEl.closest('a') || addEl.closest('button') || addEl;
              gaulaClick(addBtn);
              await gaulaWait(2000);
            }

            // 2. Clic en "Subir un archivo"
            const uploadTab = gaulaByRole('link', 'Subir un archivo') || gaulaByText('Subir un archivo', 'a');
            if (uploadTab) {
              gaulaClick(uploadTab);
              await gaulaWait(1500);
            }

            // 3. Buscar input[type=file]
            const fileInput = document.querySelector('input[type="file"][name="repo_upload_file"]') ||
                              document.querySelector('.fp-upload-form input[type="file"]') ||
                              document.querySelector('.file-picker input[type="file"]') ||
                              document.querySelector('input[type="file"]');

            if (fileInput) {
              gaulaUploadFile(fileInput, file);
              await gaulaWait(2000);

              // 4. Clic en "Subir este archivo"
              const uploadBtn = gaulaByRole('button', 'Subir este archivo');
              if (uploadBtn) {
                gaulaClick(uploadBtn);
                await gaulaWait(4000);
                uploaded = true;
              }
            }
            if (!uploaded) await gaulaWait(1500);
          }
        }

        if (!uploaded) {
          console.warn('[GAULA] No se pudo subir el archivo después de todos los intentos');
        }

        // Esperar a que Moodle termine de procesar
        await gaulaWait(2000);
      }

      // --- Si es PDF, configurar Apariencia como "Incrustar" (valor 5) ---
      if (resourceType === 'pdf') {
        const appearanceHeader = [...document.querySelectorAll('a[role="button"], button')].find(el =>
          el.textContent.trim().includes('Apariencia')
        );
        if (appearanceHeader) {
          gaulaClick(appearanceHeader);
          await gaulaWait(500);
        }
        const showSelect = gaulaByLabel('Mostrar', { exact: true });
        if (showSelect) {
          gaulaSetSelect(showSelect, '5');
          await gaulaWait(300);
        }
      }

      // --- Preparar estado para cuando volvamos al curso ---
      const currentIdx = fileIndex;
      const isLast = currentIdx + 1 >= totalFiles;
      await gaulaSaveState({
        action: 'upload_resource',
        step: isLast ? 'finish' : 'next_file',
        queue: state.queue, // Solo metadatos (nombres), sin archivos serializados
        fileIndex: isLast ? currentIdx : currentIdx + 1,
        totalFiles,
        resourceType,
        courseUrl: state.courseUrl,
        targetSection: state.targetSection
      });

      // --- Guardar y regresar al curso ---
      await gaulaWait(1000);
      const saveBtn = document.querySelector('#id_submitbutton2') ||
                      gaulaByRole('button', 'Guardar cambios y regresar al') ||
                      gaulaByRole('button', 'Guardar cambios y regresar');
      if (saveBtn) {
        gaulaReportProgress(currentIdx + 1, totalFiles, 'running', { step: `${fileName} guardado` });
        gaulaClick(saveBtn);
      } else {
        console.warn('[GAULA] No se encontró botón de guardar');
      }
      return;
    }

    // ============================================================
    // PASO B: course/view.php → mover recurso y procesar siguiente
    // ============================================================
    if (url.includes('/course/view.php') && (state.step === 'next_file' || state.step === 'finish')) {
      await gaulaWait(2500);

      // Mover el recurso recién creado a la sección destino
      if (state.targetSection) {
        const prevIdx = state.step === 'next_file' ? state.fileIndex - 1 : state.fileIndex;
        const prevFile = state.queue[prevIdx];
        if (prevFile) {
          try {
            const secIdx = prevFile.sectionIndex || 1;
            await gaulaMoveLastResource(state.targetSection, prevFile.name, secIdx, state.resourceType);
            await gaulaWait(1500);
          } catch (e) {
            console.warn('[GAULA] No se pudo mover:', e.message);
          }
        }
      }

      // Si es el último archivo, terminar y limpiar archivos temporales
      if (state.step === 'finish') {
        gaulaClearFiles(state.totalFiles);
        gaulaClearState();
        gaulaReportProgress(state.totalFiles, state.totalFiles, 'done', { step: 'Todos los archivos subidos' });
        return;
      }

      // Procesar siguiente archivo
      const { queue, fileIndex, totalFiles, resourceType } = state;
      if (fileIndex < totalFiles) {
        const next = queue[fileIndex];
        gaulaReportProgress(fileIndex, totalFiles, 'running', { step: `Creando ${next.name}...` });

        await gaulaEnableEditing();
        await gaulaWait(500);

        // Guardar estado ANTES de navegar (sin archivo serializado — está en key individual)
        await gaulaSaveState({
          action: 'upload_resource',
          step: 'fill_form',
          resourceType,
          fileName: next.name,
          fileIndex,
          totalFiles,
          queue,
          courseUrl: state.courseUrl,
          targetSection: state.targetSection
        });

        // Abrir chooser y clic en "Archivo" → navega a modedit.php
        await gaulaOpenActivityChooser(next.sectionIndex || 1);
        await gaulaWait(1000);
        await gaulaSearchAndClickActivity('archi', 'Archivo');
        // Página navega → script muere → IIFE retoma en modedit.php
      } else {
        gaulaClearFiles(totalFiles);
        gaulaClearState();
        gaulaReportProgress(totalFiles, totalFiles, 'done', { step: 'Todos los archivos subidos' });
      }
      return;
    }

  } catch (err) {
    gaulaClearState();
    gaulaClearOrphanFiles(); // Limpiar archivos si hubo error
    gaulaReportProgress(0, 0, 'error', { step: 'upload_resource', error: err.message });
  }
})();

// ============================================================
// HANDLER: Recibe archivos del popup y arranca el flujo multi-página
// ============================================================
gaulaRegisterHandler('upload_resource', async (msg, sendResponse) => {
  try {
    await gaulaAcquireLock('upload_resource');
    const { resourceType, sectionIndex } = msg;
    const serializedFiles = msg.files; // Ya vienen como base64 desde el popup
    const names = msg.names;
    const totalFiles = serializedFiles.length;

    if (!window.location.href.includes('/course/view.php')) {
      sendResponse({ ok: false, error: 'Debes estar en la página del curso.' });
      return;
    }

    // Siempre intentar "RECURSOS" primero — el fallback busca "Recursos Principales" si no existe
    const targetSection = 'RECURSOS';
    const courseUrl = window.location.href;

    // Construir cola LIGERA (solo metadatos, sin archivos)
    const queue = serializedFiles.map((f, i) => ({
      name: names[i] || f.name.replace(/\.[^.]+$/, ''),
      sectionIndex: sectionIndex || 1
    }));

    // Limpiar archivos huérfanos de subidas anteriores fallidas
    gaulaClearOrphanFiles();
    await gaulaWait(100);

    // Guardar cada archivo en key individual (gaula_file_0, gaula_file_1, ...)
    for (let i = 0; i < serializedFiles.length; i++) {
      await gaulaSaveFile(i, serializedFiles[i]);
    }

    gaulaReportProgress(0, totalFiles, 'running', { step: `Creando ${queue[0].name}...` });

    await gaulaEnableEditing();
    await gaulaWait(500);

    // Guardar estado (sin archivos — ya están en keys individuales)
    await gaulaSaveState({
      action: 'upload_resource',
      step: 'fill_form',
      resourceType,
      fileName: queue[0].name,
      fileIndex: 0,
      totalFiles,
      queue,
      courseUrl,
      targetSection
    });

    // Abrir chooser y clic en "Archivo" → navega a modedit.php
    await gaulaOpenActivityChooser(sectionIndex || 1);
    await gaulaWait(1000);
    await gaulaSearchAndClickActivity('archi', 'Archivo');
    // Página navega → script muere → IIFE retoma en modedit.php

    sendResponse({ ok: true });
  } catch (err) {
    gaulaClearState();
    gaulaClearOrphanFiles(); // Limpiar archivos si hubo error
    gaulaReportProgress(0, 0, 'error', { step: 'upload_resource', error: err.message });
    sendResponse({ ok: false, error: err.message });
  }
});
