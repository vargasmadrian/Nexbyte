/**
 * Generador de Aulas - Editor de secciones HTML en Moodle.
 * Selectores de: editar_seccion_html.py
 *
 * Flujo multi-pagina:
 * 1. (Pagina del curso) Activar edicion → Crear recurso "Área de texto y medios" → navega a formulario
 * 2. (Formulario) Insertar HTML en editor Atto, guardar
 *
 * Usa chrome.storage para persistir entre navegaciones.
 */

// Al cargar, verificar si hay una inyeccion de seccion pendiente
(async function checkSectionState() {
  const state = await gaulaGetState();
  console.log('[GAULA] checkSectionState:', state, 'URL:', window.location.href);
  if (!state || (state.action !== 'edit_section' && state.action !== 'edit_section_queue')) return;

  const url = window.location.href;

  try {
    // ============================================================
    // PASO 2: Estamos en el formulario de edicion de la Pagina
    // ============================================================
    console.log('[GAULA] Verificando fill_form:', url.includes('/course/modedit.php'), state.step);
    if (url.includes('/course/modedit.php') && state.step === 'fill_form') {
      await gaulaWait(2000);
      gaulaReportProgress(3, 4, 'running', { step: `Llenando ${state.pageName}...` });

      // Inyectar HTML en el editor Atto ("Texto" en Área de texto y medios)
      const attoEditors = document.querySelectorAll('.editor_atto_content[contenteditable="true"]');
      for (const editor of attoEditors) {
        editor.focus();
        editor.innerHTML = state.htmlContent;
        editor.dispatchEvent(new Event('input', { bubbles: true }));
        editor.dispatchEvent(new Event('change', { bubbles: true }));
        await gaulaWait(300);
      }

      // Actualizar los textareas ocultos asociados (Moodle los usa al guardar)
      const hiddenTextareas = document.querySelectorAll('textarea[id^="id_introeditor"], textarea[id^="id_page"]');
      for (const ta of hiddenTextareas) {
        ta.value = state.htmlContent;
      }

      await gaulaWait(500);
      gaulaReportProgress(4, 4, 'running', { step: 'Guardando...' });

      // Guardar cambios y regresar al curso (preferir "regresar" para volver al curso)
      const saveBtn = document.querySelector('#id_submitbutton2') || // "Guardar y regresar"
                      gaulaByRole('button', 'Guardar cambios y regresar') ||
                      document.querySelector('#id_submitbutton');     // "Guardar y mostrar"
      if (saveBtn) {
        // Verificar si hay mas secciones pendientes en la cola
        const queue = state.queue || [];
        const currentIdx = state.queueIndex || 0;

        // targetSection y nombre del item actual (el que se acaba de guardar)
        const currentItem = queue.length > 0 ? queue[currentIdx] : null;
        const currentTarget = currentItem?.targetSection || null;
        const currentName = state.pageName;

        const currentSectionIdx = currentItem?.sectionIndex || state.sectionIndex || 0;
        const currentResourceType = currentItem?.sectionType || state.sectionType || null;
        if (queue.length > 0 && currentIdx + 1 < queue.length) {
          await gaulaSaveState({
            action: 'edit_section_queue',
            step: 'next_in_queue',
            queue,
            queueIndex: currentIdx + 1,
            courseUrl: state.courseUrl,
            lastTargetSection: currentTarget,
            lastResourceName: currentName,
            lastSectionIndex: currentSectionIdx,
            lastResourceType: currentResourceType
          });
        } else if (currentTarget) {
          await gaulaSaveState({
            action: 'edit_section_queue',
            step: 'next_in_queue',
            queue,
            queueIndex: queue.length,
            courseUrl: state.courseUrl,
            lastTargetSection: currentTarget,
            lastResourceName: currentName,
            lastSectionIndex: currentSectionIdx,
            lastResourceType: currentResourceType
          });
        } else {
          // Ultima seccion sin mover: limpiar estado
          gaulaClearState();
        }

        gaulaReportProgress(currentIdx + 1, queue.length || 1, 'done', { step: `${state.pageName} creado` });
        gaulaClick(saveBtn);
      } else {
        gaulaClearState();
        gaulaReportProgress(0, 0, 'error', { step: 'edit_section', error: 'No se encontró botón guardar' });
      }
      return;
    }

    // ============================================================
    // PASO 3: Volvimos al curso - procesar siguiente de la cola
    // ============================================================
    if (url.includes('/course/view.php') && state.action === 'edit_section_queue' && state.step === 'next_in_queue') {
      await gaulaWait(2000);

      // Mover el recurso recién creado si tiene targetSection
      if (state.lastTargetSection) {
        try {
          await gaulaMoveLastResource(state.lastTargetSection, state.lastResourceName, state.lastSectionIndex, state.lastResourceType);
          await gaulaWait(1000);
        } catch (e) {
          console.warn('[GAULA] No se pudo mover recurso:', e.message);
        }
      }

      const queue = state.queue || [];
      const idx = state.queueIndex || 0;

      if (idx < queue.length) {
        const next = queue[idx];
        gaulaReportProgress(idx, queue.length, 'running', { step: `Creando ${next.pageName}...` });

        // Activar edicion
        await gaulaEnableEditing();
        await gaulaWait(500);

        // Abrir selector
        await gaulaOpenActivityChooser(next.sectionIndex || 0);
        await gaulaWait(1000);

        // Guardar estado para llenar el formulario
        await gaulaSaveState({
          action: 'edit_section',
          step: 'fill_form',
          sectionType: next.sectionType,
          htmlContent: next.htmlContent,
          pageName: next.pageName,
          sectionIndex: next.sectionIndex || 0,
          queue,
          queueIndex: idx,
          courseUrl: state.courseUrl
        });

        // Buscar y click Pagina
        await gaulaSearchAndClickActivity('texto', 'Área de texto y medios');
      } else {
        gaulaClearState();
        gaulaReportProgress(queue.length, queue.length, 'done', { step: 'Todas las secciones creadas' });
      }
      return;
    }

  } catch (err) {
    gaulaClearState();
    gaulaReportProgress(0, 0, 'error', { step: 'edit_section', error: err.message });
  }
})();

// Handler para iniciar la creacion de Pagina desde el popup (seccion individual)
gaulaRegisterHandler('edit_section', async (msg, sendResponse) => {
  try {
    await gaulaAcquireLock('edit_section');
    const { sectionType, htmlContent, sectionIndex, pageName } = msg;
    gaulaReportProgress(0, 4, 'running', { step: `Creando ${pageName}...` });

    if (!window.location.href.includes('/course/view.php')) {
      sendResponse({ ok: false, error: 'Debes estar en la página del curso.' });
      return;
    }

    await gaulaEnableEditing();
    gaulaReportProgress(1, 4, 'running', { step: 'Abriendo selector de actividades...' });

    await gaulaOpenActivityChooser(sectionIndex || 0);
    await gaulaWait(1000);

    await gaulaSaveState({
      action: 'edit_section',
      step: 'fill_form',
      sectionType,
      htmlContent,
      pageName: pageName || sectionType,
      queue: [],
      queueIndex: 0,
      courseUrl: window.location.href
    });

    gaulaReportProgress(2, 4, 'running', { step: 'Navegando al formulario...' });

    await gaulaSearchAndClickActivity('texto', 'Área de texto y medios');
    sendResponse({ ok: true, message: 'Navegando al formulario de Área de texto y medios...' });

  } catch (err) {
    gaulaClearState();
    if (err.message === 'STOPPED') {
      gaulaReportProgress(0, 0, 'stopped', { step: 'edit_section' });
    } else {
      gaulaReportProgress(0, 0, 'error', { step: 'edit_section', error: err.message });
    }
    sendResponse({ ok: false, error: err.message });
  }
});

// Handler para lote de secciones (cola completa desde el popup)
gaulaRegisterHandler('edit_section_batch', async (msg, sendResponse) => {
  try {
    await gaulaAcquireLock('edit_section_batch');
    const { queue, courseUrl } = msg;
    if (!queue || queue.length === 0) {
      sendResponse({ ok: false, error: 'Cola vacía.' });
      return;
    }

    if (!window.location.href.includes('/course/view.php')) {
      sendResponse({ ok: false, error: 'Debes estar en la página del curso.' });
      return;
    }

    const first = queue[0];
    gaulaReportProgress(0, queue.length, 'running', { step: `Creando ${first.pageName}...` });

    await gaulaEnableEditing();
    await gaulaWait(500);

    await gaulaOpenActivityChooser(first.sectionIndex || 0);
    await gaulaWait(1000);

    // Guardar TODA la cola en el estado ANTES de navegar
    await gaulaSaveState({
      action: 'edit_section',
      step: 'fill_form',
      sectionType: first.sectionType,
      htmlContent: first.htmlContent,
      pageName: first.pageName,
      queue,
      queueIndex: 0,
      courseUrl: courseUrl || window.location.href
    });

    await gaulaSearchAndClickActivity('texto', 'Área de texto y medios');
    sendResponse({ ok: true, message: `Procesando cola de ${queue.length} secciones...` });

  } catch (err) {
    gaulaClearState();
    if (err.message === 'STOPPED') {
      gaulaReportProgress(0, 0, 'stopped', { step: 'edit_section_batch' });
    } else {
      gaulaReportProgress(0, 0, 'error', { step: 'edit_section_batch', error: err.message });
    }
    sendResponse({ ok: false, error: err.message });
  }
});

// ============================================================
// HANDLER: Borrar recursos en lote por tipo
// ============================================================
gaulaRegisterHandler('bulk_delete', async (msg, sendResponse) => {
  try {
    await gaulaAcquireLock('bulk_delete');
    if (!window.location.href.includes('/course/view.php')) {
      sendResponse({ ok: false, error: 'Debes estar en la página del curso.' });
      return;
    }

    await gaulaEnableEditing();
    await gaulaWait(500);

    const { resourceType } = msg;

    // Filtro por tipo usando data-activityname
    const matchers = {
      pdf: (name) => name.startsWith('PDF - ') || name.startsWith('PDF -'),
      ppt: (name) => name.startsWith('Diapositiva - ') || name.startsWith('Diapositiva -'),
      video: (name) => name.includes('Videos'),
      geneally: (name) => name.includes('Geneally') || name.includes('Genially')
    };
    const match = matchers[resourceType];
    if (!match) {
      sendResponse({ ok: false, error: 'Tipo no reconocido: ' + resourceType });
      return;
    }

    // Encontrar recursos que coincidan
    const allActivities = [...document.querySelectorAll('[data-activityname]')];
    const toDelete = allActivities.filter(el => match(el.dataset.activityname));

    if (toDelete.length === 0) {
      sendResponse({ ok: true, deleted: 0 });
      return;
    }

    let deleted = 0;
    for (let d = 0; d < toDelete.length; d++) {
      try {
        // Re-buscar porque el DOM cambia tras cada borrado
        const fresh = [...document.querySelectorAll('[data-activityname]')]
          .filter(el => match(el.dataset.activityname));
        if (fresh.length === 0) break;
        const activity = fresh[0]; // Siempre el primero que queda

        const menuBtn = activity.querySelector('[id^="action-menu-toggle-"]');
        if (!menuBtn) continue;
        gaulaClick(menuBtn);
        await gaulaWait(500);

        // Click en "Borrar"
        const menuId = menuBtn.getAttribute('aria-controls');
        let deleteItem = null;
        if (menuId) {
          const dropdown = document.getElementById(menuId);
          if (dropdown) {
            deleteItem = [...dropdown.querySelectorAll('a')].find(a =>
              a.textContent.trim() === 'Borrar'
            );
          }
        }
        if (!deleteItem) {
          deleteItem = [...document.querySelectorAll('.dropdown-menu.show a')]
            .find(a => a.textContent.trim() === 'Borrar');
        }
        if (!deleteItem) continue;
        gaulaClick(deleteItem);
        await gaulaWait(1000);

        // Confirmar "Sí"
        const confirmBtn = [...document.querySelectorAll('.modal.show button, .modal[style*="display: block"] button')]
          .find(b => b.textContent.trim() === 'Sí');
        if (confirmBtn) {
          gaulaClick(confirmBtn);
          await gaulaWait(2000);
        }

        deleted++;
      } catch (e) {
        console.warn('[GAULA] Error borrando recurso:', e.message);
      }
    }

    await gaulaReleaseLock();
    sendResponse({ ok: true, deleted });
  } catch (err) {
    await gaulaReleaseLock();
    sendResponse({ ok: false, error: err.message });
  }
});
