/**
 * Generador de Aulas - Editor del banner principal del curso.
 * Edita la primera etiqueta (label) de la sección 0 que contiene el banner.
 *
 * Flujo multi-página (codegen):
 * 1. (Curso) Clic en action-menu-toggle de la etiqueta → "Editar ajustes"
 * 2. (Formulario) "Mostrar/ocultar botones" → "HTML" → reemplazar contenido → Guardar
 */

// Al cargar, verificar si hay una edición de banner pendiente
(async function checkBannerState() {
  const state = await gaulaGetState();
  if (!state || state.action !== 'edit_banner') return;

  const url = window.location.href;

  try {
    // ============================================================
    // PASO 2: Estamos en el formulario de edición de la etiqueta
    // ============================================================
    if (url.includes('/course/modedit.php') && state.step === 'fill_banner') {
      await gaulaWait(2000);
      gaulaReportProgress(2, 3, 'running', { step: 'Editando banner...' });

      // Inyectar HTML directo en los editores Atto (contenteditable)
      const attoEditors = document.querySelectorAll('.editor_atto_content[contenteditable="true"]');
      if (attoEditors.length > 0) {
        // El editor principal de la etiqueta (Texto de la etiqueta)
        const editor = attoEditors[0];
        editor.focus();
        editor.innerHTML = state.bannerHtml;
        editor.dispatchEvent(new Event('input', { bubbles: true }));
        editor.dispatchEvent(new Event('change', { bubbles: true }));
        await gaulaWait(300);
      }

      // Actualizar textareas ocultos asociados
      const hiddenTextareas = document.querySelectorAll('textarea[id^="id_introeditor"]');
      for (const ta of hiddenTextareas) {
        ta.value = state.bannerHtml;
      }

      await gaulaWait(500);
      gaulaReportProgress(3, 3, 'running', { step: 'Guardando banner...' });

      // Preparar estado para continuar con la cola de secciones después de guardar
      if (state.pendingQueue && state.pendingQueue.length > 0) {
        await gaulaSaveState({
          action: 'edit_section_queue',
          step: 'next_in_queue',
          queue: state.pendingQueue,
          queueIndex: 0,
          courseUrl: state.courseUrl,
          lastTargetSection: null,
          lastResourceName: null
        });
      } else {
        gaulaClearState();
      }

      // Guardar cambios y regresar al curso
      const saveBtn = document.querySelector('#id_submitbutton2') ||
                      gaulaByRole('button', 'Guardar cambios y regresar') ||
                      document.querySelector('#id_submitbutton');
      if (saveBtn) {
        gaulaReportProgress(1, 1, 'done', { step: 'Banner actualizado' });
        gaulaClick(saveBtn);
      } else {
        gaulaClearState();
        gaulaReportProgress(0, 0, 'error', { step: 'edit_banner', error: 'No se encontró botón guardar' });
      }
      return;
    }

  } catch (err) {
    gaulaClearState();
    gaulaReportProgress(0, 0, 'error', { step: 'edit_banner', error: err.message });
  }
})();

// Handler para editar el banner desde el popup
gaulaRegisterHandler('edit_banner', async (msg, sendResponse) => {
  try {
    await gaulaAcquireLock('edit_banner');
    const { bannerHtml, pendingQueue, courseUrl } = msg;
    gaulaReportProgress(0, 3, 'running', { step: 'Editando banner del curso...' });

    if (!window.location.href.includes('/course/view.php')) {
      sendResponse({ ok: false, error: 'Debes estar en la página del curso.' });
      return;
    }

    await gaulaEnableEditing();
    await gaulaWait(500);

    // Buscar la primera etiqueta en la sección 0 (el banner)
    // Las etiquetas tienen action-menu-toggle con menú que incluye "Editar ajustes"
    // Buscamos el primer action-menu-toggle en la sección 0
    const section0 = document.querySelector('#coursecontentcollapse0') ||
                     document.querySelector('[data-sectionid="0"]') ||
                     document.querySelector('.course-content');

    if (!section0) {
      sendResponse({ ok: false, error: 'No se encontró la sección 0 del curso.' });
      return;
    }

    // Buscar la primera actividad que contenga el banner (buscar por clase bannerfloat o por ser la primera label)
    const allMenus = section0.querySelectorAll('[id^="action-menu-toggle-"]');
    if (allMenus.length === 0) {
      sendResponse({ ok: false, error: 'No se encontraron elementos editables en la sección 0.' });
      return;
    }

    // El banner es típicamente la primera etiqueta/actividad en la sección 0
    const firstMenu = allMenus[0];
    gaulaReportProgress(1, 3, 'running', { step: 'Abriendo editor del banner...' });

    gaulaClick(firstMenu);
    await gaulaWait(500);

    // Clic en "Editar ajustes"
    const editItem = await gaulaWaitForRole('menuitem', 'Editar ajustes', { timeout: 5000 });
    if (!editItem) {
      sendResponse({ ok: false, error: 'No se encontró "Editar ajustes" en el menú.' });
      return;
    }

    // Guardar estado antes de navegar
    await gaulaSaveState({
      action: 'edit_banner',
      step: 'fill_banner',
      bannerHtml,
      pendingQueue: pendingQueue || [],
      courseUrl: courseUrl || window.location.href
    });

    gaulaClick(editItem);
    sendResponse({ ok: true, message: 'Navegando al editor del banner...' });

  } catch (err) {
    gaulaClearState();
    if (err.message === 'STOPPED') {
      gaulaReportProgress(0, 0, 'stopped', { step: 'edit_banner' });
    } else {
      gaulaReportProgress(0, 0, 'error', { step: 'edit_banner', error: err.message });
    }
    sendResponse({ ok: false, error: err.message });
  }
});
