const PROMPT_TEMPLATE = `Extrae los temas del sílabo universitario en JSON.

REGLAS:
1. Cada unidad DEBE tener EXACTAMENTE 2 tipos distintos de met_comp entre: "CD", "APE", "TA".
2. Todos los campos son strings. met_desc y eval_desc deben tener MÁXIMO 6 PALABRAS.
3. ra_id: ID del resultado de aprendizaje tal como aparece en el sílabo (ej: "E055-001", "RA1").

FORMATO EXACTO por objeto (NO agregues campos extra, NO cambies los nombres):
{"unidad":"01","tema":"1.1","met_desc":"Clase teórica de SO","met_comp":"CD","eval_desc":"Cuestionario teórico","ra_id":"E055-001"}

Responde SOLO el array JSON []. Sin markdown, sin explicaciones, sin comentarios.

SÍLABO:

`;

const REQUIRED_FIELDS = new Set(["unidad", "tema", "met_desc", "met_comp", "eval_desc", "ra_id"]);
const FIELD_ORDER = ["unidad", "tema", "met_desc", "met_comp", "eval_desc", "ra_id"];
const VALID_MET_COMP = new Set(["CD", "APE", "TA"]);
