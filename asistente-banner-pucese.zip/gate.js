// ============================================================================
// gate.js — Capa de autenticación y verificación de plan
// ============================================================================
// Se ejecuta ANTES que popup.js. Verifica:
//   1. Usuario hace login con Google vía Supabase Auth (mismo flujo que el
//      Generador de Aulas Virtuales PUCESE — no requiere OAuth Client ID
//      adicional en Google Cloud Console)
//   2. El backend NEXBYTE confirma que tiene plan completo (o override
//      manual en banner_access)
//   3. Si OK → libera la UI normal (popup.js sigue su curso)
//   4. Si NO → bloquea la UI con pantalla "Necesitas Plan Completo"
//
// Aditivo — no modifica popup.js ni api-client.js. Si en el futuro hay que
// quitar el gating, solo se borran gate.js y gate-background.js y se
// restaura el manifest original.
// ============================================================================

const GATE_CONFIG = {
  BACKEND_URL: "https://dashboard-three-kohl-42.vercel.app/api/banner-check",
  SESSION_STORAGE_KEY: "banner_session",
  GATE_CHECK_KEY: "banner_gate_check",
  // Si la última verificación de plan tiene menos de N minutos, no revalidar
  CACHE_TTL_MIN: 60,
};

(function bannerGate() {
  // Crear overlay de gating al inicio (oculta toda la UI hasta validación)
  const overlay = document.createElement("div");
  overlay.id = "banner-gate-overlay";
  overlay.innerHTML = `
    <style>
      #banner-gate-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: linear-gradient(180deg, #0F172A 0%, #1E293B 100%);
        color: #E2E8F0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        display: flex; align-items: center; justify-content: center;
        padding: 24px; box-sizing: border-box;
      }
      .gate-card { width: 100%; max-width: 420px; text-align: center; }
      .gate-logo {
        width: 56px; height: 56px; border-radius: 14px;
        background: linear-gradient(135deg, #3B82F6, #22D3EE);
        display: inline-flex; align-items: center; justify-content: center;
        font-size: 28px; margin: 0 auto 18px;
      }
      .gate-title { font-size: 18px; font-weight: 800; margin: 0 0 8px; color: white; }
      .gate-subtitle { font-size: 13px; color: #94A3B8; margin: 0 0 24px; line-height: 1.5; }
      .gate-status { font-size: 12px; color: #64748B; margin-top: 16px; min-height: 18px; }
      .gate-btn {
        display: inline-flex; align-items: center; gap: 10px;
        background: white; color: #1f2937;
        padding: 11px 22px; border-radius: 10px;
        font-size: 14px; font-weight: 600;
        border: none; cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        transition: transform 0.2s;
      }
      .gate-btn:hover { transform: translateY(-1px); }
      .gate-btn:disabled { opacity: 0.6; cursor: wait; }
      .gate-btn .g-logo {
        width: 16px; height: 16px;
        background: conic-gradient(from -45deg, #4285F4 0% 25%, #34A853 25% 50%, #FBBC05 50% 75%, #EA4335 75% 100%);
        border-radius: 50%; position: relative;
      }
      .gate-btn .g-logo::after {
        content: 'G'; position: absolute; inset: 0;
        display: flex; align-items: center; justify-content: center;
        color: white; font-weight: 900; font-size: 10px;
      }
      .gate-locked {
        background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.25);
        border-radius: 12px; padding: 16px; margin-top: 18px;
        font-size: 13px; color: #FCA5A5; line-height: 1.55;
      }
      .gate-link {
        display: inline-block; margin-top: 12px;
        color: #22D3EE; text-decoration: none; font-size: 13px; font-weight: 600;
      }
      .gate-footer { margin-top: 24px; font-size: 11px; color: #475569; }
      .gate-logout {
        margin-top: 16px; background: none; border: none;
        color: #64748B; font-size: 12px; cursor: pointer; text-decoration: underline;
      }
    </style>
    <div class="gate-card">
      <div class="gate-logo">🎯</div>
      <h1 class="gate-title">Asistente Banner</h1>
      <p class="gate-subtitle">Inicia sesión con tu cuenta Google de NEXBYTE para usar la extensión.</p>
      <button id="gate-login-btn" class="gate-btn">
        <span class="g-logo"></span>
        <span>Iniciar sesión con Google</span>
      </button>
      <div id="gate-status" class="gate-status"></div>
      <div id="gate-locked-box" class="gate-locked" style="display:none"></div>
      <div class="gate-footer">
        <strong>Powered by NEXBYTE</strong><br>
        Requiere Plan Completo activo del Generador de Aulas Virtuales
      </div>
    </div>
  `;
  document.documentElement.appendChild(overlay);
  document.body.style.overflow = "hidden";

  const btn = overlay.querySelector("#gate-login-btn");
  const statusEl = overlay.querySelector("#gate-status");
  const lockedBox = overlay.querySelector("#gate-locked-box");

  function showStatus(text, color) {
    statusEl.textContent = text;
    statusEl.style.color = color || "#64748B";
  }

  function showLocked(message, planName) {
    lockedBox.style.display = "block";
    lockedBox.innerHTML = `
      <strong>🔒 Acceso restringido</strong><br>
      ${message}
      ${planName ? `<br><br><span style="color:#94A3B8;font-size:11px">Tu plan actual: <strong>${planName}</strong></span>` : ""}
      <br><a class="gate-link" href="https://nexbyte.pro/planes/" target="_blank">Ver planes en nexbyte.pro →</a>
      <br><button class="gate-logout" id="gate-logout-btn">Cerrar sesión y probar con otra cuenta</button>
    `;
    btn.style.display = "none";

    const logoutBtn = lockedBox.querySelector("#gate-logout-btn");
    logoutBtn?.addEventListener("click", async () => {
      await chrome.runtime.sendMessage({ type: "BANNER_LOGOUT" });
      chrome.storage.local.remove(GATE_CONFIG.GATE_CHECK_KEY);
      location.reload();
    });
  }

  function unlock() {
    overlay.remove();
    document.body.style.overflow = "";
  }

  async function verifyPlan(accessToken) {
    showStatus("Verificando tu plan con NEXBYTE...");
    const resp = await fetch(GATE_CONFIG.BACKEND_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ supabase_access_token: accessToken }),
    });
    return await resp.json();
  }

  async function checkAndUnlock(forceLogin = false) {
    btn.disabled = true;

    try {
      // 1. Obtener / crear sesión Supabase
      let sessionResp;
      if (forceLogin) {
        showStatus("Abriendo login con Google...");
        sessionResp = await chrome.runtime.sendMessage({ type: "BANNER_LOGIN_GOOGLE" });
      } else {
        sessionResp = await chrome.runtime.sendMessage({ type: "BANNER_GET_SESSION" });
        if (!sessionResp?.ok) {
          // Sin sesión válida — mostrar botón
          btn.disabled = false;
          return;
        }
      }

      if (!sessionResp?.ok) {
        throw new Error(sessionResp?.error || "Falló el inicio de sesión");
      }

      const accessToken = sessionResp.session?.access_token ||
        (await chrome.storage.local.get(GATE_CONFIG.SESSION_STORAGE_KEY))[GATE_CONFIG.SESSION_STORAGE_KEY]?.access_token;

      if (!accessToken) throw new Error("No se obtuvo token de acceso");

      // 2. Verificar plan con el backend
      const planResult = await verifyPlan(accessToken);

      // 3. Cachear el resultado
      chrome.storage.local.set({
        [GATE_CONFIG.GATE_CHECK_KEY]: {
          allowed: planResult.allowed,
          plan_name: planResult.plan_name,
          expires_at: planResult.expires_at,
          verified_at: Date.now(),
        },
      });

      if (planResult.allowed) {
        showStatus(`✓ ${planResult.message || "Acceso concedido"}`, "#22C55E");
        setTimeout(unlock, 600);
      } else {
        showLocked(planResult.message || "No tienes acceso a esta extensión.", planResult.plan_name);
      }
    } catch (e) {
      console.error("[gate]", e);
      showStatus(`Error: ${e.message}`, "#FCA5A5");
      btn.disabled = false;
    }
  }

  // Auto-check al abrir: si hay sesión válida + cache reciente, desbloquear directo
  chrome.storage.local.get(
    [GATE_CONFIG.SESSION_STORAGE_KEY, GATE_CONFIG.GATE_CHECK_KEY],
    (result) => {
      const session = result[GATE_CONFIG.SESSION_STORAGE_KEY];
      const lastCheck = result[GATE_CONFIG.GATE_CHECK_KEY];

      if (session?.access_token && lastCheck?.allowed) {
        const ageMin = (Date.now() - (lastCheck.verified_at || 0)) / 60000;
        if (ageMin < GATE_CONFIG.CACHE_TTL_MIN) {
          // Cache válido — desbloquear sin tocar la red
          showStatus(`Sesión activa (${lastCheck.plan_name})`, "#22C55E");
          setTimeout(unlock, 300);
          return;
        }
      }

      if (session?.access_token) {
        // Hay sesión pero el cache expiró — revalidar sin pedir login de nuevo
        checkAndUnlock(false);
      }
      // Sin sesión: el usuario debe hacer click en "Iniciar sesión con Google"
    }
  );

  btn.addEventListener("click", () => checkAndUnlock(true));
})();
