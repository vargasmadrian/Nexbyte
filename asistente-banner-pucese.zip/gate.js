// ============================================================================
// gate.js — Capa de autenticación y verificación de plan
// ============================================================================
// Versión 2: launchWebAuthFlow se llama DIRECTAMENTE desde el popup
// (no vía service worker) para evitar que el cierre del popup interrumpa
// el OAuth callback. Esto es el patrón Chrome MV3 recomendado.
// ============================================================================

const GATE_CONFIG = {
  SUPABASE_URL: "https://wbgqdrhfvikiciwqrdec.supabase.co",
  SUPABASE_ANON_KEY:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndiZ3FkcmhmdmlraWNpd3FyZGVjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYxMjEzNjgsImV4cCI6MjA5MTY5NzM2OH0.gB7T0FZrTad_xUnNjPADkptTbDhOQI3DBRNnDsvYNkk",
  BACKEND_URL: "https://dashboard-three-kohl-42.vercel.app/api/banner-check",
  SESSION_STORAGE_KEY: "banner_session",
  GATE_CHECK_KEY: "banner_gate_check",
  CACHE_TTL_MIN: 60,
};

(function bannerGate() {
  // Overlay UI
  const overlay = document.createElement("div");
  overlay.id = "banner-gate-overlay";
  overlay.innerHTML = `
    <style>
      #banner-gate-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: linear-gradient(180deg, #0F172A 0%, #1E293B 100%);
        color: #E2E8F0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        display: flex; align-items: center; justify-content: center;
        padding: 24px; box-sizing: border-box;
      }
      .gate-card { width: 100%; max-width: 420px; text-align: center; }
      .gate-logo {
        width: 56px; height: 56px; border-radius: 14px;
        background: linear-gradient(135deg, #3B82F6, #22D3EE);
        display: inline-flex; align-items: center; justify-content: center;
        font-size: 28px; margin: 0 auto 18px;
      }
      .gate-title { font-size: 18px; font-weight: 800; margin: 0 0 8px; color: white; }
      .gate-subtitle { font-size: 13px; color: #94A3B8; margin: 0 0 24px; line-height: 1.5; }
      .gate-status { font-size: 12px; color: #64748B; margin-top: 16px; min-height: 18px; }
      .gate-btn {
        display: inline-flex; align-items: center; gap: 10px;
        background: white; color: #1f2937;
        padding: 11px 22px; border-radius: 10px;
        font-size: 14px; font-weight: 600;
        border: none; cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        transition: transform 0.2s;
      }
      .gate-btn:hover { transform: translateY(-1px); }
      .gate-btn:disabled { opacity: 0.6; cursor: wait; }
      .gate-btn .g-logo {
        width: 16px; height: 16px;
        background: conic-gradient(from -45deg, #4285F4 0% 25%, #34A853 25% 50%, #FBBC05 50% 75%, #EA4335 75% 100%);
        border-radius: 50%; position: relative;
      }
      .gate-btn .g-logo::after {
        content: 'G'; position: absolute; inset: 0;
        display: flex; align-items: center; justify-content: center;
        color: white; font-weight: 900; font-size: 10px;
      }
      .gate-locked {
        background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.25);
        border-radius: 12px; padding: 16px; margin-top: 18px;
        font-size: 13px; color: #FCA5A5; line-height: 1.55;
      }
      .gate-link {
        display: inline-block; margin-top: 12px;
        color: #22D3EE; text-decoration: none; font-size: 13px; font-weight: 600;
      }
      .gate-footer { margin-top: 24px; font-size: 11px; color: #475569; }
      .gate-logout {
        margin-top: 16px; background: none; border: none;
        color: #64748B; font-size: 12px; cursor: pointer; text-decoration: underline;
      }
      .gate-debug {
        margin-top: 12px; font-size: 10px; color: #475569;
        font-family: ui-monospace, monospace;
        text-align: left; max-width: 380px; margin-left: auto; margin-right: auto;
        white-space: pre-wrap; word-break: break-all;
      }
    </style>
    <div class="gate-card">
      <div class="gate-logo">🎯</div>
      <h1 class="gate-title">Asistente Banner</h1>
      <p class="gate-subtitle">Inicia sesión con tu cuenta Google de NEXBYTE para usar la extensión.</p>
      <button id="gate-login-btn" class="gate-btn">
        <span class="g-logo"></span>
        <span>Iniciar sesión con Google</span>
      </button>
      <div id="gate-status" class="gate-status"></div>
      <div id="gate-locked-box" class="gate-locked" style="display:none"></div>
      <div class="gate-footer">
        <strong>Powered by NEXBYTE</strong><br>
        Requiere Plan Completo activo del Generador de Aulas Virtuales
      </div>
      <div id="gate-debug" class="gate-debug" style="display:none"></div>
    </div>
  `;
  document.documentElement.appendChild(overlay);
  document.body.style.overflow = "hidden";

  const btn = overlay.querySelector("#gate-login-btn");
  const statusEl = overlay.querySelector("#gate-status");
  const lockedBox = overlay.querySelector("#gate-locked-box");
  const debugEl = overlay.querySelector("#gate-debug");

  let debugLines = [];
  function debug(msg) {
    console.log("[gate]", msg);
    debugLines.push(`[${new Date().toISOString().substr(11, 8)}] ${msg}`);
    if (debugLines.length > 8) debugLines.shift();
    debugEl.style.display = "block";
    debugEl.textContent = debugLines.join("\n");
  }

  function showStatus(text, color) {
    statusEl.textContent = text;
    statusEl.style.color = color || "#64748B";
  }

  function showLocked(message, planName) {
    lockedBox.style.display = "block";
    lockedBox.innerHTML = `
      <strong>🔒 Acceso restringido</strong><br>
      ${message}
      ${planName ? `<br><br><span style="color:#94A3B8;font-size:11px">Tu plan actual: <strong>${planName}</strong></span>` : ""}
      <br><a class="gate-link" href="https://nexbyte.pro/planes/" target="_blank">Ver planes en nexbyte.pro →</a>
      <br><button class="gate-logout" id="gate-logout-btn">Cerrar sesión y probar con otra cuenta</button>
    `;
    btn.style.display = "none";

    const logoutBtn = lockedBox.querySelector("#gate-logout-btn");
    logoutBtn?.addEventListener("click", async () => {
      await chrome.storage.local.remove([
        GATE_CONFIG.SESSION_STORAGE_KEY,
        GATE_CONFIG.GATE_CHECK_KEY,
      ]);
      location.reload();
    });
  }

  function unlock() {
    overlay.remove();
    document.body.style.overflow = "";
  }

  // OAuth flow EJECUTADO DIRECTAMENTE EN EL POPUP (no via service worker)
  async function doGoogleLogin() {
    debug("Iniciando OAuth Supabase + Google...");

    if (!chrome?.identity?.launchWebAuthFlow) {
      throw new Error("chrome.identity no disponible. Verifica permisos en manifest.");
    }

    const redirectUrl = chrome.identity.getRedirectURL();
    debug("Redirect URL: " + redirectUrl);

    const authUrl =
      `${GATE_CONFIG.SUPABASE_URL}/auth/v1/authorize?provider=google&redirect_to=` +
      encodeURIComponent(redirectUrl);
    debug("Auth URL: " + authUrl.substring(0, 100) + "...");

    const responseUrl = await chrome.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true,
    });

    if (!responseUrl) throw new Error("No se recibió respuesta de Google");
    debug("Got response URL: " + responseUrl.substring(0, 80) + "...");

    // El access_token viene en el HASH (#access_token=...&refresh_token=...)
    const url = new URL(responseUrl);
    const hashParams = new URLSearchParams(url.hash.substring(1));
    const accessToken = hashParams.get("access_token");
    const refreshToken = hashParams.get("refresh_token");

    if (!accessToken) {
      // Fallback: buscar en query params por si Supabase cambió el flow
      const queryToken = url.searchParams.get("access_token");
      if (queryToken) {
        debug("Token encontrado en query (no hash)");
        return queryToken;
      }
      throw new Error("No se obtuvo access_token. URL: " + responseUrl.substring(0, 150));
    }

    debug("✓ Access token obtenido");

    // Persistir
    await chrome.storage.local.set({
      [GATE_CONFIG.SESSION_STORAGE_KEY]: {
        access_token: accessToken,
        refresh_token: refreshToken,
        timestamp: Date.now(),
      },
    });

    return accessToken;
  }

  async function verifyPlan(accessToken) {
    debug("Verificando plan con backend NEXBYTE...");
    const resp = await fetch(GATE_CONFIG.BACKEND_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ supabase_access_token: accessToken }),
    });
    const data = await resp.json();
    debug(`Backend response: allowed=${data.allowed}, reason=${data.reason}`);
    return data;
  }

  async function checkAndUnlock(forceLogin = false) {
    btn.disabled = true;
    showStatus("Conectando...");

    try {
      let accessToken;

      if (forceLogin) {
        // Login fresh
        showStatus("Abriendo Google...");
        accessToken = await doGoogleLogin();
      } else {
        // Reusar token guardado
        const stored = await chrome.storage.local.get(GATE_CONFIG.SESSION_STORAGE_KEY);
        accessToken = stored[GATE_CONFIG.SESSION_STORAGE_KEY]?.access_token;
        if (!accessToken) {
          btn.disabled = false;
          return; // Sin sesión, mostrar botón
        }
        debug("Reusando token guardado");
      }

      // Verificar plan con backend
      const planResult = await verifyPlan(accessToken);

      // Cachear
      chrome.storage.local.set({
        [GATE_CONFIG.GATE_CHECK_KEY]: {
          allowed: planResult.allowed,
          plan_name: planResult.plan_name,
          expires_at: planResult.expires_at,
          verified_at: Date.now(),
        },
      });

      if (planResult.allowed) {
        showStatus(`✓ ${planResult.message || "Acceso concedido"}`, "#22C55E");
        setTimeout(unlock, 700);
      } else {
        showLocked(planResult.message || "No tienes acceso a esta extensión.", planResult.plan_name);
      }
    } catch (e) {
      console.error("[gate] error", e);
      debug("ERROR: " + (e.message || String(e)));
      showStatus(`Error: ${e.message || String(e)}`, "#FCA5A5");
      btn.disabled = false;
    }
  }

  // Auto-check si hay cache reciente
  chrome.storage.local.get(
    [GATE_CONFIG.SESSION_STORAGE_KEY, GATE_CONFIG.GATE_CHECK_KEY],
    (result) => {
      const session = result[GATE_CONFIG.SESSION_STORAGE_KEY];
      const lastCheck = result[GATE_CONFIG.GATE_CHECK_KEY];

      if (session?.access_token && lastCheck?.allowed) {
        const ageMin = (Date.now() - (lastCheck.verified_at || 0)) / 60000;
        if (ageMin < GATE_CONFIG.CACHE_TTL_MIN) {
          showStatus(`Sesión activa (${lastCheck.plan_name})`, "#22C55E");
          setTimeout(unlock, 300);
          return;
        }
      }

      if (session?.access_token) {
        // Hay token pero cache expiró — revalidar sin pedir login de nuevo
        checkAndUnlock(false);
      }
    }
  );

  btn.addEventListener("click", () => checkAndUnlock(true));
})();
