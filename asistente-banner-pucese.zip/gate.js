// ============================================================================
// gate.js — Capa de autenticación y verificación de plan
// ============================================================================
// Se ejecuta ANTES que popup.js. Verifica:
//   1. Usuario hace login con Google (chrome.identity)
//   2. El backend de NEXBYTE confirma que tiene plan completo + permiso RSMC
//   3. Si OK → libera la UI normal (popup.js sigue su curso)
//   4. Si NO → bloquea la UI con pantalla "Necesitas Plan Completo"
//
// Aditivo — no modifica popup.js ni api-client.js. Si en el futuro hay que
// quitar el gating, solo se borra este archivo y la referencia en popup.html.
// ============================================================================

const GATE_CONFIG = {
  BACKEND_URL: 'https://dashboard-three-kohl-42.vercel.app/api/banner-check',
  STORAGE_KEY: 'banner_gate_session',
  // Si el token tiene menos de N minutos, no revalidar contra el backend
  CACHE_TTL_MIN: 60,
};

(function bannerGate() {
  // Crear overlay de gating al inicio (oculta toda la UI hasta validación)
  const overlay = document.createElement('div');
  overlay.id = 'banner-gate-overlay';
  overlay.innerHTML = `
    <style>
      #banner-gate-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: linear-gradient(180deg, #0F172A 0%, #1E293B 100%);
        color: #E2E8F0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        display: flex; align-items: center; justify-content: center;
        padding: 24px; box-sizing: border-box;
      }
      .gate-card {
        width: 100%; max-width: 420px; text-align: center;
      }
      .gate-logo {
        width: 56px; height: 56px; border-radius: 14px;
        background: linear-gradient(135deg, #3B82F6, #22D3EE);
        display: inline-flex; align-items: center; justify-content: center;
        font-size: 28px; margin: 0 auto 18px;
      }
      .gate-title { font-size: 18px; font-weight: 800; margin: 0 0 8px; color: white; }
      .gate-subtitle { font-size: 13px; color: #94A3B8; margin: 0 0 24px; line-height: 1.5; }
      .gate-status {
        font-size: 12px; color: #64748B; margin-top: 16px;
        min-height: 18px;
      }
      .gate-btn {
        display: inline-flex; align-items: center; gap: 10px;
        background: white; color: #1f2937;
        padding: 11px 22px; border-radius: 10px;
        font-size: 14px; font-weight: 600;
        border: none; cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        transition: transform 0.2s;
      }
      .gate-btn:hover { transform: translateY(-1px); }
      .gate-btn:disabled { opacity: 0.6; cursor: wait; }
      .gate-btn .g-logo {
        width: 16px; height: 16px;
        background: conic-gradient(from -45deg, #4285F4 0% 25%, #34A853 25% 50%, #FBBC05 50% 75%, #EA4335 75% 100%);
        border-radius: 50%; position: relative;
      }
      .gate-btn .g-logo::after {
        content: 'G'; position: absolute; inset: 0;
        display: flex; align-items: center; justify-content: center;
        color: white; font-weight: 900; font-size: 10px;
      }
      .gate-locked {
        background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.25);
        border-radius: 12px; padding: 16px; margin-top: 18px;
        font-size: 13px; color: #FCA5A5; line-height: 1.55;
      }
      .gate-link {
        display: inline-block; margin-top: 12px;
        color: #22D3EE; text-decoration: none; font-size: 13px; font-weight: 600;
      }
      .gate-spinner {
        width: 18px; height: 18px; border: 2px solid rgba(255,255,255,0.2);
        border-top-color: #22D3EE; border-radius: 50%;
        animation: spin 0.8s linear infinite;
        display: inline-block; vertical-align: middle; margin-right: 6px;
      }
      @keyframes spin { to { transform: rotate(360deg); } }
      .gate-footer {
        margin-top: 24px; font-size: 11px; color: #475569;
      }
    </style>
    <div class="gate-card">
      <div class="gate-logo">🎯</div>
      <h1 class="gate-title">Asistente Banner</h1>
      <p class="gate-subtitle">Inicia sesión con tu cuenta Google de NEXBYTE para usar la extensión.</p>
      <button id="gate-login-btn" class="gate-btn">
        <span class="g-logo"></span>
        <span>Iniciar sesión con Google</span>
      </button>
      <div id="gate-status" class="gate-status"></div>
      <div id="gate-locked-box" class="gate-locked" style="display:none"></div>
      <div class="gate-footer">
        <strong>Powered by NEXBYTE</strong><br>
        Requiere Plan Completo activo del Generador de Aulas Virtuales
      </div>
    </div>
  `;
  document.documentElement.appendChild(overlay);

  // Bloquear todo el body hasta validación
  document.body.style.overflow = 'hidden';

  const btn = overlay.querySelector('#gate-login-btn');
  const statusEl = overlay.querySelector('#gate-status');
  const lockedBox = overlay.querySelector('#gate-locked-box');

  function showStatus(text, color) {
    statusEl.textContent = text;
    statusEl.style.color = color || '#64748B';
  }

  function showLocked(message, planName) {
    lockedBox.style.display = 'block';
    lockedBox.innerHTML = `
      <strong>🔒 Acceso restringido</strong><br>
      ${message}
      ${planName ? `<br><br><span style="color:#94A3B8;font-size:11px">Tu plan actual: <strong>${planName}</strong></span>` : ''}
      <br><a class="gate-link" href="https://nexbyte.pro/planes/" target="_blank">Ver planes en nexbyte.pro →</a>
    `;
    btn.style.display = 'none';
  }

  function unlock() {
    // Liberar UI normal
    overlay.remove();
    document.body.style.overflow = '';
    // popup.js ya se está ejecutando — no hace falta hacer nada más
  }

  async function getGoogleIdToken() {
    return new Promise((resolve, reject) => {
      if (!chrome?.identity?.getAuthToken) {
        return reject(new Error('chrome.identity no disponible. Verifica el manifest.'));
      }
      // Limpiar cache previa para forzar fresh token con id_token
      chrome.identity.getAuthToken({ interactive: true }, async (accessToken) => {
        if (chrome.runtime.lastError || !accessToken) {
          return reject(chrome.runtime.lastError || new Error('No se obtuvo token de Google'));
        }
        // Convertir access token a id_token vía userinfo (NOTA: chrome.identity devuelve
        // access_token, no id_token. Para id_token usamos /tokeninfo en el endpoint).
        // Pero el endpoint del backend espera id_token. Solución: pedir id_token explícito.
        // En Manifest V3, chrome.identity NO da id_token directo. Workaround: usar
        // userinfo endpoint y luego firmar nuestro propio JWT, O verificar el access_token
        // en el backend con userinfo. Hacemos lo segundo (más simple):
        resolve(accessToken);
      });
    });
  }

  async function verifyBackend(googleAccessToken) {
    showStatus('Verificando con NEXBYTE...');
    const resp = await fetch(GATE_CONFIG.BACKEND_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ google_access_token: googleAccessToken }),
    });
    if (!resp.ok && resp.status !== 200) {
      throw new Error(`Servidor respondió ${resp.status}`);
    }
    return await resp.json();
  }

  async function checkAndUnlock() {
    btn.disabled = true;
    showStatus('Iniciando sesión...');

    try {
      // 1. Token Google
      const accessToken = await getGoogleIdToken();
      // 2. Verificar contra backend
      const result = await verifyBackend(accessToken);

      if (result.allowed) {
        // Persistir sesión exitosa
        const session = {
          allowed: true,
          plan_name: result.plan_name,
          expires_at: result.expires_at,
          verified_at: Date.now(),
        };
        chrome.storage.local.set({ [GATE_CONFIG.STORAGE_KEY]: session });
        showStatus(`✓ ${result.message || 'Acceso concedido'}`, '#22C55E');
        setTimeout(unlock, 600);
      } else {
        chrome.storage.local.remove(GATE_CONFIG.STORAGE_KEY);
        showLocked(result.message || 'No tienes acceso a esta extensión.', result.plan_name);
      }
    } catch (e) {
      console.error('[gate]', e);
      showStatus(`Error: ${e.message}`, '#FCA5A5');
      btn.disabled = false;
    }
  }

  // Auto-check si hay sesión cacheada reciente
  chrome.storage.local.get(GATE_CONFIG.STORAGE_KEY, (result) => {
    const session = result[GATE_CONFIG.STORAGE_KEY];
    if (session && session.allowed) {
      const ageMin = (Date.now() - session.verified_at) / 60000;
      if (ageMin < GATE_CONFIG.CACHE_TTL_MIN) {
        showStatus(`Sesión activa (${session.plan_name})`, '#22C55E');
        setTimeout(unlock, 400);
        return;
      }
    }
    // Sin sesión válida → mostrar botón de login
  });

  btn.addEventListener('click', checkAndUnlock);
})();
