/**
 * Llamadas directas a las APIs REST de Gemini y OpenAI (sin SDKs).
 */

// Configurar worker de pdf.js
pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';

async function extractTextFromPDF(file) {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let text = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map(item => item.str).join(' ') + '\n';
  }
  return text;
}

async function callGemini(model, apiKey, text) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: PROMPT_TEMPLATE + text.substring(0, 150000) }] }],
      generationConfig: {
        maxOutputTokens: 16384,
        temperature: 0.1,
        responseMimeType: 'application/json'
      }
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    const msg = err.error?.message || `Error ${response.status}`;
    throw new Error(msg);
  }

  const data = await response.json();
  return data.candidates[0].content.parts[0].text;
}

async function callOpenAI(model, apiKey, text) {
  const modelName = model === 'openai-gpt-4o-mini' ? 'gpt-4o-mini' : 'gpt-4o';
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: modelName,
      messages: [
        { role: 'system', content: PROMPT_TEMPLATE },
        { role: 'user', content: text.substring(0, 100000) }
      ],
      temperature: 0.1,
      max_tokens: 16384,
      response_format: { type: 'json_object' }
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    const msg = err.error?.message || `Error ${response.status}`;
    throw new Error(msg);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

async function callAI(provider, apiKey, text) {
  if (provider.startsWith('gemini')) {
    return await callGemini(provider, apiKey, text);
  } else if (provider.startsWith('openai')) {
    return await callOpenAI(provider, apiKey, text);
  }
  throw new Error('Motor de IA no soportado.');
}

function classifyError(err) {
  const msg = err.message || String(err);
  if (/quota/i.test(msg) || /429/.test(msg))
    return 'Cuota excedida o Rate Limit. Intenta Gemini Flash o verifica tus fondos.';
  if (/401/.test(msg) || /API key/i.test(msg))
    return 'API Key rechazada. Revisa que esté correcta y sin espacios.';
  if (/Failed to fetch/i.test(msg))
    return 'No se pudo conectar con la API. Verifica tu conexión a internet.';
  return 'Error: ' + msg;
}
