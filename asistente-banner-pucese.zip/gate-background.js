// ============================================================================
// gate-background.js — Service Worker
// ============================================================================
// Maneja el flujo OAuth con Supabase Auth (mismo patrón que la extensión
// Generador de Aulas Virtuales PUCESE 3.0). Esto reusa el client_id que
// ya está configurado en Supabase, sin necesidad de crear uno nuevo en
// Google Cloud Console.
//
// Flujo:
//   1. Popup envía mensaje LOGIN_GOOGLE
//   2. Este service worker abre launchWebAuthFlow → Supabase /authorize?provider=google
//   3. Supabase redirige a Google, usuario aprueba, vuelve a Supabase, redirige al chrome-extension://
//   4. Extraemos el access_token del hash de la URL
//   5. Persistimos en chrome.storage.local como `banner_session`
//   6. Devolvemos { ok: true, user: {...} } al popup
//
// Para verificar plan, popup llama a /api/banner-check con el access_token
// Supabase. El backend valida y devuelve allowed/blocked.
// ============================================================================

const CONFIG = {
  SUPABASE_URL: "https://wbgqdrhfvikiciwqrdec.supabase.co",
  SUPABASE_ANON_KEY:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndiZ3FkcmhmdmlraWNpd3FyZGVjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYxMjEzNjgsImV4cCI6MjA5MTY5NzM2OH0.gB7T0FZrTad_xUnNjPADkptTbDhOQI3DBRNnDsvYNkk",
};

const SESSION_KEY = "banner_session";

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "BANNER_LOGIN_GOOGLE") {
    handleGoogleLogin()
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "BANNER_LOGOUT") {
    handleLogout()
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "BANNER_GET_SESSION") {
    getSession()
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});

async function handleGoogleLogin() {
  // Redirect URL canónico de Chrome para extensiones
  const redirectUrl = chrome.identity.getRedirectURL("callback");
  const authUrl =
    `${CONFIG.SUPABASE_URL}/auth/v1/authorize?provider=google&redirect_to=` +
    encodeURIComponent(redirectUrl);

  const responseUrl = await chrome.identity.launchWebAuthFlow({
    url: authUrl,
    interactive: true,
  });

  const url = new URL(responseUrl);
  const hashParams = new URLSearchParams(url.hash.substring(1));
  const accessToken = hashParams.get("access_token");
  const refreshToken = hashParams.get("refresh_token");

  if (!accessToken) throw new Error("No se recibió token de acceso");

  // Obtener datos del usuario
  const userRes = await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/user`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      apikey: CONFIG.SUPABASE_ANON_KEY,
    },
  });

  if (!userRes.ok) throw new Error("Error al obtener datos del usuario");
  const user = await userRes.json();

  // Persistir sesión
  await chrome.storage.local.set({
    [SESSION_KEY]: {
      access_token: accessToken,
      refresh_token: refreshToken,
      user_id: user.id,
      email: user.email,
      timestamp: Date.now(),
    },
  });

  return { ok: true, user };
}

async function handleLogout() {
  const { [SESSION_KEY]: session } = await chrome.storage.local.get(SESSION_KEY);
  if (session?.access_token) {
    try {
      await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/logout`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${session.access_token}`,
          apikey: CONFIG.SUPABASE_ANON_KEY,
        },
      });
    } catch (e) {
      // Ignorar errores de red al hacer logout
    }
  }
  await chrome.storage.local.remove(SESSION_KEY);
  return { ok: true };
}

async function getSession() {
  const { [SESSION_KEY]: session } = await chrome.storage.local.get(SESSION_KEY);
  if (!session?.access_token) return { ok: false, error: "No hay sesión" };

  // Verificar que el token sigue vigente
  const res = await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/user`, {
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      apikey: CONFIG.SUPABASE_ANON_KEY,
    },
  });

  if (!res.ok) {
    await chrome.storage.local.remove(SESSION_KEY);
    return { ok: false, error: "Sesión expirada" };
  }

  const user = await res.json();
  return { ok: true, user, session };
}
