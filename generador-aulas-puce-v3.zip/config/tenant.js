// ============================================================
// Configuración tenant para la extensión Chrome — PUCE Quito
// ============================================================
// Espejo de /config/tenant.js (raíz del repo). Mantener sincronizados.
// La extensión no usa ES modules, así que se expone como var global.
//
// Inclusión: en popup.html y otros entry points, agregar ANTES de los
// scripts que dependan de TENANT:
//   <script src="config/tenant.js"></script>
// ============================================================

window.TENANT = {
  id: 'puce-quito',

  university: {
    shortName: 'PUCE',
    fullName: 'Pontificia Universidad Católica del Ecuador',
    sedeName: 'PUCE Quito',
    sedeShort: 'Quito',
    moodleUrls: ['eva.puce.edu.ec'],
    // PUCE Quito usa rutas con prefijo de período (/QUI-202601R/course/...)
    // Los selectores del extension pueden necesitar ajuste al probarse.
    emailDomain: 'puce.edu.ec',
  },

  branding: {
    productName: 'Generador de Aulas Virtuales',
    sidebarSubtitle: 'PUCE Quito',
    footerCopyright: 'Generador de Aulas Virtuales — PUCE Quito',
  },
};
