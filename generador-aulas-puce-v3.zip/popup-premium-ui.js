// popup-premium-ui.js
// UI persistente (campanita, soporte, footer remoto, anuncio) replicada
// del popup principal para que la página premium se vea consistente.
//
// 100% aditivo: no modifica popup.js ni popup.html. Solo se carga desde
// popup-premium.html. Si algún fetch falla, el resto de la página sigue
// funcionando idéntica.

(function () {
  'use strict';

  // ============================================================
  // Helpers comunes
  // ============================================================
  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function decodeJwtSub(token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return payload.sub || null;
    } catch { return null; }
  }

  async function getStoredSession() {
    try {
      const stored = await new Promise((res) => chrome.storage.local.get('session', res));
      const s = stored?.session;
      if (!s?.access_token) return null;
      return { token: s.access_token, userId: decodeJwtSub(s.access_token) };
    } catch { return null; }
  }

  function authHeaders(token, extra) {
    return Object.assign({
      'apikey': CONFIG.SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${token}`,
    }, extra || {});
  }

  // ============================================================
  // FOOTER + ANUNCIO REMOTO (extension-info.json)
  // ============================================================
  (async function loadFooter() {
    try {
      const url = 'https://nexbyte.pro/extension-info.json?t=' + Math.floor(Date.now() / 60000);
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) return;
      const info = await res.json();

      if (info.announcement && typeof info.announcement === 'string' && info.announcement.trim()) {
        const ann = document.getElementById('ext-announcement');
        if (ann) {
          ann.textContent = info.announcement;
          ann.style.display = 'block';
          if (info.product_url) {
            ann.addEventListener('click', () => chrome.tabs.create({ url: info.product_url }));
          }
        }
      }

      const footer = document.getElementById('ext-credits-footer');
      const line1 = document.getElementById('ext-credits-line1');
      const line2 = document.getElementById('ext-credits-line2');
      const links = document.getElementById('ext-credits-links');
      if (!footer || !line1 || !line2 || !links) return;

      const company = info.company?.name || 'NEXBYTE';
      const author = info.author?.name || '';
      const role = info.author?.role || '';
      let version = '';
      try { version = chrome.runtime.getManifest().version; } catch (_) {}
      if (!version) version = info.version_visible || '';
      const productUrl = info.product_url || info.company?.url || 'https://nexbyte.pro';
      const supportUrl = info.support_url || 'https://nexbyte.pro';

      line1.textContent = `Generador de Aulas ${version ? 'v' + version : ''} · ${company}`.trim();
      line2.textContent = author ? `Por ${author}${role ? ' · ' + role : ''}` : '';

      const mkLink = (label, href) => {
        const a = document.createElement('a');
        a.textContent = label;
        a.href = href;
        a.style.color = '#1d4ed8';
        a.style.textDecoration = 'none';
        a.style.cursor = 'pointer';
        a.addEventListener('click', (e) => { e.preventDefault(); chrome.tabs.create({ url: href }); });
        return a;
      };
      links.innerHTML = '';
      links.appendChild(mkLink('Producto ↗', productUrl));
      if (supportUrl && supportUrl !== productUrl) {
        const sep = document.createElement('span');
        sep.textContent = '·';
        sep.style.color = '#9ca3af';
        links.appendChild(sep);
        links.appendChild(mkLink('Soporte ↗', supportUrl));
      }

      footer.style.display = 'block';
    } catch (_) { /* silencio */ }
  })();

  // ============================================================
  // CAMPANITA DE NOTIFICACIONES (notifications.json)
  // ============================================================
  // Filtra items por `audience` si está presente. Si no hay audience,
  // se muestra a todos (compatibilidad hacia atrás).
  async function getCurrentPlan() {
    try {
      if (typeof CONFIG === 'undefined' || !CONFIG.SUPABASE_URL) return null;
      const s = await getStoredSession();
      if (!s?.token || !s.userId) return null;
      const today = new Date().toISOString().split('T')[0];
      const url = `${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?user_id=eq.${s.userId}&status=eq.active&period_end=gte.${today}&select=plan_name&order=created_at.desc&limit=1`;
      const r = await fetch(url, { headers: authHeaders(s.token, { 'Accept': 'application/json' }) });
      if (!r.ok) return null;
      const rows = await r.json();
      return rows?.[0]?.plan_name || null;
    } catch { return null; }
  }

  (async function loadBell() {
    const STORAGE_KEY = 'gaula_notif_read_ids';
    const NOTIF_URL = 'https://nexbyte.pro/notifications.json?t=' + Math.floor(Date.now() / 60000);

    function getReadIds() {
      return new Promise((resolve) => {
        chrome.storage.local.get(STORAGE_KEY, (res) => {
          resolve(Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY] : []);
        });
      });
    }
    function setReadIds(ids) {
      return new Promise((resolve) => chrome.storage.local.set({ [STORAGE_KEY]: ids }, resolve));
    }
    function fmtDate(s) {
      try { return new Date(s).toLocaleDateString('es-EC', { day: '2-digit', month: 'short', year: 'numeric' }); }
      catch { return s || ''; }
    }

    let items = [];
    try {
      const res = await fetch(NOTIF_URL, { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      items = Array.isArray(data?.items) ? data.items : [];
    } catch { return; }

    // Filtro por audiencia: si el item tiene `audience` y el plan del
    // usuario NO está incluido, lo ocultamos. Sin audience → se muestra.
    const userPlan = await getCurrentPlan();
    if (userPlan) {
      items = items.filter((it) => {
        if (!Array.isArray(it.audience) || it.audience.length === 0) return true;
        return it.audience.includes(userPlan);
      });
    }

    if (items.length === 0) return;

    const navActions = document.querySelector('.nav-actions');
    if (!navActions) return;

    const wrap = document.createElement('div');
    wrap.id = 'notif-bell-wrap';
    wrap.style.cssText = 'position:relative;display:inline-flex;align-items:center';
    wrap.innerHTML = `
      <button id="notif-bell-btn" type="button" aria-label="Notificaciones" style="position:relative;background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.25);border-radius:50%;width:34px;height:34px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span id="notif-badge" style="display:none;position:absolute;top:-2px;right:-2px;background:#ef4444;color:#fff;font-size:10px;font-weight:700;line-height:1;padding:3px 5px;border-radius:10px;min-width:16px;text-align:center;border:2px solid #1e3a8a"></span>
      </button>
    `;
    navActions.insertBefore(wrap, navActions.firstChild);

    const btn = wrap.querySelector('#notif-bell-btn');
    const badge = wrap.querySelector('#notif-badge');
    const dropdown = document.getElementById('notif-dropdown');
    const list = document.getElementById('notif-list');
    const markAllBtn = document.getElementById('notif-mark-all');
    if (!btn || !badge || !dropdown || !list || !markAllBtn) return;

    let readIds = await getReadIds();

    function render() {
      const unread = items.filter((it) => it && it.id && !readIds.includes(it.id));
      if (unread.length > 0) {
        badge.textContent = unread.length > 9 ? '9+' : String(unread.length);
        badge.style.display = 'block';
      } else {
        badge.style.display = 'none';
      }
      const sorted = [...items].sort((a, b) => {
        const aRead = readIds.includes(a.id) ? 1 : 0;
        const bRead = readIds.includes(b.id) ? 1 : 0;
        if (aRead !== bRead) return aRead - bRead;
        return (b.date || '').localeCompare(a.date || '');
      });
      list.innerHTML = '';
      sorted.forEach((it) => {
        if (!it?.id) return;
        const isRead = readIds.includes(it.id);
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 12px;border-bottom:1px solid #f3f4f6;cursor:pointer;background:' + (isRead ? '#fff' : '#eff6ff') + ';transition:background 0.15s';
        item.onmouseenter = () => { item.style.background = '#f3f4f6'; };
        item.onmouseleave = () => { item.style.background = isRead ? '#fff' : '#eff6ff'; };

        const typeBadge = it.type === 'promo' ? '<span style="display:inline-block;font-size:9px;background:#fef3c7;color:#92400e;padding:1px 6px;border-radius:6px;margin-right:4px;text-transform:uppercase;letter-spacing:0.5px">Promo</span>'
          : it.type === 'release' ? '<span style="display:inline-block;font-size:9px;background:#dbeafe;color:#1e40af;padding:1px 6px;border-radius:6px;margin-right:4px;text-transform:uppercase;letter-spacing:0.5px">Versión</span>'
          : '';

        const titleEl = document.createElement('div');
        titleEl.style.cssText = 'font-size:13px;font-weight:600;color:#111827;margin-bottom:2px;display:flex;align-items:center;gap:4px';
        titleEl.innerHTML = (isRead ? '' : '<span style="display:inline-block;width:6px;height:6px;background:#1d4ed8;border-radius:50%;flex-shrink:0"></span>') +
          typeBadge + '<span>' + escapeHtml(it.title || '') + '</span>';

        const bodyEl = document.createElement('div');
        bodyEl.style.cssText = 'font-size:12px;color:#4b5563;line-height:1.4;margin-bottom:4px';
        bodyEl.textContent = it.body || '';

        const dateEl = document.createElement('div');
        dateEl.style.cssText = 'font-size:10px;color:#9ca3af';
        dateEl.textContent = fmtDate(it.date);

        item.appendChild(titleEl);
        item.appendChild(bodyEl);
        item.appendChild(dateEl);

        item.addEventListener('click', async () => {
          if (!isRead) {
            readIds = [...readIds, it.id];
            await setReadIds(readIds);
            render();
          }
          if (it.url) chrome.tabs.create({ url: it.url });
        });
        list.appendChild(item);
      });
    }

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = dropdown.style.display !== 'none' && dropdown.style.display !== '';
      dropdown.style.display = open ? 'none' : 'block';
    });

    document.addEventListener('click', (e) => {
      if (!wrap.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.style.display = 'none';
      }
    });

    markAllBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      readIds = items.map((it) => it.id).filter(Boolean);
      await setReadIds(readIds);
      render();
    });

    render();
  })();

  // ============================================================
  // CHAT DE SOPORTE
  // ============================================================
  (function initSupport() {
    let userId = null;
    let token = null;
    let pollIntervalId = null;
    let pendingImageBlob = null;
    let pendingImageName = null;
    let lastMessageCount = 0;
    let lastFingerprint = '';
    let clearedAtIso = null;
    const CLEARED_KEY = 'gaula_support_cleared_at';
    const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
    let panelHandlersSetup = false;

    async function ensureSession() {
      if (typeof CONFIG === 'undefined' || !CONFIG.SUPABASE_URL || !CONFIG.SUPABASE_ANON_KEY) return null;
      const s = await getStoredSession();
      if (!s?.token || !s.userId) return null;
      token = s.token;
      userId = s.userId;
      return { url: CONFIG.SUPABASE_URL, anonKey: CONFIG.SUPABASE_ANON_KEY, token };
    }

    function loadClearedAt() {
      return new Promise((resolve) => {
        chrome.storage.local.get(CLEARED_KEY, (res) => { clearedAtIso = res[CLEARED_KEY] || null; resolve(); });
      });
    }
    function saveClearedAt(iso) {
      return new Promise((resolve) => chrome.storage.local.set({ [CLEARED_KEY]: iso }, resolve));
    }

    async function dbSelect(ctx, table, query) {
      const r = await fetch(`${ctx.url}/rest/v1/${table}?${query}`, { headers: authHeaders(ctx.token, { 'Accept': 'application/json' }) });
      if (!r.ok) throw new Error(`SELECT ${table} ${r.status}`);
      return r.json();
    }
    async function dbCount(ctx, table, query) {
      const r = await fetch(`${ctx.url}/rest/v1/${table}?${query}&select=id`, {
        headers: authHeaders(ctx.token, { 'Accept': 'application/json', 'Prefer': 'count=exact', 'Range-Unit': 'items', 'Range': '0-0' }),
      });
      if (!r.ok) return 0;
      const range = r.headers.get('content-range') || '*/0';
      const total = parseInt(range.split('/')[1], 10);
      return Number.isFinite(total) ? total : 0;
    }
    async function dbInsert(ctx, table, row) {
      const r = await fetch(`${ctx.url}/rest/v1/${table}`, {
        method: 'POST',
        headers: authHeaders(ctx.token, { 'Content-Type': 'application/json', 'Prefer': 'return=representation' }),
        body: JSON.stringify(row),
      });
      if (!r.ok) {
        const txt = await r.text().catch(() => '');
        throw new Error(`INSERT ${table} ${r.status}: ${txt.slice(0, 200)}`);
      }
      return r.json();
    }
    async function dbPatch(ctx, table, query, patch) {
      const r = await fetch(`${ctx.url}/rest/v1/${table}?${query}`, {
        method: 'PATCH',
        headers: authHeaders(ctx.token, { 'Content-Type': 'application/json' }),
        body: JSON.stringify(patch),
      });
      if (!r.ok) throw new Error(`PATCH ${table} ${r.status}`);
    }
    async function storageUpload(ctx, bucket, path, blob) {
      const r = await fetch(`${ctx.url}/storage/v1/object/${bucket}/${encodeURIComponent(path).replace(/%2F/g, '/')}`, {
        method: 'POST',
        headers: authHeaders(ctx.token, { 'Content-Type': blob.type || 'application/octet-stream', 'x-upsert': 'false' }),
        body: blob,
      });
      if (!r.ok) {
        const txt = await r.text().catch(() => '');
        throw new Error(`UPLOAD ${r.status}: ${txt.slice(0, 200)}`);
      }
      return r.json().catch(() => ({}));
    }
    async function storageSign(ctx, bucket, path, expiresIn) {
      const r = await fetch(`${ctx.url}/storage/v1/object/sign/${bucket}/${encodeURIComponent(path).replace(/%2F/g, '/')}`, {
        method: 'POST',
        headers: authHeaders(ctx.token, { 'Content-Type': 'application/json' }),
        body: JSON.stringify({ expiresIn: expiresIn || 3600 }),
      });
      if (!r.ok) return null;
      const data = await r.json().catch(() => null);
      const signedPath = data?.signedURL || data?.signedUrl;
      if (!signedPath) return null;
      if (signedPath.startsWith('http')) return signedPath;
      if (signedPath.startsWith('/storage/v1')) return ctx.url + signedPath;
      return ctx.url + '/storage/v1' + (signedPath.startsWith('/') ? signedPath : '/' + signedPath);
    }

    function injectButton(ctx) {
      const navActions = document.querySelector('.nav-actions');
      if (!navActions || document.getElementById('support-bell-btn')) return;
      const wrap = document.createElement('div');
      wrap.id = 'support-bell-wrap';
      wrap.style.cssText = 'position:relative;display:inline-flex;align-items:center';
      wrap.innerHTML = `
        <button id="support-bell-btn" type="button" aria-label="Soporte" title="Soporte NEXBYTE" style="position:relative;background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.25);border-radius:50%;width:34px;height:34px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span id="support-badge" style="display:none;position:absolute;top:-2px;right:-2px;background:#ef4444;color:#fff;font-size:10px;font-weight:700;line-height:1;padding:3px 5px;border-radius:10px;min-width:16px;text-align:center;border:2px solid #1e3a8a"></span>
        </button>
      `;
      navActions.insertBefore(wrap, navActions.firstChild);
      document.getElementById('support-bell-btn').addEventListener('click', toggleSupportPanel);
    }

    async function refreshUnreadBadge() {
      const ctx = await ensureSession();
      if (!ctx) return;
      try {
        const count = await dbCount(ctx, 'support_messages',
          `user_id=eq.${userId}&sender=eq.admin&read_by_user=eq.false`);
        const badge = document.getElementById('support-badge');
        if (!badge) return;
        if (count > 0) {
          badge.textContent = count > 9 ? '9+' : String(count);
          badge.style.display = 'block';
        } else {
          badge.style.display = 'none';
        }
      } catch (e) { console.warn('[support] badge', e); }
    }

    async function loadMessages() {
      const ctx = await ensureSession();
      const list = document.getElementById('support-messages');
      if (!ctx || !list) return;
      if (clearedAtIso === null) await loadClearedAt();
      let data;
      try {
        const clearFilter = clearedAtIso ? `&created_at=gt.${encodeURIComponent(clearedAtIso)}` : '';
        data = await dbSelect(ctx, 'support_messages',
          `user_id=eq.${userId}${clearFilter}&order=created_at.asc&limit=200&select=id,sender,body,image_url,created_at,read_by_user`);
      } catch (e) {
        list.innerHTML = '<div style="color:#dc2626;text-align:center;padding:20px;font-size:12px">Error: ' + escapeHtml(e.message) + '</div>';
        return;
      }
      if (!data || data.length === 0) {
        const emptyMsg = clearedAtIso
          ? 'Conversación limpiada de tu vista.<br><span style="font-size:10px;opacity:0.7">El equipo de soporte sigue viendo el historial completo.</span>'
          : 'No hay mensajes todavía.<br>Escribe abajo para iniciar la conversación.';
        const fp = clearedAtIso ? 'empty-cleared' : 'empty';
        if (lastFingerprint !== fp) {
          list.innerHTML = '<div style="color:#6b7280;text-align:center;padding:30px 20px;font-size:12px">' + emptyMsg + '</div>';
          lastFingerprint = fp;
          lastMessageCount = 0;
        }
        return;
      }

      const fingerprint = data.map((m) => `${m.id}:${m.read_by_user ? 1 : 0}`).join('|');
      if (fingerprint === lastFingerprint) return;

      const wasAtBottom = (list.scrollTop + list.clientHeight) >= (list.scrollHeight - 50);
      const isNew = data.length > lastMessageCount;
      lastMessageCount = data.length;
      lastFingerprint = fingerprint;

      list.innerHTML = '';
      let lastDate = '';
      for (const m of data) {
        const date = new Date(m.created_at);
        const dayStr = date.toLocaleDateString('es-EC', { day: 'numeric', month: 'short' });
        if (dayStr !== lastDate) {
          const sep = document.createElement('div');
          sep.style.cssText = 'text-align:center;margin:8px 0;font-size:10px;color:#9ca3af';
          sep.textContent = dayStr;
          list.appendChild(sep);
          lastDate = dayStr;
        }
        const isUser = m.sender === 'user';
        const bubble = document.createElement('div');
        bubble.style.cssText = 'display:flex;margin:4px 0;' + (isUser ? 'justify-content:flex-end' : 'justify-content:flex-start');
        const inner = document.createElement('div');
        inner.style.cssText = 'max-width:78%;padding:6px 10px;border-radius:12px;font-size:12px;line-height:1.4;' +
          (isUser ? 'background:#1d4ed8;color:#fff;border-bottom-right-radius:4px' : 'background:#fff;color:#111827;border:1px solid #e5e7eb;border-bottom-left-radius:4px');
        if (m.body) {
          const txt = document.createElement('div');
          txt.textContent = m.body;
          inner.appendChild(txt);
        }
        if (m.image_url) {
          const signedUrl = await storageSign(ctx, 'support-images', m.image_url, 3600);
          if (signedUrl) {
            const img = document.createElement('img');
            img.src = signedUrl;
            img.style.cssText = 'max-width:100%;border-radius:6px;margin-top:4px;cursor:pointer';
            img.addEventListener('click', () => chrome.tabs.create({ url: signedUrl }));
            inner.appendChild(img);
          }
        }
        const time = document.createElement('div');
        time.style.cssText = 'font-size:9px;opacity:0.7;margin-top:2px;text-align:right';
        time.textContent = date.toLocaleTimeString('es-EC', { hour: '2-digit', minute: '2-digit' });
        inner.appendChild(time);
        bubble.appendChild(inner);
        list.appendChild(bubble);
      }
      if (isNew || wasAtBottom) list.scrollTop = list.scrollHeight;

      const unreadAdminIds = data.filter((m) => m.sender === 'admin' && !m.read_by_user).map((m) => m.id);
      if (unreadAdminIds.length > 0) {
        try {
          await dbPatch(ctx, 'support_messages', `id=in.(${unreadAdminIds.join(',')})`, { read_by_user: true });
          refreshUnreadBadge();
        } catch (e) { console.warn('[support] mark-read', e); }
      }
    }

    async function uploadImage(ctx, blob) {
      const ext = (blob.type || 'image/png').split('/')[1] || 'png';
      const path = `${userId}/${Date.now()}.${ext}`;
      try {
        await storageUpload(ctx, 'support-images', path, blob);
        return path;
      } catch (e) {
        showChatError('Upload imagen: ' + e.message);
        return null;
      }
    }

    function showChatError(msg) {
      const list = document.getElementById('support-messages');
      if (!list) return;
      const err = document.createElement('div');
      err.style.cssText = 'background:#fee2e2;color:#991b1b;padding:8px 10px;margin:6px 0;border-radius:6px;font-size:11px;border:1px solid #fca5a5';
      err.textContent = '⚠ ' + msg;
      list.appendChild(err);
      list.scrollTop = list.scrollHeight;
    }

    async function sendMessageNow(body, imageBlob) {
      const ctx = await ensureSession();
      if (!ctx) {
        showChatError('No hay sesión activa. Inicia sesión en la extensión y recarga esta página.');
        return false;
      }
      let image_url = null;
      if (imageBlob) {
        image_url = await uploadImage(ctx, imageBlob);
        if (!image_url) return false;
      }
      try {
        await dbInsert(ctx, 'support_messages', { user_id: userId, sender: 'user', body: body || null, image_url });
        return true;
      } catch (e) {
        showChatError('Error enviando: ' + e.message);
        return false;
      }
    }

    function clearPendingImage() {
      pendingImageBlob = null;
      pendingImageName = null;
      const preview = document.getElementById('support-image-preview');
      if (preview) preview.style.display = 'none';
    }
    function showPendingImage(blob, name) {
      pendingImageBlob = blob;
      pendingImageName = name || 'imagen.png';
      const preview = document.getElementById('support-image-preview');
      const nameEl = document.getElementById('support-image-name');
      if (preview && nameEl) {
        nameEl.textContent = pendingImageName + ' (' + Math.round(blob.size / 1024) + ' KB)';
        preview.style.display = 'flex';
      }
    }

    function startPolling() { if (!pollIntervalId) pollIntervalId = setInterval(loadMessages, 5000); }
    function stopPolling() { if (pollIntervalId) { clearInterval(pollIntervalId); pollIntervalId = null; } }

    async function toggleSupportPanel() {
      const panel = document.getElementById('support-panel');
      if (!panel) return;
      const isOpen = panel.style.display === 'flex';
      if (isOpen) {
        panel.style.display = 'none';
        stopPolling();
      } else {
        panel.style.display = 'flex';
        await loadMessages();
        startPolling();
        document.getElementById('support-input')?.focus();
      }
    }

    function setupPanelHandlers() {
      if (panelHandlersSetup) return;
      const closeBtn = document.getElementById('support-close');
      const clearBtn = document.getElementById('support-clear');
      const form = document.getElementById('support-form');
      const input = document.getElementById('support-input');
      const removeImgBtn = document.getElementById('support-image-remove');
      if (!closeBtn || !form || !input || !removeImgBtn) return;
      panelHandlersSetup = true;

      closeBtn.addEventListener('click', () => {
        document.getElementById('support-panel').style.display = 'none';
        stopPolling();
      });

      if (clearBtn) {
        clearBtn.addEventListener('click', async () => {
          if (!confirm('¿Limpiar tu vista de la conversación?\n\nEl equipo de soporte sigue viendo el historial completo.')) return;
          const now = new Date().toISOString();
          await saveClearedAt(now);
          clearedAtIso = now;
          lastMessageCount = 0;
          lastFingerprint = '';
          await loadMessages();
        });
      }

      removeImgBtn.addEventListener('click', clearPendingImage);

      input.addEventListener('paste', (e) => {
        const items = e.clipboardData?.items || [];
        for (const item of items) {
          if (item.type && item.type.indexOf('image') === 0) {
            const blob = item.getAsFile();
            if (blob) {
              if (blob.size > MAX_IMAGE_BYTES) {
                showChatError(`Imagen muy grande (${Math.round(blob.size / 1024 / 1024)} MB). Máximo: 5 MB.`);
                e.preventDefault();
                return;
              }
              showPendingImage(blob, blob.name || 'pegada.png');
              e.preventDefault();
              return;
            }
          }
        }
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          form.dispatchEvent(new Event('submit', { cancelable: true }));
        }
      });

      let submitting = false;
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (submitting) return;
        const text = input.value.trim();
        if (!text && !pendingImageBlob) return;
        submitting = true;
        const sendBtn = document.getElementById('support-send');
        sendBtn.disabled = true;
        sendBtn.textContent = '...';
        const ok = await sendMessageNow(text, pendingImageBlob);
        sendBtn.disabled = false;
        sendBtn.textContent = 'Enviar';
        submitting = false;
        if (ok) {
          input.value = '';
          clearPendingImage();
          await loadMessages();
        }
      });
    }

    // Init: requiere sesión activa para mostrar el botón de soporte
    (async () => {
      const ctx = await ensureSession();
      if (!ctx) return;  // sin sesión, no inyectamos el botón
      injectButton(ctx);
      setupPanelHandlers();
      await refreshUnreadBadge();
    })();
  })();
})();
