// ============================================================
// Background Service Worker — Auth, comunicación y ejecución
// Bug #5: Token TTL — refresh proactivo antes de expirar
// Bug #9: Retry logic con CONFIG.MAX_RETRIES
// ============================================================

importScripts('config.js');
importScripts('background-replicate.js');

// Lista de content scripts en el orden de carga del manifest (moodle-utils
// primero porque los demás dependen de sus helpers).
const GAULA_CONTENT_SCRIPTS = [
  'content-scripts/moodle-utils.js',
  'content-scripts/executor.js',
  'content-scripts/template-import.js',
  'content-scripts/resource-upload.js',
  'content-scripts/section-editor.js',
  'content-scripts/assignment-creator.js',
  'content-scripts/quiz-generator.js',
  'content-scripts/banner-editor.js',
  'content-scripts/forum-creator.js',
];

// Detecta los errores de "Content script no cargado en la pestaña" que ocurren
// típicamente después de reload de la extensión sin reabrir las pestañas Moodle.
function gaulaIsNoReceiverError(msg) {
  return /Could not establish connection|Receiving end does not exist|message channel closed/i.test(String(msg || ''));
}

// Inyecta todos los content scripts en una pestaña. Idempotente: re-ejecutar los
// IIFEs es seguro (los handlers se sobreescriben en gaulaHandlers, los listeners
// son extras pero Chrome solo procesa la primera sendResponse).
async function gaulaInjectContentScripts(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: GAULA_CONTENT_SCRIPTS,
    });
    return true;
  } catch (e) {
    console.warn('[GAULA] No se pudo inyectar content scripts en tab', tabId, ':', e.message);
    return false;
  }
}

// Envía un mensaje a content script. Si falla porque el script no está cargado
// (típico tras reload de extensión), auto-inyecta y reintenta una vez.
async function gaulaSendToTabResilient(tabId, message) {
  const sendOnce = () => new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (resp) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(resp);
    });
  });
  try {
    return await sendOnce();
  } catch (e) {
    if (!gaulaIsNoReceiverError(e.message)) throw e;
    console.log('[GAULA] Content script no responde — auto-inyectando en tab', tabId);
    const ok = await gaulaInjectContentScripts(tabId);
    if (!ok) throw e;
    // Margen para que los IIFE se asienten antes del retry
    await new Promise(r => setTimeout(r, 250));
    return await sendOnce();
  }
}

// Bug #9: Helper de retry para llamadas de red
async function gaulaFetchWithRetry(url, options, retries = CONFIG.MAX_RETRIES) {
  let lastRes;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, options);
      if (res.ok || res.status < 500) return res;
      lastRes = res;
      if (attempt < retries) await new Promise(r => setTimeout(r, CONFIG.RETRY_DELAY));
    } catch (err) {
      if (attempt >= retries) throw err;
      await new Promise(r => setTimeout(r, CONFIG.RETRY_DELAY));
    }
  }
  return lastRes; // Devolver última respuesta en vez de undefined
}

// Escuchar mensajes del popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'LOGIN_GOOGLE') {
    handleGoogleLogin().then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  if (msg.type === 'LOGOUT') {
    handleLogout().then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  if (msg.type === 'GET_SESSION') {
    getSession().then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Replicar nota de tarea: SW-only para sobrevivir a recargas de la pestaña
  // que Moodle dispara al cambiar cmidnumber.
  if (msg.type === 'REPLICATE_TASK_GRADE') {
    bgReplicateTaskGrade(msg.payload).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Solicitar script al backend, verificar créditos, y enviarlo al content script
  if (msg.type === 'EXECUTE_ACTION') {
    executeAction(msg.action, msg.payload, msg.tabId).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Llamar a generate-content desde el background (evita problemas de CORS/token en popup)
  if (msg.type === 'GENERATE_CONTENT') {
    handleGenerateContent(msg.action, msg.payload).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Reenviar mensajes al content script de la pestaña activa
  if (msg.type === 'SEND_TO_TAB') {
    sendToActiveTab(msg.message).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Navegar la pestaña a la sección target Y luego enviar el mensaje al
  // content script. Necesario en Quito format-onetopic donde el popup muere
  // cuando chrome.tabs.update transfiere el foco a la pestaña. El service
  // worker NO muere, así que la cadena navigate→dispatch se completa.
  if (msg.type === 'NAVIGATE_AND_DISPATCH') {
    handleNavigateAndDispatch(msg).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  // Navegar la pestaña del sender sin disparar el dialog beforeunload del
  // form dirty checker de Moodle. chrome.tabs.update con loadReplace=true
  // navega como una "address bar entry" y bypasses confirmation prompts en
  // la mayoría de casos (es action externa, no usuario clickeando link).
  if (msg.type === 'NAVIGATE_TAB_SILENT' && sender.tab && sender.tab.id) {
    chrome.tabs.update(sender.tab.id, { url: msg.url, loadReplace: true })
      .then(() => sendResponse({ ok: true }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});

async function handleNavigateAndDispatch({ tabId, targetUrl, message }) {
  // 1. Navegar la pestaña
  await chrome.tabs.update(tabId, { url: targetUrl });

  // 2. Esperar a que la pestaña termine de cargar
  await new Promise((resolve) => {
    const listener = (tid, info) => {
      if (tid === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        // Margen para que el content script (document_idle) se monte
        setTimeout(resolve, 900);
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });

  // 3. Enviar mensaje (con auto-inyección si el content script falta)
  try {
    const resp = await gaulaSendToTabResilient(tabId, message);
    return resp && resp.ok ? resp : (resp || { ok: false, error: 'Sin respuesta del content script' });
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ============================================================
// AUTH
// ============================================================

async function handleGoogleLogin() {
  const redirectUrl = chrome.identity.getRedirectURL('callback');
  const authUrl = `${CONFIG.SUPABASE_URL}/auth/v1/authorize?provider=google&redirect_to=${encodeURIComponent(redirectUrl)}`;

  const responseUrl = await chrome.identity.launchWebAuthFlow({
    url: authUrl,
    interactive: true,
  });

  const url = new URL(responseUrl);
  const hashParams = new URLSearchParams(url.hash.substring(1));
  const accessToken = hashParams.get('access_token');
  const refreshToken = hashParams.get('refresh_token');

  if (!accessToken) throw new Error('No se recibió token de acceso');

  await chrome.storage.local.set({
    session: { access_token: accessToken, refresh_token: refreshToken, timestamp: Date.now() }
  });

  const userRes = await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/user`, {
    headers: { 'Authorization': `Bearer ${accessToken}`, 'apikey': CONFIG.SUPABASE_ANON_KEY }
  });
  const user = await userRes.json();
  return { ok: true, user };
}

async function handleLogout() {
  const { session } = await chrome.storage.local.get('session');
  if (session?.access_token) {
    await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/logout`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${session.access_token}`, 'apikey': CONFIG.SUPABASE_ANON_KEY }
    }).catch(() => {});
  }
  await chrome.storage.local.remove('session');
  return { ok: true };
}

async function getSession() {
  const { session } = await chrome.storage.local.get('session');
  if (!session?.access_token) return { ok: false, error: 'No hay sesión' };

  // Bug #5: Refresh proactivo — si el token tiene más de 50 min, refrescar antes de que expire (JWT dura ~1h)
  const TOKEN_TTL = 50 * 60 * 1000; // 50 minutos
  const tokenAge = Date.now() - (session.timestamp || 0);
  if (tokenAge > TOKEN_TTL && session.refresh_token) {
    const refreshRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': CONFIG.SUPABASE_ANON_KEY },
      body: JSON.stringify({ refresh_token: session.refresh_token }),
    });
    if (refreshRes.ok) {
      const data = await refreshRes.json();
      await chrome.storage.local.set({
        session: { access_token: data.access_token, refresh_token: data.refresh_token, timestamp: Date.now() }
      });
      return { ok: true, user: data.user, token: data.access_token };
    }
  }

  // Bug #9: Usar fetch con retry
  const userRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/user`, {
    headers: { 'Authorization': `Bearer ${session.access_token}`, 'apikey': CONFIG.SUPABASE_ANON_KEY }
  });

  if (!userRes.ok) {
    if (session.refresh_token) {
      const refreshRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': CONFIG.SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: session.refresh_token }),
      });
      if (refreshRes.ok) {
        const data = await refreshRes.json();
        await chrome.storage.local.set({
          session: { access_token: data.access_token, refresh_token: data.refresh_token, timestamp: Date.now() }
        });
        return { ok: true, user: data.user, token: data.access_token };
      }
    }
    await chrome.storage.local.remove('session');
    return { ok: false, error: 'Sesión expirada' };
  }

  const user = await userRes.json();
  return { ok: true, user, token: session.access_token };
}

// ============================================================
// EJECUTAR ACCIONES
// ============================================================

async function executeAction(action, payload, tabId) {
  // 1. Obtener sesión
  let session = await getSession();
  if (!session.ok) return { ok: false, error: 'Debes iniciar sesión' };

  // 2. Llamar al backend: verificar suscripción y consumir créditos
  // Bug #9: Retry para edge function
  async function callEdgeFunction(token) {
    return gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/functions/v1/execute-action`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'apikey': CONFIG.SUPABASE_ANON_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action, payload }),
    });
  }

  let res = await callEdgeFunction(session.token);

  // Si devuelve 401, forzar refresh del token y reintentar una vez
  if (res.status === 401) {
    const { session: stored } = await chrome.storage.local.get('session');
    if (stored?.refresh_token) {
      const refreshRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': CONFIG.SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: stored.refresh_token }),
      });
      if (refreshRes.ok) {
        const data = await refreshRes.json();
        await chrome.storage.local.set({
          session: { access_token: data.access_token, refresh_token: data.refresh_token, timestamp: Date.now() }
        });
        res = await callEdgeFunction(data.access_token);
      }
    }
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const msg = err.error || err.message || `Error ${res.status}`;
    return { ok: false, error: `${msg} (${action})` };
  }

  const data = await res.json();
  if (!data.ok) return data;

  // 3. Los scripts de acción están bundleados en la extensión (CSP de Moodle
  //    bloquea new Function/eval). El popup guarda el estado directamente
  //    en gaula_content_state y navega la pestaña. Los content scripts
  //    detectan el estado al cargar y ejecutan la acción correspondiente.

  return {
    ok: true,
    uses_remaining: data.uses_remaining,
    uses_total: data.uses_total,
  };
}

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

async function sendToActiveTab(message) {
  const tabId = await getActiveTabId();
  if (!tabId) return { ok: false, error: 'No hay pestaña activa' };
  try {
    return await gaulaSendToTabResilient(tabId, message);
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Proxy para generate-content — usa el token fresco del background
async function handleGenerateContent(action, payload) {
  let session = await getSession();
  if (!session.ok) throw new Error('Debes iniciar sesión');

  let res = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/functions/v1/generate-content`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${session.token}`,
      'apikey': CONFIG.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ action, ...payload }),
  });

  // Si 401, forzar refresh y reintentar
  if (res.status === 401) {
    const { session: stored } = await chrome.storage.local.get('session');
    if (stored?.refresh_token) {
      const refreshRes = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': CONFIG.SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: stored.refresh_token }),
      });
      if (refreshRes.ok) {
        const data = await refreshRes.json();
        await chrome.storage.local.set({
          session: { access_token: data.access_token, refresh_token: data.refresh_token, timestamp: Date.now() }
        });
        res = await gaulaFetchWithRetry(`${CONFIG.SUPABASE_URL}/functions/v1/generate-content`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${data.access_token}`,
            'apikey': CONFIG.SUPABASE_ANON_KEY,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ action, ...payload }),
        });
      }
    }
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Error ${res.status}`);
  }

  return res.json();
}
