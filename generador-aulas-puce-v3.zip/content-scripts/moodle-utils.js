/**
 * GeneradorAulas 3.0 - Utilidades compartidas para Moodle DOM.
 * Fixes aplicados:
 * - Bug #1: gaulaSaveState siempre retorna Promise (await obligatorio)
 * - Bug #3: Lock de operación para evitar concurrencia
 * - Bug #8: Timeout configurable (CONFIG.ELEMENT_TIMEOUT)
 * - Bug #11: saveFormState con debounce
 * - Bug #14: Logs persistentes de errores
 * - Bug #15: Limpieza de estados huérfanos
 */

window.__gaulaStopFlag = false;

// ============================================================
// Bug #3: Lock de operación — previene ejecuciones concurrentes
// ============================================================
const GAULA_LOCK_KEY = 'gaula_operation_lock';

async function gaulaAcquireLock(operationName) {
  const { [GAULA_LOCK_KEY]: lock } = await chrome.storage.local.get(GAULA_LOCK_KEY);
  // Si hay un lock activo de menos de 5 minutos, rechazar
  if (lock && lock.active && (Date.now() - lock.ts) < 300000) {
    throw new Error(`Operación "${lock.operation}" en progreso. Espera a que termine.`);
  }
  await chrome.storage.local.set({
    [GAULA_LOCK_KEY]: { active: true, operation: operationName, ts: Date.now() }
  });
}

async function gaulaReleaseLock() {
  await chrome.storage.local.remove(GAULA_LOCK_KEY);
}

// Auto-liberar lock cuando se limpia el estado
const _originalClearState = typeof gaulaClearState === 'function' ? gaulaClearState : null;

// ============================================================
// Bug #15: Limpieza de estados huérfanos al cargar
// ============================================================
(async function gaulaCleanOrphanState() {
  const state = await new Promise(resolve => {
    chrome.storage.local.get('gaula_content_state', result => {
      resolve(result.gaula_content_state || null);
    });
  });
  if (!state) return;

  // Si el estado tiene más de 10 minutos sin actualización, es huérfano
  const stateAge = Date.now() - (state.ts || 0);
  if (stateAge > 600000) { // 10 minutos
    console.warn('[GAULA 3.0] Limpiando estado huérfano:', state.action, state.step);
    chrome.storage.local.remove('gaula_content_state');
    chrome.storage.local.remove(GAULA_LOCK_KEY);
    // Limpiar archivos huérfanos
    chrome.storage.local.get(null, (all) => {
      const orphanKeys = Object.keys(all).filter(k => k.startsWith('gaula_file_'));
      if (orphanKeys.length > 0) chrome.storage.local.remove(orphanKeys);
    });
  }
})();

// ============================================================
// Utilidades base
// ============================================================

function gaulaWait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function gaulaCheckStop() { if (window.__gaulaStopFlag) throw new Error('STOPPED'); }

// Construye un URL absoluto a /course/edit.php?id=X preservando el prefijo
// del path Moodle (en Quito: /QUI-202601R). Deriva el base path desde la URL
// actual en lugar de depender de M.cfg.wwwroot, que puede no estar cargado
// cuando el content script corre.
function gaulaCourseEditUrl(courseId) {
  const path = window.location.pathname || '';
  // Match /<prefix>/course/(view|edit|...)
  const m = path.match(/^(.*?)\/course\/[a-z]+\.php/i);
  const base = m ? m[1] : '';
  return `${window.location.origin}${base}/course/edit.php?id=${encodeURIComponent(courseId)}`;
}

// Bug #8: Timeout configurable desde CONFIG (default 20s en vez de 10s)
function gaulaWaitForElement(selector, timeout, parent = document) {
  timeout = timeout || (typeof CONFIG !== 'undefined' ? CONFIG.ELEMENT_TIMEOUT : 20000);
  return new Promise((resolve, reject) => {
    const el = parent.querySelector(selector);
    if (el) return resolve(el);
    const observer = new MutationObserver(() => {
      const el = parent.querySelector(selector);
      if (el) { observer.disconnect(); resolve(el); }
    });
    observer.observe(parent, { childList: true, subtree: true });
    setTimeout(() => { observer.disconnect(); reject(new Error(`Timeout esperando: ${selector}`)); }, timeout);
  });
}

function gaulaClick(element) {
  element.scrollIntoView({ behavior: 'instant', block: 'center' });
  element.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
  element.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
  element.click();
}

function gaulaSetValue(element, value) {
  element.focus(); element.value = value;
  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
  element.dispatchEvent(new Event('blur', { bubbles: true }));
}

function gaulaSetSelect(element, value) {
  element.value = value;
  element.dispatchEvent(new Event('change', { bubbles: true }));
}

function gaulaSetEditor(editorId, htmlContent) {
  if (typeof tinymce !== 'undefined') {
    const editor = tinymce.get(editorId);
    if (editor) { editor.setContent(htmlContent); editor.fire('change'); return true; }
  }
  const attoEditor = document.querySelector(`[data-fieldtype="editor"] .editor_atto_content[contenteditable="true"]`);
  if (attoEditor) { attoEditor.innerHTML = htmlContent; attoEditor.dispatchEvent(new Event('input', { bubbles: true })); return true; }
  const textarea = document.getElementById(editorId);
  if (textarea) { textarea.value = htmlContent; textarea.dispatchEvent(new Event('change', { bubbles: true })); return true; }
  return false;
}

function gaulaUploadFile(fileInput, file) {
  const dt = new DataTransfer(); dt.items.add(file);
  fileInput.files = dt.files;
  fileInput.dispatchEvent(new Event('change', { bubbles: true }));
}

function gaulaByRole(role, name, opts = {}) {
  const parent = opts.parent || document;
  const exact = opts.exact || false;
  const roleToSelector = {
    button: 'button, input[type="button"], input[type="submit"], [role="button"]',
    link: 'a, [role="link"]',
    textbox: 'input[type="text"], input[type="password"], input[type="email"], input[type="url"], input[type="number"], input[type="search"], textarea, [contenteditable="true"], [role="textbox"]',
    menuitem: '[role="menuitem"], .dropdown-item',
    checkbox: 'input[type="checkbox"]',
    option: 'option',
    group: 'fieldset, [role="group"]',
    cell: 'td, th, [role="cell"], [role="gridcell"]',
    searchbox: 'input[type="search"], [role="searchbox"]',
  };
  const selector = roleToSelector[role] || `[role="${role}"]`;
  const elements = [...parent.querySelectorAll(selector)];
  return elements.find(el => {
    const text = (el.textContent || '').trim();
    const ariaLabel = el.getAttribute('aria-label') || '';
    const attrName = el.getAttribute('name') || '';
    const title = el.getAttribute('title') || '';
    const value = el.getAttribute('value') || '';
    let labelText = '';
    const elId = el.id;
    if (elId) { const assocLabel = parent.querySelector(`label[for="${elId}"]`); if (assocLabel) labelText = assocLabel.textContent.trim(); }
    if (!labelText) { const parentLabel = el.closest('label'); if (parentLabel) labelText = parentLabel.textContent.trim(); }
    const combined = `${text} ${ariaLabel} ${attrName} ${title} ${value} ${labelText}`;
    if (exact) return text === name || ariaLabel === name || labelText === name;
    return combined.toLowerCase().includes(name.toLowerCase());
  });
}

function gaulaByLabel(labelText, opts = {}) {
  const parent = opts.parent || document;
  const exact = opts.exact || false;
  const labels = [...parent.querySelectorAll('label')];
  const label = labels.find(l => { const t = l.textContent.trim(); return exact ? t === labelText : t.toLowerCase().includes(labelText.toLowerCase()); });
  if (label) { const forId = label.getAttribute('for'); if (forId) return parent.querySelector(`#${forId}`); return label.querySelector('input, select, textarea'); }
  return parent.querySelector(`[aria-label*="${labelText}"]`);
}

function gaulaByText(text, tag = '*', parent = document) {
  const elements = [...parent.querySelectorAll(tag)];
  return elements.find(el => el.textContent.trim().includes(text));
}

// Bug #8: Timeout configurable
async function gaulaWaitForRole(role, name, opts = {}) {
  const timeout = opts.timeout || (typeof CONFIG !== 'undefined' ? CONFIG.ELEMENT_TIMEOUT : 20000);
  const interval = 300; const maxAttempts = Math.ceil(timeout / interval);
  for (let i = 0; i < maxAttempts; i++) { const el = gaulaByRole(role, name, opts); if (el) return el; await gaulaWait(interval); }
  throw new Error(`Timeout esperando ${role}: "${name}"`);
}

async function gaulaWaitForLabel(labelText, opts = {}) {
  const timeout = opts.timeout || (typeof CONFIG !== 'undefined' ? CONFIG.ELEMENT_TIMEOUT : 20000);
  const interval = 300; const maxAttempts = Math.ceil(timeout / interval);
  for (let i = 0; i < maxAttempts; i++) { const el = gaulaByLabel(labelText, opts); if (el) return el; await gaulaWait(interval); }
  throw new Error(`Timeout esperando label: "${labelText}"`);
}

async function gaulaEnableEditing() {
  const editSwitch = document.querySelector('[id$="-editingswitch"]');
  if (editSwitch && !editSwitch.checked) { gaulaClick(editSwitch); await gaulaWait(1500); }
}

async function gaulaOpenActivityChooser(sectionIndex) {
  const section = document.querySelector(`#coursecontentcollapse${sectionIndex}`);
  if (!section) throw new Error(`Seccion ${sectionIndex} no encontrada`);
  // Selector estable de Moodle 4.x (independiente de i18n): data-action="open-chooser".
  // Fallbacks de texto para builds antiguos / temas custom: "Añadir..." (Moodle es), "Crear..." (PUCESE custom).
  const addBtn = section.querySelector('button[data-action="open-chooser"]')
              || gaulaByRole('button', 'Añadir una actividad o un recurso', { parent: section })
              || gaulaByRole('button', 'Crear una Actividad o Recurso', { parent: section });
  if (!addBtn) throw new Error('Boton para abrir el selector de actividad/recurso no encontrado');
  gaulaClick(addBtn); await gaulaWait(1000);
}

async function gaulaSearchAndClickActivity(searchTerm, linkName) {
  linkName = linkName || searchTerm;
  const searchInput = gaulaByRole('textbox', 'Buscar actividades por nombre') || document.querySelector('input[id^="searchinput"]') || document.querySelector('input[role="searchbox"]');
  if (!searchInput) throw new Error('No se encontró la barra de búsqueda del selector de actividades');
  searchInput.value = ''; searchInput.focus();
  gaulaSetValue(searchInput, searchTerm);
  searchInput.dispatchEvent(new Event('input', { bubbles: true }));
  await gaulaWait(1000);
  const allOptions = document.querySelectorAll('a[data-action="add-chooser-option"]');
  const activityLink = [...allOptions].find(a => { const nameEl = a.querySelector('.optionname'); return nameEl && nameEl.textContent.trim().toLowerCase().includes(linkName.toLowerCase()); });
  if (!activityLink) throw new Error(`No se encontró la actividad "${linkName}" en el selector`);
  gaulaClick(activityLink);
}

// Bug #1: gaulaSaveState SIEMPRE retorna Promise y agrega timestamp
function gaulaSaveState(state) {
  state.ts = Date.now(); // Timestamp para detección de huérfanos (Bug #15)
  return chrome.storage.local.set({ gaula_content_state: state });
}

function gaulaGetState() { return new Promise(resolve => { chrome.storage.local.get('gaula_content_state', result => { resolve(result.gaula_content_state || null); }); }); }

// Bug #3: gaulaClearState también libera el lock
function gaulaClearState() {
  chrome.storage.local.remove('gaula_content_state');
  chrome.storage.local.remove(GAULA_LOCK_KEY);
}

// Auto-detectar tipo de aula leyendo las secciones del DOM
function gaulaDetectCourseType() {
  const rdaPattern = /^RDA\s+\d+$/i;
  const elements = document.querySelectorAll('a, h3, h4, .sectionname, [data-for="section_title"], .inplaceeditable');
  for (const el of elements) {
    const t = el.textContent.trim();
    if (rdaPattern.test(t)) return 'repotenciada';
    if (t === 'RECURSOS' || t === 'PRODUCTOS Y ACTIVIDADES') return 'repotenciada';
  }
  const allText = document.body?.innerText || '';
  if (/\bRDA\s+\d+\b/i.test(allText)) return 'repotenciada';
  if (/\bRECURSOS\b/.test(allText) || /\bPRODUCTOS Y ACTIVIDADES\b/.test(allText)) return 'repotenciada';
  return 'normal';
}

// Fallbacks inteligentes según tipo de recurso
function gaulaFindFallbackSection(targetName, resourceType) {
  const key = targetName.toLowerCase();
  const t = (resourceType || '').toLowerCase();
  if (key === 'recursos') {
    if (t === 'video' || t === 'geneally') return ['recursos opcionales', 'recursos principales'];
    if (t === 'pdf' || t === 'ppt') return ['recursos principales', 'recursos opcionales'];
    return ['recursos principales', 'recursos opcionales'];
  }
  if (key === 'productos y actividades') {
    if (t === 'quiz') return ['evaluacion [bg-etiqueta', 'actividades'];
    if (t === 'assignment') return ['actividades'];
    return ['actividades', 'evaluacion [bg-etiqueta'];
  }
  if (key === 'recursos principales' || key === 'recursos opcionales') return ['recursos'];
  if (key === 'actividades') return ['productos y actividades'];
  if (key.startsWith('evaluacion')) return ['productos y actividades', 'actividades'];
  return [];
}

function gaulaDismissMoveModal() {
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
  const modal = document.querySelector('.modal.show, .modal[style*="display: block"]');
  if (modal) {
    const closeBtn = modal.querySelector('button.close, [data-dismiss="modal"], [data-action="hide"]');
    if (closeBtn) gaulaClick(closeBtn); else modal.style.display = 'none';
  }
  const backdrop = document.querySelector('.modal-backdrop');
  if (backdrop) backdrop.remove();
}

function gaulaSectionMatch(linkText, target) {
  const lt = linkText.replace(/[\u00A0\s]+/g, ' ').trim().toLowerCase();
  const t = target.toLowerCase();
  if (lt === t) return true;
  if (lt.includes(t)) return true;
  return false;
}

function gaulaFindTargetLink(targetSectionName, sectionIndex) {
  const allTargetLinks = [...document.querySelectorAll('a')].filter(a =>
    gaulaSectionMatch(a.textContent, targetSectionName) && a.offsetParent !== null
  );
  console.log('[GAULA] findTargetLink: target="' + targetSectionName + '", secIdx=' + sectionIndex + ', matches=' + allTargetLinks.length);
  let targetLink = null;
  if (allTargetLinks.length > 1 && sectionIndex != null) {
    const cleanText = t => t.replace(/[\u00A0\s]+/g, ' ').trim();
    const sectionHeaders = [...document.querySelectorAll('a')].filter(a =>
      a.offsetParent !== null &&
      new RegExp(`^(RDA|Tema)\\s+${sectionIndex}$`, 'i').test(cleanText(a.textContent))
    );
    if (sectionHeaders.length > 0) {
      const sectionHeader = sectionHeaders[0];
      const allLinks = [...document.querySelectorAll('a')];
      const headerIdx = allLinks.indexOf(sectionHeader);
      const nextHeaderIdx = allLinks.findIndex((a, i) => i > headerIdx && a.offsetParent !== null && /^(RDA|Tema)\s+\d+$/i.test(a.textContent.trim()));
      const endIdx = nextHeaderIdx > 0 ? nextHeaderIdx : allLinks.length;
      for (let i = headerIdx + 1; i < endIdx; i++) {
        if (gaulaSectionMatch(allLinks[i].textContent, targetSectionName) && allLinks[i].offsetParent !== null) {
          targetLink = allLinks[i]; break;
        }
      }
    }
    if (!targetLink) targetLink = allTargetLinks[sectionIndex - 1] || allTargetLinks[allTargetLinks.length - 1];
  } else {
    targetLink = allTargetLinks[0] || null;
  }
  return targetLink;
}

// Mueve `movingCmid` para que quede inmediatamente DESPUÉS de `anchorCmid`
// dentro de la misma sección. Usa el web service core_courseformat_update_course
// con action `cm_move`. NOTA: cm_moveafter NO existe en Moodle 4.0/4.1 (lo
// introdujeron en 4.4+). Por eso usamos cm_move pasando como `targetcmid` el
// SUCESOR del anchor en el cmlist actual — cm_move coloca el moving en la
// posición de targetcmid (i.e., "antes de targetcmid"), que equivale a
// "después del anchor". Si el anchor es el último, omitimos targetcmid (default
// es append al final). Retorna true si ok.
// Helpers DOM-based — content scripts viven en isolated world y NO pueden leer
// `window.M.cfg` (que es page-world JS de Moodle). Por eso extraemos sesskey,
// courseId y wwwroot del DOM en lugar de M.cfg.
function gaulaGetSesskey() {
  const inp = document.querySelector('input[name="sesskey"]');
  if (inp?.value) return inp.value;
  const logout = document.querySelector('a[href*="logout.php?sesskey="]');
  if (logout) {
    const m = logout.getAttribute('href').match(/sesskey=([^&]+)/);
    if (m) return m[1];
  }
  // Fallback: cualquier link con sesskey en query
  const any = document.querySelector('a[href*="sesskey="]');
  if (any) {
    const m = any.getAttribute('href').match(/sesskey=([A-Za-z0-9]+)/);
    if (m) return m[1];
  }
  return null;
}

function gaulaGetCourseId() {
  // body class "course-N" donde N > 1 (1 es site)
  const m = document.body.className.match(/\bcourse-(\d+)\b/);
  if (m && m[1] !== '1') return parseInt(m[1], 10);
  // Fallback: ?id= en URL si estamos en /course/view.php
  const urlId = new URL(location.href).searchParams.get('id');
  if (urlId) return parseInt(urlId, 10);
  return null;
}

function gaulaGetWwwroot() {
  // Preservar el path prefix de la sede (ej. /QUI-202601R)
  const m = location.pathname.match(/^(\/[^\/]+)\/(course|mod|question|admin|local|theme|user|grade|backup|report|enrol|message|calendar|my|blocks|lib)\b/);
  if (m) return `${location.origin}${m[1]}`;
  return location.origin;
}

// Mueve `movingCmid` para que quede AL FINAL del grupo del anchor (justo antes
// del siguiente label-anchor). `allAnchorCmids` es la lista de TODOS los cmids
// que son anchors visuales (Recursos / Productos y actividades / Grabación...).
// Esto permite distinguir un anchor del contenido del grupo, y colocar el nuevo
// recurso después del último item ya existente en el grupo (orgánicamente).
//
// Semántica de cm_move targetcmid: "el moving toma la posición de targetcmid"
// (es decir, queda ANTES de targetcmid). Por eso pasamos el cmid del siguiente
// anchor — el moving queda justo antes de ese siguiente anchor, lo que equivale
// a "al final del grupo actual".
async function gaulaCmMoveAfter(movingCmid, anchorCmid, allAnchorCmids) {
  const sesskey = gaulaGetSesskey();
  const wwwroot = gaulaGetWwwroot();
  const courseId = gaulaGetCourseId();
  console.log('%c[GAULA-DEBUG] cm_move prereqs:', 'color:#0891b2', { sesskey: !!sesskey, courseId, wwwroot, movingCmid, anchorCmid, allAnchors: allAnchorCmids });
  if (!sesskey || !courseId || !movingCmid || !anchorCmid) {
    console.warn('[GAULA-DEBUG] cm_move ABORT: missing prereq', { sesskey: !!sesskey, courseId });
    return false;
  }

  const anchorEl = document.getElementById('module-' + anchorCmid);
  const section = anchorEl ? anchorEl.closest('li.section') : null;
  console.log('%c[GAULA-DEBUG] cm_move DOM:', 'color:#0891b2', { anchorElExists: !!anchorEl, sectionId: section?.id, sectionDataId: section?.dataset?.id });
  if (!section) {
    console.warn('[GAULA] cm_move: sección del anchor no encontrada en DOM.');
    return false;
  }
  const realSectionId = parseInt(section.dataset.id, 10);
  if (!realSectionId) {
    console.warn('[GAULA] cm_move: sectionid interno no resuelto. dataset.id=' + section.dataset.id);
    return false;
  }
  const acts = [...section.querySelectorAll('li.activity')];
  const cmlist = acts.map(a => parseInt(a.id.replace('module-', ''), 10)).filter(Boolean);
  const anchorIdx = cmlist.indexOf(anchorCmid);
  console.log('%c[GAULA-DEBUG] cm_move cmlist:', 'color:#0891b2', { cmlist, anchorIdx });
  if (anchorIdx === -1) {
    console.warn('[GAULA-DEBUG] cm_move ABORT: anchorCmid ' + anchorCmid + ' no está en cmlist');
    return false;
  }

  // Encontrar el siguiente ANCHOR en cmlist después del actual. El nuevo cm
  // se colocará JUSTO ANTES de ese siguiente anchor (= al final del grupo actual).
  const anchorSet = new Set((allAnchorCmids || []).filter(c => c !== anchorCmid));
  let nextAnchorCmid = null;
  for (let i = anchorIdx + 1; i < cmlist.length; i++) {
    if (cmlist[i] === movingCmid) continue;
    if (anchorSet.has(cmlist[i])) { nextAnchorCmid = cmlist[i]; break; }
  }
  console.log('%c[GAULA-DEBUG] nextAnchorCmid=' + nextAnchorCmid, 'color:#0891b2');

  // Idempotencia: si el moving ya está en la posición correcta
  // (justo antes del nextAnchor, o al final si no hay nextAnchor), no hacer nada.
  if (nextAnchorCmid) {
    const nextIdx = cmlist.indexOf(nextAnchorCmid);
    const movingIdx = cmlist.indexOf(movingCmid);
    if (movingIdx === nextIdx - 1) {
      console.log('[GAULA] moving ya está al final del grupo, skip');
      return true;
    }
  } else {
    const movingIdx = cmlist.indexOf(movingCmid);
    if (movingIdx === cmlist.length - 1) {
      console.log('[GAULA] moving ya está al final de la sección (sin nextAnchor), skip');
      return true;
    }
  }

  const args = {
    action: 'cm_move',
    courseid: courseId,
    ids: [movingCmid],
    targetsectionid: realSectionId,
  };
  // Si hay siguiente anchor, posiciono ANTES de él (= al final del grupo).
  // Si no (este anchor es el último de la sección), omito targetcmid → append al final.
  if (nextAnchorCmid) args.targetcmid = nextAnchorCmid;

  const url = `${wwwroot}/lib/ajax/service.php?sesskey=${sesskey}&info=core_courseformat_update_course`;
  const body = [{ index: 0, methodname: 'core_courseformat_update_course', args }];
  console.log('%c[GAULA-DEBUG] cm_move POST args:', 'color:#0891b2', args);
  try {
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      credentials: 'include',
    });
    const json = await resp.json().catch(() => null);
    console.log('%c[GAULA-DEBUG] cm_move response status=' + resp.status + ' json[0]:', 'color:#0891b2', json?.[0]);
    if (!resp.ok || !json || json[0]?.exception || json[0]?.error === true) {
      const errMsg = json?.[0]?.exception?.message || json?.[0]?.error || JSON.stringify(json).slice(0, 200);
      console.warn('[GAULA] cm_move falló:', errMsg);
      return false;
    }
    return true;
  } catch (e) {
    console.warn('[GAULA] cm_move exception:', e.message);
    return false;
  }
}

// Mapeo de nombres legacy ("RECURSOS"/"PRODUCTOS Y ACTIVIDADES") a anchor keys
// de la plantilla detectada por gaulaScanCourseStructure.
function gaulaMapTargetToAnchorKey(targetSectionName) {
  if (!targetSectionName) return null;
  const t = targetSectionName.toLowerCase();
  if (/recurso/.test(t)) return 'recursos';
  if (/producto|actividad|evaluac/.test(t)) return 'actividades';
  if (/grabaci/.test(t)) return 'grabacion';
  return null;
}

async function gaulaMoveLastResource(targetSectionName, resourceName, sectionIndex, resourceType) {
  // En Quito (format-onetopic), cada Criterio es una sección plana. Mover entre
  // secciones (como hace PUCESE para "RECURSOS") no aplica. En lugar de eso,
  // detectamos un anchor (label con h1 "Recursos"/"Productos y actividades"/etc.)
  // dentro de la misma sección y movemos el recurso recién creado para que quede
  // inmediatamente después del anchor, usando el AJAX cm_moveafter de Moodle 4.x.
  if (document.body.classList.contains('format-onetopic')) {
    try {
      console.log('%c[GAULA-DEBUG] gaulaMoveLastResource ENTER onetopic', 'color:#7c3aed;font-weight:bold', { targetSectionName, resourceName, sectionIndex, resourceType });
      const struct = gaulaScanCourseStructure();
      console.log('%c[GAULA-DEBUG] scan anchors:', 'color:#7c3aed', struct.anchors);
      const anchorKey = gaulaMapTargetToAnchorKey(targetSectionName);
      const anchor = anchorKey ? struct.anchors[anchorKey] : null;
      console.log('%c[GAULA-DEBUG] anchorKey=' + anchorKey + ' anchor=', 'color:#7c3aed', anchor);
      if (!anchor) {
        console.warn('[GAULA] No hay anchor "' + anchorKey + '" en la sección actual. ' +
                     'El recurso queda al final. (Plantilla oficial no aplicada o anchor renombrado.)');
        return;
      }
      // Buscar el recurso recién creado (la última actividad por defecto, o por nombre si viene)
      const activeSec = [...document.querySelectorAll('li.section')].find(s => s.id !== 'section-0');
      if (!activeSec) return;
      const acts = [...activeSec.querySelectorAll('li.activity')];
      let movingAct = null;
      if (resourceName) {
        movingAct = [...acts].reverse().find(a => {
          const an = a.dataset.activityname || a.querySelector('.instancename')?.textContent || '';
          return an.trim() === resourceName.trim() || an.toLowerCase().includes(resourceName.toLowerCase());
        });
      }
      if (!movingAct) movingAct = acts[acts.length - 1];
      if (!movingAct || !movingAct.id || !movingAct.id.startsWith('module-')) {
        console.warn('[GAULA] No se identificó cmid del recurso a mover.');
        return;
      }
      const movingCmid = parseInt(movingAct.id.replace('module-', ''), 10);
      const targetCmid = parseInt(anchor.id.replace('module-', ''), 10);
      // Lista de TODOS los anchor cmids para que el move pueda calcular dónde
      // termina el grupo (= cmid del siguiente anchor). Así el nuevo recurso
      // queda AL FINAL del grupo, no al inicio (orden orgánico).
      const allAnchorCmids = Object.values(struct.anchors)
        .filter(Boolean)
        .map(a => parseInt(a.id.replace('module-', ''), 10));
      console.log('%c[GAULA-DEBUG] calling cm_move movingCmid=' + movingCmid + ' anchorCmid=' + targetCmid + ' allAnchors=' + JSON.stringify(allAnchorCmids), 'color:#7c3aed;font-weight:bold');
      const ok = await gaulaCmMoveAfter(movingCmid, targetCmid, allAnchorCmids);
      console.log('%c[GAULA-DEBUG] cm_move result=' + ok, 'color:#7c3aed;font-weight:bold');
      if (ok) {
        console.log('[GAULA] Recurso ' + movingCmid + ' movido tras anchor "' + anchor.text + '" (cmid ' + targetCmid + ').');
      } else {
        console.warn('[GAULA] Move-after falló; recurso queda al final.');
      }
      // NOTA: el reload del DOM (Moodle no observa cambios hechos vía WS directo)
      // lo hace el CALLER después de que limpie state. Si reload aquí, los flujos
      // de queue (section-editor.js) se quedan con state='next_in_queue' y la
      // IIFE re-ejecuta este move tras el reload → bucle infinito.
      return ok;
    } catch (e) {
      console.error('[GAULA-DEBUG] gaulaMoveLastResource onetopic EXCEPTION:', e);
      return false;
    }
  }
  try {
    await gaulaEnableEditing(); await gaulaWait(500);
    let actionMenuBtn = null;
    const searchScope = sectionIndex != null ? document.querySelector(`#coursecontentcollapse${sectionIndex}`) : document;
    if (resourceName && searchScope) {
      const allActivities = [...searchScope.querySelectorAll('[data-activityname]')];
      const matches = allActivities.filter(el => el.dataset.activityname === resourceName || el.dataset.activityname.toLowerCase().includes(resourceName.toLowerCase()));
      if (matches.length > 0) { const activityEl = matches[matches.length - 1]; actionMenuBtn = activityEl.querySelector('[id^="action-menu-toggle-"]'); }
    }
    if (!actionMenuBtn && searchScope) { const sectionMenus = searchScope.querySelectorAll('[id^="action-menu-toggle-"]'); if (sectionMenus.length > 0) actionMenuBtn = sectionMenus[sectionMenus.length - 1]; }
    if (!actionMenuBtn) { const allMenus = document.querySelectorAll('[id^="action-menu-toggle-"]'); if (allMenus.length === 0) return; actionMenuBtn = allMenus[allMenus.length - 1]; }
    gaulaClick(actionMenuBtn); await gaulaWait(500);
    const menuId = actionMenuBtn.getAttribute('aria-controls');
    let moveItem = null;
    if (menuId) { const dropdown = document.getElementById(menuId); if (dropdown) moveItem = [...dropdown.querySelectorAll('[role="menuitem"]')].find(el => el.textContent.trim() === 'Mover'); }
    if (!moveItem) moveItem = await gaulaWaitForRole('menuitem', 'Mover', { exact: true });
    gaulaClick(moveItem); await gaulaWait(1000);

    let targetLink = gaulaFindTargetLink(targetSectionName, sectionIndex);

    if (!targetLink) {
      console.warn(`[GAULA 3.0] Sección "${targetSectionName}" no encontrada, buscando alternativas...`);
      const fallbacks = gaulaFindFallbackSection(targetSectionName, resourceType);
      for (const fb of fallbacks) {
        targetLink = gaulaFindTargetLink(fb, sectionIndex);
        if (targetLink) {
          console.log(`[GAULA 3.0] Usando sección alternativa: "${fb}"`);
          break;
        }
      }
    }

    if (targetLink) {
      gaulaClick(targetLink); await gaulaWait(2000);
      gaulaDismissMoveModal(); await gaulaWait(300);
    } else {
      console.warn(`[GAULA 3.0] No se encontró sección destino para "${targetSectionName}" ni alternativas. Cerrando modal.`);
      gaulaDismissMoveModal(); await gaulaWait(300);
    }
  } catch (e) { console.warn('Gaula 3.0: No se pudo mover el recurso:', e.message); }
}

// Bug #14: Log persistente de errores para diagnóstico
function gaulaReportProgress(current, total, status, extra = {}) {
  const state = { current, total, status, ts: Date.now(), ...extra };
  chrome.storage.local.set({ gaula_progress: state });
  // Bug #14: Si es error, guardarlo en historial persistente
  if (status === 'error') {
    chrome.storage.local.get('gaula_error_log', (result) => {
      const log = result.gaula_error_log || [];
      log.push({ ...state, url: window.location.href });
      // Mantener solo los últimos 20 errores
      if (log.length > 20) log.splice(0, log.length - 20);
      chrome.storage.local.set({ gaula_error_log: log });
    });
  }
  try { chrome.runtime.sendMessage({ action: 'gaula_progress', ...state }); } catch (e) { /* popup cerrado */ }
}

function gaulaDeserializeFile(serialized) {
  const { data, name, type } = serialized;
  const byteString = atob(data.split(',')[1]);
  const ab = new ArrayBuffer(byteString.length);
  const ia = new Uint8Array(ab);
  for (let i = 0; i < byteString.length; i++) ia[i] = byteString.charCodeAt(i);
  return new File([ab], name, { type });
}

// ============================================================
// Escáner de estructura del curso (RDAs + Criterios + anchors)
// ============================================================
// Lee los tabs nav-tabs (padres = RDAs, hijos = Criterios si format-onetopic
// anidado) y los anchors (labels "Recursos", "Productos y actividades",
// "Grabación de clase virtual") en la sección activa.
// Lo que NO está activo no se ve en el DOM, por eso las criterios solo
// aparecen del RDA activo. Popup puede navegar para escanear otros RDAs si
// necesita inventario completo.
function gaulaScanCourseStructure() {
  const allNavTabs = [...document.querySelectorAll('ul.nav-tabs')];
  const tabsByLevel = allNavTabs.map(ul => [...ul.querySelectorAll('a')]
    .map(a => {
      if (!a.href) return null;
      let secParam = null;
      try { secParam = new URL(a.href).searchParams.get('section'); } catch (_) { return null; }
      // Excluir botones tipo "+Adicionar sección" (changenumsections.php sin param ?section=).
      // También excluir entradas sin label visible.
      if (secParam == null) return null;
      const label = a.textContent.replace(/[\s ]+/g, ' ').trim();
      if (!label) return null;
      return {
        label,
        sectionId: parseInt(secParam, 10),
        active: a.classList.contains('active'),
      };
    })
    .filter(Boolean));
  const parentTabs = tabsByLevel[0] || [];
  const childTabs = tabsByLevel[1] || [];
  const activeRdaIdx = parentTabs.findIndex(t => t.active);

  // Mapa rdas[i]. Si hay anidación, criterios viene poblado solo para el RDA activo.
  const rdas = parentTabs.map((rda, idx) => ({
    label: rda.label,
    sectionId: rda.sectionId,
    active: rda.active,
    criterios: (childTabs.length > 0 && idx === activeRdaIdx)
      ? childTabs
      : (childTabs.length === 0
          ? [{ label: rda.label, sectionId: rda.sectionId, active: rda.active }]
          : null), // null = no inspeccionado todavía
  }));

  // Anchors en la sección activa
  const activeSec = [...document.querySelectorAll('li.section')].find(s => s.id !== 'section-0');
  const anchors = { recursos: null, actividades: null, grabacion: null };
  if (activeSec) {
    const labels = [...activeSec.querySelectorAll('li.activity.modtype_label')];
    for (const lbl of labels) {
      const h = lbl.querySelector('h1');
      if (!h) continue;
      const t = h.textContent.replace(/[\s ]+/g, ' ').trim();
      const tl = t.toLowerCase();
      if (!anchors.recursos && /^recursos\s*$/i.test(tl)) anchors.recursos = { id: lbl.id, text: t };
      else if (!anchors.actividades && /^productos y actividades(\s+\w+)?\s*$/i.test(tl)) anchors.actividades = { id: lbl.id, text: t };
      else if (!anchors.grabacion && /^grabaci[oó]n.*(virtual|tutor)/i.test(tl)) anchors.grabacion = { id: lbl.id, text: t };
    }
  }

  return {
    format: document.body.classList.contains('format-onetopic') ? 'onetopic' :
            document.body.classList.contains('format-topics') ? 'topics' : 'other',
    hasNestedCriterios: childTabs.length > 0,
    activeRdaIdx,
    rdas,
    activeSectionId: activeSec ? parseInt(activeSec.dataset.section || activeSec.id.replace('section-', ''), 10) : null,
    anchors,
  };
}

// Handler registry
const gaulaHandlers = {};
function gaulaRegisterHandler(action, handler) { gaulaHandlers[action] = handler; }

// Lee el árbol del gradebook del curso actual y devuelve RDAs/Criterios.
// El popup lo llama para popular el selector "Replicar nota en otros criterios".
gaulaRegisterHandler('fetch_grade_tree', async (msg, sendResponse) => {
  // Solo responder desde el top frame. Si responde un iframe (Atto, recursos),
  // probablemente no tiene courseId y devolvería error antes de que el top
  // frame complete su fetch — el popup recibe la PRIMERA respuesta.
  if (window !== window.top) return;
  try {
    // Resolver courseId con cascada de fuentes:
    // 1) msg.courseId (si el popup lo pasa explícito)
    // 2) gaulaGetCourseId() — body class "course-N" o ?id= en URL
    // 3) M.cfg.courseId — disponible en algunas vistas Moodle
    // 4) Buscar en breadcrumb / enlaces a course/view.php?id=N
    let courseId = msg?.courseId || gaulaGetCourseId() || (window.M && window.M.cfg && window.M.cfg.courseId);
    if (!courseId) {
      const courseLink = document.querySelector('a[href*="/course/view.php?id="]');
      if (courseLink) {
        const m = courseLink.href.match(/[?&]id=(\d+)/);
        if (m) courseId = parseInt(m[1], 10);
      }
    }
    if (!courseId) {
      sendResponse({ ok: false, error: 'No se detectó el curso. Abre una página del aula (ej. la portada del curso) y reintenta.' });
      return;
    }
    const baseUrl = gaulaGetWwwroot();
    const tree = await gaulaFetchGradeTree({ courseId, baseUrl });
    if (!tree.ok) {
      sendResponse({ ok: false, error: tree.error || 'No se pudo leer el gradebook' });
      return;
    }
    const idn = await gaulaSuggestNextIdnumber({ courseId, baseUrl });
    sendResponse({ ok: true, tree, suggestedIdnumber: idn.ok ? idn.nextIdnumber : 'A1' });
  } catch (e) {
    sendResponse({ ok: false, error: e.message });
  }
});

// ============================================================
// MULTI-BANCO HELPERS
// ============================================================

// Crea una categoría de banco de preguntas via POST al form HTML de Moodle.
// parentValue debe tener formato "<catid>,<contextid>" (ej. "32082,257662"
// para crear bajo "Superior para test prueba 10" — contexto módulo del quiz).
// IMPORTANTE: el form Moodle es application/x-www-form-urlencoded (NO multipart),
// usamos URLSearchParams y Content-Type explícito. Si no, Moodle responde 404.
// Devuelve { ok, catValue, error } donde catValue = "<newCatId>,<contextid>".
async function gaulaCreateQuestionCategory({ cmid, name, parentValue, baseUrl }) {
  try {
    const sesskey = gaulaGetSesskey();
    if (!sesskey) return { ok: false, error: 'no sesskey' };
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/question/bank/managecategories/category.php`;

    const params = new URLSearchParams();
    params.append('cmid', String(cmid));
    params.append('id', '0');
    params.append('sesskey', sesskey);
    params.append('_qf__qbank_managecategories_form_question_category_edit_form', '1');
    params.append('mform_isexpanded_id_categoryheader', '1');
    params.append('parent', parentValue);
    params.append('name', name);
    params.append('info[text]', '');
    params.append('info[format]', '1');
    params.append('idnumber', '');
    params.append('submitbutton', 'Añadir Categoría');

    const resp = await fetch(url, {
      method: 'POST',
      body: params.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include'
    });
    if (!resp.ok) return { ok: false, error: `HTTP ${resp.status}` };
    const html = await resp.text();

    // Después del POST exitoso, Moodle responde con la página de manage categories
    // listando todas las cats. Buscamos nuestra nueva cat por nombre y extraemos
    // su categoryid del link "Editar pregunta" cercano (patrón cat=NNN%2CMMM).
    const escName = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // El nombre aparece dentro de un <a> de "Editar pregunta" que tiene cat=catid%2Cctxid
    const linkRe = new RegExp(`cat=(\\d+)%2C(\\d+)[^"]*"[^>]*>\\s*${escName}\\b`, 'i');
    let m = html.match(linkRe);
    if (!m) {
      // Fallback: buscar el texto y luego un delete=NNN/edit=NNN o cat=NNN%2CMMM cercano
      const idxName = html.indexOf(name);
      if (idxName >= 0) {
        const around = html.substring(Math.max(0, idxName - 600), Math.min(html.length, idxName + 600));
        m = around.match(/cat=(\d+)%2C(\d+)/i) || around.match(/delete=(\d+)/);
        if (m && !m[2]) {
          // Si fallback dio solo catid, derivamos ctxid del parent
          const parentCtxid = (parentValue.split(',')[1] || '').trim();
          return { ok: true, catValue: `${m[1]},${parentCtxid}` };
        }
      }
    }
    if (!m) return { ok: false, error: 'no se pudo extraer catid de respuesta' };
    return { ok: true, catValue: `${m[1]},${m[2]}` };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Crea N random slots en un quiz, todos apuntando a una categoría existente.
// Equivalente a click "Agregar > una pregunta aleatoria" → seleccionar cat → numbertoadd=N → submit.
// Igual que category.php: form usa application/x-www-form-urlencoded.
async function gaulaAddRandomSlots({ cmid, categoryValue, count, addonpage, baseUrl }) {
  try {
    const sesskey = gaulaGetSesskey();
    if (!sesskey) return { ok: false, error: 'no sesskey' };
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/mod/quiz/addrandom.php`;
    const returnurl = `${root}/mod/quiz/edit.php?cmid=${cmid}`;

    const params = new URLSearchParams();
    params.append('addonpage', String(addonpage || 0));
    params.append('cmid', String(cmid));
    params.append('returnurl', returnurl);
    params.append('sesskey', sesskey);
    params.append('_qf__quiz_add_random_form', '1');
    params.append('category', categoryValue);
    params.append('includesubcategories', '0');
    params.append('fromtags', '_qf__force_multiselect_submission');
    params.append('numbertoadd', String(count));
    params.append('existingcategory', 'Agregar pregunta aleatoria');

    const resp = await fetch(url, {
      method: 'POST',
      body: params.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include'
    });
    if (!resp.ok) return { ok: false, error: `HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ============================================================
// Gradebook tree (RDAs / Criterios) — para feature de réplicas
// de nota entre criterios via fórmula calculada.
// ============================================================

// Lee /grade/edit/tree/index.php y devuelve la jerarquía de RDAs y
// Criterios. Las categorías de grado están marcadas por <tr id="grade-
// item-cgN" data-category="cgN" data-itemid="M">. El número de clases
// "cgX" en el className indica la profundidad: 1=RDA, 2=Criterio.
async function gaulaFetchGradeTree({ courseId, baseUrl }) {
  try {
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/grade/edit/tree/index.php?id=${courseId}`;
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const html = await r.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');

    const rdas = [];
    let currentRda = null;
    doc.querySelectorAll('tr[id^="grade-item-cg"]').forEach(tr => {
      const cgId = tr.getAttribute('data-category');
      if (!cgId) return;
      const catId = cgId.replace(/^cg/, '');
      const itemId = tr.getAttribute('data-itemid');
      // Nombre limpio: el primer span/h-element con el nombre, sin acciones.
      // El texto del tr incluye "Editar/Ocultar/Borrar"; extraemos hasta el primer
      // marcador de acción.
      const fullText = tr.textContent.replace(/\s+/g, ' ').trim();
      const name = fullText.split(/\s+(Valor de cr|Editar|Borrar|Ocultar|Media|Total|-)/)[0].trim();
      const cgClasses = (tr.className.match(/\bcg\d+\b/g) || []);
      const depth = cgClasses.length;
      if (depth === 1) {
        currentRda = { id: catId, itemId, name, criterios: [] };
        rdas.push(currentRda);
      } else if (depth === 2 && currentRda) {
        currentRda.criterios.push({ id: catId, itemId, name });
      }
    });
    return { ok: true, rdas };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Sugerir el siguiente idnumber A{n} disponible escaneando el HTML del
// tree por idnumbers existentes con patrón A\d+. Conservador: empezar
// desde el mayor + 1 si no hay huecos importantes.
async function gaulaSuggestNextIdnumber({ courseId, baseUrl }) {
  try {
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/grade/edit/tree/index.php?id=${courseId}`;
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const html = await r.text();
    const used = new Set();
    // Los idnumbers aparecen como "(A1)" o data-attrs o tooltips. Buscar amplio.
    for (const m of html.matchAll(/[\s"'(>]A(\d+)[\s"'<)]/g)) {
      const n = parseInt(m[1]);
      if (n > 0 && n < 1000) used.add(n);
    }
    let next = 1;
    while (used.has(next)) next++;
    return { ok: true, nextIdnumber: 'A' + next, used: [...used].sort((a,b) => a-b) };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Encontrar el itemid de un grade item del tree por nombre exacto y
// (opcional) categoryid del padre. También devuelve cmid si el item está
// asociado a un course module (link <a href*="/mod/.../view.php?id=N"> en
// la fila) — necesario para editar el cmidnumber del mod, que es la fuente
// real del idnumber del grade item (el propio campo del item está readonly).
async function gaulaFindGradeItemByName({ courseId, name, parentCategoryId, baseUrl }) {
  try {
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/grade/edit/tree/index.php?id=${courseId}`;
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const html = await r.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const wanted = name.toLowerCase().trim();
    const candidates = [];
    doc.querySelectorAll('tr[id^="grade-item-ig"]').forEach(tr => {
      const itemId = tr.getAttribute('data-itemid');
      if (!itemId) return;
      const fullText = tr.textContent.replace(/\s+/g, ' ').trim();
      const head = fullText.split(/\s+\d+[,.]?\d*\s+Editar|\s+Editar/)[0].trim().toLowerCase();
      const parentMatch = tr.className.match(/\bcg(\d+)\b/g) || [];
      const directParent = parentMatch[parentMatch.length - 1]?.replace(/^cg/, '');
      // Extraer cmid si la fila tiene link a /mod/{tipo}/view.php?id=N
      let cmid = null;
      const modLink = tr.querySelector('a[href*="/mod/"][href*="/view.php?id="]');
      if (modLink) {
        const m = modLink.href.match(/[?&]id=(\d+)/);
        if (m) cmid = m[1];
      }
      if (head === wanted || head.includes(wanted)) {
        candidates.push({ itemId, parentCategoryId: directParent, cmid, fullText: fullText.slice(0, 100) });
      }
    });
    let pick = candidates[0];
    if (parentCategoryId) {
      pick = candidates.find(c => c.parentCategoryId === String(parentCategoryId)) || pick;
    }
    if (!pick) return { ok: false, error: 'item not found', candidates: candidates.slice(0, 5) };
    return { ok: true, itemId: pick.itemId, parentCategoryId: pick.parentCategoryId, cmid: pick.cmid };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Setea el cmidnumber del course module via /course/modedit.php.
// El grade item del mod hereda automáticamente este idnumber, así que ESTE
// es el camino correcto para items tipo "mod" (NO gaulaSetGradeItemIdnumber,
// cuyo input está readonly/disabled).
//
// Estrategia: cargamos el form completo de modedit.php (incluye cientos de
// campos del editor Atto y demás), construimos el body con FormData del
// propio form (preserva valores tal cual), y modificamos solo cmidnumber.
async function gaulaSetCmIdnumber({ cmid, idnumber, baseUrl }) {
  try {
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/course/modedit.php?update=${cmid}`;
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const html = await r.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const form = doc.querySelector('form.mform') || doc.querySelector('form[id^="mform"]');
    if (!form) return { ok: false, error: 'mform not found' };
    // form.action puede ser hijack-eado por un <input name="action">; usar getAttribute.
    let action = form.getAttribute('action') || url;
    if (!/^https?:/.test(action)) {
      // Resolver relativo al wwwroot
      try { action = new URL(action, url).toString(); } catch (_) {}
    }
    const fd = new FormData(form);
    fd.set('cmidnumber', idnumber);
    const params = new URLSearchParams();
    for (const [k, v] of fd.entries()) {
      if (v instanceof File) continue;
      params.append(k, v);
    }
    if (!params.has('submitbutton')) {
      params.append('submitbutton', 'Guardar cambios y regresar al curso');
    }
    const resp = await fetch(action, {
      method: 'POST',
      body: params.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include',
      redirect: 'follow'
    });
    if (!resp.ok) return { ok: false, error: `HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Crear grade item manual en una categoría específica.
// Devuelve { ok, itemId } — itemId derivado refetcheando el tree y buscando
// el item por nombre + parentCategoryId.
async function gaulaCreateManualGradeItem({ courseId, parentCategoryId, name, grademax, idnumber, baseUrl }) {
  try {
    const sesskey = gaulaGetSesskey();
    if (!sesskey) return { ok: false, error: 'no sesskey' };
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/grade/edit/tree/item.php?courseid=${courseId}`;
    const params = new URLSearchParams();
    params.append('id', '0');
    params.append('courseid', String(courseId));
    params.append('itemtype', 'manual');
    params.append('sesskey', sesskey);
    params.append('_qf__edit_item_form', '1');
    params.append('mform_isexpanded_id_general', '1');
    params.append('mform_isexpanded_id_headerparent', '1');
    params.append('itemname', name);
    params.append('iteminfo', '');
    params.append('idnumber', idnumber || '');
    params.append('gradetype', '1');                          // Valor
    params.append('grademax', String(grademax).replace('.', ',')); // "50,00"
    params.append('grademin', '0,00');
    params.append('gradepass', '0,00');
    params.append('display', '0');                            // valor por defecto
    params.append('decimals', '-1');                          // valor por defecto
    params.append('hidden', '0');
    params.append('locked', '0');
    params.append('aggregationcoef', '0,0000');
    params.append('parentcategory', String(parentCategoryId));
    params.append('submitbutton', 'Guardar cambios');

    const resp = await fetch(url, {
      method: 'POST',
      body: params.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include',
      redirect: 'follow'
    });
    if (!resp.ok) return { ok: false, error: `HTTP ${resp.status}` };

    // Esperar un poquito a que Moodle persista, luego buscar el item creado.
    await new Promise(r => setTimeout(r, 600));
    const find = await gaulaFindGradeItemByName({ courseId, name, parentCategoryId, baseUrl });
    if (find.ok) return { ok: true, itemId: find.itemId };
    return { ok: true, itemId: null, warning: 'creado pero itemId no localizado' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Asignar idnumber a un item existente (PUT/POST a item.php?id=X copiando
// todos los demás campos del form para no resetear nada).
async function gaulaSetGradeItemIdnumber({ courseId, itemId, idnumber, baseUrl }) {
  try {
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/grade/edit/tree/item.php?courseid=${courseId}&id=${itemId}`;
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const html = await r.text();

    // Reconstruir todos los inputs del form preservando valores y solo
    // cambiando idnumber. Importante: mantener parentcategory para que el
    // item no se mueva de categoría.
    const formMatch = html.match(/<form[^>]*action="[^"]*item\.php[^"]*"[^>]*>([\s\S]*?)<\/form>/i);
    if (!formMatch) return { ok: false, error: 'form not found' };
    const formHtml = formMatch[1];
    const params = new URLSearchParams();
    // Inputs (incluye hidden + visible). Saltamos submits.
    for (const m of formHtml.matchAll(/<input\s+([^>]+?)\s*\/?>/gi)) {
      const attrs = m[1];
      const name = attrs.match(/name="([^"]+)"/)?.[1];
      if (!name) continue;
      const type = (attrs.match(/type="([^"]+)"/)?.[1] || 'text').toLowerCase();
      if (type === 'submit' || type === 'reset' || type === 'button' || type === 'image') continue;
      const value = attrs.match(/value="([^"]*)"/)?.[1] || '';
      if (type === 'checkbox') {
        if (/\schecked/i.test(attrs)) params.append(name, value || '1');
        continue;
      }
      if (type === 'radio') {
        if (/\schecked/i.test(attrs)) params.append(name, value);
        continue;
      }
      if (name === 'idnumber') {
        params.append(name, idnumber);
      } else {
        params.append(name, value);
      }
    }
    // Selects: tomar el option selected
    for (const m of formHtml.matchAll(/<select\s+[^>]*name="([^"]+)"[^>]*>([\s\S]*?)<\/select>/gi)) {
      const name = m[1];
      const sel = m[2].match(/<option\s+value="([^"]*)"[^>]*\sselected[^>]*>/i);
      if (sel) {
        params.append(name, sel[1]);
      } else {
        const first = m[2].match(/<option\s+value="([^"]*)"/i);
        if (first) params.append(name, first[1]);
      }
    }
    // Textareas
    for (const m of formHtml.matchAll(/<textarea\s+[^>]*name="([^"]+)"[^>]*>([\s\S]*?)<\/textarea>/gi)) {
      params.append(m[1], m[2]);
    }
    params.append('submitbutton', 'Guardar cambios');

    const resp = await fetch(url, {
      method: 'POST',
      body: params.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include'
    });
    if (!resp.ok) return { ok: false, error: `HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Asignar fórmula de cálculo a un grade item. Estrategia: GET form, FormData
// del form para preservar TODO, luego mutar calculation y POST. Más resiliente
// que construir los params a mano (Moodle puede agregar campos entre versiones).
// IMPORTANTE: el idnumber referenciado en la fórmula DEBE existir cuando se
// guarda; si no, Moodle rechaza con error de validación y calculation queda
// vacío. Por eso siempre seteamos el cmidnumber del mod ANTES de aplicar las
// fórmulas en las réplicas.
async function gaulaSetGradeItemCalculation({ courseId, itemId, formula, baseUrl }) {
  try {
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/grade/edit/tree/calculation.php?courseid=${courseId}&id=${itemId}`;
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const html = await r.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const form = doc.querySelector('form.mform') || doc.querySelector('form[id^="mform"]');
    if (!form) return { ok: false, error: 'mform not found' };
    let action = form.getAttribute('action') || url;
    if (!/^https?:/.test(action)) {
      try { action = new URL(action, url).toString(); } catch (_) {}
    }
    const fd = new FormData(form);
    fd.set('calculation', formula);
    const params = new URLSearchParams();
    for (const [k, v] of fd.entries()) {
      if (v instanceof File) continue;
      params.append(k, v);
    }
    if (!params.has('submitbutton')) params.append('submitbutton', 'Guardar cambios');
    const resp = await fetch(action, {
      method: 'POST',
      body: params.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include'
    });
    if (!resp.ok) return { ok: false, error: `HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Borra un grade item manual via POST de confirmación. Solo funciona para
// items manuales (los tipo "mod" no tienen opción Borrar — hay que borrar
// el mod entero). Endpoint: POST /grade/edit/tree/index.php con eid, action=delete, confirm=1.
async function gaulaDeleteGradeItem({ courseId, itemId, baseUrl }) {
  try {
    const sesskey = gaulaGetSesskey();
    if (!sesskey) return { ok: false, error: 'no sesskey' };
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/grade/edit/tree/index.php`;
    const params = new URLSearchParams();
    params.append('eid', `ig${itemId}`);
    params.append('action', 'delete');
    params.append('confirm', '1');
    params.append('sesskey', sesskey);
    params.append('id', String(courseId));
    const resp = await fetch(url, {
      method: 'POST',
      body: params.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include',
      redirect: 'follow'
    });
    if (!resp.ok) return { ok: false, error: `HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Obtener la lista de idnumbers VÁLIDOS del curso desde el form de calculation.
// Moodle expone "Elementos de calificación disponibles" como <li>nombre: [[idn]]</li>.
// Necesitamos un itemId con calculation editable como punto de entrada al form.
async function gaulaListAvailableIdnumbers({ courseId, sampleItemId, baseUrl }) {
  try {
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const url = `${root}/grade/edit/tree/calculation.php?courseid=${courseId}&id=${sampleItemId}`;
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const html = await r.text();
    const idnumbers = new Set();
    for (const m of html.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/g)) {
      const text = m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      const bracketMatch = text.match(/\[\[([^\]]+)\]\]/);
      if (bracketMatch) idnumbers.add(bracketMatch[1]);
    }
    return { ok: true, idnumbers: [...idnumbers] };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Detecta réplicas huérfanas: items con nombre que empieza por "↻ " cuya
// fórmula referencia idnumbers que ya no existen. Devuelve lista detallada.
async function gaulaFindOrphanReplicas({ courseId, baseUrl }) {
  try {
    const root = baseUrl || gaulaGetWwwroot() || window.location.origin;
    const treeUrl = `${root}/grade/edit/tree/index.php?id=${courseId}`;
    const r = await fetch(treeUrl, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const html = await r.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const replicaRows = [...doc.querySelectorAll('tr[id^="grade-item-ig"]')].filter(tr => {
      const txt = tr.textContent.replace(/\s+/g, ' ').trim();
      return txt.startsWith('↻');
    });
    if (replicaRows.length === 0) return { ok: true, orphans: [], totalReplicas: 0 };
    const sampleItemId = replicaRows[0].getAttribute('data-itemid');
    const idnsRes = await gaulaListAvailableIdnumbers({ courseId, sampleItemId, baseUrl });
    if (!idnsRes.ok) return { ok: false, error: idnsRes.error };
    const validIdns = new Set(idnsRes.idnumbers);

    const orphans = [];
    for (const tr of replicaRows) {
      const itemId = tr.getAttribute('data-itemid');
      if (!itemId) continue;
      const fullText = tr.textContent.replace(/\s+/g, ' ').trim();
      const name = fullText.split(/\s+\d+[,.]?\d*\s+Editar|\s+Editar/)[0].trim();
      const parentClasses = tr.className.match(/\bcg(\d+)\b/g) || [];
      const parentCategoryId = parentClasses[parentClasses.length - 1]?.replace(/^cg/, '');
      const calcUrl = `${root}/grade/edit/tree/calculation.php?courseid=${courseId}&id=${itemId}`;
      const cr = await fetch(calcUrl, { credentials: 'include' });
      if (!cr.ok) continue;
      const calcHtml = await cr.text();
      const tdoc = new DOMParser().parseFromString(calcHtml, 'text/html');
      const formula = tdoc.querySelector('textarea[name="calculation"]')?.value?.trim() || '';
      const refs = [...formula.matchAll(/\[\[([^\]]+)\]\]/g)].map(m => m[1]);
      const brokenRefs = refs.filter(ref => !validIdns.has(ref));
      if (refs.length > 0 && brokenRefs.length === refs.length) {
        orphans.push({ itemId, name, formula, brokenRefs, parentCategoryId });
      }
    }
    return { ok: true, orphans, totalReplicas: replicaRows.length, validIdns: [...validIdns] };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Handlers para popup ────────────────────────────────────────────────────
gaulaRegisterHandler('find_orphan_replicas', async (msg, sendResponse) => {
  if (window !== window.top) return;
  try {
    const courseId = msg?.courseId || gaulaGetCourseId();
    if (!courseId) { sendResponse({ ok: false, error: 'No se detectó el curso. Abre una página del aula.' }); return; }
    const baseUrl = gaulaGetWwwroot();
    const res = await gaulaFindOrphanReplicas({ courseId, baseUrl });
    sendResponse(res);
  } catch (e) {
    sendResponse({ ok: false, error: e.message });
  }
});

gaulaRegisterHandler('delete_grade_items', async (msg, sendResponse) => {
  if (window !== window.top) return;
  try {
    const courseId = msg?.courseId || gaulaGetCourseId();
    if (!courseId) { sendResponse({ ok: false, error: 'No se detectó el curso.' }); return; }
    const baseUrl = gaulaGetWwwroot();
    const itemIds = Array.isArray(msg?.itemIds) ? msg.itemIds : [];
    const results = [];
    for (const itemId of itemIds) {
      const dres = await gaulaDeleteGradeItem({ courseId, itemId, baseUrl });
      results.push({ itemId, ok: dres.ok, error: dres.error });
    }
    const okCount = results.filter(r => r.ok).length;
    sendResponse({ ok: true, deleted: okCount, total: itemIds.length, results });
  } catch (e) {
    sendResponse({ ok: false, error: e.message });
  }
});
