/**
 * GeneradorAulas 2.0 - Executor / Coordinator.
 * Recibe mensajes del popup/background y coordina con los scripts de acción.
 * NO ejecuta strings de código (bloqueado por CSP de Moodle).
 * Los scripts de acción están bundleados en la extensión y se auto-ejecutan
 * al detectar estado pendiente en gaulaGetState().
 */

// ============================================================
// LISTENER: recibir mensajes del popup/background
// ============================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Detener operación en curso
  if (msg.action === 'gaula_stop') {
    window.__gaulaStopFlag = true;
    gaulaClearState();
    sendResponse({ ok: true });
    return;
  }

  // Guardar estado para iniciar una acción
  // Los scripts bundleados lo detectarán en la próxima carga de página
  if (msg.action === 'gaula_execute') {
    const { params, actionName } = msg;
    window.__gaulaStopFlag = false;
    console.log('[EXECUTOR] Acción solicitada:', actionName);
    // El popup ya guarda el estado directamente para acciones multi-página.
    // Este handler existe como fallback para acciones single-page.
    sendResponse({ ok: true });
    return true;
  }

  // Auto-detectar tipo de aula
  if (msg.action === 'detect_course_type') {
    sendResponse({ courseType: gaulaDetectCourseType() });
    return;
  }

  // Escanear estructura: RDAs/Criterios/anchors. Usado por popup para resolver
  // sectionId correcto antes de operar (reemplaza la fórmula activeRda+1 que
  // falla en cursos con criterios anidados).
  if (msg.action === 'get_course_structure') {
    try {
      sendResponse({ ok: true, structure: gaulaScanCourseStructure() });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return;
  }

  // Ejecutar handler registrado (acciones single-page como create_forum)
  const handler = gaulaHandlers[msg.action];
  if (handler) {
    window.__gaulaStopFlag = false;
    handler(msg, sendResponse);
    return true;
  }
});
