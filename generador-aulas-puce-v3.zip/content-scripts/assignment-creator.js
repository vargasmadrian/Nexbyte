/**
 * Generador de Aulas - Crear tareas con rubrica en Moodle.
 * Selectores verificados con Playwright Codegen (2026-04-07).
 *
 * Flujo con maquina de estados (cada paso navega a otra pagina):
 *   1. course/view.php → Abrir chooser, click "Tarea" → NAVEGA a modedit.php
 *   2. modedit.php (step: fill_form) → Llenar nombre, desc, fechas, archivo, calificacion → click Guardar → NAVEGA
 *   3. grade/grading (step: define_rubric) → Llenar rubrica → click Guardar → NAVEGA
 *   4. course/view.php (step: move_task) → Mover a seccion "Actividades"
 *
 * Usa chrome.storage (gaula_content_state) para persistir entre navegaciones.
 */

/**
 * Encuentra un grupo de fecha de Moodle por su ID o por su legend.
 * Moodle usa IDs predecibles: id_allowsubmissionsfromdate, id_duedate, id_cutoffdate, id_gradingduedate
 */
function gaulaFindDateGroup(fieldsetId, legendName) {
  // Primero intentar por ID directo de Moodle
  let group = document.getElementById(fieldsetId);
  if (group) return group;

  // Fallback: buscar fieldset cuyo legend directo contenga el texto
  const fieldsets = document.querySelectorAll('fieldset');
  return [...fieldsets].find(fs => {
    const legend = fs.querySelector(':scope > legend') ||
                   fs.querySelector(':scope > .fcontainer > legend') ||
                   fs.querySelector('legend');
    return legend && legend.textContent.trim().includes(legendName);
  }) || null;
}

/**
 * Helper: configura los selects de fecha dentro de un grupo (fieldset/group).
 * Usa IDs de Moodle (ej: id_duedate_day, id_duedate_month) que son predecibles.
 * Fallback a buscar selects por sufijo de name attribute.
 */
function gaulaSetDateGroup(group, date) {
  if (!group || !date) return;

  // Buscar select por sufijo de ID (_day, _month, etc.) o por name attribute
  const findSelect = (suffix) => {
    // 1. Buscar por ID que termine en _suffix dentro del grupo
    const byId = group.querySelector(`select[id$="_${suffix}"]`);
    if (byId) return byId;
    // 2. Buscar por name que contenga [suffix]
    const byName = group.querySelector(`select[name*="[${suffix}]"]`);
    if (byName) return byName;
    return null;
  };

  // Orden: año → mes → día para evitar que Moodle resetee el día al cambiar mes
  const yearSelect = findSelect('year');
  if (yearSelect) gaulaSetSelect(yearSelect, String(date.getFullYear()));

  const monthSelect = findSelect('month');
  if (monthSelect) gaulaSetSelect(monthSelect, String(date.getMonth() + 1));

  const daySelect = findSelect('day');
  if (daySelect) gaulaSetSelect(daySelect, String(date.getDate()));

  const hourSelect = findSelect('hour');
  if (hourSelect) gaulaSetSelect(hourSelect, String(date.getHours()));

  const minSelect = findSelect('minute');
  if (minSelect) gaulaSetSelect(minSelect, String(date.getMinutes()));
}

// ============================================================
// MAQUINA DE ESTADOS — se ejecuta al cargar cada pagina
// ============================================================
(async function checkAssignmentState() {
  // Solo ejecutar en el frame principal — iframes no deben interferir
  if (window !== window.top) return;
  // Trace siempre — confirma que el content script corrió en esta página.
  console.log('%c[GAULA-DEBUG] assignment-creator IIFE START', 'color:#1d4ed8;font-weight:bold', { url: window.location.href.substring(0, 120) });
  const state = await gaulaGetState();
  console.log('%c[GAULA-DEBUG] checkAssignmentState state:', 'color:#1d4ed8', JSON.stringify({ action: state?.action, step: state?.step, sectionIndex: state?.sectionIndex, taskName: state?.taskName }));
  if (!state || state.action !== 'create_assignment') {
    console.log('%c[GAULA-DEBUG] IIFE exit: no create_assignment state', 'color:#94a3b8');
    return;
  }

  const url = window.location.href;

  // ──────────────────────────────────────────────────────────
  // STEP: fill_form — Estamos en modedit.php, llenar formulario
  // ──────────────────────────────────────────────────────────
  if (url.includes('/modedit.php') && state.step === 'fill_form') {
    console.log('[GAULA] Entrando a fill_form, taskData:', JSON.stringify(state.taskData?.nombre));
    try {
      const task = state.taskData;
      await gaulaWait(1500);

      // Codegen: getByRole('textbox', { name: 'Nombre de la tarea' }).click() + .fill(...)
      const nameInput = await gaulaWaitForRole('textbox', 'Nombre de la tarea');
      if (nameInput) {
        gaulaClick(nameInput);
        await gaulaWait(200);
        gaulaSetValue(nameInput, task.nombre);
      }
      await gaulaWait(300);

      // Codegen: getByRole('textbox', { name: 'Descripción' }).click() + .fill(...)
      const descInput = gaulaByRole('textbox', 'Descripción');
      if (descInput && task.descripcionHtml) {
        gaulaClick(descInput);
        await gaulaWait(200);
        if (descInput.contentEditable === 'true') {
          descInput.innerHTML = task.descripcionHtml;
          descInput.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          gaulaSetValue(descInput, task.descripcionHtml);
        }
      }

      // Codegen: getByLabel('Muestra la descripción en la').check()
      const showDescCheck = gaulaByLabel('Muestra la descripción en la') ||
                            gaulaByLabel('Muestra ldescripción en la');
      if (showDescCheck && !showDescCheck.checked) {
        gaulaClick(showDescCheck);
      }

      // Codegen: getByRole('textbox', { name: 'Instrucciones de actividad' })
      if (task.instrucciones) {
        const instrInput = gaulaByRole('textbox', 'Instrucciones de actividad');
        if (instrInput) {
          gaulaClick(instrInput);
          await gaulaWait(200);
          if (instrInput.contentEditable === 'true') {
            instrInput.innerHTML = task.instrucciones;
            instrInput.dispatchEvent(new Event('input', { bubbles: true }));
          } else {
            gaulaSetValue(instrInput, task.instrucciones);
          }
        }
      }

      // Subir PDF adjunto del docente (serializado como base64)
      if (task.pdfSerialized) {
        const file = gaulaDeserializeFile(task.pdfSerialized);

        // Codegen: getByText('Agregar...').click()
        const addSpan = gaulaByText('Agregar...', 'span') || gaulaByText('Agregar...', 'a');
        if (addSpan) {
          const addBtn = addSpan.closest('a') || addSpan.closest('button') || addSpan;
          gaulaClick(addBtn);
          await gaulaWait(1500);
        }

        // Codegen: getByRole('link', { name: 'Subir un archivo' })
        const uploadTab = gaulaByRole('link', 'Subir un archivo');
        if (uploadTab) {
          gaulaClick(uploadTab);
          await gaulaWait(800);
        }

        // Buscar input[type=file]
        const fileInput = document.querySelector('input[type="file"][name="repo_upload_file"]') ||
                          document.querySelector('.fp-upload-form input[type="file"]') ||
                          document.querySelector('input[type="file"]');
        if (fileInput) {
          gaulaUploadFile(fileInput, file);
          await gaulaWait(2000);

          // Codegen: getByRole('button', { name: 'Subir este archivo' })
          const uploadBtn = gaulaByRole('button', 'Subir este archivo');
          if (uploadBtn) {
            gaulaClick(uploadBtn);
            await gaulaWait(3000);
          }
        }
      }

      // Disponibilidad — SIEMPRE expandir para poder desactivar campos conflictivos
      const dispBtn = gaulaByRole('button', 'Disponibilidad') ||
                      gaulaByText('Disponibilidad', 'button');
      if (dispBtn) {
        gaulaClick(dispBtn);
        await gaulaWait(500);
      }

      // Fechas de disponibilidad (si el docente las configuró)
      if (task.dateFrom || task.dateTo) {
        const fromDate = task.dateFrom ? new Date(task.dateFrom + 'T00:00:00') : null;
        const toDate = task.dateTo ? new Date(task.dateTo + 'T23:59:00') : null;

        // 1. "Permitir entregas desde" — ID: id_allowsubmissionsfromdate
        if (fromDate) {
          const allowGroup = gaulaFindDateGroup('id_allowsubmissionsfromdate', 'Permitir entregas desde');
          if (allowGroup) {
            const enableCheck = allowGroup.querySelector('input[type="checkbox"]');
            if (enableCheck && !enableCheck.checked) {
              gaulaClick(enableCheck);
              await gaulaWait(300);
            }
            gaulaSetDateGroup(allowGroup, fromDate);
            await gaulaWait(200);
          }
        }

        // 2. "Fecha de entrega" — ID: id_duedate
        if (toDate) {
          const dueGroup = gaulaFindDateGroup('id_duedate', 'Fecha de entrega');
          if (dueGroup) {
            const enableCheck = dueGroup.querySelector('input[type="checkbox"]');
            if (enableCheck && !enableCheck.checked) {
              gaulaClick(enableCheck);
              await gaulaWait(300);
            }
            gaulaSetDateGroup(dueGroup, toDate);
            await gaulaWait(200);
          }
        }

        // 3. "Fecha límite" — ID: id_cutoffdate — dateTo + 6 meses, habilitado
        const cutoffGroup = gaulaFindDateGroup('id_cutoffdate', 'Fecha límite');
        if (cutoffGroup) {
          const enableCheck = cutoffGroup.querySelector('input[type="checkbox"]');
          if (enableCheck && !enableCheck.checked) {
            gaulaClick(enableCheck);
            await gaulaWait(300);
          }
          const cutoffDate = toDate ? new Date(toDate) : (fromDate ? new Date(fromDate) : new Date());
          cutoffDate.setMonth(cutoffDate.getMonth() + 6);
          gaulaSetDateGroup(cutoffGroup, cutoffDate);
          await gaulaWait(200);
        }
      }

      // 4. "Recordarme calificar en" — ID: id_gradingduedate — SIEMPRE deshabilitado
      const gradingGroup = gaulaFindDateGroup('id_gradingduedate', 'Recordarme calificar en');
      if (gradingGroup) {
        const enableCheck = gradingGroup.querySelector('input[type="checkbox"]');
        if (enableCheck && enableCheck.checked) {
          gaulaClick(enableCheck);
          await gaulaWait(200);
        }
      }

      // Numero maximo de archivos que el estudiante puede subir
      // Codegen: getByLabel('Número máximo de archivos').selectOption('3')
      const maxFilesSelect = gaulaByLabel('Número máximo de archivos');
      if (maxFilesSelect) gaulaSetSelect(maxFilesSelect, '3');

      // Calificacion — expandir seccion
      // Codegen: getByRole('button', { name: '# Calificación' })
      const gradeBtn = gaulaByRole('button', '# Calificación') ||
                       gaulaByRole('button', 'Calificación');
      if (gradeBtn) {
        gaulaClick(gradeBtn);
        await gaulaWait(500);
      }

      // Calificación máxima de la tarea — escala 1:1 con la suma de la rúbrica
      // (popup.js recalcRubricPoints distribuye 50 puntos entre los criterios).
      const maxGradeInput = gaulaByLabel('Calificación máxima');
      if (maxGradeInput) gaulaSetValue(maxGradeInput, '50');

      // Metodo de calificacion: rubrica (solo si hay rubrica)
      // Codegen: getByLabel('Método de calificación').selectOption('rubric')
      if (task.rubricaJson) {
        const methodSelect = gaulaByLabel('Método de calificación');
        if (methodSelect) gaulaSetSelect(methodSelect, 'rubric');
      }

      // Categoria de calificaciones — busca en cascada por lo que exista en Moodle:
      // 1. "Criterio X RDA N" (repotenciada con criterios)
      // 2. "Parcial N" (no repotenciada — N = rdaNum)
      // 3. "RDA N" (repotenciada sin criterios)
      const catSelect = gaulaByLabel('Categoría de calificaciones');
      if (catSelect) {
        if (state.gradeCategoryValue) {
          gaulaSetSelect(catSelect, state.gradeCategoryValue);
        } else if (state.rdaIndex != null) {
          const rdaNum = state.rdaIndex + 1;
          const critNum = state.criterioIndex || 1;
          const opts = [...catSelect.options];
          const clean = t => t.replace(/[\u00A0\s]+/g, ' ').trim();
          console.log('[GAULA] Buscando categoría: rdaNum=' + rdaNum + ', critNum=' + critNum);
          console.log('[GAULA] Opciones:', opts.map(o => JSON.stringify(clean(o.textContent))));
          const option =
            opts.find(o => new RegExp(`Criterio\\s+${critNum}\\s+RDA\\s+${rdaNum}\\b`, 'i').test(clean(o.textContent))) ||
            opts.find(o => new RegExp(`^Parcial\\s+${rdaNum}\\b`, 'i').test(clean(o.textContent))) ||
            opts.find(o => new RegExp(`^RDA\\s+${rdaNum}\\b`, 'i').test(clean(o.textContent)));
          if (option) {
            console.log('[GAULA] Categoría seleccionada:', clean(option.textContent));
            gaulaSetSelect(catSelect, option.value);
          } else {
            console.warn('[GAULA] No se encontró categoría para rdaNum=' + rdaNum);
          }
        }
      }

      await gaulaWait(300);

      // Datos comunes para siguientes pasos
      const moveData = {
        taskName: task.nombre,
        sectionIndex: state.sectionIndex,
        taskIndex: state.taskIndex,
        totalTasks: state.totalTasks,
        replicateTargets: state.replicateTargets || [],
        replicateIdnumber: state.replicateIdnumber || null,
        criterioIndex: state.criterioIndex || 1
      };

      // Guardar — AWAIT para asegurar que el estado se persiste antes de navegar
      if (task.rubricaJson) {
        // Con rubrica → "Guardar cambios y mostrar" → navega a pagina de rubrica
        await gaulaSaveState({
          action: 'create_assignment',
          step: 'define_rubric',
          rubricaJson: task.rubricaJson,
          rubricName: `Rúbrica ${task.nombre}`,
          rubricDesc: `Rúbrica para evaluar: ${task.nombre}`,
          ...moveData
        });
        const saveShowBtn = gaulaByRole('button', 'Guardar cambios y mostrar');
        if (saveShowBtn) gaulaClick(saveShowBtn);
      } else {
        // Sin rubrica → "Guardar cambios y regresar al curso"
        await gaulaSaveState({
          action: 'create_assignment',
          step: 'move_task',
          ...moveData
        });
        const saveReturnBtn = gaulaByRole('button', 'Guardar cambios y regresar al');
        if (saveReturnBtn) gaulaClick(saveReturnBtn);
      }

      gaulaReportProgress(state.taskIndex + 1, state.totalTasks, 'running', { step: 'create_assignment' });

    } catch (err) {
      gaulaClearState();
      gaulaReportProgress(0, 0, 'error', { step: 'create_assignment', error: err.message });
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: define_rubric — Estamos en grade/grading, definir rubrica
  // ──────────────────────────────────────────────────────────
  if (url.includes('/grade/grading/') && state.step === 'define_rubric') {
    try {
      await gaulaWait(1500);

      // Codegen: getByRole('link', { name: 'Nuevo formulario desde cero' })
      const newFormLink = gaulaByRole('link', 'Nuevo formulario desde cero');
      if (newFormLink) {
        gaulaClick(newFormLink);
        await gaulaWait(2000);
      }

      const rubricaJson = state.rubricaJson;
      if (!rubricaJson || !rubricaJson.criterios) {
        gaulaClearState();
        return;
      }

      // Codegen: getByRole('textbox', { name: 'Nombre' })
      const nameInput = gaulaByRole('textbox', 'Nombre');
      if (nameInput) gaulaSetValue(nameInput, state.rubricName || 'Rúbrica');

      // Descripcion — usar editor Atto
      const descEditor = document.querySelector('.editor_atto_content[contenteditable="true"]');
      if (descEditor) {
        descEditor.innerHTML = state.rubricDesc || 'Rúbrica generada automáticamente';
        descEditor.dispatchEvent(new Event('input', { bubbles: true }));
      }

      // Llenar criterios — queries scopeadas a cada .criterion row
      for (let c = 0; c < rubricaJson.criterios.length; c++) {
        const criterio = rubricaJson.criterios[c];

        if (c === 0) {
          // Click en la descripcion del primer criterio para editarlo
          const firstDesc = document.querySelector('.criterion .description') ||
                            gaulaByText('Clic para editar criterio');
          if (firstDesc) {
            gaulaClick(firstDesc);
            await gaulaWait(300);
          }
        } else {
          // Agregar nuevo criterio
          const addCriterioBtn = gaulaByRole('button', 'Añadir criterio');
          if (addCriterioBtn) {
            gaulaClick(addCriterioBtn);
            await gaulaWait(500);
          }
          // Click en el nuevo criterio
          const newDesc = gaulaByText('Clic para editar criterio');
          if (newDesc) {
            gaulaClick(newDesc);
            await gaulaWait(300);
          }
        }

        // Encontrar la fila del criterio actual
        const critRows = [...document.querySelectorAll('.criterion')];
        const critRow = critRows[c];
        if (!critRow) continue;

        // Llenar nombre del criterio — buscar textarea DENTRO de esta fila
        const critTA = critRow.querySelector('.description textarea') ||
                       critRow.querySelector('textarea[name*="description"]');
        if (critTA) gaulaSetValue(critTA, criterio.nombre);

        // Agregar niveles si faltan (no asumir 3 por defecto — Moodle puede copiar estructura)
        const existingLevels = critRow.querySelectorAll('td.level').length;
        const neededLevels = criterio.niveles.length - existingLevels;
        if (neededLevels > 0) {
          for (let extra = 0; extra < neededLevels; extra++) {
            const addLevelBtn = critRow.querySelector('.addlevel input[type="submit"]') ||
                                critRow.querySelector('.addlevel button') ||
                                [...critRow.querySelectorAll('input[type="submit"], button')].find(
                                  btn => (btn.value || btn.textContent || '').includes('Añadir nivel')
                                );
            if (addLevelBtn) {
              gaulaClick(addLevelBtn);
              await gaulaWait(300);
            }
          }
        }

        // Llenar niveles — scopeado a los td.level DENTRO de este criterio
        const levelCells = critRow.querySelectorAll('td.level');
        for (let n = 0; n < criterio.niveles.length && n < levelCells.length; n++) {
          const nivel = criterio.niveles[n];
          const levelEl = levelCells[n];

          // Click en definicion para editarla
          const defArea = levelEl.querySelector('.definition');
          if (defArea) {
            gaulaClick(defArea);
            await gaulaWait(200);
          }
          // Llenar definicion (textarea dentro del nivel)
          const defTA = levelEl.querySelector('.definition textarea');
          if (defTA) gaulaSetValue(defTA, nivel.descripcion);

          // Click en score para editarlo
          const scoreArea = levelEl.querySelector('.score');
          if (scoreArea) {
            gaulaClick(scoreArea);
            await gaulaWait(200);
          }
          // Llenar puntuacion (input dentro del nivel)
          const scoreInput = levelEl.querySelector('.score input');
          if (scoreInput) gaulaSetValue(scoreInput, String(nivel.puntos));
        }

        await gaulaWait(300);
        gaulaCheckStop();
      }

      // Codegen: getByRole('button', { name: 'Guardar rúbrica y dejarla' })
      await gaulaSaveState({
        action: 'create_assignment',
        step: 'move_task',
        taskName: state.taskName,
        sectionIndex: state.sectionIndex,
        taskIndex: state.taskIndex,
        totalTasks: state.totalTasks,
        replicateTargets: state.replicateTargets || [],
        replicateIdnumber: state.replicateIdnumber || null,
        criterioIndex: state.criterioIndex || 1
      });
      const saveRubricBtn = gaulaByRole('button', 'Guardar rúbrica y dejarla');
      if (saveRubricBtn) {
        gaulaClick(saveRubricBtn);
        await gaulaWait(2000);
      }

      gaulaReportProgress(state.taskIndex + 1, state.totalTasks, 'running', { step: 'create_assignment' });

    } catch (err) {
      gaulaClearState();
      gaulaReportProgress(0, 0, 'error', { step: 'create_assignment', error: err.message });
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: move_task — Puede estar en mod/assign/view.php o course/view.php
  // ──────────────────────────────────────────────────────────

  // Despues de guardar rubrica, Moodle va a /mod/assign/view.php (vista de tarea)
  // Necesitamos navegar de vuelta al curso
  if (state.step === 'move_task' && (url.includes('/mod/assign/view.php') || url.includes('/grade/grading/'))) {
    // CAPTURAR cmid de la tarea recién creada (visible en URL). Lo necesitamos
    // para que el flujo replicate identifique LA TAREA NUEVA (no una vieja con
    // el mismo nombre) al setear cmidnumber. Solo capturamos desde mod/assign/view
    // que es el único lugar donde el cmid está en la URL.
    if (url.includes('/mod/assign/view.php')) {
      const taskCmid = new URL(url).searchParams.get('id');
      if (taskCmid && !state.taskCmid) {
        await gaulaSaveState({ ...state, taskCmid });
      }
    }
    const pathPrefixMatch = location.pathname.match(/^(\/[^\/]+)\/(course|mod|question|admin|local|theme|user|grade|backup|report|enrol|message|calendar|my|blocks)\b/);
    const baseUrl = state.baseUrl
                  || (pathPrefixMatch ? `${location.origin}${pathPrefixMatch[1]}` : null)
                  || (window.M && window.M.cfg && window.M.cfg.wwwroot)
                  || window.location.origin;
    const bodyCourseMatch = document.body.className.match(/\bcourse-(\d+)\b/);
    const courseId = (bodyCourseMatch && bodyCourseMatch[1] !== '1' ? bodyCourseMatch[1] : null)
                  || (window.M && window.M.cfg && window.M.cfg.courseId);
    if (courseId && state.sectionIndex) {
      window.location.href = `${baseUrl}/course/view.php?id=${courseId}&section=${state.sectionIndex}`;
      return;
    }
    const courseLink = document.querySelector('.breadcrumb a[href*="/course/view.php"]') ||
                       document.querySelector('a[href*="/course/view.php"]');
    if (courseLink) {
      window.location.href = courseLink.href;
    }
    return;
  }

  // Ya en el curso — mover la tarea a la seccion "Actividades"
  if (url.includes('/course/view.php') && state.step === 'move_task') {
    console.log('%c[GAULA-DEBUG] move_task branch ENTERED on course/view.php', 'color:#dc2626;font-weight:bold');
    const currentSec = new URL(url).searchParams.get('section');
    console.log('%c[GAULA-DEBUG] currentSec=' + currentSec + ' state.sectionIndex=' + state.sectionIndex, 'color:#dc2626');
    if (state.sectionIndex && currentSec !== String(state.sectionIndex)) {
      const u = new URL(url);
      u.searchParams.set('section', String(state.sectionIndex));
      u.hash = '';
      console.log('%c[GAULA-DEBUG] move_task: NAVIGATING to section=' + state.sectionIndex, 'color:#dc2626;font-weight:bold');
      location.href = u.toString();
      return;
    }
    try {
      console.log('%c[GAULA-DEBUG] move_task: SECTION OK, calling gaulaMoveLastResource', 'color:#16a34a;font-weight:bold');
      await gaulaWait(1000);
      const taskName = state.taskName;
      const totalTasks = state.totalTasks;
      const secIdx = state.sectionIndex;
      const replicateTargets = Array.isArray(state.replicateTargets) ? state.replicateTargets : [];
      const replicateIdnumber = state.replicateIdnumber || null;
      // Si hay réplicas pendientes, NO limpiamos state aún — pasamos al step
      // 'replicate_after_reload' tras reload, ya en una página fresca, sin
      // awaits de move_task compitiendo (resuelve bug "solo se crea 1 de N").
      const willReplicate = replicateTargets.length > 0 && replicateIdnumber;
      // ADITIVO / gated por host: SOLO en los campus virtuales de Quito con aulas
      // PREEXISTENTES (posgrados, oferta nacional, rutas) el anchor "PRODUCTOS Y
      // ACTIVIDADES" no existe, el move devuelve falsy y el flujo se quedaba atascado
      // en 'move_task' (rebote al curso al abrir la tarea). Ahí avanzamos igual
      // (best-effort). En el resto de sedes NO cambia nada: advance === result, que es
      // EXACTAMENTE la lógica antigua probada.
      const isPreexistingCampus = gaulaIsPreexistingQuitoCampus();
      if (!willReplicate) gaulaClearState();
      gaulaReportProgress(totalTasks, totalTasks, 'done', { step: 'create_assignment' });
      console.log('%c[GAULA-DEBUG] move_task call: secIdx=' + secIdx + ', taskName=' + taskName, 'color:#16a34a');
      const result = await gaulaMoveLastResource('PRODUCTOS Y ACTIVIDADES', taskName, secIdx, 'assignment');
      console.log('%c[GAULA-DEBUG] move_task DONE, result=' + result + ' preexistingCampus=' + isPreexistingCampus, 'color:#16a34a;font-weight:bold');

      const advance = result || isPreexistingCampus;
      if (advance && willReplicate) {
        await gaulaSaveState({
          action: 'create_assignment',
          step: 'replicate_after_reload',
          taskName,
          taskCmid: state.taskCmid || null,
          replicateTargets,
          replicateIdnumber
        });
        console.log('%c[GAULA-DEBUG] state saved for replicate_after_reload — reloading', 'color:#0891b2;font-weight:bold');
      }
      if (advance) {
        await gaulaWait(300);
        location.reload();
      }
    } catch (err) {
      console.error('%c[GAULA-DEBUG] move_task EXCEPTION:', 'color:#dc2626;font-weight:bold', err);
      // Solo en campus preexistentes limpiamos para no dejar el state atascado (rebote).
      // En el resto de sedes el comportamiento del catch queda igual que antes.
      if (gaulaIsPreexistingQuitoCampus()) gaulaClearState();
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: replicate_after_reload — corre en course/view.php tras reload.
  // Delegamos al BACKGROUND service worker porque la pestaña Moodle aborta
  // el JS cuando cambia cmidnumber (algún listener interno de Moodle hace
  // reload o invalida el contexto). El SW es independiente de la pestaña.
  // ──────────────────────────────────────────────────────────
  if (state.step === 'replicate_after_reload' && url.includes('/course/view.php')) {
    const taskName = state.taskName;
    const taskCmid = state.taskCmid || null;
    const replicateTargets = Array.isArray(state.replicateTargets) ? state.replicateTargets : [];
    const replicateIdnumber = state.replicateIdnumber || null;
    gaulaClearState();
    if (!replicateTargets.length || !replicateIdnumber) return;
    try {
      await gaulaLog('content: delegating replicate to background', { taskName, taskCmid, targetCount: replicateTargets.length });
      await gaulaWait(800);
      const baseUrl = gaulaGetWwwroot();
      const courseId = gaulaGetCourseId();
      const sesskey = gaulaGetSesskey();
      chrome.runtime.sendMessage({
        type: 'REPLICATE_TASK_GRADE',
        payload: { baseUrl, courseId, sesskey, taskName, taskCmid, idnumber: replicateIdnumber, targets: replicateTargets }
      }, (resp) => {
        // Si la pestaña sigue viva, loguear; si no, el SW ya logueó por su cuenta.
        if (chrome.runtime.lastError) return;
        gaulaLog('content: background replied', { ok: resp?.ok, summary: resp?.summary, finalIdnumber: resp?.finalIdnumber, error: resp?.error });
      });
    } catch (err) {
      await gaulaLog('content: replicate_after_reload EXCEPTION', { error: err.message });
    }
    return;
  }
})();

// ============================================================
// HELPER: Replicar nota de tarea en otros criterios via fórmula
// ============================================================
// Crea N grade items manuales (uno por target) con fórmula `=[[A{n}]]`
// que replican la nota original. Moodle recalcula automáticamente cuando
// se califica la tarea.
//
// Pasos:
//  1. Encontrar itemId de la tarea recién creada (gaulaFindGradeItemByName).
//  2. Asignar idnumber A{n} a la tarea (gaulaSetGradeItemIdnumber).
//  3. Por cada target: crear item manual + setear calculation `=[[A{n}]]`.
async function gaulaReplicateTaskGrade({ taskName, idnumber, targets }) {
  const courseId = gaulaGetCourseId();
  const baseUrl = gaulaGetWwwroot();
  await gaulaLog('REPL start', { taskName, idnumber, targetCount: targets?.length, targets });
  if (!courseId) { await gaulaLog('REPL FATAL no courseId'); return; }

  // 1. Encontrar el grade item de la tarea + cmid
  let find;
  for (let attempt = 0; attempt < 5; attempt++) {
    find = await gaulaFindGradeItemByName({ courseId, name: taskName, baseUrl });
    if (find.ok && find.cmid) break;
    await gaulaLog('REPL find attempt ' + attempt, { ok: find?.ok, cmid: find?.cmid, error: find?.error });
    await gaulaWait(800);
  }
  if (!find || !find.ok) {
    await gaulaLog('REPL FATAL task not found in gradebook', { taskName });
    return;
  }
  if (!find.cmid) {
    await gaulaLog('REPL FATAL grade item without cmid', { taskName, itemId: find.itemId });
    return;
  }
  const taskItemId = find.itemId;
  const cmid = find.cmid;
  await gaulaLog('REPL task located', { taskItemId, cmid });

  // 2a. Resolver idnumber disponible — si el preferido (ej. A1) ya está en uso
  //     por otra tarea anterior, incrementar al siguiente libre (A2, A3, ...).
  //     Sin esto, gaulaSetCmIdnumber falla porque Moodle valida unicidad.
  const resolved = await gaulaResolveAvailableIdnumber({
    courseId, sampleItemId: taskItemId, preferred: idnumber, baseUrl
  });
  const finalIdnumber = (resolved.ok ? resolved.idnumber : (resolved.fallback || idnumber));
  if (finalIdnumber !== idnumber) {
    await gaulaLog('REPL idnumber adjusted', { preferred: idnumber, finalIdnumber, used: resolved.used });
  }

  // 2b. Asignar cmidnumber del MOD
  const setIdn = await gaulaSetCmIdnumber({ cmid, idnumber: finalIdnumber, baseUrl });
  if (!setIdn.ok) {
    await gaulaLog('REPL FATAL setCmIdnumber failed', { error: setIdn.error, finalIdnumber });
    return;
  }
  await gaulaLog('REPL cmidnumber set', { idnumber: finalIdnumber, cmid });
  // Usar finalIdnumber en todas las fórmulas de réplicas
  idnumber = finalIdnumber;
  await gaulaWait(500);

  // 3. Por cada target: crear item manual + fórmula con logging detallado.
  //    Si falla el set de fórmula, intentamos borrar la réplica recién creada
  //    para no dejar huérfanas que el botón "Limpiar copias huérfanas" tenga
  //    que recoger luego.
  const summary = { total: targets.length, ok: 0, failed: [] };
  for (let i = 0; i < targets.length; i++) {
    const target = targets[i];
    const label = target.name || `cat ${target.categoryId}`;
    await gaulaLog(`REPL target ${i + 1}/${targets.length} START`, { label, categoryId: target.categoryId });
    try {
      const replicaName = `↻ ${taskName}`;
      const created = await gaulaCreateManualGradeItem({
        courseId,
        parentCategoryId: target.categoryId,
        name: replicaName,
        grademax: 50,
        idnumber: '',
        baseUrl
      });
      await gaulaLog(`REPL target ${i + 1} create result`, {
        ok: created.ok, itemId: created.itemId, error: created.error,
        retried: created.retried, repostedAndFound: created.repostedAndFound
      });
      if (!created.ok || !created.itemId) {
        summary.failed.push({ target: label, step: 'create', error: created.error });
        continue;
      }
      const calc = await gaulaSetGradeItemCalculation({
        courseId,
        itemId: created.itemId,
        formula: `=[[${idnumber}]]`,
        baseUrl
      });
      await gaulaLog(`REPL target ${i + 1} calculation result`, {
        ok: calc.ok, error: calc.error, formulaSaved: calc.formulaSaved, retried: calc.retried
      });
      if (!calc.ok) {
        const del = await gaulaDeleteGradeItem({ courseId, itemId: created.itemId, baseUrl });
        await gaulaLog(`REPL target ${i + 1} rollback delete`, { ok: del.ok, error: del.error });
        summary.failed.push({ target: label, step: 'calculation', error: calc.error });
        continue;
      }
      await gaulaLog(`REPL target ${i + 1} OK ✓`, { label });
      summary.ok++;
    } catch (e) {
      await gaulaLog(`REPL target ${i + 1} EXCEPTION`, { label, error: e.message, stack: e.stack?.slice(0, 300) });
      summary.failed.push({ target: label, step: 'exception', error: e.message });
    }
  }
  await gaulaLog('REPL DONE summary', summary);
}

// ============================================================
// HANDLER: recibe mensaje del popup para iniciar creacion
// Solo hace el primer paso (abrir chooser + click Tarea)
// y guarda estado antes de que la pagina navegue.
// ============================================================
gaulaRegisterHandler('create_assignment', async (msg, sendResponse) => {
  // Solo ejecutar en el frame principal — evita que iframes borren el estado
  if (window !== window.top) {
    sendResponse({ ok: true });
    return;
  }

  try {
    await gaulaAcquireLock('create_assignment');
    const { assignments, rdaIndex, sectionIndex, gradeCategoryValue, criterioIndex, replicateTargets, replicateIdnumber } = msg;
    const total = assignments.length;
    const task = assignments[0]; // Una tarea por ciclo

    gaulaReportProgress(0, total, 'running', { step: 'create_assignment', rdaIndex });

    // Guardar estado ANTES de navegar — la pagina se destruira al hacer click
    await gaulaSaveState({
      action: 'create_assignment',
      step: 'fill_form',
      taskData: {
        nombre: task.nombre,
        descripcionHtml: task.descripcionHtml || '',
        rubricaJson: task.rubricaJson || null,
        instrucciones: task.instrucciones || '',
        pdfSerialized: task.pdfSerialized || null,
        dateFrom: task.dateFrom || '',
        dateTo: task.dateTo || ''
      },
      gradeCategoryValue: gradeCategoryValue || null,
      criterioIndex: criterioIndex || 1,
      rdaIndex: rdaIndex,
      sectionIndex: sectionIndex || 1,
      taskIndex: 0,
      totalTasks: total,
      replicateTargets: Array.isArray(replicateTargets) ? replicateTargets : [],
      replicateIdnumber: replicateIdnumber || null
    });
    console.log('[GAULA] Estado guardado, procediendo a crear tarea...');

    await gaulaEnableEditing();

    // Abrir chooser y click "Tarea" — esto NAVEGA a modedit.php
    await gaulaOpenActivityChooser(sectionIndex || 1);
    await gaulaWait(500);
    await gaulaSearchAndClickActivity('tarea', 'Tarea');
    // Pagina navega → script muere → IIFE retoma en modedit.php con step: fill_form

    sendResponse({ ok: true });

  } catch (err) {
    gaulaClearState();
    if (err.message === 'STOPPED') {
      gaulaReportProgress(0, 0, 'stopped', { step: 'create_assignment' });
    } else {
      gaulaReportProgress(0, 0, 'error', { step: 'create_assignment', error: err.message });
    }
    sendResponse({ ok: false, error: err.message });
  }
});
