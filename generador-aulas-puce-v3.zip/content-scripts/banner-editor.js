/**
 * Generador de Aulas - Editor del banner principal del curso.
 * Edita la primera etiqueta (label) de la sección 0 que contiene el banner.
 *
 * Flujo multi-página (codegen):
 * 1. (Curso) Clic en action-menu-toggle de la etiqueta → "Editar ajustes"
 * 2. (Formulario) "Mostrar/ocultar botones" → "HTML" → reemplazar contenido → Guardar
 */

// Al cargar, verificar si hay una edición de banner pendiente
(async function checkBannerState() {
  const state = await gaulaGetState();
  if (!state || state.action !== 'edit_banner') return;

  const url = window.location.href;

  try {
    // ============================================================
    // PASO 2: Estamos en el formulario de edición de la etiqueta
    // ============================================================
    if (url.includes('/course/modedit.php') && state.step === 'fill_banner') {
      await gaulaWait(2000);
      gaulaReportProgress(2, 3, 'running', { step: 'Editando banner...' });

      // Inyectar HTML directo en los editores Atto (contenteditable)
      const attoEditors = document.querySelectorAll('.editor_atto_content[contenteditable="true"]');
      if (attoEditors.length > 0) {
        // El editor principal de la etiqueta (Texto de la etiqueta)
        const editor = attoEditors[0];
        editor.focus();
        editor.innerHTML = state.bannerHtml;
        editor.dispatchEvent(new Event('input', { bubbles: true }));
        editor.dispatchEvent(new Event('change', { bubbles: true }));
        await gaulaWait(300);
      }

      // Actualizar textareas ocultos asociados
      const hiddenTextareas = document.querySelectorAll('textarea[id^="id_introeditor"]');
      for (const ta of hiddenTextareas) {
        ta.value = state.bannerHtml;
      }

      await gaulaWait(500);
      gaulaReportProgress(3, 3, 'running', { step: 'Guardando banner...' });

      // Preparar estado para continuar con la cola de secciones después de guardar
      if (state.pendingQueue && state.pendingQueue.length > 0) {
        await gaulaSaveState({
          action: 'edit_section_queue',
          step: 'next_in_queue',
          queue: state.pendingQueue,
          queueIndex: 0,
          courseUrl: state.courseUrl,
          lastTargetSection: null,
          lastResourceName: null
        });
      } else {
        gaulaClearState();
      }

      // Guardar cambios y regresar al curso
      const saveBtn = document.querySelector('#id_submitbutton2') ||
                      gaulaByRole('button', 'Guardar cambios y regresar') ||
                      document.querySelector('#id_submitbutton');
      if (saveBtn) {
        gaulaReportProgress(1, 1, 'done', { step: 'Banner actualizado' });
        gaulaClick(saveBtn);
      } else {
        gaulaClearState();
        gaulaReportProgress(0, 0, 'error', { step: 'edit_banner', error: 'No se encontró botón guardar' });
      }
      return;
    }

  } catch (err) {
    gaulaClearState();
    gaulaReportProgress(0, 0, 'error', { step: 'edit_banner', error: err.message });
  }
})();

// Handler para editar el banner desde el popup
gaulaRegisterHandler('edit_banner', async (msg, sendResponse) => {
  try {
    await gaulaAcquireLock('edit_banner');
    const { bannerHtml, pendingQueue, courseUrl } = msg;
    gaulaReportProgress(0, 3, 'running', { step: 'Editando banner del curso...' });

    if (!window.location.href.includes('/course/view.php')) {
      sendResponse({ ok: false, error: 'Debes estar en la página del curso.' });
      return;
    }

    // Quito (format-onetopic): NO existe un "banner editable" en section-0.
    // La primera actividad típica es el foro "Avisos" — sobrescribirlo destruiría
    // contenido funcional del docente. Skip banner edit y procesar solo el queue
    // (la página "Información del Curso").
    if (document.body.classList.contains('format-onetopic')) {
      console.log('[GAULA 3.0] Quito format-onetopic: skip banner edit, procesando solo queue.');
      if (!pendingQueue || pendingQueue.length === 0) {
        gaulaClearState();
        gaulaReportProgress(0, 0, 'done', { step: 'Quito: banner no modificado (sin queue tampoco)' });
        sendResponse({ ok: true, message: 'En Quito no se modifica el banner. Nada que crear sin queue.' });
        return;
      }
      await gaulaEnableEditing();
      await gaulaWait(500);
      const first = pendingQueue[0];
      gaulaReportProgress(1, 3, 'running', { step: `Creando ${first.pageName} en sección ${first.sectionIndex || 0}...` });
      await gaulaOpenActivityChooser(first.sectionIndex || 0);
      await gaulaWait(1000);
      await gaulaSaveState({
        action: 'edit_section',
        step: 'fill_form',
        sectionType: first.sectionType,
        htmlContent: first.htmlContent,
        pageName: first.pageName,
        queue: pendingQueue,
        queueIndex: 0,
        courseUrl: courseUrl || window.location.href
      });
      await gaulaSearchAndClickActivity('texto', 'Área de texto y medios');
      sendResponse({ ok: true, message: 'Quito: creando "Información del Curso" sin tocar el banner...' });
      return;
    }

    await gaulaEnableEditing();
    await gaulaWait(500);

    // Buscar la primera etiqueta en la sección 0 (el banner)
    // Las etiquetas tienen action-menu-toggle con menú que incluye "Editar ajustes"
    // Buscamos el primer action-menu-toggle en la sección 0
    const section0 = document.querySelector('#coursecontentcollapse0') ||
                     document.querySelector('[data-sectionid="0"]') ||
                     document.querySelector('.course-content');

    if (!section0) {
      sendResponse({ ok: false, error: 'No se encontró la sección 0 del curso.' });
      return;
    }

    // Buscar la primera actividad que contenga el banner (buscar por clase bannerfloat o por ser la primera label)
    const allMenus = section0.querySelectorAll('[id^="action-menu-toggle-"]');
    if (allMenus.length === 0) {
      sendResponse({ ok: false, error: 'No se encontraron elementos editables en la sección 0.' });
      return;
    }

    // El banner es típicamente la primera etiqueta/actividad en la sección 0
    const firstMenu = allMenus[0];
    gaulaReportProgress(1, 3, 'running', { step: 'Abriendo editor del banner...' });

    gaulaClick(firstMenu);
    await gaulaWait(500);

    // Clic en "Editar ajustes"
    const editItem = await gaulaWaitForRole('menuitem', 'Editar ajustes', { timeout: 5000 });
    if (!editItem) {
      sendResponse({ ok: false, error: 'No se encontró "Editar ajustes" en el menú.' });
      return;
    }

    // Guardar estado antes de navegar
    await gaulaSaveState({
      action: 'edit_banner',
      step: 'fill_banner',
      bannerHtml,
      pendingQueue: pendingQueue || [],
      courseUrl: courseUrl || window.location.href
    });

    gaulaClick(editItem);
    sendResponse({ ok: true, message: 'Navegando al editor del banner...' });

  } catch (err) {
    gaulaClearState();
    if (err.message === 'STOPPED') {
      gaulaReportProgress(0, 0, 'stopped', { step: 'edit_banner' });
    } else {
      gaulaReportProgress(0, 0, 'error', { step: 'edit_banner', error: err.message });
    }
    sendResponse({ ok: false, error: err.message });
  }
});

// ============================================================
// set_course_banner — sube un SVG temático al overviewfiles del curso
// Visible para TODOS (estudiantes incluidos) porque Moodle lo usa como
// background-image del banner del tema PUCE.
// ============================================================
gaulaRegisterHandler('set_course_banner', async (msg, sendResponse) => {
  try {
    const { courseId } = msg;
    if (!courseId) {
      sendResponse({ ok: false, error: 'courseId requerido' });
      return;
    }
    await gaulaSaveState({
      action: 'set_course_banner',
      step: 'fill_overviewfiles',
      courseId,
      filename: msg.filename || 'gaula-banner-tema.svg'
    });
    gaulaReportProgress(1, 3, 'running', { step: 'Abriendo configuración del curso...' });
    window.location.href = gaulaCourseEditUrl(courseId);
    sendResponse({ ok: true, message: 'Navegando a Configuración del curso...' });
  } catch (e) {
    gaulaClearState();
    sendResponse({ ok: false, error: e.message });
  }
});

// IIFE: cuando aterriza en course/edit.php con state pendiente, rellena el filemanager.
(async function checkSetCourseBannerState() {
  const state = await gaulaGetState();
  console.log('[GAULA banner IIFE] init, url=', window.location.href, 'state=', state ? `${state.action}/${state.step}` : 'null');
  if (!state || state.action !== 'set_course_banner') return;

  // Step 'navigate_to_edit': estamos en course/view.php tras terminar la cola del sílabo.
  // Navegamos a course/edit.php para que el siguiente paso (fill_overviewfiles) corra.
  if (state.step === 'navigate_to_edit' && window.location.href.includes('/course/view.php')) {
    console.log('[GAULA banner IIFE] navigate_to_edit step detected → navegando a edit.php');
    await gaulaWait(1500);
    gaulaReportProgress(1, 3, 'running', { step: 'Aplicando banner del tema al curso...' });
    await gaulaSaveState({ ...state, step: 'fill_overviewfiles' });
    window.location.href = gaulaCourseEditUrl(state.courseId);
    return;
  }

  if (state.step !== 'fill_overviewfiles') {
    console.log('[GAULA banner IIFE] step no es fill_overviewfiles, salida temprana. step=', state.step);
    return;
  }
  if (!window.location.href.includes('/course/edit.php')) {
    console.log('[GAULA banner IIFE] url no es edit.php, salida temprana. url=', window.location.href);
    return;
  }
  console.log('[GAULA banner IIFE] entrando al try block del upload XHR');

  try {
    await gaulaWait(1200);
    gaulaReportProgress(2, 3, 'running', { step: 'Subiendo SVG temático...' });

    // 1) Leer SVG serializado del storage
    const fileSerialized = await gaulaGetFile(0);
    if (!fileSerialized) throw new Error('No se encontró el SVG en storage');
    const file = gaulaDeserializeFile(fileSerialized);

    // 2) Extraer params del form. NO podemos acceder a `M` (Moodle global) porque vive
    // en el main world y el content script corre en isolated world. Leemos todo del DOM.
    const sesskeyInput = document.querySelector('input[name="sesskey"]');
    const sesskey = sesskeyInput?.value;
    const itemidInput = document.querySelector('input[name="overviewfiles_filemanager"]');
    const itemid = itemidInput?.value;
    // wwwroot lo derivamos de la URL actual
    const pathMatch = window.location.pathname.match(/^(.*?)\/course\/[a-z]+\.php/i);
    const wwwroot = `${window.location.origin}${pathMatch ? pathMatch[1] : ''}`;
    if (!sesskey || !itemid) throw new Error(`No se encontró sesskey (${!!sesskey}) o itemid (${!!itemid}) en el form`);

    // contextid + uploadRepoId los extraemos de los scripts inline (vienen del init del filemanager)
    const allScripts = Array.from(document.querySelectorAll('script')).map(s => s.textContent || '').join('\n');
    const ctxMatch = allScripts.match(/"context":\{"id":(\d+),"contextlevel":50/);
    const contextId = ctxMatch ? parseInt(ctxMatch[1]) : null;
    const uploadRepoMatch = allScripts.match(/"(\d+)":\{"id":"\1","name":"Subir un archivo","type":"upload"/);
    const uploadRepoId = uploadRepoMatch ? parseInt(uploadRepoMatch[1]) : null;
    if (!contextId || !uploadRepoId) throw new Error(`No se encontró contextId (${contextId}) o uploadRepoId (${uploadRepoId}) en page scripts`);

    console.log('[GAULA banner] XHR params:', { itemid, contextId, uploadRepoId, fileSize: file.size });

    // 3a) LISTAR archivos existentes en el draft area
    const listResp = await fetch(`${wwwroot}/repository/draftfiles_ajax.php?action=list`, {
      method: 'POST', credentials: 'include',
      body: new URLSearchParams({ sesskey, itemid: String(itemid), filepath: '/' })
    });
    const listData = await listResp.json();
    const existingFiles = listData.list || [];
    console.log('[GAULA banner] archivos existentes:', existingFiles.length, existingFiles.map(f => f.filename));

    // 3b) BORRAR cada archivo existente (maxfiles=1 — el save rechaza si quedan stale)
    for (const f of existingFiles) {
      const delResp = await fetch(`${wwwroot}/repository/draftfiles_ajax.php?action=delete`, {
        method: 'POST', credentials: 'include',
        body: new URLSearchParams({ sesskey, itemid: String(itemid), filename: f.filename, filepath: f.filepath || '/' })
      });
      const delData = await delResp.json().catch(() => ({}));
      console.log('[GAULA banner] borrado:', f.filename, '→', delData);
    }

    // 3c) SUBIR el nuevo SVG via repository_ajax.php (más rápido que dnd, no enforza maxfiles)
    const fd = new FormData();
    fd.append('sesskey', sesskey);
    fd.append('repo_id', String(uploadRepoId));
    fd.append('itemid', String(itemid));
    fd.append('ctx_id', String(contextId));
    fd.append('savepath', '/');
    fd.append('title', file.name);
    fd.append('author', 'GAULA Banner');
    fd.append('license', 'unknown');
    fd.append('repo_upload_file', file);

    const uploadUrl = `${wwwroot}/repository/repository_ajax.php?action=upload`;
    const r = await fetch(uploadUrl, { method: 'POST', credentials: 'include', body: fd });
    const respText = await r.text();
    let resp;
    try { resp = JSON.parse(respText); } catch (_) { resp = { raw: respText }; }
    if (resp.error) throw new Error('Upload rechazado: ' + resp.error);
    console.log('[GAULA banner] XHR upload OK:', resp.file || resp.url?.split('/').pop());

    // 4) Click "Guardar cambios y mostrar" (vuelve al course view automáticamente)
    await gaulaWait(300);
    gaulaReportProgress(3, 3, 'running', { step: 'Guardando configuración...' });
    const saveBtn = document.querySelector('#id_saveanddisplay');
    if (!saveBtn) throw new Error('No se encontró el botón "Guardar cambios y mostrar"');

    // Nota: el formchangechecker de Moodle dispara beforeunload SOLO al navegar fuera,
    // no al hacer submit del propio form. El click sobre #id_saveanddisplay es un submit
    // normal del form, así que no debería disparar el dialog.
    // (Antes intentaba inyectar un <script> que llamaba M.core_formchangechecker.set_form_submitted()
    //  pero la CSP de Moodle bloquea inline scripts en isolated world.)

    // Limpiar el SVG temporal del storage (ya no lo necesitamos)
    chrome.storage.local.remove('gaula_file_0').catch(() => {});
    gaulaClearState();
    console.log('[GAULA banner IIFE] clicking saveBtn:', saveBtn.id, 'value:', saveBtn.value);
    gaulaClick(saveBtn);
    gaulaReportProgress(3, 3, 'done', { step: '🎨 Banner del tema aplicado' });
  } catch (err) {
    console.error('[GAULA set_course_banner]', err);
    gaulaClearState();
    gaulaReportProgress(0, 0, 'error', { step: 'set_course_banner', error: err.message });
  }
})();
