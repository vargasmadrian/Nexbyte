/**
 * Generador de Aulas - Crear cuestionarios/evaluaciones en Moodle.
 * Selectores verificados con Playwright Codegen (2026-04-08 / 2026-04-09).
 *
 * Flujo con maquina de estados:
 *   1. course/view.php → handler guarda estado, click "Cuestionario" → NAVEGA a modedit.php
 *   2. modedit.php (step: fill_quiz_form) → Llenar nombre, fechas, tiempo, etc. → Guardar → NAVEGA
 *   3. mod/quiz/view.php (step: goto_import) → "Mas" → "Banco de preguntas" → select import
 *   4. importquestions (step: fill_import_form) → Formato Aiken, subir archivo, Importar
 *   5. (step: after_import) → Click "Continuar"
 *   6. (step: goto_quiz_edit) → Click "Preguntas" para ir a quiz/edit.php
 *   7. mod/quiz/edit.php (step: add_questions) → Agregar del banco, seleccionar todas, añadir
 *   8. (step: navigate_course) → Volver al curso
 *   9. course/view.php (step: move_quiz) → Mover a seccion "Evaluacion"
 */

// ============================================================
// MAQUINA DE ESTADOS — se ejecuta al cargar cada pagina
// ============================================================
(async function checkQuizState() {
  if (window !== window.top) return;

  const state = await gaulaGetState();
  if (!state || state.action !== 'create_quiz') return;

  const url = window.location.href;

  // ──────────────────────────────────────────────────────────
  // STEP: fill_quiz_form — Estamos en modedit.php, llenar formulario
  // ──────────────────────────────────────────────────────────
  if (url.includes('/modedit.php') && state.step === 'fill_quiz_form') {
    try {
      const quiz = state.quizData;
      await gaulaWait(1500);

      const nameInput = await gaulaWaitForRole('textbox', 'Nombre');
      if (nameInput) {
        gaulaClick(nameInput);
        await gaulaWait(200);
        gaulaSetValue(nameInput, quiz.nombre);
      }
      await gaulaWait(300);

      // Descripción temática (Atto editor → contenteditable, iframe, o textarea)
      if (quiz.quizIntroHtml) {
        const attoEditor = document.querySelector('div[id^="id_introeditoreditable"]') ||
                           document.querySelector('div[contenteditable="true"][role="textbox"]');
        if (attoEditor) attoEditor.innerHTML = quiz.quizIntroHtml;
        const iframe = document.querySelector('iframe[id^="id_introeditor"]');
        if (iframe && iframe.contentDocument && iframe.contentDocument.body) {
          iframe.contentDocument.body.innerHTML = quiz.quizIntroHtml;
        }
        const ta = document.querySelector('textarea[name="introeditor[text]"]') ||
                   document.querySelector('textarea[id^="id_introeditor"]');
        if (ta) ta.value = quiz.quizIntroHtml;

        // Mostrar descripción en la página del curso
        const showDesc = document.querySelector('#id_showdescription');
        if (showDesc && !showDesc.checked) { gaulaClick(showDesc); await gaulaWait(200); }
        await gaulaWait(300);
      }

      // ── Temporalizacion ──
      const timeBtn = gaulaByRole('button', 'Temporalización') ||
                      gaulaByText('Temporalización', 'button');
      if (timeBtn) {
        gaulaClick(timeBtn);
        await gaulaWait(500);
      }

      if (quiz.dateFrom || quiz.dateTo) {
        const hFrom = String(quiz.hourFrom || 0).padStart(2, '0');
        const mFrom = String(quiz.minFrom || 0).padStart(2, '0');
        const hTo = String(quiz.hourTo || 23).padStart(2, '0');
        const mTo = String(quiz.minTo || 55).padStart(2, '0');
        const fromDate = quiz.dateFrom ? new Date(quiz.dateFrom + 'T' + hFrom + ':' + mFrom + ':00') : null;
        const toDate = quiz.dateTo ? new Date(quiz.dateTo + 'T' + hTo + ':' + mTo + ':00') : null;

        if (fromDate) {
          const openGroup = gaulaFindDateGroup('id_timeopen', 'Abrir cuestionario');
          if (openGroup) {
            const enableCheck = openGroup.querySelector('input[type="checkbox"]');
            if (enableCheck && !enableCheck.checked) {
              gaulaClick(enableCheck);
              await gaulaWait(300);
            }
            gaulaSetDateGroup(openGroup, fromDate);
            await gaulaWait(200);
          }
        }

        if (toDate) {
          const closeGroup = gaulaFindDateGroup('id_timeclose', 'Cerrar cuestionario');
          if (closeGroup) {
            const enableCheck = closeGroup.querySelector('input[type="checkbox"]');
            if (enableCheck && !enableCheck.checked) {
              gaulaClick(enableCheck);
              await gaulaWait(300);
            }
            gaulaSetDateGroup(closeGroup, toDate);
            await gaulaWait(200);
          }
        }
      }

      // Limite de tiempo
      if (quiz.timeLimit) {
        const timeLimitGroup = gaulaFindDateGroup('id_timelimit', 'Límite de tiempo');
        if (timeLimitGroup) {
          const enableCheck = timeLimitGroup.querySelector('input[type="checkbox"]');
          if (enableCheck && !enableCheck.checked) {
            gaulaClick(enableCheck);
            await gaulaWait(300);
          }
          const timeInput = timeLimitGroup.querySelector('input[type="text"]') ||
                            timeLimitGroup.querySelector('input[type="number"]');
          if (timeInput) gaulaSetValue(timeInput, String(quiz.timeLimit));
        }
      }

      // ── Calificacion ──
      const gradeBtn = gaulaByRole('button', 'Calificación') ||
                       gaulaByText('Calificación', 'button');
      if (gradeBtn) {
        gaulaClick(gradeBtn);
        await gaulaWait(500);
      }

      // Calificación máxima 50 (consistente con tareas; Moodle escala las
      // preguntas internas al rango definido aquí).
      const maxGradeInput = gaulaByLabel('Calificación máxima');
      if (maxGradeInput) gaulaSetValue(maxGradeInput, '50');

      // Categoria de calificaciones — busca en cascada por lo que exista en Moodle:
      // 1. "Criterio X RDA N" (repotenciada con criterios)
      // 2. "Parcial N" (no repotenciada — N = rdaNum)
      // 3. "RDA N" (repotenciada sin criterios)
      const catSelect = gaulaByLabel('Categoría de calificaciones');
      if (catSelect) {
        if (state.gradeCategoryValue) {
          gaulaSetSelect(catSelect, state.gradeCategoryValue);
        } else if (state.rdaIndex != null) {
          const rdaNum = state.rdaIndex + 1;
          const critNum = state.criterioIndex || 1;
          const opts = [...catSelect.options];
          const clean = t => t.replace(/[\u00A0\s]+/g, ' ').trim();
          console.log('[GAULA] Quiz: Buscando categoría: rdaNum=' + rdaNum + ', critNum=' + critNum);
          console.log('[GAULA] Quiz: Opciones:', opts.map(o => JSON.stringify(clean(o.textContent))));
          const option =
            opts.find(o => new RegExp(`Criterio\\s+${critNum}\\s+RDA\\s+${rdaNum}\\b`, 'i').test(clean(o.textContent))) ||
            opts.find(o => new RegExp(`^Parcial\\s+${rdaNum}\\b`, 'i').test(clean(o.textContent))) ||
            opts.find(o => new RegExp(`^RDA\\s+${rdaNum}\\b`, 'i').test(clean(o.textContent)));
          if (option) {
            console.log('[GAULA] Quiz: Categoría seleccionada:', clean(option.textContent));
            gaulaSetSelect(catSelect, option.value);
          } else {
            console.warn('[GAULA] Quiz: No se encontró categoría para rdaNum=' + rdaNum);
          }
        }
      }

      const gradePassInput = gaulaByLabel('Calificación para aprobar');
      if (gradePassInput) gaulaSetValue(gradePassInput, '');

      const attemptsSelect = gaulaByLabel('Intentos permitidos');
      if (attemptsSelect) gaulaSetSelect(attemptsSelect, '1');

      // ── Esquema ──
      const schemaBtn = gaulaByRole('button', 'Esquema') ||
                        gaulaByText('Esquema', 'button');
      if (schemaBtn) {
        gaulaClick(schemaBtn);
        await gaulaWait(300);
        const moreBtn = gaulaByRole('button', 'Mostrar más');
        if (moreBtn) {
          gaulaClick(moreBtn);
          await gaulaWait(300);
        }
        const navSelect = gaulaByLabel('Método de navegación');
        if (navSelect) gaulaSetSelect(navSelect, 'sequential');
      }

      // ── Restricciones: Contrasena ──
      if (quiz.password) {
        const restrictBtn = gaulaByRole('button', 'Restricciones extra sobre') ||
                            gaulaByText('Restricciones extra', 'button');
        if (restrictBtn) {
          gaulaClick(restrictBtn);
          await gaulaWait(300);
        }
        const pwReveal = gaulaByRole('link', 'Haz click para insertar texto');
        if (pwReveal) {
          gaulaClick(pwReveal);
          await gaulaWait(300);
        }
        const pwInput = gaulaByRole('textbox', 'Se requiere contraseña') ||
                        gaulaByLabel('Se requiere contraseña');
        if (pwInput) gaulaSetValue(pwInput, quiz.password);
      }

      await gaulaWait(300);

      // Decidir siguiente paso
      const hasAiken = state.aikenText && state.aikenText.trim().length > 0;
      const hasXml = state.xmlText && state.xmlText.trim().length > 0;
      // En randomMode las preguntas vienen en state.banks (no en state.aikenText),
      // así que también consideramos "hay preguntas" si hay al menos un banco con aikenText.
      const hasBanks = state.randomMode && Array.isArray(state.banks) &&
                       state.banks.some(b => b.aikenText && b.aikenText.trim().length > 0);
      const hasQuestions = hasAiken || hasXml || hasBanks;
      const nextStep = hasQuestions ? 'goto_import' : 'navigate_course';

      await gaulaSaveState({
        ...state,                  // ← preserva randomMode, banks, currentBankIdx, etc.
        action: 'create_quiz',
        step: nextStep,
        quizName: quiz.nombre,
        sectionIndex: state.sectionIndex,
        taskIndex: state.taskIndex,
        totalTasks: state.totalTasks,
        aikenText: state.aikenText || '',
        xmlText: state.xmlText || '',
        xmlFileName: state.xmlFileName || ''
      });

      // Codegen: getByRole('button', { name: 'Guardar cambios y mostrar' }).click()
      const saveBtn = gaulaByRole('button', 'Guardar cambios y mostrar');
      if (saveBtn) gaulaClick(saveBtn);

      gaulaReportProgress(state.taskIndex + 1, state.totalTasks, 'running', { step: 'create_quiz' });

    } catch (err) {
      gaulaClearState();
      gaulaReportProgress(0, 0, 'error', { step: 'create_quiz', error: err.message });
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: goto_import — Desde quiz view, navegar a importar preguntas
  // Codegen: "Mas" → "Banco de preguntas" → select import option
  // ──────────────────────────────────────────────────────────
  if (state.step === 'goto_import' && url.includes('/mod/quiz/view.php')) {
    try {
      await gaulaWait(1000);

      // Extraer cmid del quiz desde la URL
      const quizCmid = new URL(url).searchParams.get('id') || '';

      // baseUrl: derivar del location actual preservando el prefix tipo /QUI-202601R/.
      // M.cfg.wwwroot a veces falla; location.origin dropea el path-prefix de la sede.
      const pathPrefixMatch = location.pathname.match(/^(\/[^\/]+)\/(course|mod|question|admin|local|theme|user|grade|backup|report|enrol|message|calendar|my|blocks)\b/);
      const baseUrl = pathPrefixMatch
        ? `${location.origin}${pathPrefixMatch[1]}`
        : ((window.M && window.M.cfg && window.M.cfg.wwwroot) || location.origin);

      // URL ?cmid=X funciona en ambos (PUCESE y Quito) y expone la opción
      // "Por defecto en [QuizName]" en el form de import (categoría del contexto
      // del quiz). Importar ahí evita contaminar el banco de preguntas del curso
      // y permite cleanup automático al borrar el quiz.
      // PRE-FETCH del import HTML para descubrir el value de "Por defecto en {QuizName}"
      // y armar la URL final con ?cat=catid,contextid. Esto hace que Moodle preseleccione
      // la cat correcta server-side y evita el flaky setSelect (Moodle reactive theme
      // a veces reescribe la selección con la "last used" cacheada).
      let catParam = '';
      try {
        const probeUrl = `${baseUrl}/question/bank/importquestions/import.php?cmid=${quizCmid}`;
        const probeResp = await fetch(probeUrl, { credentials: 'include' });
        const probeHtml = await probeResp.text();
        // Extraer todas las <option value="N,M">label</option> del select id="id_category"
        const selectMatch = probeHtml.match(/<select[^>]*id="id_category"[^>]*>([\s\S]*?)<\/select>/i);
        const optionsSection = selectMatch ? selectMatch[1] : probeHtml;
        const optionRe = /<option\s+value="(\d+%?,?\d*|\d+,\d+)"[^>]*>([\s\S]*?)<\/option>/gi;
        const optionTuples = [];
        let m;
        while ((m = optionRe.exec(optionsSection)) !== null) {
          const value = m[1].replace('%2C', ',');
          const text = m[2].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/[\s ]+/g, ' ').trim();
          optionTuples.push({ value, text });
        }
        const quizNameLower = (state.quizName || '').toLowerCase();
        const targetOpt = optionTuples.find(o => /por defecto en/i.test(o.text) && o.text.toLowerCase().includes(quizNameLower)) ||
                          optionTuples.find(o => o.text.toLowerCase().includes(quizNameLower) && !/superior para/i.test(o.text));
        if (targetOpt) {
          catParam = '&cat=' + encodeURIComponent(targetOpt.value);
          state.quizCatValue = targetOpt.value;  // guardamos para override en submit
          console.log('[GAULA] goto_import: cat resuelto via prefetch -> ' + targetOpt.text + ' value=' + targetOpt.value);
        } else {
          console.warn('[GAULA] goto_import: NO se encontró "Por defecto en ' + state.quizName + '" en HTML del prefetch. Continuando sin &cat=.');
        }
      } catch (e) {
        console.warn('[GAULA] goto_import: prefetch falló, continuando sin &cat=:', e.message);
      }

      // ── MULTI-BANCO (randomMode) ─────────────────────────────
      // Si está activado el toggle "Preguntas aleatorias", creamos una cat
      // por cada banco (hijas de "Por defecto en {quizName}" en contexto
      // módulo del quiz). Después navegamos al import del primer banco.
      // Las cats se borran automáticamente cuando el quiz se elimina.
      if (state.randomMode && Array.isArray(state.banks) && state.banks.length > 0 && state.quizCatValue) {
        console.log('[GAULA] randomMode ON, creando ' + state.banks.length + ' bancos...');
        const banks = state.banks.map(b => ({ ...b }));  // copia mutable
        for (let i = 0; i < banks.length; i++) {
          const bank = banks[i];
          try {
            const result = await gaulaCreateQuestionCategory({
              cmid: quizCmid,
              name: bank.name || ('Banco ' + (i + 1)),
              parentValue: state.quizCatValue,
              baseUrl
            });
            if (result.ok && result.catValue) {
              banks[i].catValue = result.catValue;
              console.log('[GAULA] banco ' + (i + 1) + ' "' + bank.name + '" → catValue=' + result.catValue);
            } else {
              console.warn('[GAULA] banco ' + (i + 1) + ' fallo cat creation: ' + result.error + '. Fallback a cat default.');
              banks[i].catValue = state.quizCatValue;
            }
          } catch (e) {
            console.warn('[GAULA] excepcion creando cat banco ' + (i + 1) + ':', e.message);
            banks[i].catValue = state.quizCatValue;
          }
        }
        // Cargar el primer banco como aikenText/quizCatValue para fill_import_form
        const first = banks[0];
        await gaulaSaveState({
          ...state,
          step: 'fill_import_form',
          quizCmid: quizCmid,
          baseUrl: baseUrl,
          banks: banks,
          currentBankIdx: 0,
          aikenText: first.aikenText || '',
          quizCatValue: first.catValue
        });
        const importUrlMulti = `${baseUrl}/question/bank/importquestions/import.php?cmid=${quizCmid}&cat=${encodeURIComponent(first.catValue)}`;
        console.log('[GAULA] goto_import (random) → banco 1 → ' + importUrlMulti);
        window.location.href = importUrlMulti;
        return;
      }

      // Flow SIMPLE (toggle OFF): comportamiento original.
      await gaulaSaveState({
        ...state,
        step: 'fill_import_form',
        quizCmid: quizCmid,
        baseUrl: baseUrl,
        quizCatValue: state.quizCatValue  // explicitly pass for override
      });

      const importUrl = `${baseUrl}/question/bank/importquestions/import.php?cmid=${quizCmid}${catParam}`;
      console.log('[GAULA] goto_import → ' + importUrl);
      window.location.href = importUrl;

    } catch (err) {
      // Si falla, continuar sin importar
      await gaulaSaveState({ ...state, step: 'navigate_course', aikenText: '' });
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: fill_import_form — En pagina de importar preguntas
  // Codegen: Formato Aiken → Seleccione archivo → Adjunto → setInputFiles → Subir → Importar
  // ──────────────────────────────────────────────────────────
  if (url.includes('/importquestions/') && state.step === 'fill_import_form') {
    try {
      await gaulaWait(1500);

      const useXml = !!(state.xmlText);
      const formatValue = useXml ? 'xml' : 'aiken';
      const formatLabel = useXml ? 'Formato XML de Moodle' : 'Formato Aiken';

      // 1. Seleccionar formato (Aiken o XML de Moodle)
      const formatRadio = [...document.querySelectorAll('input[type="radio"]')].find(r =>
        r.value === formatValue
      );
      if (formatRadio) {
        gaulaClick(formatRadio);
        await gaulaWait(500);
      } else {
        const fmtLabel = [...document.querySelectorAll('label, span')].find(el =>
          el.textContent.trim() === formatLabel
        );
        if (fmtLabel) {
          gaulaClick(fmtLabel);
          await gaulaWait(500);
        }
      }

      // 2. Codegen: getByRole('button', { name: '# General' }).click()
      //    Expandir seccion General para ver la categoria
      const generalBtn = gaulaByRole('button', 'General') ||
                         [...document.querySelectorAll('button, a')].find(el =>
                           el.textContent.trim().includes('General') && el.getAttribute('aria-expanded') !== undefined
                         );
      if (generalBtn) {
        gaulaClick(generalBtn);
        await gaulaWait(500);
      }

      // 3. Codegen: getByLabel('Categoría a donde importar').selectOption(...)
      //    PUCESE: la categoría "Por defecto en [QuizName]" existe en el contexto del quiz.
      //    Quito: usamos ?courseid → solo aparecen categorías del banco de curso, no del quiz.
      //    Guardamos la categoría finalmente seleccionada en state para que add_questions
      //    la pueda re-seleccionar en el modal de añadir preguntas.
      const catSelect = gaulaByLabel('Categoría a donde importar') ||
                        document.getElementById('id_category');
      let importCategoryText = null;
      if (catSelect) {
        // Poll por la opción "Por defecto en {quizName}" — a veces Moodle no la
        // expone instantáneamente al cargar el form (la crea on-demand). Si
        // intentamos seleccionar antes de que aparezca, caemos a la default
        // de Moodle (que puede ser una cat con preguntas existentes → mezcla).
        async function _gaulaWaitForQuizCat() {
          if (!state.quizName) return null;
          const lowerQuiz = state.quizName.toLowerCase();
          const norm = t => t.replace(/[\s ]+/g, ' ').trim();
          for (let attempt = 0; attempt < 6; attempt++) {
            const opts = [...catSelect.options];
            const found =
              opts.find(o => /por defecto en/i.test(norm(o.textContent)) && norm(o.textContent).toLowerCase().includes(lowerQuiz)) ||
              opts.find(o => norm(o.textContent).toLowerCase().includes(lowerQuiz) && !/superior para/i.test(norm(o.textContent))) ||
              opts.find(o => norm(o.textContent).toLowerCase().includes(lowerQuiz));
            if (found) return found;
            await gaulaWait(350);
          }
          return null;
        }
        const _quizCat = await _gaulaWaitForQuizCat();
        // NO hacer setSelect — el theme puce dispara JS reactivo que devuelve
        // la cat a "last used" (= "ad"). Confiamos en `&cat=` del URL que
        // goto_import añadió: server-side preselecciona la cat correcta y NO
        // disparamos un change client-side que el reactive theme pueda revertir.
        if (_quizCat && catSelect.value !== _quizCat.value) {
          console.warn('[GAULA] La cat pre-seleccionada NO es la del quiz. URL hasCat=' + new URL(url).searchParams.has('cat') + '. Selected=' + catSelect.value + ' Expected=' + _quizCat.value);
        } else if (!_quizCat && state.quizName) {
          console.warn('[GAULA] No apareció "Por defecto en ' + state.quizName + '" en el dropdown.');
        } else if (_quizCat) {
          console.log('[GAULA] cat pre-seleccionada por URL OK -> value=' + catSelect.value);
        }
        if (false && state.quizName) {
          const opts = [...catSelect.options];
          const lowerQuiz = state.quizName.toLowerCase();
          const norm = t => t.replace(/[\s ]+/g, ' ').trim();
          // Preferir "Por defecto en X" (hoja con preguntas), evitar "Superior para X" (padre vacio).
          const quizCatOption =
            opts.find(o => /por defecto en/i.test(norm(o.textContent)) && norm(o.textContent).toLowerCase().includes(lowerQuiz)) ||
            opts.find(o => norm(o.textContent).toLowerCase().includes(lowerQuiz) && !/superior para/i.test(norm(o.textContent))) ||
            opts.find(o => norm(o.textContent).toLowerCase().includes(lowerQuiz));
          if (quizCatOption) {
            gaulaSetSelect(catSelect, quizCatOption.value);
            console.log('[GAULA] fill_import_form cat -> ' + norm(quizCatOption.textContent));
            await gaulaWait(300);
          }
        }
        // Capturar el texto de la opción seleccionada (sea la que pusimos o la default de Moodle)
        const selOpt = catSelect.options[catSelect.selectedIndex];
        if (selOpt) importCategoryText = selOpt.textContent.replace(/[\s ]+/g, ' ').trim();
      }

      // 4. Codegen: getByRole('button', { name: 'Seleccione un archivo...' }).click()
      const selectFileBtn = gaulaByRole('button', 'Seleccione un archivo') ||
                            [...document.querySelectorAll('a, button')].find(el =>
                              el.textContent.trim().includes('Seleccione un archivo')
                            );
      if (selectFileBtn) {
        gaulaClick(selectFileBtn);
        await gaulaWait(1000);
      }

      // 5. Asegurar que el tab "Subir un archivo" del file picker esté activo.
      //    OJO Quito: el botón con label "Adjunto" es el proxy del <input type="file">
      //    nativo — clickearlo abre el OS dialog y bloquea el flujo. NO hacer eso.
      //    En Moodle 4.x el tab "Subir un archivo" suele venir seleccionado por defecto;
      //    solo lo cambiamos si NO está activo.
      const uploadTab = [...document.querySelectorAll('[role="tab"], .nav-link, .fp-repo-area .fp-repo')]
        .find(t => /subir un archivo/i.test(t.textContent || '') && t.offsetParent !== null);
      if (uploadTab && !uploadTab.classList.contains('active') && uploadTab.getAttribute('aria-selected') !== 'true') {
        gaulaClick(uploadTab);
        await gaulaWait(800);
      }

      // 6. Crear archivo y subirlo (Aiken .txt o Moodle XML .xml)
      let fileContent, fileName, fileMime;
      if (useXml) {
        fileContent = state.xmlText;
        fileName = state.xmlFileName || 'preguntas.xml';
        fileMime = 'text/xml';
      } else {
        fileContent = state.aikenText || '';
        fileName = 'preguntas.txt';
        fileMime = 'text/plain';
      }
      const blob = new Blob([fileContent], { type: fileMime });
      const file = new File([blob], fileName, { type: fileMime });

      const fileInput = document.querySelector('.filepicker-container input[type="file"]') ||
                        document.querySelector('.fp-upload-form input[type="file"]') ||
                        document.querySelector('.file-picker input[type="file"]') ||
                        document.querySelector('input[type="file"][name="repo_upload_file"]') ||
                        document.querySelector('input[type="file"]');

      if (fileInput) {
        const dt = new DataTransfer();
        dt.items.add(file);
        fileInput.files = dt.files;
        fileInput.dispatchEvent(new Event('change', { bubbles: true }));
        await gaulaWait(1000);
      }

      // 7. Codegen: getByRole('button', { name: 'Subir este archivo' }).click()
      const uploadBtn = gaulaByRole('button', 'Subir este archivo') ||
                        [...document.querySelectorAll('button')].find(el =>
                          el.textContent.trim().includes('Subir este archivo')
                        );
      if (uploadBtn) {
        gaulaClick(uploadBtn);
        await gaulaWait(2000);
      }

      // 8. Guardar estado y hacer click en Importar.
      // CRÍTICO: Moodle (theme puce) tiene un data-initial-value en el select
      // de categoría que apunta a la "última cat usada" del usuario, y JS
      // reactivo que reaplica esa cat. Tanto `gaulaSetSelect` como `?cat=` del
      // URL son sobreescritos. La ÚNICA forma robusta es interceptar el submit
      // del form, construir FormData manualmente con la cat correcta, y
      // mandarlo via fetch — eso bypassea por completo el theme reactivo.
      await gaulaSaveState({
        ...state,
        step: 'after_import',
        importCategoryText: state.quizCatValue
          ? 'Por defecto en ' + (state.quizName || '')
          : (importCategoryText || state.importCategoryText || null)
      });

      const importForm = (catSelect && catSelect.closest('form')) ||
                         document.querySelector('form[action*="import.php"]') ||
                         document.querySelector('form.mform') ||
                         document.querySelector('form');
      const desiredCat = state.quizCatValue;

      if (importForm && desiredCat && catSelect) {
        // Estrategia: REEMPLAZAR las opciones del select con una sola opción
        // = desiredCat. El theme puce tiene reactive JS que revierte el select
        // a la "última cat usada" via data-initial-value, pero si la única
        // opción que existe es la deseada, no hay nada que revertir. Bonus:
        // el submit es nativo, así que el changechecker reconoce que es el
        // propio form submiteándose → NO dispara beforeunload dialog.
        try {
          const optionLabel = state.quizName ? 'Por defecto en ' + state.quizName : 'Categoría destino';
          catSelect.innerHTML = '<option value="' + desiredCat + '" selected>' + optionLabel + '</option>';
          catSelect.value = desiredCat;
          catSelect.setAttribute('data-initial-value', desiredCat);
          console.log('[GAULA] select category sustituido por single-option = ' + desiredCat);
        } catch (e) {
          console.warn('[GAULA] no se pudo sustituir select category:', e.message);
        }
      } else if (!desiredCat) {
        console.warn('[GAULA] No hay desiredCat — el import usará la cat default de Moodle.');
      }

      const importBtn = document.getElementById('id_submitbutton') ||
                        gaulaByRole('button', 'Importar');
      if (importBtn) {
        // Submit nativo del form → POST normal → no aparece dialog beforeunload
        // porque el form-changechecker marca dataset.formSubmitted='true'.
        gaulaClick(importBtn);
      }

    } catch (err) {
      console.warn('[GAULA] Error en importacion:', err.message);
      await gaulaSaveState({ ...state, step: 'navigate_course', aikenText: '' });
      const courseLink = document.querySelector('a[href*="/course/view.php"]');
      if (courseLink) window.location.href = courseLink.href;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: after_import — Saltar directo a mod/quiz/edit.php
  // Antes: buscaba "Continuar" → click. Pero en Quito a veces aterrizamos
  // en question/edit.php (sin Continuar) y el lookup de "Preguntas" en
  // goto_quiz_edit matcheaba erróneamente "Banco de preguntas" → loop.
  // Solución: ya importamos las preguntas, saltar directo al editor del quiz.
  // ──────────────────────────────────────────────────────────
  if (state.step === 'after_import' || state.step === 'goto_quiz_edit') {
    const pathPrefixMatch_ai = location.pathname.match(/^(\/[^\/]+)\/(course|mod|question|admin|local|theme|user|grade|backup|report|enrol|message|calendar|my|blocks)\b/);
    const baseUrl_ai = state.baseUrl
                  || (pathPrefixMatch_ai ? `${location.origin}${pathPrefixMatch_ai[1]}` : null)
                  || (window.M && window.M.cfg && window.M.cfg.wwwroot)
                  || window.location.origin;

    // ── MULTI-BANCO: loop entre bancos o pasar a add_random_slots ─
    if (state.randomMode && Array.isArray(state.banks) && state.banks.length > 0) {
      const currentIdx = state.currentBankIdx ?? 0;
      const nextIdx = currentIdx + 1;
      if (nextIdx < state.banks.length) {
        // Siguiente banco: navegar a su import.php
        const nextBank = state.banks[nextIdx];
        console.log('[GAULA] after_import (random) → banco ' + (nextIdx + 1) + ' "' + nextBank.name + '"');
        await gaulaSaveState({
          ...state,
          step: 'fill_import_form',
          currentBankIdx: nextIdx,
          aikenText: nextBank.aikenText || '',
          quizCatValue: nextBank.catValue
        });
        const nextUrl = `${baseUrl_ai}/question/bank/importquestions/import.php?cmid=${state.quizCmid}&cat=${encodeURIComponent(nextBank.catValue)}`;
        window.location.href = nextUrl;
        return;
      }
      // Todos los bancos importados → add_random_slots
      console.log('[GAULA] after_import (random) → todos bancos importados, vamos a add_random_slots');
      await gaulaSaveState({ ...state, step: 'add_random_slots', aikenText: '' });
      const editUrl = `${baseUrl_ai}/mod/quiz/edit.php?cmid=${state.quizCmid}`;
      if (url.includes('/mod/quiz/edit.php')) {
        // Ya estamos ahí, fall-through al handler de add_random_slots
        state.step = 'add_random_slots';
      } else {
        window.location.href = editUrl;
        return;
      }
    } else {
      // Flow SIMPLE (toggle OFF): comportamiento original.
      if (url.includes('/mod/quiz/edit.php')) {
        state.step = 'add_questions';
        await gaulaSaveState({ ...state, step: 'add_questions' });
        // sin return — fall-through a add_questions block abajo
      } else {
        await gaulaSaveState({ ...state, step: 'add_questions' });
        if (!state.quizCmid) {
          console.warn('[GAULA] after_import: state.quizCmid vacío, abortando.');
          gaulaClearState();
          return;
        }
        console.log('[GAULA] after_import → mod/quiz/edit.php?cmid=' + state.quizCmid);
        window.location.href = `${baseUrl_ai}/mod/quiz/edit.php?cmid=${state.quizCmid}`;
        return;
      }
    }
  }

  // ──────────────────────────────────────────────────────────
  // STEP: add_random_slots — Crea random slots con gaulaAddRandomSlots
  // Una llamada por banco con count = bank.randomCount.
  // Después navega a finish_quiz_edit para cleanup/move.
  // ──────────────────────────────────────────────────────────
  if (url.includes('/mod/quiz/edit.php') && state.step === 'add_random_slots') {
    try {
      const pathPrefixMatch = location.pathname.match(/^(\/[^\/]+)\/(course|mod|question|admin|local|theme|user|grade|backup|report|enrol|message|calendar|my|blocks)\b/);
      const baseUrl = state.baseUrl
                    || (pathPrefixMatch ? `${location.origin}${pathPrefixMatch[1]}` : null)
                    || (window.M && window.M.cfg && window.M.cfg.wwwroot)
                    || window.location.origin;
      const banks = state.banks || [];
      console.log('[GAULA] add_random_slots: añadiendo random slots para ' + banks.length + ' bancos');
      let totalAdded = 0;
      for (let i = 0; i < banks.length; i++) {
        const bank = banks[i];
        if (!bank.catValue) {
          console.warn('[GAULA] banco ' + (i + 1) + ' sin catValue, skip.');
          continue;
        }
        const count = parseInt(bank.randomCount) || 0;
        if (count < 1) {
          console.warn('[GAULA] banco ' + (i + 1) + ' randomCount inválido (' + count + '), skip.');
          continue;
        }
        const result = await gaulaAddRandomSlots({
          cmid: state.quizCmid,
          categoryValue: bank.catValue,
          count: count,
          addonpage: 0,
          baseUrl
        });
        if (result.ok) {
          totalAdded += count;
          console.log('[GAULA] banco ' + (i + 1) + ': ' + count + ' random slots agregados.');
        } else {
          console.warn('[GAULA] banco ' + (i + 1) + ': fallo addrandom → ' + result.error);
        }
      }
      console.log('[GAULA] add_random_slots: total ' + totalAdded + ' slots agregados al quiz.');
      await gaulaSaveState({ ...state, step: 'finish_quiz_edit' });
      location.reload();
    } catch (err) {
      console.warn('[GAULA] Error add_random_slots:', err.message);
      await gaulaSaveState({ ...state, step: 'navigate_course', aikenText: '' });
      const courseLink = document.querySelector('a[href*="/course/view.php"]');
      if (courseLink) window.location.href = courseLink.href;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: add_questions — En quiz/edit.php, agregar preguntas del banco
  // Codegen: Agregar → "del banco de preguntas" → seleccionar todos → Añadir
  // ──────────────────────────────────────────────────────────
  if (url.includes('/mod/quiz/edit.php') && state.step === 'add_questions') {
    // Salvavidas: si por alguna razón llegamos aquí en randomMode, redirigimos
    // a add_random_slots (no debería pasar — el after_import branch toma el path
    // random — pero por consistencia).
    if (state.randomMode) {
      await gaulaSaveState({ ...state, step: 'add_random_slots' });
      location.reload();
      return;
    }
    try {
      await gaulaWait(2000);

      // Codegen: getByRole('button', { name: 'Agregar' }).click()
      // IMPORTANTE: En Moodle es un <a> con data-toggle="dropdown" que abre un menu.
      // NO confundir con links de navegacion al banco de preguntas.
      // Buscar especificamente el dropdown toggle dentro del area de edicion del quiz.
      const addBtn = document.querySelector('.mod_quiz-edit-action-buttons [data-toggle="dropdown"]') ||
                     document.querySelector('.slots [data-toggle="dropdown"]') ||
                     document.querySelector('a.btn[data-toggle="dropdown"]') ||
                     [...document.querySelectorAll('a[data-toggle="dropdown"], button[data-toggle="dropdown"]')].find(el =>
                       el.textContent.trim().toLowerCase().includes('agregar')
                     );

      if (!addBtn) {
        console.warn('[GAULA] No se encontró dropdown Agregar');
        throw new Error('Dropdown Agregar no encontrado');
      }

      gaulaClick(addBtn);
      await gaulaWait(1000);

      // Codegen: getByRole('menuitem', { name: 'del banco de preguntas' }).click()
      // Buscar dentro del dropdown-menu que se acaba de abrir
      let fromBankItem = null;
      for (let attempt = 0; attempt < 8; attempt++) {
        // Buscar en dropdown-menus visibles
        const visibleMenus = document.querySelectorAll('.dropdown-menu.show, .dropdown-menu[style*="display: block"]');
        for (const menu of visibleMenus) {
          fromBankItem = [...menu.querySelectorAll('a, [role="menuitem"]')].find(el =>
            el.textContent.trim().toLowerCase().includes('banco de preguntas')
          );
          if (fromBankItem) break;
        }
        // Fallback global
        if (!fromBankItem) {
          fromBankItem = [...document.querySelectorAll('[role="menuitem"], .dropdown-item')].find(el =>
            el.textContent.trim().toLowerCase().includes('banco de preguntas') &&
            el.offsetParent !== null // visible
          );
        }
        if (fromBankItem) break;
        await gaulaWait(500);
      }

      if (!fromBankItem) {
        console.warn('[GAULA] No se encontró opción "del banco de preguntas"');
        throw new Error('Opción banco de preguntas no encontrada');
      }

      gaulaClick(fromBankItem);
      await gaulaWait(3000);

      // Codegen: getByLabel('Seleccionar una categoría:').selectOption(...)
      // Preferencia:
      //   1. PUCESE: "Por defecto en [QuizName]" (categoría del quiz).
      //   2. Quito: la categoría a la que realmente importamos (state.importCategoryText)
      //      — no existe "Por defecto en [QuizName]" porque el import fue a courseid.
      const catFilterSelect = gaulaByLabel('Seleccionar una categoría') ||
                              gaulaByLabel('Seleccionar una categoría:') ||
                              document.querySelector('select[name="category"]');
      if (catFilterSelect) {
        const opts = [...catFilterSelect.options];
        const norm = t => t.replace(/[\s ]+/g, ' ').trim().toLowerCase();
        let pick = null;
        if (state.quizName) {
          const lowerQuiz = state.quizName.toLowerCase();
          // Preferir "Por defecto en X" (categoria hoja con preguntas), evitar "Superior para X" (padre).
          pick = opts.find(o => /por defecto en/i.test(norm(o.textContent)) && norm(o.textContent).includes(lowerQuiz))
              || opts.find(o => norm(o.textContent).includes(lowerQuiz) && !/superior para/i.test(norm(o.textContent)))
              || opts.find(o => norm(o.textContent).includes(lowerQuiz));
        }
        if (!pick && state.importCategoryText) {
          pick = opts.find(o => norm(o.textContent).includes(norm(state.importCategoryText)));
        }
        if (pick) {
          gaulaSetSelect(catFilterSelect, pick.value);
          catFilterSelect.dispatchEvent(new Event('change', { bubbles: true }));
          console.log('[GAULA] add_questions cat filter -> ' + pick.textContent.trim());
          await gaulaWait(2000);
        }
      }

      // Codegen: getByLabel('Seleccionar todos').check()
      let selectAllCb = null;
      for (let attempt = 0; attempt < 10; attempt++) {
        selectAllCb = gaulaByLabel('Seleccionar todos') ||
                      document.querySelector('input[type="checkbox"][id*="selectall"]') ||
                      document.querySelector('th input[type="checkbox"]');
        if (selectAllCb) break;
        await gaulaWait(500);
      }

      if (selectAllCb && !selectAllCb.checked) {
        gaulaClick(selectAllCb);
        await gaulaWait(500);
      }

      // Codegen: getByRole('link', { name: 'Mostrar 50' }).click()
      const showAllLink = [...document.querySelectorAll('a')].find(a =>
        /mostrar\s+\d+/i.test(a.textContent.trim()) ||
        /show\s+\d+/i.test(a.textContent.trim())
      );
      if (showAllLink) {
        gaulaClick(showAllLink);
        await gaulaWait(2000);

        // Re-seleccionar todos despues de mostrar todas
        const selectAllCb2 = gaulaByLabel('Seleccionar todos') ||
                             document.querySelector('input[type="checkbox"][id*="selectall"]') ||
                             document.querySelector('th input[type="checkbox"]');
        if (selectAllCb2) {
          if (selectAllCb2.checked) selectAllCb2.checked = false;
          gaulaClick(selectAllCb2);
          await gaulaWait(500);
        }
      }

      // Codegen: getByRole('button', { name: 'Añadir preguntas' }).click()
      const addQuestionsBtn = gaulaByRole('button', 'Añadir preguntas') ||
                              gaulaByRole('button', 'Agregar preguntas seleccionadas') ||
                              [...document.querySelectorAll('button, input[type="submit"]')].find(el =>
                                (el.textContent || el.value || '').toLowerCase().includes('añadir pregunta') ||
                                (el.textContent || el.value || '').toLowerCase().includes('add selected')
                              );

      // IMPORTANTE: Guardar estado ANTES de click — el click recarga la pagina
      await gaulaSaveState({ ...state, step: 'finish_quiz_edit', aikenText: '' });

      if (addQuestionsBtn) {
        gaulaClick(addQuestionsBtn);
      }

    } catch (err) {
      console.warn('[GAULA] Error agregando preguntas:', err.message);
      await gaulaSaveState({ ...state, step: 'navigate_course', aikenText: '' });
      const courseLink = document.querySelector('a[href*="/course/view.php"]');
      if (courseLink) window.location.href = courseLink.href;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: finish_quiz_edit — Preguntas ya agregadas, check shuffle y salir
  // ──────────────────────────────────────────────────────────
  if (url.includes('/mod/quiz/edit.php') && state.step === 'finish_quiz_edit') {
    await gaulaWait(1500);

    // Codegen: getByLabel('Reordenar las preguntas al').check()
    const shuffleCb = gaulaByLabel('Reordenar las preguntas al') ||
                      gaulaByLabel('Barajar');
    if (shuffleCb && !shuffleCb.checked) {
      gaulaClick(shuffleCb);
      await gaulaWait(500);
    }

    // Setear "Calificación máxima" del quiz a 50. El input vive en su propio
    // form en la barra superior derecha de edit.php junto al botón "Guardar".
    // Moodle escala la puntuación total (suma de pesos) al rango maxgrade.
    const maxGradeInput = document.querySelector('input[name="maxgrade"]');
    if (maxGradeInput) {
      gaulaSetValue(maxGradeInput, '50');
      const saveMaxForm = maxGradeInput.closest('form');
      const saveMaxBtn = saveMaxForm
        && (saveMaxForm.querySelector('button[type="submit"]')
            || saveMaxForm.querySelector('input[type="submit"]'));
      if (saveMaxBtn) {
        gaulaClick(saveMaxBtn);
        await gaulaWait(1200);
      }
    }

    // Navegar al curso → SECCION ESPECIFICA del quiz creado.
    // El breadcrumb cae en section=0 (General) y eso impide que move_quiz
    // encuentre el anchor "Productos y actividades" en la sección correcta.
    await gaulaSaveState({ ...state, step: 'navigate_course' });
    const pathPrefixMatch = location.pathname.match(/^(\/[^\/]+)\/(course|mod|question|admin|local|theme|user|grade|backup|report|enrol|message|calendar|my|blocks)\b/);
    const baseUrl = state.baseUrl
                  || (pathPrefixMatch ? `${location.origin}${pathPrefixMatch[1]}` : null)
                  || (window.M && window.M.cfg && window.M.cfg.wwwroot)
                  || window.location.origin;
    const bodyCourseMatch = document.body.className.match(/\bcourse-(\d+)\b/);
    const courseId = (bodyCourseMatch && bodyCourseMatch[1] !== '1' ? bodyCourseMatch[1] : null)
                  || (window.M && window.M.cfg && window.M.cfg.courseId);
    const targetSec = state.sectionIndex;
    if (courseId && targetSec) {
      window.location.href = `${baseUrl}/course/view.php?id=${courseId}&section=${targetSec}`;
    } else {
      const courseLink = document.querySelector('.breadcrumb a[href*="/course/view.php"]') ||
                         document.querySelector('a[href*="/course/view.php"]');
      if (courseLink) window.location.href = courseLink.href;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: navigate_course — Volver al curso desde cualquier pagina
  // ──────────────────────────────────────────────────────────
  if (state.step === 'navigate_course' && !url.includes('/course/view.php')) {
    // Preferir URL con sección explícita si tenemos state.sectionIndex
    const pathPrefixMatch = location.pathname.match(/^(\/[^\/]+)\/(course|mod|question|admin|local|theme|user|grade|backup|report|enrol|message|calendar|my|blocks)\b/);
    const baseUrl = state.baseUrl
                  || (pathPrefixMatch ? `${location.origin}${pathPrefixMatch[1]}` : null)
                  || (window.M && window.M.cfg && window.M.cfg.wwwroot)
                  || window.location.origin;
    const bodyCourseMatch = document.body.className.match(/\bcourse-(\d+)\b/);
    const courseId = (bodyCourseMatch && bodyCourseMatch[1] !== '1' ? bodyCourseMatch[1] : null)
                  || (window.M && window.M.cfg && window.M.cfg.courseId);
    if (courseId && state.sectionIndex) {
      window.location.href = `${baseUrl}/course/view.php?id=${courseId}&section=${state.sectionIndex}`;
      return;
    }
    const courseLink = document.querySelector('.breadcrumb a[href*="/course/view.php"]') ||
                       document.querySelector('a[href*="/course/view.php"]');
    if (courseLink) {
      window.location.href = courseLink.href;
    }
    return;
  }

  // ──────────────────────────────────────────────────────────
  // STEP: move_quiz — Mover a seccion "Evaluacion"
  // ──────────────────────────────────────────────────────────
  if (url.includes('/course/view.php') && (state.step === 'move_quiz' || state.step === 'navigate_course')) {
    // Asegurar que estamos en la sección correcta (Moodle puede redirigir
    // a course/view.php?id=X sin section=, lo que renderiza otra sección).
    const currentSec = new URL(url).searchParams.get('section');
    if (state.sectionIndex && currentSec !== String(state.sectionIndex)) {
      const u = new URL(url);
      u.searchParams.set('section', String(state.sectionIndex));
      u.hash = '';
      console.log('[GAULA] move_quiz: navegando a section=' + state.sectionIndex + ' antes de mover');
      location.href = u.toString();
      return;
    }
    try {
      await gaulaWait(1000);
      const quizName = state.quizName;
      const totalTasks = state.totalTasks;
      const secIdx = state.sectionIndex;
      // Intentar mover: primero busca secciones repo, luego no-repo (el fallback maneja ambos)
      gaulaClearState();
      gaulaReportProgress(totalTasks, totalTasks, 'done', { step: 'create_quiz' });
      console.log('[GAULA] move_quiz: secIdx=' + secIdx + ', quizName=' + quizName);
      const moved = await gaulaMoveLastResource('PRODUCTOS Y ACTIVIDADES', quizName, secIdx, 'quiz');
      // Reload para refrescar el DOM con el nuevo orden (state ya está limpio).
      if (moved) {
        await gaulaWait(300);
        location.reload();
      }
    } catch (err) {
      // Estado ya limpio
    }
    return;
  }
})();

// ============================================================
// HANDLER: recibe mensaje del popup para iniciar creacion
// ============================================================
gaulaRegisterHandler('create_quiz', async (msg, sendResponse) => {
  if (window !== window.top) {
    sendResponse({ ok: true });
    return;
  }

  try {
    await gaulaAcquireLock('create_quiz');
    const { quizName, dateFrom, dateTo, timeLimit, quizPassword,
            rdaIndex, sectionIndex, questions, gradeCategoryValue, criterioIndex,
            aikenText, xmlText, xmlFileName, randomMode, banks } = msg;

    gaulaReportProgress(0, 1, 'running', { step: 'create_quiz', rdaIndex });

    await gaulaSaveState({
      action: 'create_quiz',
      step: 'fill_quiz_form',
      quizData: {
        nombre: quizName,
        dateFrom: dateFrom || '',
        dateTo: dateTo || '',
        hourFrom: msg.hourFrom || '0',
        minFrom: msg.minFrom || '0',
        hourTo: msg.hourTo || '23',
        minTo: msg.minTo || '55',
        timeLimit: timeLimit || 0,
        password: quizPassword || '',
        quizIntroHtml: msg.quizIntroHtml || ''
      },
      gradeCategoryValue: gradeCategoryValue || null,
      criterioIndex: criterioIndex || 1,
      rdaIndex: rdaIndex,
      sectionIndex: sectionIndex || 1,
      aikenText: aikenText || '',
      xmlText: xmlText || '',
      xmlFileName: xmlFileName || '',
      questions: questions || [],
      taskIndex: 0,
      totalTasks: 1,
      // Multi-banco (toggle "Preguntas aleatorias")
      randomMode: !!randomMode,
      banks: Array.isArray(banks) ? banks : null,
      currentBankIdx: 0
    });

    await gaulaEnableEditing();

    await gaulaOpenActivityChooser(sectionIndex || 1);
    await gaulaWait(500);
    await gaulaSearchAndClickActivity('cuestionario', 'Cuestionario');

    sendResponse({ ok: true });

  } catch (err) {
    gaulaClearState();
    if (err.message === 'STOPPED') {
      gaulaReportProgress(0, 0, 'stopped', { step: 'create_quiz' });
    } else {
      gaulaReportProgress(0, 0, 'error', { step: 'create_quiz', error: err.message });
    }
    sendResponse({ ok: false, error: err.message });
  }
});
