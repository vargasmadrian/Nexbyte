/**
 * Generador de Aulas — Inyección de "Instrucciones por RDA" (banner por sección).
 *
 * Rellena el banner placeholder (#recpre-semanaN / #cambiarp-semanaN) de cada
 * sección RDA/Criterio editando el label existente vía modedit form-POST
 * (NO crea recursos nuevos, NO navega: fetch del form → reemplaza placeholders
 * → POST). Valida sólo para hosts PUCESA/PUCE (gated por host).
 *
 * Mensaje esperado desde el popup:
 *   { action:'fill_rda_instructions', rdas:[{rda_num,titulo,semanas,inicio,fin,docente,contenidos:[],instrucciones}] }
 *
 * Mapea secciones→RDA leyendo las pestañas onetopic: las pestañas "RDA N" son
 * las secciones padre; cada sección (criterio) pertenece al RDA cuya sección
 * padre es la mayor <= a ella. Así RDA1→[1,2,3], RDA2→[4,5,6], etc., sin
 * importar cuántos criterios tenga cada RDA.
 */

// Hosts donde esta función está habilitada (gating aditivo; no afecta otras sedes).
const GAULA_RDA_HOSTS = ['eva.pucesa.edu.ec', 'eva.puce.edu.ec'];

// Escapa HTML para texto que va dentro de nodos.
function gaulaRdaEsc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Construye la lista de contenidos (caja azul) con encabezado "Contenidos mínimos".
function gaulaRdaContenidosUl(contenidos) {
  const items = ['<li><strong>Contenidos mínimos</strong></li>']
    .concat((contenidos || []).map(c => `<li>${gaulaRdaEsc(c)}</li>`));
  return `<ul class="my-4" style="background-color:#164284; padding: 20px 20px 20px 40px; color:white;">\n                ${items.join('\n                ')}\n            </ul>`;
}

// Rellena el HTML original del label (template) con los datos del RDA, preservando
// SVG/animaciones/estructura. Reemplazos tolerantes a espacios (validados en vivo).
function gaulaRdaFillTemplate(html, rda) {
  const titulo = gaulaRdaEsc(rda.titulo || '');
  let out = html
    .replace(/(<h3 style="color:#164284;"><strong>RDA )\d+(: )Titulo 1(<\/strong><\/h3>)/,
      `$1${rda.rda_num || ''}$2${titulo}$3`)
    .replace(/(<strong>RdA )\d+(: <\/strong><\/span>)Titulo RDA 1/,
      `$1${rda.rda_num || ''}$2${titulo}`)
    .replace(/(<strong>Docentes: <\/strong><\/span>)Docente/,
      `$1${gaulaRdaEsc(rda.docente || 'Docente')}`)
    .replace(/(<strong>Instrucciones: <\/strong><\/span>)[\s\S]*?<\/p>/,
      `$1${gaulaRdaEsc(rda.instrucciones || '')}</p>`)
    .replace(/<ul class="my-4"[\s\S]*?<\/ul>/, gaulaRdaContenidosUl(rda.contenidos))
    .replace(/<p>Texto general\.[\s\S]*?<\/p>/, '');
  // Semana (rango) — preserva "Desarrollo del curso – Semana ..."
  if (rda.semanas) {
    out = out.replace(/(<strong>Desarrollo del curso – Semana )[^<]*(<\/strong>)/,
      `$1${gaulaRdaEsc(rda.semanas)}$2`);
  }
  // Fechas (sólo si se proporcionaron)
  if (rda.inicio) out = out.replace(/(<strong>Inicio:<\/strong>)[\s\S]*?de\s+\w+/, `$1 ${gaulaRdaEsc(rda.inicio)}`);
  if (rda.fin) out = out.replace(/(<strong>Finaliza:<\/strong>)[\s\S]*?de\s+\w+/, `$1 ${gaulaRdaEsc(rda.fin)}`);
  return out;
}

// Lee las pestañas onetopic del DOM actual → mapa sección→índice de RDA (0-based).
function gaulaRdaSectionMap() {
  const links = [...document.querySelectorAll('a[href*="section="]')];
  const parentSecs = []; // secciones de pestañas "RDA N"
  const allSecs = new Set();
  for (const a of links) {
    const m = (a.getAttribute('href') || '').match(/section=(\d+)/);
    if (!m) continue;
    const sec = parseInt(m[1], 10);
    const txt = (a.textContent || '').replace(/\s+/g, ' ').trim();
    if (/^RDA\s*\d+/i.test(txt)) parentSecs.push(sec);
    if (/RDA\s*\d+|Criterio/i.test(txt)) allSecs.add(sec);
  }
  const parents = [...new Set(parentSecs)].sort((a, b) => a - b);
  const sections = [...allSecs].sort((a, b) => a - b);
  const sectionToRda = {};
  for (const s of sections) {
    let idx = 0;
    for (let k = 0; k < parents.length; k++) { if (parents[k] <= s) idx = k; }
    sectionToRda[s] = idx;
  }
  return { parents, sections, sectionToRda };
}

// Encuentra el cmid del label que contiene #recpre-semana en el HTML de una sección.
function gaulaRdaFindLabelCmid(doc) {
  const banner = doc.querySelector('#region-main [id^="recpre-semana"], [id^="recpre-semana"]');
  if (!banner) return null;
  const li = banner.closest('li[id^="module-"]');
  if (li) { const m = li.id.match(/module-(\d+)/); if (m) return m[1]; }
  return null;
}

// Edita un label vía modedit form-POST. Devuelve true si guardó.
async function gaulaRdaSaveLabel(wwwroot, courseId, cmid, newIntro) {
  const res = await fetch(`${wwwroot}/course/modedit.php?update=${cmid}&return=0&sr=0`, { credentials: 'include' });
  const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
  const form = doc.querySelector('form#mform1, form[action*="modedit"]');
  if (!form) throw new Error('Form modedit no encontrado para cmid ' + cmid);
  const fd = new URLSearchParams();
  form.querySelectorAll('input, textarea, select').forEach(el => {
    const n = el.name; if (!n || n === 'cancel') return;
    if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
    let v = el.value !== undefined ? el.value : '';
    // Omitir arrays vacíos → evita el fatal moodle_database::get_in_or_equal()
    if (n.endsWith('[]') && (v === '' || v == null)) return;
    fd.set(n, v);
  });
  fd.set('introeditor[text]', newIntro);
  fd.set('introeditor[format]', '1');
  if (!fd.has('submitbutton2')) fd.set('submitbutton2', 'Guardar cambios y regresar');
  const post = await fetch(`${wwwroot}/course/modedit.php`, {
    method: 'POST', credentials: 'include',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: fd.toString(), redirect: 'manual',
  });
  // Éxito = redirect (302 opaque) de "guardar y regresar"
  if (post.type === 'opaqueredirect' || post.status === 0 || post.status === 302) return true;
  if (post.status === 200) {
    const edoc = new DOMParser().parseFromString(await post.text(), 'text/html');
    const err = (edoc.querySelector('#region-main h2, .errormessage, .alert-danger')?.textContent || '').replace(/\s+/g, ' ').trim();
    throw new Error('Moodle rechazó el guardado: ' + (err.slice(0, 120) || 'sin detalle'));
  }
  throw new Error('POST modedit status ' + post.status);
}

gaulaRegisterHandler('fill_rda_instructions', async (msg, sendResponse) => {
  try {
    if (!GAULA_RDA_HOSTS.includes(location.host)) {
      sendResponse({ ok: false, error: 'Función disponible solo en aulas PUCE/PUCESA.' });
      return;
    }
    await gaulaAcquireLock('fill_rda_instructions');
    const rdas = msg.rdas || [];
    if (!rdas.length) { sendResponse({ ok: false, error: 'Sin datos de RDA.' }); return; }

    const wwwroot = gaulaGetWwwroot();
    const courseId = gaulaGetCourseId();
    if (!wwwroot || !courseId) { sendResponse({ ok: false, error: 'No se pudo leer wwwroot/courseId.' }); return; }

    const map = gaulaRdaSectionMap();
    if (!map.sections.length) { sendResponse({ ok: false, error: 'No se detectaron secciones RDA/Criterio (¿formato onetopic?).' }); return; }

    const total = map.sections.length;
    let done = 0, filled = 0, skipped = 0;
    const errors = [];
    gaulaReportProgress(0, total, 'running', { step: 'Rellenando banners de RDA...' });

    for (const sec of map.sections) {
      gaulaCheckStop();
      const rdaIdx = map.sectionToRda[sec] || 0;
      const rda = rdas[rdaIdx];
      done++;
      if (!rda) { skipped++; continue; }
      try {
        const r = await fetch(`${wwwroot}/course/view.php?id=${courseId}&section=${sec}`, { credentials: 'include' });
        const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
        const cmid = gaulaRdaFindLabelCmid(doc);
        if (!cmid) { skipped++; gaulaReportProgress(done, total, 'running', { step: `Sec ${sec}: sin banner, omitida` }); continue; }
        // Tomar el HTML actual del label desde su propio form (intro real) y rellenarlo
        const formRes = await fetch(`${wwwroot}/course/modedit.php?update=${cmid}&return=0&sr=0`, { credentials: 'include' });
        const fdoc = new DOMParser().parseFromString(await formRes.text(), 'text/html');
        const ta = fdoc.querySelector('textarea[name="introeditor[text]"]');
        const orig = ta ? ta.value : '';
        if (!/recpre-semana|RDA \d+: Titulo|Texto Instrucciones/.test(orig)) { skipped++; continue; }
        const filledHtml = gaulaRdaFillTemplate(orig, rda);
        await gaulaRdaSaveLabel(wwwroot, courseId, cmid, filledHtml);
        filled++;
        gaulaReportProgress(done, total, 'running', { step: `RDA ${rda.rda_num} → sección ${sec} ✓` });
        await gaulaWait(300);
      } catch (e) {
        errors.push(`sec ${sec}: ${e.message}`);
        gaulaReportProgress(done, total, 'running', { step: `Sec ${sec}: error (continúa)` });
      }
    }

    await gaulaReleaseLock();
    gaulaReportProgress(total, total, 'done', { step: `Listo: ${filled} banners rellenados${skipped ? `, ${skipped} omitidos` : ''}${errors.length ? `, ${errors.length} con error` : ''}` });
    sendResponse({ ok: true, filled, skipped, errors });
    // Recargar para ver el resultado pintado
    await gaulaWait(600);
    location.reload();
  } catch (err) {
    await gaulaReleaseLock();
    if (err.message === 'STOPPED') gaulaReportProgress(0, 0, 'stopped', { step: 'fill_rda_instructions' });
    else gaulaReportProgress(0, 0, 'error', { step: 'fill_rda_instructions', error: err.message });
    sendResponse({ ok: false, error: err.message });
  }
});
