/**
 * GeneradorAulas 2.0 - Executor / Coordinator.
 * Recibe mensajes del popup/background y coordina con los scripts de acción.
 * NO ejecuta strings de código (bloqueado por CSP de Moodle).
 * Los scripts de acción están bundleados en la extensión y se auto-ejecutan
 * al detectar estado pendiente en gaulaGetState().
 */

// ============================================================
// Acciones de inyección que REQUIEREN el modo edición activado.
// ============================================================
const GAULA_NEEDS_EDIT = new Set([
  'create_assignment', 'create_quiz', 'edit_section_batch', 'edit_section',
  'upload_resource', 'upload_folder', 'edit_banner', 'create_forum'
]);
function _gaulaDbg(m) {
  try { chrome.storage.local.get('gaula_resume_dbg', r => {
    const arr = Array.isArray(r.gaula_resume_dbg) ? r.gaula_resume_dbg : [];
    arr.push({ t: Date.now(), m, url: location.href.slice(-45) });
    chrome.storage.local.set({ gaula_resume_dbg: arr.slice(-25) });
  }); } catch (_) {}
}

// ============================================================
// RESUME tras activar edición. El switch de edición hace POST a editmode.php →
// RECARGA. Si una acción llega con la edición apagada, la guardamos, activamos
// edición (recarga) y reanudamos aquí. CLAVE: NO consumir el flag hasta confirmar
// que la edición YA quedó activa (la recarga puede pasar por estados intermedios).
// ============================================================
(async function gaulaResumeAfterEdit() {
  try {
    if (!window.location.href.includes('/course/view.php')) return;
    const { gaula_resume_after_edit: pend } = await chrome.storage.local.get('gaula_resume_after_edit');
    if (!pend || !pend.msg) return;
    _gaulaDbg('found pend ' + pend.msg.action);
    if (Date.now() - (pend.ts || 0) > 60000) { await chrome.storage.local.remove('gaula_resume_after_edit'); _gaulaDbg('TTL'); return; }
    const sw = document.querySelector('[id$="-editingswitch"]');
    if (!sw) { _gaulaDbg('no switch'); return; }
    if (!sw.checked) { _gaulaDbg('edicion aun NO activa, conservo pend'); return; } // NO consumir
    await chrome.storage.local.remove('gaula_resume_after_edit'); // edición confirmada → one-shot
    const handler = typeof gaulaHandlers !== 'undefined' ? gaulaHandlers[pend.msg.action] : null;
    _gaulaDbg('edicion activa, handler=' + !!handler);
    if (!handler) return;
    await gaulaWait(800);
    _gaulaDbg('llamando handler');
    handler(pend.msg, () => {});
  } catch (e) { _gaulaDbg('ERR ' + String(e && e.message || e).slice(0, 80)); }
})();

// ============================================================
// LISTENER: recibir mensajes del popup/background
// ============================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Detener operación en curso
  if (msg.action === 'gaula_stop') {
    window.__gaulaStopFlag = true;
    gaulaClearState();
    sendResponse({ ok: true });
    return;
  }

  // Guardar estado para iniciar una acción
  // Los scripts bundleados lo detectarán en la próxima carga de página
  if (msg.action === 'gaula_execute') {
    const { params, actionName } = msg;
    window.__gaulaStopFlag = false;
    console.log('[EXECUTOR] Acción solicitada:', actionName);
    // El popup ya guarda el estado directamente para acciones multi-página.
    // Este handler existe como fallback para acciones single-page.
    sendResponse({ ok: true });
    return true;
  }

  // Auto-detectar tipo de aula
  if (msg.action === 'detect_course_type') {
    sendResponse({ courseType: gaulaDetectCourseType() });
    return;
  }

  // Escanear estructura: RDAs/Criterios/anchors. Usado por popup para resolver
  // sectionId correcto antes de operar (reemplaza la fórmula activeRda+1 que
  // falla en cursos con criterios anidados).
  if (msg.action === 'get_course_structure') {
    try {
      sendResponse({ ok: true, structure: gaulaScanCourseStructure() });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return;
  }

  // Pre-check: si la acción requiere modo edición y el lápiz está APAGADO,
  // guardamos la acción, activamos edición (POST editmode.php → recarga) y la
  // reanudamos vía gaulaResumeAfterEdit() tras la recarga. Así el primer clic
  // inyecta directo en vez de solo prender el lápiz.
  if (GAULA_NEEDS_EDIT.has(msg.action) && location.href.includes('/course/view.php')) {
    const sw = document.querySelector('[id$="-editingswitch"]');
    if (sw && !sw.checked) {
      chrome.storage.local.set({ gaula_resume_after_edit: { msg, ts: Date.now() } }, () => {
        sendResponse({ ok: true, message: 'Activando modo edición e insertando…' });
        // El form postea a editmode.php usando el checkbox `setmode` (value "on").
        // Hay que MARCARLO antes de enviar, si no no se envía setmode → seguiría apagado.
        sw.checked = true;
        const form = sw.closest('form');
        if (form && typeof form.requestSubmit === 'function') form.requestSubmit();
        else if (form) form.submit();
        else gaulaClick(sw);
      });
      return true;
    }
  }

  // Ejecutar handler registrado (acciones single-page como create_forum)
  const handler = gaulaHandlers[msg.action];
  if (handler) {
    window.__gaulaStopFlag = false;
    handler(msg, sendResponse);
    return true;
  }
});
