// ============================================================
// Configuración central — GeneradorAulas 3.0
// Las credenciales se cargan desde chrome.storage (configuradas en primer login)
// El anon key es público por diseño de Supabase, pero centralizado aquí.
// ============================================================
const CONFIG = {
  // PUCE Quito Supabase (cuenta secundaria, ref bmdtewkgtnqslwlqurph)
  SUPABASE_URL: 'https://bmdtewkgtnqslwlqurph.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtZHRld2tndG5xc2x3bHF1cnBoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgyNTM5NDcsImV4cCI6MjA5MzgyOTk0N30.qsWYN93iJwoUL0GIbFJzgE4HUeNJter8mZg1Lziz768',
  // Timeout configurable para conexiones lentas (Bug #8)
  ELEMENT_TIMEOUT: 20000,
  // Máximo de reintentos para llamadas de red (Bug #9)
  MAX_RETRIES: 2,
  RETRY_DELAY: 1500,
  // URL del landing de producto — versión PUCE Quito
  PRICING_URL: 'https://nexbyte.pro/planes-puce/',
};
