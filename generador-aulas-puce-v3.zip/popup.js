// ============================================================
// GeneradorAulas 3.0 — Popup Controller
// Bug #2: Restaurar estado de operación activa al reabrir popup
// Bug #7: Validación de tipos de archivo
// Bug #11: Debounce en saveFormState
// Bug #12: Cache TTL para categorías de calificación
// ============================================================

// --- Screens ---
const screenLogin = document.getElementById('screen-login');
const screenNoSub = document.getElementById('screen-no-sub');
const screenMain = document.getElementById('screen-main');

// --- Login elements ---
const btnGoogleLogin = document.getElementById('btnGoogleLogin');
const loginError = document.getElementById('loginError');
const nosubUserName = document.getElementById('nosubUserName');
const btnLogoutNoSub = document.getElementById('btnLogoutNoSub');

// --- Main elements ---
const userName = document.getElementById('userName');
const userAvatar = document.getElementById('userAvatar');
const creditsCount = document.getElementById('creditsCount');
const btnLogout = document.getElementById('btnLogout');
const courseTypeEl = document.getElementById('courseType');
const statusEl = document.getElementById('status');
const btnStop = document.getElementById('btnStop');

// --- RdA data storage ---
function gaulaToday() { return new Date().toISOString().split('T')[0]; }
function gaulaNextWeek() { const d = new Date(); d.setDate(d.getDate() + 7); return d.toISOString().split('T')[0]; }

function createEmptyManualTask() {
  return {
    nombre: '', descripcion: '', pdf: null, pdfName: '', dateFrom: gaulaToday(), dateTo: gaulaNextWeek(),
    rubrica: [{ nombre: '', niveles: [
      { nombre: 'Excelente', puntos: 5, descripcion: '' },
      { nombre: 'Bueno', puntos: 3, descripcion: '' },
      { nombre: 'Regular', puntos: 1, descripcion: '' },
      { nombre: 'Insuficiente', puntos: 0, descripcion: '' }
    ]}]
  };
}

// Estructura de un "banco" en modo random. Persistible salvo pdf/file (File no serializable).
function createEmptyBank(idx) {
  const defaultNames = ['Teoría', 'Práctica', 'Casos de estudio'];
  return {
    name: defaultNames[idx] || `Banco ${idx + 1}`,
    source: 'ai',           // 'ai' | 'file'
    pdf: null,              // File transient (solo durante sesión popup)
    pdfName: '',            // persistido
    generateCount: 50,      // cuántas pedir a IA (igual al modo OFF: 20 o 50)
    difficulty: 'medio',
    language: 'es',         // idioma de las preguntas: 'es' | 'en'
    aikenText: '',          // resultado IA o contenido archivo (normalizado)
    detectedCount: 0,       // preguntas válidas en aikenText
    droppedCount: 0,        // preguntas descartadas por formato inválido (info para el user)
    randomCount: 20         // cuántas slots aleatorios crear
  };
}

function createEmptyManualQuiz() {
  return {
    nombre: '', dateFrom: gaulaToday(), dateTo: gaulaToday(), time: 60, password: '',
    aikenText: '', xmlContent: '',
    // Multi-banco (toggle "Preguntas aleatorias")
    randomMode: false,
    banks: [createEmptyBank(0)]
  };
}

// Recursos por RDA: matriz [criterio][slot]. Soporta hasta 4 criterios x 3 slots.
// Antes (v3.12.0): rdaData[i].pdfs = [null,null,null]  (3 slots planos, criterio implícito)
// Ahora (v3.13.0): rdaData[i].pdfs = [[..c1..], [..c2..], [..c3..], [..c4..]]  (4 crit x 3 slots)
function emptyCritFileMatrix() {
  return [[null,null,null],[null,null,null],[null,null,null],[null,null,null]];
}
function emptyCritStringMatrix() {
  return [['','',''],['','',''],['','',''],['','','']];
}
const rdaData = [
  { pdfs: emptyCritFileMatrix(), ppts: emptyCritFileMatrix(), videos: emptyCritStringMatrix(), geneallys: emptyCritStringMatrix(), tasks: [{},{},{}], evals: [{},{},{}], forumTopic: '', aiAnalyzed: false, pdfText: '', manualTask: createEmptyManualTask(), manualQuiz: createEmptyManualQuiz() },
  { pdfs: emptyCritFileMatrix(), ppts: emptyCritFileMatrix(), videos: emptyCritStringMatrix(), geneallys: emptyCritStringMatrix(), tasks: [{},{},{}], evals: [{},{},{}], forumTopic: '', aiAnalyzed: false, pdfText: '', manualTask: createEmptyManualTask(), manualQuiz: createEmptyManualQuiz() },
  { pdfs: emptyCritFileMatrix(), ppts: emptyCritFileMatrix(), videos: emptyCritStringMatrix(), geneallys: emptyCritStringMatrix(), tasks: [{},{},{}], evals: [{},{},{}], forumTopic: '', aiAnalyzed: false, pdfText: '', manualTask: createEmptyManualTask(), manualQuiz: createEmptyManualQuiz() }
];
// Helper: devuelve el subarray del criterio activo (creándolo si falta).
function critArr(rda, field) {
  const idx = Math.max(0, Math.min(3, (activeCriterio || 1) - 1));
  if (!Array.isArray(rda[field])) rda[field] = field === 'pdfs' || field === 'ppts' ? emptyCritFileMatrix() : emptyCritStringMatrix();
  while (rda[field].length <= idx) rda[field].push(field === 'pdfs' || field === 'ppts' ? [null,null,null] : ['','','']);
  return rda[field][idx];
}
// Helper: aplana todos los criterios (para flows que necesitan todo el RDA, ej. Analizar con IA).
function flatCrits(rda, field) {
  if (!Array.isArray(rda[field])) return [];
  return rda[field].flat();
}
let activeRda = 0;
// SOLO evaposgrado (Opción A): secciones REALES de contenido del curso (sin "General"),
// detectadas dinámicamente. Si está set, el dropdown #evaposSectionSel manda y activeRda
// es el índice en este arreglo. En el resto de sedes queda null → comportamiento original.
let EVAPOS_SECTIONS = null;
function gaulaActiveTabIsEvapos(url) {
  return /(?:evaposgrado|evaenlinea|aulasvirtuales)\.puce\.edu\.ec/.test(url || '');
}
// Criterio activo para uploads (videos/PPT/PDF/Geneally) — 1-based. Solo aplica
// si el aula tiene Criterios anidados (hasNestedCriterios). Tasks/quizzes usan
// su propio dropdown (manualTaskCriterio/manualQuizCriterio).
let activeCriterio = 1;
// Cache: array[rdaIdx] = número de criterios en ese RDA. Inferido al abrir popup
// vía gaps entre sectionIds de RDAs consecutivos. Usado para mostrar los tabs
// criterio correctos al cambiar de RDA en el popup (sin re-navegar la pestaña).
let criterioCountsCache = null;

// ============================================================
// NAVEGACION DE PANTALLAS
// ============================================================

function showScreen(screen) {
  [screenLogin, screenNoSub, screenMain].forEach(s => s.classList.remove('active'));
  screen.classList.add('active');
}

// ============================================================
// INICIALIZACION
// ============================================================

async function init() {
  const result = await sendMessage({ type: 'GET_SESSION' });
  if (!result.ok) { showScreen(screenLogin); return; }
  await loadUserData(result.user);

  // Bug #2: Restaurar estado de operación activa al reabrir popup
  checkActiveOperation();
}

async function checkActiveOperation() {
  const data = await chrome.storage.local.get(['gaula_content_state', 'gaula_progress']);
  const state = data.gaula_content_state;
  const progress = data.gaula_progress;

  if (state && state.action) {
    // Hay una operación en curso — mostrar barra de progreso
    const wrapper = document.getElementById('progressWrapper');
    const label = document.getElementById('progressLabel');
    wrapper.style.display = 'block';
    btnStop.style.display = 'block';

    if (progress && progress.status === 'running') {
      label.textContent = progress.label || `${state.action} en progreso...`;
      const count = document.getElementById('progressCount');
      const fill = document.getElementById('progressFill');
      if (progress.total > 0) {
        count.textContent = `${progress.current}/${progress.total}`;
        fill.style.width = `${(progress.current / progress.total) * 100}%`;
      }
    } else {
      label.textContent = `${state.action} en progreso...`;
    }
  }
}

let currentUserId = null;
let currentSubId = null;

async function loadUserData(user) {
  const sub = await fetchSubscription(user.id);
  if (!sub) {
    const displayName = user.user_metadata?.full_name || user.user_metadata?.name || user.email;
    nosubUserName.textContent = displayName;
    showScreen(screenNoSub);
    return;
  }

  currentUserId = user.id;
  currentSubId = sub.id;

  const displayName = user.user_metadata?.full_name || user.user_metadata?.name || user.email;
  const avatar = user.user_metadata?.avatar_url || user.user_metadata?.picture || '';

  userName.textContent = displayName.split(' ')[0];
  if (avatar) { userAvatar.src = avatar; userAvatar.style.display = 'block'; }
  else { userAvatar.style.display = 'none'; }

  creditsCount.textContent = 'Mi Plan';

  showScreen(screenMain);
  initUI();
  restoreScrollPosition();
}

// Auto-detectar tipo de aula ejecutando script directo en el frame principal
// autoDetectCourseType eliminado — el popup es genérico, el content script detecta en Moodle

async function fetchSubscription(userId) {
  const session = await sendMessage({ type: 'GET_SESSION' });
  if (!session.ok) return null;

  const url = `${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?user_id=eq.${userId}&status=eq.active&period_end=gte.${new Date().toISOString().split('T')[0]}&order=period_end.desc&limit=1`;
  const res = await fetch(url, {
    headers: { 'Authorization': `Bearer ${session.token}`, 'apikey': CONFIG.SUPABASE_ANON_KEY }
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.length > 0 ? data[0] : null;
}

// ============================================================
// USAGE PANEL (Mi Plan dropdown)
// ============================================================

const ACTION_LIMITS = {
  import_template: { label: 'Importar plantilla', max: 12 },
  generate_no_ai: { label: 'Generar sílabo', max: 12 },
  generate_ai: { label: 'Generar sílabo IA', max: 12, ai: true },
  edit_banner: { label: 'Editar banner', max: 12 },
  upload_resources: { label: 'Subir recursos', max: 140 },
  create_task: { label: 'Crear tarea', max: 90 },
  generate_rubric: { label: 'Rúbrica IA', max: 90, ai: true },
  create_quiz: { label: 'Crear evaluación', max: 30 },
  generate_aiken: { label: 'Preguntas IA', max: 30, ai: true },
};

const usagePanel = document.getElementById('usagePanel');
const creditsBadge = document.getElementById('creditsBadge');

creditsBadge.addEventListener('click', async (e) => {
  e.stopPropagation();
  const isOpen = usagePanel.classList.toggle('open');
  if (isOpen) await loadUsagePanel();
});

document.addEventListener('click', (e) => {
  if (!usagePanel.contains(e.target) && !creditsBadge.contains(e.target)) {
    usagePanel.classList.remove('open');
  }
});

// Botón "Comprar más usos" abre la página de precios en nueva pestaña
document.getElementById('btnBuyMore').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: CONFIG.PRICING_URL });
  usagePanel.classList.remove('open');
});

async function loadUsagePanel() {
  const content = document.getElementById('usagePanelContent');
  if (!currentUserId || !currentSubId) {
    content.innerHTML = '<div style="font-size:11px;color:#94a3b8;">Sin suscripción activa</div>';
    return;
  }

  content.innerHTML = '<div style="font-size:11px;color:#94a3b8;">Cargando...</div>';

  try {
    const session = await sendMessage({ type: 'GET_SESSION' });
    if (!session.ok) return;

    const headers = { 'Authorization': `Bearer ${session.token}`, 'apikey': CONFIG.SUPABASE_ANON_KEY };

    const [usageRes, subRes] = await Promise.all([
      fetch(`${CONFIG.SUPABASE_URL}/rest/v1/action_usage?subscription_id=eq.${currentSubId}`, { headers }),
      fetch(`${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?id=eq.${currentSubId}&select=period_end,plan_name`, { headers }),
    ]);

    const usageData = usageRes.ok ? await usageRes.json() : [];
    const subData = subRes.ok ? await subRes.json() : [];

    const usageMap = {};
    usageData.forEach(u => { usageMap[u.action] = u.uses_count; });

    let html = '';
    for (const [action, info] of Object.entries(ACTION_LIMITS)) {
      const used = usageMap[action] || 0;
      const pct = Math.min((used / info.max) * 100, 100);
      const barClass = pct >= 90 ? 'red' : pct >= 70 ? 'yellow' : 'green';
      const aiTag = info.ai ? '<span class="usage-ai-tag">IA</span>' : '';

      html += `<div class="usage-row">
        <span class="usage-row-label">${info.label}${aiTag}</span>
        <span class="usage-row-count">${used}/${info.max}</span>
      </div>
      <div class="usage-bar"><div class="usage-bar-fill ${barClass}" style="width:${pct}%"></div></div>`;
    }

    if (subData.length > 0) {
      const endDate = new Date(subData[0].period_end).toLocaleDateString('es-EC');
      html += `<div class="usage-panel-period">Válido hasta: ${endDate}</div>`;
    }

    content.innerHTML = html;
  } catch (e) {
    content.innerHTML = '<div style="font-size:11px;color:#ef4444;">Error al cargar uso</div>';
  }
}

// ============================================================
// LOGIN / LOGOUT
// ============================================================

btnGoogleLogin.addEventListener('click', async () => {
  btnGoogleLogin.disabled = true;
  btnGoogleLogin.textContent = 'Conectando...';
  loginError.style.display = 'none';

  const result = await sendMessage({ type: 'LOGIN_GOOGLE' });
  if (result.ok) {
    await loadUserData(result.user);
  } else {
    loginError.textContent = result.error || 'Error al iniciar sesion';
    loginError.style.display = 'block';
    btnGoogleLogin.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 48 48">
        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
      </svg>
      Iniciar sesion con Google`;
    btnGoogleLogin.disabled = false;
  }
});

btnLogout.addEventListener('click', doLogout);
btnLogoutNoSub.addEventListener('click', doLogout);
async function doLogout() {
  await sendMessage({ type: 'LOGOUT' });
  showScreen(screenLogin);
}

// ============================================================
// UTILITIES
// ============================================================

function sendMessage(msg) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage(msg, response => {
      resolve(response || { ok: false, error: 'Sin respuesta' });
    });
  });
}

function formatDate(dateStr) {
  const months = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
  const d = new Date(dateStr + 'T12:00:00');
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function escapeAttr(str) {
  return (str || '').replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

// showStatus: muestra mensaje cerca de un botón o en un contenedor con ID
// - nearBtn: un elemento DOM (botón) junto al cual insertar el mensaje
// - suffix: fallback al elemento #status{suffix}
function showStatus(msg, type, nearBtnOrSuffix) {
  // Limpiar status previos inline
  document.querySelectorAll('.status-inline-dynamic').forEach(el => el.remove());

  let el;
  if (nearBtnOrSuffix instanceof HTMLElement) {
    // Crear un div inline justo después del botón (o su contenedor .btn-row / .subsection)
    el = document.createElement('div');
    el.className = 'status-inline-dynamic status-inline ' + type;
    el.textContent = msg;
    const container = nearBtnOrSuffix.closest('.btn-row') || nearBtnOrSuffix.closest('.uaz-ready') || nearBtnOrSuffix.parentElement;
    container.insertAdjacentElement('afterend', el);
  } else {
    // Fallback: usar elemento con ID
    const suffix = nearBtnOrSuffix || '';
    el = suffix ? document.getElementById(`status${suffix}`) : statusEl;
    if (!el) return;
    el.textContent = msg;
    el.className = 'status-inline ' + type;
  }
  el.style.display = 'block';
  if (type === 'success') setTimeout(() => { el.style.display = 'none'; if (el.classList.contains('status-inline-dynamic')) el.remove(); }, 5000);
}

function hideStatus(suffix = '') {
  document.querySelectorAll('.status-inline-dynamic').forEach(el => el.remove());
  const el = suffix ? document.getElementById(`status${suffix}`) : statusEl;
  if (el) el.style.display = 'none';
}

function updateCredits(text) {
  creditsCount.textContent = text;
}

async function serializeFile(file) {
  return new Promise(resolve => {
    const reader = new FileReader();
    reader.onload = () => resolve({ data: reader.result, name: file.name, type: file.type });
    reader.readAsDataURL(file);
  });
}

// Extract text from PDF using pdf.js (client-side, before sending to backend)
async function extractTextFromPDF(file) {
  const arrayBuffer = await file.arrayBuffer();
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let text = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map(item => item.str).join(' ') + '\n';
  }
  return text;
}

// Extract text from Excel (.xlsx/.xls) using SheetJS — concatena todas las hojas
// como CSV separado por " | ", precedido del nombre de la hoja. Lo entiende bien la IA.
async function extractTextFromExcel(file) {
  if (typeof XLSX === 'undefined') throw new Error('Lib XLSX no cargada');
  const arrayBuffer = await file.arrayBuffer();
  const wb = XLSX.read(arrayBuffer, { type: 'array' });
  let text = '';
  for (const name of wb.SheetNames) {
    text += `\n=== HOJA: ${name} ===\n`;
    text += XLSX.utils.sheet_to_csv(wb.Sheets[name], { FS: ' | ', blankrows: false });
  }
  return text.trim();
}

// Wrapper: detecta tipo del archivo del sílabo y llama al extractor correcto.
// PDF y Excel devuelven texto plano que la IA procesa igual.
async function extractTextFromSyllabus(file) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (ext === 'pdf') return extractTextFromPDF(file);
  if (ext === 'xlsx' || ext === 'xls') return extractTextFromExcel(file);
  throw new Error(`Formato no soportado: .${ext}`);
}

// Execute action via backend (auth + credits)
async function executeAction(action, payload) {
  const result = await sendMessage({ type: 'EXECUTE_ACTION', action, payload });
  if (result.ok && result.uses_remaining != null && result.uses_remaining >= 0) {
    showStatus(`Usos restantes: ${result.uses_remaining}/${result.uses_total}`, 'success');
  }
  return result;
}

// ============================================================
// INIT UI (called after login+subscription verified)
// ============================================================

let uiInitialized = false;

function initUI() {
  if (uiInitialized) return;
  uiInitialized = true;

  initDateRangePickers();
  initQuizTimeSelects();
  initQuizTimeLimitSelect();
  initFileSlotButtons();
  initUploadZones();
  initRdaTabs();
  initCriterioTabs();
  initManualCriterioPills('manualTaskCriterioTabs', 'manualTaskCriterio', 'manualTask');
  initManualCriterioPills('manualQuizCriterioTabs', 'manualQuizCriterio', 'manualQuiz');
  // Refresh criterio sub-selector según la estructura del aula. Async, no bloqueante.
  refreshCriterioSelector().catch(() => {});
  initAiTabs();
  initCourseType();
  initSchedule();
  initRubric();
  initActionButtons();
  initAikenLoader();
  initMultiBanksUI();
  // Tema visual global: cargar y enganchar selector. Async pero no bloqueante.
  // Detectar el tenant (Quito vs Ambato) ANTES de inicializar el selector,
  // así el preview del tema ya muestra el logo institucional correcto.
  detectTenant().then(() => loadActiveTheme()).then(() => initThemeSelector());

  // Footer legal: año actual + versión del manifest (siempre sincronizados)
  try {
    const yearEl = document.getElementById('legal-year');
    if (yearEl) yearEl.textContent = String(new Date().getFullYear());
    const verEl = document.getElementById('legal-version');
    if (verEl && chrome.runtime?.getManifest) {
      const v = chrome.runtime.getManifest().version;
      if (v) verEl.textContent = 'v' + v;
    }
  } catch (_) {}
  initUrlValidation();
  initProgressMonitor();
  // Auto-guardar al cambiar cualquier campo de tarea/evaluación
  ['manualTaskName','manualTaskDesc','manualTaskCriterio',
   'manualTaskDateFrom','manualTaskDateTo',
   'manualQuizName','manualQuizPassword','manualQuizTime','manualQuizCriterio',
   'manualQuizDateFrom','manualQuizDateTo',
   'manualQuizHourFrom','manualQuizMinFrom','manualQuizHourTo','manualQuizMinTo'
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', () => saveFormState());
  });
  ['manualTaskName','manualTaskDesc','manualQuizName','manualQuizPassword'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', () => saveFormState());
  });
  loadFormState();
}

// ============================================================
// FILE SLOT BUTTONS
// ============================================================

function initFileSlotButtons() {
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.file-slot-btn');
    if (!btn) return;
    const slot = btn.closest('.file-slot');
    const input = slot.querySelector('input[type="file"]');
    if (input) input.click();
  });
  // Bug #7: Validación de tipo de archivo
  const ALLOWED_FILE_TYPES = {
    'pdf-input': { exts: ['.pdf'], mime: ['application/pdf'], label: 'PDF' },
    'ppt-input': { exts: ['.pptx', '.ppt'], mime: ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/vnd.ms-powerpoint'], label: 'PowerPoint' },
  };

  document.addEventListener('change', (e) => {
    if (e.target.type !== 'file' || !e.target.closest('.file-slot')) return;
    const slot = e.target.closest('.file-slot');
    const nameInput = slot.querySelector('.file-slot-name');
    const file = e.target.files[0];

    // Bug #7: Validar tipo de archivo
    if (file) {
      for (const [cls, rule] of Object.entries(ALLOWED_FILE_TYPES)) {
        if (e.target.classList.contains(cls)) {
          const ext = '.' + file.name.split('.').pop().toLowerCase();
          if (!rule.exts.includes(ext)) {
            showStatus(`Solo se permiten archivos ${rule.label} (${rule.exts.join(', ')})`, 'error');
            e.target.value = '';
            return;
          }
          break;
        }
      }
    }

    if (nameInput) {
      if (file) {
        nameInput.value = file.name.replace(/\.[^.]+$/, '');
        nameInput.classList.add('has-file');
        nameInput.removeAttribute('readonly');
      } else {
        nameInput.value = 'Sin archivo';
        nameInput.classList.remove('has-file');
        nameInput.setAttribute('readonly', '');
      }
    }
  });
}

// ============================================================
// UPLOAD ZONES (template + syllabus)
// ============================================================

function initUploadZones() {
  // Template .mbz
  const dropTemplate = document.getElementById('dropZoneTemplate');
  const templateFile = document.getElementById('templateFile');
  const templateFileName = document.getElementById('templateFileName');
  const btnImport = document.getElementById('btnImportTemplate');

  // Helper: setea el "ready" state visual con un nombre dado
  const setTemplateReady = (name) => {
    dropTemplate.classList.add('has-file');
    dropTemplate.querySelector('.uaz-idle').style.display = 'none';
    dropTemplate.querySelector('.uaz-ready').style.display = 'flex';
    templateFileName.textContent = name;
    btnImport.disabled = false;
  };

  templateFile.addEventListener('change', () => {
    if (templateFile.files[0]) {
      const ext = templateFile.files[0].name.split('.').pop().toLowerCase();
      if (ext !== 'mbz') {
        showStatus('Solo se permiten archivos .mbz (backup de Moodle)', 'error');
        templateFile.value = '';
        return;
      }
      setTemplateReady(templateFile.files[0].name);
    }
  });

  templateFileName.addEventListener('click', () => {
    templateFile.value = '';
    dropTemplate.classList.remove('has-file');
    dropTemplate.querySelector('.uaz-idle').style.display = 'flex';
    dropTemplate.querySelector('.uaz-ready').style.display = 'none';
    btnImport.disabled = true;
  });

  // Pre-cargar la plantilla PUCE Quito por defecto (bundle dentro de la extensión).
  // El usuario puede sobrescribirla clickeando el nombre o arrastrando otro .mbz.
  (async () => {
    try {
      const url = chrome.runtime.getURL('plantillas/plantilla-puce-quito.mbz');
      const resp = await fetch(url);
      if (!resp.ok) return;
      const blob = await resp.blob();
      const file = new File([blob], 'Plantilla puce.mbz', { type: 'application/octet-stream' });
      const dt = new DataTransfer();
      dt.items.add(file);
      templateFile.files = dt.files;
      setTemplateReady('Plantilla puce.mbz (por defecto)');
    } catch (e) {
      console.warn('[GAULA] No se pudo precargar plantilla por defecto:', e);
    }
  })();

  // Syllabus PDF
  const dropSyllabus = document.getElementById('dropZoneSyllabus');
  const syllabusFile = document.getElementById('syllabusFile');
  const syllabusFileName = document.getElementById('syllabusFileName');
  const btnGenAI = document.getElementById('btnGenerateAI');
  const btnGenNoAI = document.getElementById('btnGenerateNoAI');

  syllabusFile.addEventListener('change', () => {
    if (syllabusFile.files[0]) {
      // Validar que sea PDF o Excel (.xlsx/.xls)
      const ext = syllabusFile.files[0].name.split('.').pop().toLowerCase();
      if (!['pdf', 'xlsx', 'xls'].includes(ext)) {
        showStatus('Solo se permiten archivos PDF o Excel (.xlsx, .xls) para el sílabo', 'error');
        syllabusFile.value = '';
        return;
      }
      dropSyllabus.classList.add('has-file');
      dropSyllabus.querySelector('.uaz-idle').style.display = 'none';
      dropSyllabus.querySelector('.uaz-ready').style.display = 'flex';
      syllabusFileName.textContent = syllabusFile.files[0].name;
      btnGenAI.disabled = false;
      btnGenNoAI.disabled = false;
    }
  });

  syllabusFileName.addEventListener('click', () => {
    syllabusFile.value = '';
    dropSyllabus.classList.remove('has-file');
    dropSyllabus.querySelector('.uaz-idle').style.display = 'flex';
    dropSyllabus.querySelector('.uaz-ready').style.display = 'none';
    btnGenAI.disabled = true;
    btnGenNoAI.disabled = true;
  });
}

// ============================================================
// RDA TABS
// ============================================================

function initRdaTabs() {
  document.querySelectorAll('.rda-tab, .rda-tab-mini').forEach(tab => {
    tab.addEventListener('click', () => {
      const rdaIndex = parseInt(tab.dataset.rda) - 1;
      switchRda(rdaIndex);
    });
  });
  // (evaposgrado: las pills de secciones reales se generan en setupEvaposSections
  //  y traen su propio click → switchRda(i).)
}

// `activeCriterio` es GLOBAL (igual que activeRda). Un solo valor compartido
// entre los pills de Recursos, Tarea y Evaluación. Click en cualquier pill
// actualiza los 3 grupos + los hidden inputs + persiste inmediato.
function setActiveCriterio(val, opts = {}) {
  const num = parseInt(val) || 1;
  const prev = activeCriterio;
  // 1. Guardar lo que el user tenga en pantalla bajo el criterio ANTERIOR
  //    (antes de mover el cursor al criterio nuevo).
  if (opts.save !== false && prev !== num) {
    saveCurrentRdaData();
  }
  activeCriterio = num;
  const strVal = String(num);
  // 2. Sincronizar visual en los 3 grupos de pills
  ['criterioSelector', 'manualTaskCriterioTabs', 'manualQuizCriterioTabs'].forEach(id => {
    const root = document.getElementById(id);
    if (!root) return;
    root.querySelectorAll('.criterio-tab').forEach(t => {
      t.classList.toggle('active', t.dataset.criterio === strVal);
    });
  });
  // 3. Sincronizar hidden inputs (lo que lee saveManualTaskData / saveManualQuizData
  // y los handlers de upload al construir el mensaje al content script).
  const hT = document.getElementById('manualTaskCriterio');
  if (hT) hT.value = strVal;
  const hQ = document.getElementById('manualQuizCriterio');
  if (hQ) hQ.value = strVal;
  // 4. Recargar slots de "Contenido por RDA" con archivos del criterio nuevo
  if (prev !== num) {
    loadRdaData(activeRda);
  }
  if (opts.save !== false) _saveFormStateImmediate();
}

function initCriterioTabs() {
  const root = document.getElementById('criterioSelector');
  if (!root) return;
  root.querySelectorAll('.criterio-tab').forEach(tab => {
    tab.addEventListener('click', () => setActiveCriterio(tab.dataset.criterio || '1'));
  });
}

// Pills de Tarea/Quiz: comparten el mismo activeCriterio global.
function initManualCriterioPills(containerId, hiddenInputId, dataKey) {
  const root = document.getElementById(containerId);
  if (!root) return;
  root.querySelectorAll('.criterio-tab').forEach(tab => {
    tab.addEventListener('click', () => setActiveCriterio(tab.dataset.criterio || '1'));
  });
}

// Aplica el active visual al pill correspondiente a `value` dentro de containerId.
// (Helper interno usado por loadManualTaskData/Quiz al cargar datos del RDA.)
function applyManualCriterioActive(containerId, value) {
  const root = document.getElementById(containerId);
  if (!root) return;
  root.querySelectorAll('.criterio-tab').forEach(t => {
    t.classList.toggle('active', t.dataset.criterio === String(value || '1'));
  });
}

// Ajusta cuántos tabs criterio son visibles en un container, según el RDA actual.
// Si criterioCountsCache está poblado (aula nested), respeta ese count.
// En aulas flat, muestra 4 (porque grade categories pueden incluir hasta Criterio 4).
function updateManualCriterioVisibility(containerId, rdaIdx) {
  const root = document.getElementById(containerId);
  if (!root) return;
  const count = (criterioCountsCache && criterioCountsCache[rdaIdx]) || 4;
  root.querySelectorAll('.criterio-tab').forEach((btn, i) => {
    btn.style.display = i < count ? 'inline-block' : 'none';
  });
}

// Marca como activo el tab criterio correspondiente a activeCriterio (visual).
// Llamarlo después de cambiar activeCriterio programáticamente o tras loadFormState.
function applyActiveCriterioUI() {
  document.querySelectorAll('.criterio-tab').forEach(t => {
    const n = parseInt(t.dataset.criterio) || 0;
    t.classList.toggle('active', n === activeCriterio);
  });
}

// ── Opción A (evaposgrado): pills con las secciones REALES ────────────────
// Los 3 contenedores de pills (selector principal + mini de Tarea + mini de
// Evaluación), igual que la extensión normal. Las pills reales se INSERTAN como
// .evapos-pill (ocultando las originales sin tocarlas) y se sincronizan vía switchRda.
const EVAPOS_PILL_CONTAINERS = [
  { sel: '#rdaSelectorOrig', cls: 'rda-tab' },
  { sel: '#rdaMiniTask', cls: 'rda-tab-mini' },
  { sel: '#rdaMiniQuiz', cls: 'rda-tab-mini' },
];
// Restaura la UI original (pills RDA fijas) y desactiva el modo evaposgrado.
function gaulaResetEvaposUI() {
  EVAPOS_SECTIONS = null;
  EVAPOS_PILL_CONTAINERS.forEach(c => {
    const box = document.querySelector(c.sel);
    if (!box) return;
    box.querySelectorAll('.evapos-pill').forEach(b => b.remove());          // quitar pills reales
    box.querySelectorAll('button:not(.evapos-pill)').forEach(b => { b.style.display = ''; }); // restaurar originales
  });
  // Restaurar los contenedores de criterio mini (pudieron quedar ocultos en un curso
  // no repotenciado de evaposgrado). En el resto de sedes deben mostrarse normal.
  ['manualTaskCriterioTabs', 'manualQuizCriterioTabs'].forEach(id => {
    const el = document.getElementById(id); if (el) el.style.display = '';
  });
}
// Construye EVAPOS_SECTIONS desde la estructura real y renderiza las MISMAS pills
// (mismo look) con los nombres reales del curso EN LOS 3 CONTENEDORES, ocultando
// las pills fijas originales. "General" (sección 0) se ignora; si el curso no tiene
// otras secciones, se ofrece "General" como único destino.
function setupEvaposSections(struct) {
  const selector = document.getElementById('criterioSelector');
  if (!struct || !Array.isArray(struct.rdas)) { EVAPOS_SECTIONS = null; return; }
  let secs = struct.rdas.filter(r => r.sectionId !== 0 && !/^general$/i.test((r.label || '').trim()));
  if (!secs.length) secs = [{ label: 'General', sectionId: 0, criterios: null }];
  EVAPOS_SECTIONS = secs.map(s => ({ label: s.label, sectionId: s.sectionId, criterios: s.criterios || null }));
  if (activeRda >= EVAPOS_SECTIONS.length || activeRda < 0) activeRda = 0;
  // Render pills reales en los 3 contenedores (oculta originales, no las borra).
  EVAPOS_PILL_CONTAINERS.forEach(c => {
    const box = document.querySelector(c.sel);
    if (!box) return;
    box.querySelectorAll('.evapos-pill').forEach(b => b.remove());
    box.querySelectorAll('button:not(.evapos-pill)').forEach(b => { b.style.display = 'none'; });
    EVAPOS_SECTIONS.forEach((s, i) => {
      const b = document.createElement('button');
      b.className = c.cls + ' evapos-pill' + (i === activeRda ? ' active' : '');
      b.textContent = s.label;
      b.dataset.evaposIdx = String(i);
      b.addEventListener('click', () => switchRda(i));
      box.appendChild(b);
    });
  });
  // rdaData trae 3 slots fijos; algunos cursos de evaposgrado tienen 4+ secciones
  // (p.ej. Unidad 1-4). Padear para que loadRdaData/saveCurrentRdaData no rompan.
  while (rdaData.length < EVAPOS_SECTIONS.length) {
    rdaData.push({ pdfs: emptyCritFileMatrix(), ppts: emptyCritFileMatrix(), videos: emptyCritStringMatrix(), geneallys: emptyCritStringMatrix(), tasks: [{}, {}, {}], evals: [{}, {}, {}], forumTopic: '', aiAnalyzed: false, pdfText: '', manualTask: createEmptyManualTask(), manualQuiz: createEmptyManualQuiz() });
  }
  loadRdaData(activeRda);
  // Criterios: SOLO existen en repotenciado (RDA con sub-tabs anidados). En no
  // repotenciado (Tema / Calificación N / Parcial N) NO hay criterios → se ocultan
  // los 3 selectores de criterio (principal + mini Tarea + mini Evaluación).
  const critMiniTask = document.getElementById('manualTaskCriterioTabs');
  const critMiniQuiz = document.getElementById('manualQuizCriterioTabs');
  if (struct.hasNestedCriterios && selector) {
    criterioCountsCache = EVAPOS_SECTIONS.map((s, i) => {
      if (s.criterios && s.criterios.length) return s.criterios.length;
      if (i < EVAPOS_SECTIONS.length - 1) return Math.max(1, EVAPOS_SECTIONS[i + 1].sectionId - s.sectionId);
      return 3;
    });
    selector.style.display = 'flex';
    if (critMiniTask) critMiniTask.style.display = '';
    if (critMiniQuiz) critMiniQuiz.style.display = '';
    updateCriterioButtonsForRda(activeRda);
    updateManualCriterioVisibility('manualTaskCriterioTabs', activeRda);
    updateManualCriterioVisibility('manualQuizCriterioTabs', activeRda);
  } else {
    criterioCountsCache = null;
    activeCriterio = 1;  // sin criterios → siempre el "criterio 1" lógico
    if (selector) selector.style.display = 'none';
    if (critMiniTask) critMiniTask.style.display = 'none';
    if (critMiniQuiz) critMiniQuiz.style.display = 'none';
  }
}

// Pide la estructura del aula y construye un cache de criterio counts por RDA.
// Mecánica: solo el RDA activo expone sus criterios en DOM (format-onetopic).
// Para los demás RDAs inferimos el count vía gaps: RDA i tiene
// (rda[i+1].sectionId - rda[i].sectionId) criterios. El último RDA usa el count
// del RDA anterior como heurística (asume estructura uniforme — válido en PUCE).
async function refreshCriterioSelector() {
  const selector = document.getElementById('criterioSelector');
  if (!selector) return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab.url?.includes('/course/view.php')) {
      selector.style.display = 'none';
      criterioCountsCache = null;
      gaulaResetEvaposUI();
      return;
    }
    const res = await getCourseStructure(tab.id);
    const struct = res?.structure;
    // Opción A (SOLO evaposgrado): dropdown de secciones REALES detectadas.
    if (gaulaActiveTabIsEvapos(tab.url) && struct && Array.isArray(struct.rdas) && struct.rdas.length) {
      setupEvaposSections(struct);
      return;
    }
    gaulaResetEvaposUI(); // no evaposgrado → comportamiento original (pills RDA fijas)
    if (!struct?.hasNestedCriterios || !struct.rdas) {
      selector.style.display = 'none';
      criterioCountsCache = null;
      return;
    }
    // Construir cache de criterio counts por RDA
    const counts = [];
    for (let i = 0; i < struct.rdas.length; i++) {
      const rda = struct.rdas[i];
      if (rda.criterios && rda.criterios.length > 0) {
        // RDA activo en Moodle: vemos sus criterios en DOM, tomar count real
        counts.push(rda.criterios.length);
      } else if (i < struct.rdas.length - 1) {
        // RDA intermedio: inferir por gap con el siguiente
        const next = struct.rdas[i + 1];
        const gap = next.sectionId - rda.sectionId;
        counts.push(Math.max(1, gap));
      } else {
        // Último RDA sin criterios visibles: usar count del previo (heurística uniforme)
        counts.push(counts[counts.length - 1] || 3);
      }
    }
    criterioCountsCache = counts;
    selector.style.display = 'flex';
    updateCriterioButtonsForRda(activeRda);
    // También refrescar la visibilidad de los pills de Tarea/Quiz que usan el mismo cache
    updateManualCriterioVisibility('manualTaskCriterioTabs', activeRda);
    updateManualCriterioVisibility('manualQuizCriterioTabs', activeRda);
  } catch (e) {
    selector.style.display = 'none';
    criterioCountsCache = null;
  }
}

// Ajusta visibilidad de los tabs criterio según el RDA actualmente seleccionado
// en el popup. Reseta activeCriterio a 1 si queda fuera de rango.
function updateCriterioButtonsForRda(rdaIdx) {
  if (!criterioCountsCache) return;
  const count = criterioCountsCache[rdaIdx] || 3;
  document.querySelectorAll('.criterio-tab').forEach((btn, i) => {
    btn.style.display = i < count ? 'inline-block' : 'none';
  });
  // Si activeCriterio quedó fuera de rango (RDA distinto con menos criterios), resetear a 1.
  // Si sigue en rango, NO reseteamos — el usuario lo eligió y se respeta entre RDA y entre aperturas.
  if (activeCriterio > count) {
    activeCriterio = 1;
  }
  applyActiveCriterioUI();
}

function switchRda(index) {
  saveCurrentRdaData();
  // Evaposgrado: index es el índice en EVAPOS_SECTIONS; mantener en rango.
  if (EVAPOS_SECTIONS && (index < 0 || index >= EVAPOS_SECTIONS.length)) index = 0;
  activeRda = index;
  document.querySelectorAll('.rda-tab').forEach((tab, i) => {
    tab.classList.toggle('active', i === index);
  });
  document.querySelectorAll('.rda-tab-mini').forEach((tab, i) => {
    tab.classList.toggle('active', i % 3 === index);
  });
  // Evaposgrado: marcar la pill real activa en LOS 3 contenedores (sincronizadas).
  // DEBE ir DESPUÉS de los toggles de arriba (las evapos-pill comparten clase con
  // ellos), para tener la última palabra. Su orden coincide con EVAPOS_SECTIONS.
  if (EVAPOS_SECTIONS) {
    EVAPOS_PILL_CONTAINERS.forEach(c => {
      const box = document.querySelector(c.sel);
      if (box) box.querySelectorAll('.evapos-pill').forEach((b, i) => b.classList.toggle('active', i === index));
    });
  }
  loadRdaData(index);
  // Ajustar tabs criterio según el RDA recién seleccionado (cada RDA puede
  // tener cantidad distinta — leemos del cache inferido por gaps).
  updateCriterioButtonsForRda(index);
  // También para los pills de Tarea/Quiz (siempre visibles, pero el count puede variar por RDA)
  updateManualCriterioVisibility('manualTaskCriterioTabs', index);
  updateManualCriterioVisibility('manualQuizCriterioTabs', index);
  // Save inmediato — un click en tab puede ser seguido de cerrar popup
  _saveFormStateImmediate();
}

function saveCurrentRdaData() {
  const rda = rdaData[activeRda];
  const pdfsArr = critArr(rda, 'pdfs');
  const pptsArr = critArr(rda, 'ppts');
  const videosArr = critArr(rda, 'videos');
  const geneallysArr = critArr(rda, 'geneallys');
  document.querySelectorAll('.pdf-input').forEach((input, i) => { if (input.files[0]) pdfsArr[i] = input.files[0]; });
  document.querySelectorAll('.ppt-input').forEach((input, i) => { if (input.files[0]) pptsArr[i] = input.files[0]; });
  document.querySelectorAll('.video-url').forEach((input, i) => { videosArr[i] = input.value; });
  document.querySelectorAll('.geneally-url').forEach((input, i) => { geneallysArr[i] = input.value; });
  document.querySelectorAll('#taskPanels .ai-tab-panel').forEach((panel, i) => {
    rda.tasks[i] = {
      ...rda.tasks[i],
      nombre: panel.querySelector('.task-name').value,
      descripcion: panel.querySelector('.task-desc').value,
      dateFrom: panel.querySelector('.task-date-from')?.value || '',
      dateTo: panel.querySelector('.task-date-to')?.value || ''
    };
  });
  document.querySelectorAll('#evalPanels .ai-tab-panel').forEach((panel, i) => {
    rda.evals[i] = {
      ...rda.evals[i],
      dateFrom: panel.querySelector('.eval-date-from')?.value || '',
      dateTo: panel.querySelector('.eval-date-to')?.value || ''
    };
  });
  rda.forumTopic = document.querySelector('.forum-topic')?.value || '';
  saveManualTaskData();
  saveManualQuizData();
}

function loadRdaData(index) {
  const rda = rdaData[index];
  const pdfsArr = critArr(rda, 'pdfs');
  const pptsArr = critArr(rda, 'ppts');
  const videosArr = critArr(rda, 'videos');
  const geneallysArr = critArr(rda, 'geneallys');
  const critIdx = Math.max(0, Math.min(3, (activeCriterio || 1) - 1));
  const savedPdfNames = (rda._pdfNames && rda._pdfNames[critIdx]) || [];
  const savedPptNames = (rda._pptNames && rda._pptNames[critIdx]) || [];
  document.querySelectorAll('.pdf-input').forEach((input, i) => {
    const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
    const hasFile = pdfsArr[i];
    const savedName = savedPdfNames[i];
    if (hasFile) {
      nameEl.value = hasFile.name.replace(/\.[^.]+$/, '');
      nameEl.classList.add('has-file');
      nameEl.removeAttribute('readonly');
    } else if (savedName) {
      nameEl.value = savedName.replace(/\.[^.]+$/, '') + ' (recargar)';
      nameEl.classList.add('has-file');
      nameEl.setAttribute('readonly', '');
    } else {
      nameEl.value = 'Sin archivo';
      nameEl.classList.remove('has-file');
      nameEl.setAttribute('readonly', '');
    }
  });
  document.querySelectorAll('.ppt-input').forEach((input, i) => {
    const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
    const hasFile = pptsArr[i];
    const savedName = savedPptNames[i];
    if (hasFile) {
      nameEl.value = hasFile.name.replace(/\.[^.]+$/, '');
      nameEl.classList.add('has-file');
      nameEl.removeAttribute('readonly');
    } else if (savedName) {
      nameEl.value = savedName.replace(/\.[^.]+$/, '') + ' (recargar)';
      nameEl.classList.add('has-file');
      nameEl.setAttribute('readonly', '');
    } else {
      nameEl.value = 'Sin archivo';
      nameEl.classList.remove('has-file');
      nameEl.setAttribute('readonly', '');
    }
  });
  document.querySelectorAll('.video-url').forEach((input, i) => { input.value = videosArr[i] || ''; });
  document.querySelectorAll('.geneally-url').forEach((input, i) => { input.value = geneallysArr[i] || ''; });
  document.querySelectorAll('#taskPanels .ai-tab-panel').forEach((panel, i) => {
    panel.querySelector('.task-name').value = rda.tasks[i].nombre || '';
    panel.querySelector('.task-desc').value = rda.tasks[i].descripcion || '';
    const df = panel.querySelector('.task-date-from'); if (df) df.value = rda.tasks[i].dateFrom || '';
    const dt = panel.querySelector('.task-date-to'); if (dt) dt.value = rda.tasks[i].dateTo || '';
  });
  document.querySelectorAll('#evalPanels .ai-tab-panel').forEach((panel, i) => {
    const df = panel.querySelector('.eval-date-from'); if (df) df.value = rda.evals[i]?.dateFrom || '';
    const dt = panel.querySelector('.eval-date-to'); if (dt) dt.value = rda.evals[i]?.dateTo || '';
  });
  document.querySelector('.forum-topic').value = rda.forumTopic || '';
  loadManualTaskData(index);
  loadManualQuizData(index);
  document.querySelectorAll('.date-range-picker').forEach(p => { if (p._drpUpdate) p._drpUpdate(); });
  document.getElementById('stageAiResults').style.display = rda.aiAnalyzed ? 'block' : 'none';

  const hasPdfs = flatCrits(rda, 'pdfs').some(f => f);
  document.getElementById('btnAnalyzeAi').disabled = !hasPdfs;
  document.getElementById('aiHelpText').textContent = hasPdfs
    ? 'PDFs cargados. Listo para analizar.'
    : 'Sube al menos un PDF para poder analizar con IA.';
}

// ============================================================
// AI TABS (task/eval results)
// ============================================================

function initAiTabs() {
  document.querySelectorAll('.ai-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const tabType = tab.dataset.tab;
      const index = tab.dataset.index;
      document.querySelectorAll(`.ai-tab[data-tab="${tabType}"]`).forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const container = tabType === 'task' ? document.getElementById('taskPanels') : document.getElementById('evalPanels');
      container.querySelectorAll('.ai-tab-panel').forEach(p => p.classList.remove('active'));
      container.querySelector(`.ai-tab-panel[data-index="${index}"]`).classList.add('active');
    });
  });
}

// ============================================================
// COURSE TYPE
// ============================================================

function initCourseType() {
  // Ya no hay autodetección — el popup es genérico
}

function syncCourseTypeUI() {
  // Ya no cambia nada dinámicamente — tabs y criterios son fijos
}

function getRdaLabel() {
  return 'RDA';
}

// ============================================================
// SCHEDULE (dynamic blocks)
// ============================================================

let scheduleBlocks = [];

function initSchedule() {
  document.getElementById('btnAddSchedule').addEventListener('click', () => {
    createScheduleBlock();
    saveFormState();
  });
  createScheduleBlock(); // start with one
}

function createScheduleBlock(data = {}) {
  const id = Date.now() + Math.random();
  scheduleBlocks.push({
    id, dia: data.dia || 'Lunes', horaInicio: data.horaInicio || '08:00',
    horaFin: data.horaFin || '10:00', aula: data.aula || '', modalidad: data.modalidad || 'Presencial'
  });
  renderScheduleBlocks();
}

function removeScheduleBlock(id) {
  scheduleBlocks = scheduleBlocks.filter(b => b.id !== id);
  renderScheduleBlocks();
  saveFormState();
}

function _schTimeOpts(type, selected) {
  const max = type === 'h' ? 24 : 60;
  const step = type === 'h' ? 1 : 5;
  let html = '';
  for (let v = 0; v < max; v += step) {
    const label = String(v).padStart(2, '0');
    html += `<option value="${v}" ${v === selected ? 'selected' : ''}>${label}</option>`;
  }
  return html;
}

// Helper: envuelve un <select class="trp-sel ..."> con UI custom estilo iOS.
// Mantiene el select nativo oculto para que el código que escucha 'change' siga funcionando.
function _renderCustomTimeSelect(extraClass, type, selected) {
  const max = type === 'h' ? 24 : 60;
  const step = type === 'h' ? 1 : 5;
  let nativeOpts = '';
  let menuOpts = '';
  for (let v = 0; v < max; v += step) {
    const label = String(v).padStart(2, '0');
    const isSel = v === selected;
    nativeOpts += `<option value="${v}" ${isSel ? 'selected' : ''}>${label}</option>`;
    menuOpts += `<div class="cts-option${isSel ? ' selected' : ''}" data-value="${v}"><span class="cts-check">${isSel ? '✓' : ''}</span><span>${label}</span></div>`;
  }
  const display = String(selected).padStart(2, '0');
  return `<span class="cts">
    <select class="trp-sel ${extraClass} cts-native">${nativeOpts}</select>
    <button type="button" class="cts-trigger" tabindex="-1">
      <span class="cts-current">${display}</span>
      <span class="cts-chevron">▾</span>
    </button>
    <div class="cts-menu" hidden>${menuOpts}</div>
  </span>`;
}

function _parseTime(t) { const p = (t || '00:00').split(':'); return { h: parseInt(p[0]) || 0, m: parseInt(p[1]) || 0 }; }

function renderScheduleBlocks() {
  const container = document.getElementById('scheduleList');
  container.innerHTML = scheduleBlocks.map(b => {
    const s = _parseTime(b.horaInicio), e = _parseTime(b.horaFin);
    return `<div class="schedule-block" data-id="${b.id}">
      ${scheduleBlocks.length > 1 ? '<button type="button" class="btn-remove-schedule" title="Quitar">&times;</button>' : ''}
      <div class="config-row">
        <div class="config-item"><label>Dia</label>
          <select class="sch-day">
            ${['Lunes','Martes','Miercoles','Jueves','Viernes','Sabado','Domingo'].map(d => `<option ${b.dia===d?'selected':''}>${d}</option>`).join('')}
          </select>
        </div>
        <div class="config-item"><label>Horario</label>
          <div class="time-range-picker">
            <input type="hidden" class="sch-start-h" value="${s.h}"><input type="hidden" class="sch-start-m" value="${s.m}">
            <input type="hidden" class="sch-end-h" value="${e.h}"><input type="hidden" class="sch-end-m" value="${e.m}">
            <span class="trp-display">${String(s.h).padStart(2,'0')}:${String(s.m).padStart(2,'0')} - ${String(e.h).padStart(2,'0')}:${String(e.m).padStart(2,'0')}</span>
            <div class="trp-dropdown" style="display:none">
              <div class="trp-section"><span class="trp-label">Inicio</span><div class="trp-selects">${_renderCustomTimeSelect('trp-sh','h',s.h)}<span class="time-sep">:</span>${_renderCustomTimeSelect('trp-sm','m',s.m)}</div></div>
              <div class="trp-section"><span class="trp-label">Fin</span><div class="trp-selects">${_renderCustomTimeSelect('trp-eh','h',e.h)}<span class="time-sep">:</span>${_renderCustomTimeSelect('trp-em','m',e.m)}</div></div>
            </div>
          </div>
        </div>
        <div class="config-item"><label>Aula</label><input type="text" class="sch-room" value="${escapeAttr(b.aula)}" placeholder="301"></div>
        <div class="config-item"><label>Modalidad</label>
          <select class="sch-mode">
            ${['Presencial','Virtual','Hibrida'].map(m => `<option ${b.modalidad===m?'selected':''}>${m}</option>`).join('')}
          </select>
        </div>
      </div>
    </div>`;
  }).join('');

  // Remove buttons
  container.querySelectorAll('.btn-remove-schedule').forEach(btn => {
    btn.addEventListener('click', () => removeScheduleBlock(Number(btn.closest('.schedule-block').dataset.id)));
  });

  // Sync on change
  container.querySelectorAll('input, select').forEach(el => {
    el.addEventListener('change', () => { syncScheduleData(); saveFormState(); });
  });

  // Time range pickers in schedule
  container.querySelectorAll('.time-range-picker').forEach(initTimeRangePicker);
}

// Conecta cada .cts (custom time select) dentro del picker:
// - click trigger → toggle menu
// - click option → set valor en native <select>, dispatch 'change', cierra menu
// - delegación: usa MutationObserver no, simple event delegation con scope al picker
function _bindCustomTimeSelects(picker) {
  picker.querySelectorAll('.cts').forEach(cts => {
    if (cts._ctsBound) return;
    cts._ctsBound = true;
    const native = cts.querySelector('.cts-native');
    const trigger = cts.querySelector('.cts-trigger');
    const menu = cts.querySelector('.cts-menu');
    const current = cts.querySelector('.cts-current');

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      // Cerrar otros menus abiertos en el picker
      picker.querySelectorAll('.cts-menu').forEach(m => { if (m !== menu) m.setAttribute('hidden', ''); });
      if (menu.hasAttribute('hidden')) {
        menu.removeAttribute('hidden');
        // Auto-scroll al option selected
        const sel = menu.querySelector('.cts-option.selected');
        if (sel) menu.scrollTop = sel.offsetTop - menu.clientHeight / 2 + sel.offsetHeight / 2;
      } else {
        menu.setAttribute('hidden', '');
      }
    });

    menu.querySelectorAll('.cts-option').forEach(opt => {
      opt.addEventListener('click', (e) => {
        e.stopPropagation();
        const val = opt.dataset.value;
        // Actualizar UI
        menu.querySelectorAll('.cts-option').forEach(o => {
          o.classList.toggle('selected', o === opt);
          const chk = o.querySelector('.cts-check');
          if (chk) chk.textContent = (o === opt) ? '✓' : '';
        });
        current.textContent = String(val).padStart(2, '0');
        // Actualizar native select + dispatch change
        native.value = val;
        native.dispatchEvent(new Event('change', { bubbles: true }));
        menu.setAttribute('hidden', '');
      });
    });
  });
}

// Listener global para cerrar menus al click afuera
document.addEventListener('click', (e) => {
  if (!e.target.closest('.cts')) {
    document.querySelectorAll('.cts-menu').forEach(m => m.setAttribute('hidden', ''));
  }
});

function initTimeRangePicker(picker) {
  _bindCustomTimeSelects(picker);
  const display = picker.querySelector('.trp-display');
  const dropdown = picker.querySelector('.trp-dropdown');
  const hSH = picker.querySelector('input.sch-start-h') || picker.querySelector('[id$="HourFrom"]');
  const hSM = picker.querySelector('input.sch-start-m') || picker.querySelector('[id$="MinFrom"]');
  const hEH = picker.querySelector('input.sch-end-h') || picker.querySelector('[id$="HourTo"]');
  const hEM = picker.querySelector('input.sch-end-m') || picker.querySelector('[id$="MinTo"]');

  if (!hSH || !display) return;

  function updateDisplay() {
    display.textContent = `${String(hSH.value).padStart(2,'0')}:${String(hSM.value).padStart(2,'0')} - ${String(hEH.value).padStart(2,'0')}:${String(hEM.value).padStart(2,'0')}`;
  }

  display.addEventListener('click', (e) => {
    e.stopPropagation();
    document.querySelectorAll('.trp-dropdown').forEach(d => { if (d !== dropdown) d.style.display = 'none'; });
    dropdown.style.display = dropdown.style.display === 'none' ? 'flex' : 'none';
  });

  picker.querySelectorAll('.trp-sel').forEach(sel => {
    sel.addEventListener('change', () => {
      if (sel.classList.contains('trp-sh')) hSH.value = sel.value;
      if (sel.classList.contains('trp-sm')) hSM.value = sel.value;
      if (sel.classList.contains('trp-eh')) hEH.value = sel.value;
      if (sel.classList.contains('trp-em')) hEM.value = sel.value;
      updateDisplay();
      // Validar horario docente (hora fin > hora inicio)
      const blockEl = picker.closest('.schedule-block');
      if (blockEl) validateScheduleTime(blockEl);
      // Validar quiz dates si es el picker del quiz
      if (picker.id === 'quizTimePicker') validateQuizDates();
      syncScheduleData();
      saveFormState();
    });
  });

  // Exponer función para sincronizar selects visibles desde hidden inputs
  picker._trpUpdate = () => {
    const selSH = picker.querySelector('.trp-sh');
    const selSM = picker.querySelector('.trp-sm');
    const selEH = picker.querySelector('.trp-eh');
    const selEM = picker.querySelector('.trp-em');
    if (selSH) selSH.value = hSH.value;
    if (selSM) selSM.value = hSM.value;
    if (selEH) selEH.value = hEH.value;
    if (selEM) selEM.value = hEM.value;
    updateDisplay();
  };
}

function syncScheduleData() {
  document.querySelectorAll('.schedule-block').forEach((el, i) => {
    if (!scheduleBlocks[i]) return;
    scheduleBlocks[i].dia = el.querySelector('.sch-day').value;
    const sh = String(el.querySelector('input.sch-start-h').value).padStart(2,'0');
    const sm = String(el.querySelector('input.sch-start-m').value).padStart(2,'0');
    scheduleBlocks[i].horaInicio = sh + ':' + sm;
    const eh = String(el.querySelector('input.sch-end-h').value).padStart(2,'0');
    const em = String(el.querySelector('input.sch-end-m').value).padStart(2,'0');
    scheduleBlocks[i].horaFin = eh + ':' + em;
    scheduleBlocks[i].aula = el.querySelector('.sch-room').value;
    scheduleBlocks[i].modalidad = el.querySelector('.sch-mode').value;
  });
}

function getScheduleData() {
  syncScheduleData();
  return scheduleBlocks.map(b => ({ dia: b.dia, horaInicio: b.horaInicio, horaFin: b.horaFin, aula: b.aula, modalidad: b.modalidad }));
}

// Validar que hora fin > hora inicio en horario docente
function validateScheduleTime(blockEl) {
  const picker = blockEl.querySelector('.time-range-picker');
  if (!picker) return;
  const hiddenSH = picker.querySelector('input.sch-start-h');
  const hiddenSM = picker.querySelector('input.sch-start-m');
  const hiddenEH = picker.querySelector('input.sch-end-h');
  const hiddenEM = picker.querySelector('input.sch-end-m');
  const selEH = picker.querySelector('.trp-eh');
  const selEM = picker.querySelector('.trp-em');

  const sh = parseInt(hiddenSH.value) || 0;
  const sm = parseInt(hiddenSM.value) || 0;
  const eh = parseInt(hiddenEH.value) || 0;
  const em = parseInt(hiddenEM.value) || 0;

  // Auto-corregir si hora fin <= hora inicio
  if (eh < sh || (eh === sh && em <= sm)) {
    const correctedH = Math.min(sh + 1, 23);
    hiddenEH.value = String(correctedH);
    hiddenEM.value = String(sm);
    if (selEH) selEH.value = String(correctedH);
    if (selEM) selEM.value = String(sm);
  }

  // Deshabilitar opciones invalidas en hora fin
  if (selEH) {
    [...selEH.options].forEach(o => { o.disabled = parseInt(o.value) < sh; });
  }
  const currentEH = parseInt(hiddenEH.value) || 0;
  if (selEM) {
    [...selEM.options].forEach(o => { o.disabled = currentEH === sh && parseInt(o.value) <= sm; });
  }

  // Actualizar display
  const display = picker.querySelector('.trp-display');
  if (display) {
    const sh = String(hiddenSH.value).padStart(2,'0');
    const sm = String(hiddenSM.value).padStart(2,'0');
    const eh = String(hiddenEH.value).padStart(2,'0');
    const em = String(hiddenEM.value).padStart(2,'0');
    // Quiz picker usa formato descriptivo, horario de clases usa formato corto
    if (picker.id === 'quizTimePicker') {
      display.textContent = `Abre ${sh}:${sm} · Cierra ${eh}:${em}`;
    } else {
      display.textContent = `${sh}:${sm} - ${eh}:${em}`;
    }
  }
}

// Validar fechas/horas de evaluacion (cierre >= apertura + duracion)
function validateQuizDates() {
  const fromDate = document.getElementById('manualQuizDateFrom').value;
  const toEl = document.getElementById('manualQuizDateTo');
  const hiddenHTo = document.getElementById('manualQuizHourTo');
  const hiddenMTo = document.getElementById('manualQuizMinTo');
  const picker = document.getElementById('quizTimePicker');
  const selEH = picker ? picker.querySelector('.trp-eh') : null;
  const selEM = picker ? picker.querySelector('.trp-em') : null;
  if (!fromDate) return;

  const hFrom = parseInt(document.getElementById('manualQuizHourFrom').value) || 0;
  const mFrom = parseInt(document.getElementById('manualQuizMinFrom').value) || 0;
  const quizMinutes = parseInt(document.getElementById('manualQuizTime').value) || 60;

  // Cierre minimo = apertura + duracion del quiz
  const openDT = new Date(fromDate + 'T' + String(hFrom).padStart(2,'0') + ':' + String(mFrom).padStart(2,'0') + ':00');
  const minCloseDT = new Date(openDT.getTime() + quizMinutes * 60000);

  // Si no hay fecha de cierre, auto-poner
  if (!toEl.value) {
    toEl.value = minCloseDT.toISOString().split('T')[0];
  }

  // Si el cierre actual es anterior al minimo, auto-corregir
  const toDate = toEl.value;
  const hTo = parseInt(hiddenHTo.value) || 0;
  const mTo = parseInt(hiddenMTo.value) || 0;
  const closeDT = new Date(toDate + 'T' + String(hTo).padStart(2,'0') + ':' + String(mTo).padStart(2,'0') + ':00');

  if (closeDT < minCloseDT) {
    toEl.value = minCloseDT.toISOString().split('T')[0];
    const correctedH = minCloseDT.getHours();
    const minVal = Math.ceil(minCloseDT.getMinutes() / 5) * 5;
    if (minVal >= 60) {
      hiddenHTo.value = String(correctedH + 1);
      hiddenMTo.value = '0';
    } else {
      hiddenHTo.value = String(correctedH);
      hiddenMTo.value = String(minVal);
    }
  }

  // Deshabilitar opciones invalidas en los selects de hora cierre
  const sameDay = fromDate === toEl.value;
  const minCloseSameDay = minCloseDT.toISOString().split('T')[0] === toEl.value;
  const minHour = minCloseSameDay ? minCloseDT.getHours() : 0;
  const minMin = minCloseSameDay ? Math.ceil(minCloseDT.getMinutes() / 5) * 5 : 0;

  if (selEH) {
    [...selEH.options].forEach(o => { o.disabled = sameDay && parseInt(o.value) < minHour; });
  }
  const currentHTo = parseInt(hiddenHTo.value) || 0;
  if (selEM) {
    [...selEM.options].forEach(o => { o.disabled = sameDay && currentHTo === minHour && parseInt(o.value) < minMin; });
  }

  // Actualizar display y guardar
  if (picker) {
    const display = picker.querySelector('.trp-display');
    if (display) {
      const sh = String(document.getElementById('manualQuizHourFrom').value).padStart(2,'0');
      const sm = String(document.getElementById('manualQuizMinFrom').value).padStart(2,'0');
      const eh = String(hiddenHTo.value).padStart(2,'0');
      const em = String(hiddenMTo.value).padStart(2,'0');
      display.textContent = `Abre ${sh}:${sm} · Cierra ${eh}:${em}`;
    }
  }
  saveManualQuizData();
}

// ============================================================
// DATE RANGE PICKER
// ============================================================

const MONTHS_ES = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
const DAYS_ES = ['Lu','Ma','Mi','Ju','Vi','Sa','Do'];

function initDateRangePickers() {
  document.querySelectorAll('.date-range-picker').forEach(picker => {
    const display = picker.querySelector('.drp-display');
    const fromInput = picker.querySelector('input[type="hidden"]:first-of-type') || picker.querySelector('[class$="date-from"]');
    const toInput = picker.querySelectorAll('input[type="hidden"]')[1] || picker.querySelector('[class$="date-to"]');
    if (!display || !fromInput || !toInput) return;

    let state = { from: fromInput.value || null, to: toInput.value || null, selecting: null, viewMonth: new Date().getMonth(), viewYear: new Date().getFullYear() };
    let calendar = null;

    updateDisplay();
    display.addEventListener('click', (e) => { e.stopPropagation(); if (calendar) { closeCalendar(); return; } openCalendar(); });

    function updateDisplay() {
      if (state.from && state.to) { display.textContent = fmtD(state.from) + '  →  ' + fmtD(state.to); display.classList.add('has-dates'); }
      else if (state.from) { display.textContent = fmtD(state.from) + '  →  ...'; display.classList.add('has-dates'); }
      else { display.textContent = 'Seleccionar fechas'; display.classList.remove('has-dates'); }
    }

    function fmtD(ds) { const d = new Date(ds + 'T12:00:00'); return d.getDate() + ' ' + MONTHS_ES[d.getMonth()] + ' ' + d.getFullYear(); }
    function toISO(y, m, d) { return `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`; }

    function openCalendar() {
      state.selecting = 'from';
      if (state.from) { const d = new Date(state.from + 'T12:00:00'); state.viewMonth = d.getMonth(); state.viewYear = d.getFullYear(); }
      calendar = document.createElement('div'); calendar.className = 'drp-calendar'; picker.appendChild(calendar);
      renderCal();
      setTimeout(() => document.addEventListener('click', outsideClick), 0);
    }
    function closeCalendar() { if (calendar) { calendar.remove(); calendar = null; } document.removeEventListener('click', outsideClick); }
    function outsideClick(e) { if (!picker.contains(e.target)) closeCalendar(); }

    function renderCal() {
      const y = state.viewYear, m = state.viewMonth;
      const firstDay = (new Date(y, m, 1).getDay() + 6) % 7;
      const daysInMonth = new Date(y, m + 1, 0).getDate();
      const todayISO = new Date().toISOString().split('T')[0];
      // Permitir crear tareas/evaluaciones para HOY y hasta 5 días en el pasado
      // (fechas anteriores). Días anteriores a (hoy-5) siguen deshabilitados.
      const _minD = new Date(); _minD.setDate(_minD.getDate() - 5);
      const minISO = _minD.toISOString().split('T')[0];

      let html = `<div class="drp-header"><button type="button" class="drp-prev">&lt;</button><span class="drp-month-label">${MONTHS_ES[m]} ${y}</span><button type="button" class="drp-next">&gt;</button></div>`;
      html += `<div class="drp-weekdays">${DAYS_ES.map(d => `<span>${d}</span>`).join('')}</div><div class="drp-days">`;
      for (let i = 0; i < firstDay; i++) html += '<span class="drp-day empty"></span>';
      for (let d = 1; d <= daysInMonth; d++) {
        const iso = toISO(y, m, d);
        const isPast = iso < minISO;   // bloqueado solo si es anterior a hoy-5 días
        let cls = 'drp-day';
        if (isPast) cls += ' past';
        if (iso === todayISO) cls += ' today';
        if (state.from && iso === state.from) cls += ' start';
        if (state.to && iso === state.to) cls += ' end';
        if (state.from && state.to && iso > state.from && iso < state.to) cls += ' in-range';
        html += `<span class="${cls}" data-date="${iso}">${d}</span>`;
      }
      html += '</div>';
      html += `<div class="drp-hint">${state.selecting === 'from' ? 'Selecciona fecha inicio' : 'Selecciona fecha fin'}</div>`;
      calendar.innerHTML = html;

      calendar.querySelector('.drp-prev').addEventListener('click', (e) => { e.stopPropagation(); state.viewMonth--; if (state.viewMonth < 0) { state.viewMonth = 11; state.viewYear--; } renderCal(); });
      calendar.querySelector('.drp-next').addEventListener('click', (e) => { e.stopPropagation(); state.viewMonth++; if (state.viewMonth > 11) { state.viewMonth = 0; state.viewYear++; } renderCal(); });
      calendar.querySelectorAll('.drp-day:not(.empty):not(.past)').forEach(el => {
        el.addEventListener('click', (e) => {
          e.stopPropagation();
          const date = el.dataset.date;
          if (state.selecting === 'from') { state.from = date; state.to = null; state.selecting = 'to'; fromInput.value = date; toInput.value = ''; }
          else { if (date < state.from) { state.to = state.from; state.from = date; } else { state.to = date; } fromInput.value = state.from; toInput.value = state.to; state.selecting = 'from'; closeCalendar(); saveFormState(); }
          updateDisplay();
          if (calendar) renderCal();
        });
      });
    }

    picker._drpUpdate = () => { state.from = fromInput.value || null; state.to = toInput.value || null; updateDisplay(); };
  });
}

// ============================================================
// QUIZ TIME SELECTS
// ============================================================

function initQuizTimeSelects() {
  const picker = document.getElementById('quizTimePicker');
  if (!picker) return;
  // Reemplazar los <select> vacíos del HTML con el custom dropdown estilo iOS
  const trpSelectsDivs = picker.querySelectorAll('.trp-selects');
  if (trpSelectsDivs.length >= 2) {
    trpSelectsDivs[0].innerHTML =
      _renderCustomTimeSelect('trp-sh','h',8) +
      '<span class="time-sep">:</span>' +
      _renderCustomTimeSelect('trp-sm','m',0);
    trpSelectsDivs[1].innerHTML =
      _renderCustomTimeSelect('trp-eh','h',23) +
      '<span class="time-sep">:</span>' +
      _renderCustomTimeSelect('trp-em','m',55);
  }
  initTimeRangePicker(picker);
}

function initQuizTimeLimitSelect() {
  const sel = document.getElementById('manualQuizTime');
  if (!sel) return;
  [
    [10,'10m'],[15,'15m'],[20,'20m'],[30,'30m'],[45,'45m'],
    [60,'1H'],[90,'1H30'],[120,'2H'],
    [150,'2H30'],[180,'3H'],[240,'4H']
  ].forEach(([v,l]) => { sel.add(new Option(l, v)); });
  sel.value = 120;
}

// ============================================================
// RUBRIC
// ============================================================

function initRubric() {
  document.getElementById('btnAddCriterion').addEventListener('click', () => {
    const mt = rdaData[activeRda].manualTask;
    mt.rubrica.push({ nombre: '', niveles: [
      { nombre: 'Excelente', puntos: 5, descripcion: '' },
      { nombre: 'Bueno', puntos: 3, descripcion: '' },
      { nombre: 'Regular', puntos: 1, descripcion: '' },
      { nombre: 'Insuficiente', puntos: 0, descripcion: '' }
    ]});
    renderRubricCriteria();
    saveFormState();
  });
  renderRubricCriteria();
}

function recalcRubricPoints(mt) {
  const n = mt.rubrica.length || 1;
  // 50 puntos totales distribuidos entre N criterios; coincide con la
  // "Calificación máxima" de la tarea seteada en assignment-creator.js.
  const max = Math.round((50 / n) * 100) / 100;
  const ratios = [1, 2/3, 1/3, 0];
  mt.rubrica.forEach(c => { c.niveles.forEach((nv, i) => { nv.puntos = Math.round(max * (ratios[i] || 0) * 100) / 100; }); });
}

function renderRubricCriteria() {
  const mt = rdaData[activeRda].manualTask;
  recalcRubricPoints(mt);
  const container = document.getElementById('rubricCriteria');
  container.innerHTML = mt.rubrica.map((c, ci) => `
    <div class="rubric-block" data-index="${ci}">
      <div style="display:flex;gap:4px;align-items:center">
        <input type="text" class="rubric-name" value="${escapeAttr(c.nombre)}" placeholder="Criterio (ej: Contenido)" style="flex:1">
        ${mt.rubrica.length > 1 ? '<button type="button" class="btn-remove-rubric" title="Quitar">&times;</button>' : ''}
      </div>
      <div class="rubric-levels-grid">
        ${c.niveles.map((nv, ni) => `<div class="rubric-level"><span class="rubric-level-label">${nv.nombre} (${nv.puntos}pts)</span><textarea class="rubric-level-desc" data-nivel="${ni}" rows="2" placeholder="${nv.nombre}">${escapeAttr(nv.descripcion)}</textarea></div>`).join('')}
      </div>
    </div>
  `).join('');

  container.querySelectorAll('.btn-remove-rubric').forEach(btn => {
    btn.addEventListener('click', () => { mt.rubrica.splice(parseInt(btn.closest('.rubric-block').dataset.index), 1); renderRubricCriteria(); saveFormState(); });
  });
  container.querySelectorAll('input, textarea').forEach(el => {
    el.addEventListener('input', () => { syncRubricData(); saveFormState(); });
  });
}

function renderRubricFromJson(rubricaJson) {
  const mt = rdaData[activeRda].manualTask;
  if (!rubricaJson?.criterios) return;
  const nivelNames = ['Excelente', 'Bueno', 'Regular', 'Insuficiente'];
  mt.rubrica = rubricaJson.criterios.map(c => ({
    nombre: c.nombre || '',
    niveles: (c.niveles || []).map((nv, i) => ({
      nombre: nv.nombre || nivelNames[i] || `Nivel ${i + 1}`,
      puntos: nv.puntos ?? 0,
      descripcion: nv.descripcion || ''
    }))
  }));
  renderRubricCriteria();
}

function syncRubricData() {
  const mt = rdaData[activeRda].manualTask;
  document.querySelectorAll('#rubricCriteria .rubric-block').forEach((block, ci) => {
    if (!mt.rubrica[ci]) return;
    mt.rubrica[ci].nombre = block.querySelector('.rubric-name').value;
    block.querySelectorAll('.rubric-level-desc').forEach(input => {
      mt.rubrica[ci].niveles[parseInt(input.dataset.nivel)].descripcion = input.value;
    });
  });
}

function saveManualTaskData() {
  const mt = rdaData[activeRda].manualTask;
  mt.nombre = document.getElementById('manualTaskName').value;
  mt.descripcion = document.getElementById('manualTaskDesc').value;
  mt.dateFrom = document.getElementById('manualTaskDateFrom').value;
  mt.dateTo = document.getElementById('manualTaskDateTo').value;
  mt.criterio = document.getElementById('manualTaskCriterio').value;
  const pdfInput = document.getElementById('manualTaskPdf');
  if (pdfInput.files[0]) mt.pdf = pdfInput.files[0];
  syncRubricData();
}

function loadManualTaskData(index) {
  const mt = rdaData[index].manualTask;
  document.getElementById('manualTaskName').value = mt.nombre || '';
  document.getElementById('manualTaskDesc').value = mt.descripcion || '';
  document.getElementById('manualTaskDateFrom').value = mt.dateFrom || gaulaToday();
  document.getElementById('manualTaskDateTo').value = mt.dateTo || gaulaNextWeek();
  // El criterio ahora es global (activeCriterio). Sincronizar pills + hidden con él.
  document.getElementById('manualTaskCriterio').value = String(activeCriterio || 1);
  applyManualCriterioActive('manualTaskCriterioTabs', activeCriterio || 1);
  updateManualCriterioVisibility('manualTaskCriterioTabs', activeRda);
  const mtPdfName = document.getElementById('manualTaskPdfName');
  const hasF = mt.pdf || mt.pdfName;
  mtPdfName.value = hasF ? (mt.pdf ? mt.pdf.name.replace(/\.[^.]+$/, '') : mt.pdfName) : 'Sin archivo';
  mtPdfName.classList.toggle('has-file', !!hasF);
  if (hasF) mtPdfName.removeAttribute('readonly'); else mtPdfName.setAttribute('readonly', '');
  renderRubricCriteria();
}

function saveManualQuizData() {
  const mq = rdaData[activeRda].manualQuiz;
  mq.nombre = document.getElementById('manualQuizName')?.value || '';
  mq.password = document.getElementById('manualQuizPassword')?.value || '';
  mq.dateFrom = document.getElementById('manualQuizDateFrom')?.value || '';
  mq.dateTo = document.getElementById('manualQuizDateTo')?.value || '';
  mq.time = parseInt(document.getElementById('manualQuizTime')?.value) || 60;
  mq.aikenText = document.getElementById('manualQuizAiken')?.value || '';
  mq.criterio = document.getElementById('manualQuizCriterio')?.value || '1';
  mq.hourFrom = document.getElementById('manualQuizHourFrom')?.value || '8';
  mq.minFrom = document.getElementById('manualQuizMinFrom')?.value || '0';
  mq.hourTo = document.getElementById('manualQuizHourTo')?.value || '23';
  mq.minTo = document.getElementById('manualQuizMinTo')?.value || '55';
  // Multi-banco
  const randomToggle = document.getElementById('quizRandomMode');
  if (randomToggle) mq.randomMode = !!randomToggle.checked;
  if (!Array.isArray(mq.banks) || mq.banks.length === 0) mq.banks = [createEmptyBank(0)];
  // banks ya se sincronizan en sus event handlers (live-sync); aquí solo aseguramos shape.
}

function loadManualQuizData(index) {
  const mq = rdaData[index].manualQuiz;
  const el = (id) => document.getElementById(id);
  if (el('manualQuizName')) el('manualQuizName').value = mq.nombre || '';
  if (el('manualQuizPassword')) el('manualQuizPassword').value = mq.password || '';
  if (el('manualQuizDateFrom')) el('manualQuizDateFrom').value = mq.dateFrom || gaulaToday();
  if (el('manualQuizDateTo')) el('manualQuizDateTo').value = mq.dateTo || gaulaToday();
  if (el('manualQuizTime')) el('manualQuizTime').value = mq.time || 60;
  if (el('manualQuizHourFrom')) el('manualQuizHourFrom').value = mq.hourFrom || '8';
  if (el('manualQuizMinFrom')) el('manualQuizMinFrom').value = mq.minFrom || '0';
  if (el('manualQuizHourTo')) el('manualQuizHourTo').value = mq.hourTo || '23';
  if (el('manualQuizMinTo')) el('manualQuizMinTo').value = mq.minTo || '55';
  // El criterio ahora es global (activeCriterio). Sincronizar pills + hidden con él.
  if (el('manualQuizCriterio')) el('manualQuizCriterio').value = String(activeCriterio || 1);
  applyManualCriterioActive('manualQuizCriterioTabs', activeCriterio || 1);
  updateManualCriterioVisibility('manualQuizCriterioTabs', activeRda);
  if (el('manualQuizAiken')) el('manualQuizAiken').value = mq.aikenText || '';

  // Sincronizar selects visibles del time picker con los hidden inputs restaurados
  const quizTimePicker = document.getElementById('quizTimePicker');
  if (quizTimePicker && quizTimePicker._trpUpdate) quizTimePicker._trpUpdate();

  // Actualizar previews al cargar datos
  updateAikenPreview();
  const xmlInfo = el('xmlFileInfo');
  if (xmlInfo) {
    if (mq.xmlText && mq.xmlFileName) {
      const v = validateMoodleXml(mq.xmlText);
      xmlInfo.style.display = 'block';
      xmlInfo.textContent = v.valid
        ? `${mq.xmlFileName} — ${v.count} pregunta(s) detectada(s)`
        : `Error: ${v.error}`;
      xmlInfo.style.background = v.valid ? '#f0fdf4' : '#fef2f2';
      xmlInfo.style.borderColor = v.valid ? '#bbf7d0' : '#fecaca';
      xmlInfo.style.color = v.valid ? '#166534' : '#991b1b';
    } else {
      xmlInfo.style.display = 'none';
    }
  }
  // Multi-banco: aplicar toggle + render
  if (!Array.isArray(mq.banks) || mq.banks.length === 0) mq.banks = [createEmptyBank(0)];
  const randomToggle = document.getElementById('quizRandomMode');
  if (randomToggle) randomToggle.checked = !!mq.randomMode;
  toggleRandomModeUI(!!mq.randomMode);
  if (mq.randomMode) renderBanksUI();
}

// ============================================================
// MULTI-BANCO (toggle "Preguntas aleatorias")
// ============================================================
// Cuenta preguntas Aiken: cada bloque empieza con texto y termina con "ANSWER:".
function parseAikenCount(text) {
  if (!text) return 0;
  return (text.match(/^ANSWER\s*:/gmi) || []).length;
}

// Normaliza texto Aiken para que Moodle lo acepte sin errores:
// 1. Une líneas de texto de pregunta multi-línea en una sola (Moodle exige
//    que la pregunta esté en UNA línea; sino dice "Pregunta no completada
//    antes de que la siguiente pregunta comience en la línea X").
// 2. Quita numeración inicial tipo "1. " o "1) " (la deja sin numerar).
// 3. Detecta ANSWER: X embebido dentro de la última opción (artefacto IA).
// 4. Descarta bloques sin opciones suficientes (< 2) o sin ANSWER.
// Devuelve { text, total, kept, dropped, dropReasons }.
function normalizeAikenText(rawText) {
  if (!rawText) return { text: '', total: 0, kept: 0, dropped: 0, dropReasons: [] };
  const lines = rawText.split(/\r?\n/);
  const rawBlocks = [];
  let current = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed === '') {
      if (current.length > 0) { rawBlocks.push(current); current = []; }
    } else {
      current.push(trimmed);
    }
  }
  if (current.length > 0) rawBlocks.push(current);

  const optionRe = /^([A-Da-d])[).]\s+(.+)$/;
  const answerRe = /^ANSWER\s*:\s*([A-Da-d])\s*$/i;
  const numberingRe = /^\d+[.)]\s*/;

  const blocks = [];
  const dropReasons = [];

  rawBlocks.forEach((block, blockIdx) => {
    const questionLines = [];
    const optionLines = [];
    let answerLetter = null;

    for (const line of block) {
      const ansMatch = line.match(answerRe);
      if (ansMatch) {
        answerLetter = ansMatch[1].toUpperCase();
        continue;
      }
      const optMatch = line.match(optionRe);
      if (optMatch) {
        const letter = optMatch[1].toUpperCase();
        let optText = optMatch[2].trim();
        // Detectar "X) texto ANSWER: Y" embebido
        const embeddedAns = optText.match(/^(.*?)\s*ANSWER\s*:\s*([A-Da-d])\s*$/i);
        if (embeddedAns) {
          optText = embeddedAns[1].trim();
          answerLetter = embeddedAns[2].toUpperCase();
        }
        if (optText) optionLines.push(`${letter}) ${optText}`);
        continue;
      }
      // Texto de la pregunta (puede haber varias líneas)
      let cleaned = line;
      if (questionLines.length === 0) {
        cleaned = cleaned.replace(numberingRe, '');
      }
      if (cleaned) questionLines.push(cleaned);
    }

    if (questionLines.length === 0) {
      dropReasons.push(`Bloque ${blockIdx + 1}: sin texto de pregunta.`);
      return;
    }
    if (optionLines.length < 2) {
      dropReasons.push(`Bloque ${blockIdx + 1}: menos de 2 opciones (${optionLines.length}).`);
      return;
    }
    if (!answerLetter) {
      dropReasons.push(`Bloque ${blockIdx + 1}: sin línea ANSWER.`);
      return;
    }

    const questionText = questionLines.join(' ').replace(/\s+/g, ' ').trim();
    blocks.push([questionText, ...optionLines, `ANSWER: ${answerLetter}`].join('\n'));
  });

  return {
    text: blocks.join('\n\n') + (blocks.length > 0 ? '\n' : ''),
    total: rawBlocks.length,
    kept: blocks.length,
    dropped: rawBlocks.length - blocks.length,
    dropReasons
  };
}

function toggleRandomModeUI(on) {
  const single = document.getElementById('singleBankBlock');
  const multi = document.getElementById('multiBankBlock');
  if (single) single.hidden = !!on;
  if (multi) multi.hidden = !on;
}

function renderBanksUI() {
  const container = document.getElementById('banksContainer');
  if (!container) return;
  const mq = rdaData[activeRda].manualQuiz;
  const banks = mq.banks || [];
  container.innerHTML = banks.map((bank, idx) => bankCardHTML(bank, idx, banks.length)).join('');
  // Boton "Agregar banco" oculto si ya hay 3
  const addBtn = document.getElementById('btnAddBank');
  if (addBtn) addBtn.style.display = banks.length >= 3 ? 'none' : '';
  updateBanksTotal();
}

function bankCardHTML(bank, idx, totalBanks) {
  const isAi = bank.source === 'ai';
  const isFile = bank.source === 'file';
  const detected = bank.detectedCount || parseAikenCount(bank.aikenText || '');
  const removableAttr = totalBanks > 1 ? '' : 'hidden';
  const pdfNameDisplay = bank.pdfName || 'Sin archivo';
  // Opciones del select "Generar" (IA): mismas que modo OFF (20 o 50), salvo
  // caso de estudio que fuerza a 5.
  const isCaseStudy = bank.difficulty === 'caso_estudio';
  const genOptions = isCaseStudy ? [5] : [20, 50];
  const genSelected = isCaseStudy ? 5 : (bank.generateCount || 50);
  const genHTML = genOptions.map(n => `<option value="${n}" ${genSelected === n ? 'selected' : ''}>${n}</option>`).join('');
  const genDisabledAttr = isCaseStudy ? 'disabled' : '';
  // Opciones del select "Usar random" — solo 1..detected (o vacío si no hay detectadas)
  let randomHTML = '';
  if (detected > 0) {
    const sel = parseInt(bank.randomCount) || detected;
    for (let n = 1; n <= detected; n++) {
      randomHTML += `<option value="${n}" ${n === sel ? 'selected' : ''}>${n}</option>`;
    }
  } else {
    randomHTML = '<option value="0" selected>Sin preguntas</option>';
  }
  return `
    <div class="bank-card" data-bank-idx="${idx}">
      <div class="bank-card-header">
        <span class="bank-card-title">Banco ${idx + 1}</span>
        <input type="text" class="bank-name-input" data-bank-field="name" data-bank-idx="${idx}" value="${escapeAttr(bank.name)}" placeholder="Nombre">
        <button type="button" class="bank-remove-btn" data-bank-idx="${idx}" title="Eliminar banco" ${removableAttr}>×</button>
      </div>
      <div class="bank-source-row">
        <label><input type="radio" name="bank-source-${idx}" value="ai" data-bank-idx="${idx}" data-bank-field="source" ${isAi ? 'checked' : ''}> Generar con IA</label>
        <label><input type="radio" name="bank-source-${idx}" value="file" data-bank-idx="${idx}" data-bank-field="source" ${isFile ? 'checked' : ''}> Archivo .txt</label>
      </div>
      <div class="bank-fields">
        ${isAi ? `
          <div class="bank-row">
            <button type="button" class="btn-small bank-pdf-btn" data-bank-idx="${idx}">Subir PDF</button>
            <input type="file" class="bank-pdf-input" data-bank-idx="${idx}" accept=".pdf" hidden>
            <span class="file-name">${escapeAttr(pdfNameDisplay)}</span>
          </div>
          <div class="bank-row">
            <label>Generar</label>
            <select class="bank-generate-count" data-bank-field="generateCount" data-bank-idx="${idx}" ${genDisabledAttr}>${genHTML}</select>
            <label>preguntas</label>
            <select class="bank-difficulty" data-bank-field="difficulty" data-bank-idx="${idx}">
              <option value="facil" ${bank.difficulty === 'facil' ? 'selected' : ''}>Fácil</option>
              <option value="medio" ${(bank.difficulty || 'medio') === 'medio' ? 'selected' : ''}>Medio</option>
              <option value="dificil" ${bank.difficulty === 'dificil' ? 'selected' : ''}>Difícil</option>
              <option value="caso_estudio" ${bank.difficulty === 'caso_estudio' ? 'selected' : ''}>Caso de estudio</option>
            </select>
            <select class="bank-language" data-bank-field="language" data-bank-idx="${idx}" title="Idioma de las preguntas">
              <option value="es" ${(bank.language || 'es') === 'es' ? 'selected' : ''}>ES</option>
              <option value="en" ${bank.language === 'en' ? 'selected' : ''}>EN</option>
            </select>
            <button type="button" class="rubric-ai-btn bank-generate-btn" data-bank-idx="${idx}">Generar IA</button>
          </div>
        ` : `
          <div class="bank-row">
            <button type="button" class="btn-small bank-file-btn" data-bank-idx="${idx}">Cargar .txt (Aiken)</button>
            <input type="file" class="bank-file-input" data-bank-idx="${idx}" accept=".txt" hidden>
            <span class="file-name">${detected > 0 ? `${detected} preguntas cargadas` : 'Sin archivo'}</span>
          </div>
        `}
        <textarea class="bank-aiken-textarea" data-bank-field="aikenText" data-bank-idx="${idx}" rows="3" placeholder="Preguntas en formato Aiken (se llenan al generar/cargar archivo)">${escapeAttr(bank.aikenText || '')}</textarea>
        ${detected > 0 ? `<div class="bank-status">${detected} preguntas detectadas</div>` : ''}
        ${(bank.droppedCount || 0) > 0 ? `<div class="bank-status warn">${bank.droppedCount} no detectadas (formato inválido)</div>` : ''}
        <div class="bank-msg" data-bank-idx="${idx}" hidden></div>
        <div class="bank-row">
          <label>Usar random:</label>
          <select class="bank-random-count" data-bank-field="randomCount" data-bank-idx="${idx}" ${detected === 0 ? 'disabled' : ''}>${randomHTML}</select>
          <span class="bank-random-max-text">${detected > 0 ? `de ${detected}` : ''}</span>
        </div>
      </div>
    </div>
  `;
}

function updateBanksTotal() {
  const mq = rdaData[activeRda].manualQuiz;
  const total = (mq.banks || []).reduce((s, b) => s + (parseInt(b.randomCount) || 0), 0);
  const span = document.getElementById('banksTotalCount');
  if (span) span.textContent = String(total);
}

function addBankRow() {
  const mq = rdaData[activeRda].manualQuiz;
  if (!mq.banks) mq.banks = [];
  if (mq.banks.length >= 3) return;
  mq.banks.push(createEmptyBank(mq.banks.length));
  renderBanksUI();
  saveFormState();
}

function removeBankRow(idx) {
  const mq = rdaData[activeRda].manualQuiz;
  if (!mq.banks || mq.banks.length <= 1) return;
  mq.banks.splice(idx, 1);
  renderBanksUI();
  saveFormState();
}

function setBankField(idx, field, value) {
  const mq = rdaData[activeRda].manualQuiz;
  if (!mq.banks || !mq.banks[idx]) return;
  mq.banks[idx][field] = value;
  if (field === 'aikenText') {
    // Recalcular detected/dropped via normalizer (strict: ANSWER necesita letra A-D,
    // bloque requiere ≥2 opciones, etc.). NO sobrescribimos el text del user —
    // solo actualizamos contadores. La normalización al texto ocurre al enviar
    // a Moodle (btnCreateManualQuiz) y al cargar archivo/IA.
    const norm = normalizeAikenText(value);
    mq.banks[idx].detectedCount = norm.kept;
    mq.banks[idx].droppedCount = norm.dropped;
    const max = norm.kept;
    if (max > 0 && mq.banks[idx].randomCount > max) mq.banks[idx].randomCount = max;
  }
  saveFormState();
}

function validateBanksPayload(banks) {
  const errors = [];
  if (!banks || banks.length === 0) errors.push('Agrega al menos un banco.');
  banks.forEach((b, i) => {
    const label = `Banco ${i + 1}${b.name ? ' (' + b.name + ')' : ''}`;
    if (!b.name || !b.name.trim()) errors.push(`${label}: falta nombre.`);
    if (!b.aikenText || !b.aikenText.trim()) errors.push(`${label}: sin preguntas (genera con IA o carga archivo).`);
    if (b.detectedCount === 0) errors.push(`${label}: 0 preguntas detectadas en el texto Aiken.`);
    const rc = parseInt(b.randomCount);
    if (!rc || rc < 1) errors.push(`${label}: cantidad random inválida.`);
    if (rc > b.detectedCount) errors.push(`${label}: cantidad random (${rc}) excede preguntas disponibles (${b.detectedCount}).`);
  });
  return { ok: errors.length === 0, errors };
}

// Carga un archivo .txt al banco indicado. Normaliza el Aiken antes de guardar
// (Moodle es estricto: pregunta DEBE estar en una sola línea, sin numeración).
function loadFileToBank(file, idx) {
  const mq = rdaData[activeRda].manualQuiz;
  if (!mq.banks[idx]) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    const rawText = String(e.target.result || '');
    const norm = normalizeAikenText(rawText);
    const text = norm.text;
    mq.banks[idx].aikenText = text;
    mq.banks[idx].detectedCount = norm.kept;
    mq.banks[idx].droppedCount = norm.dropped;
    const max = norm.kept;
    if (max > 0 && (!mq.banks[idx].randomCount || mq.banks[idx].randomCount > max)) {
      mq.banks[idx].randomCount = max;
    }
    renderBanksUI();
    if (norm.dropped > 0) {
      showBankStatus(idx, `${norm.kept} válidas, ${norm.dropped} descartadas (formato inválido).`, 'info');
    } else {
      showBankStatus(idx, `${norm.kept} preguntas cargadas y normalizadas.`, 'success');
    }
    saveFormState();
  };
  reader.readAsText(file);
}

// Muestra/oculta mensaje de status DENTRO de la bank-card específica (no en
// el status global del popup que vive al final). Tipo: 'loading' | 'success'
// | 'error' | 'info'.
function showBankStatus(idx, msg, type) {
  const div = document.querySelector(`.bank-msg[data-bank-idx="${idx}"]`);
  if (!div) return;
  div.textContent = msg || '';
  div.className = 'bank-msg' + (type ? ' ' + type : '');
  div.hidden = !msg;
}

function clearBankStatus(idx) {
  showBankStatus(idx, '', '');
}

// Lock visual de toda la sección de bancos mientras genera un banco.
// Deshabilita inputs/selects/buttons de OTROS bancos y el toggle/agregar, dejando
// solo visible el botón "Generando..." del banco activo.
function applyGeneratingLock(generatingIdx) {
  document.querySelectorAll('.bank-card').forEach(card => {
    const cardIdx = parseInt(card.dataset.bankIdx);
    if (cardIdx !== generatingIdx) {
      card.classList.add('locked-inactive');
      card.querySelectorAll('input, select, textarea, button').forEach(el => el.disabled = true);
    } else {
      // Bloquear inputs del banco activo salvo el botón generate (que muestra el progreso)
      card.querySelectorAll('input, select, textarea').forEach(el => el.disabled = true);
      card.querySelectorAll('button:not(.bank-generate-btn)').forEach(el => el.disabled = true);
    }
  });
  const addBtn = document.getElementById('btnAddBank');
  if (addBtn) addBtn.disabled = true;
  const toggle = document.getElementById('quizRandomMode');
  if (toggle) toggle.disabled = true;
}

function removeGeneratingLock() {
  document.querySelectorAll('.bank-card.locked-inactive').forEach(card => card.classList.remove('locked-inactive'));
  document.querySelectorAll('#multiBankBlock input, #multiBankBlock select, #multiBankBlock textarea, #multiBankBlock button').forEach(el => el.disabled = false);
  const toggle = document.getElementById('quizRandomMode');
  if (toggle) toggle.disabled = false;
}

// Genera preguntas Aiken con IA para un banco específico. Mismo patrón que el
// modo OFF: executeAction verifica créditos → loop batches de 25 con
// callGenerateContent. Persiste resultado parcial entre batches.
async function generateAikenForBank(idx) {
  console.log('[GAULA bank IA] start idx=' + idx);
  const mq = rdaData[activeRda].manualQuiz;
  const bank = mq.banks[idx];
  if (!bank) { console.warn('[GAULA bank IA] no bank en idx=' + idx); return; }
  if (!bank.pdf) {
    showBankStatus(idx, 'Sube un PDF primero.', 'error');
    console.warn('[GAULA bank IA] bank.pdf vacío');
    return;
  }
  console.log('[GAULA bank IA] bank.pdf=', bank.pdf.name, bank.pdf.size, 'bytes, type=', bank.pdf.type);
  clearBankStatus(idx);

  // Localizar el botón generar de este banco para feedback visual (spinner + disabled)
  const setBtnGenerating = (on, label) => {
    const b = document.querySelector(`.bank-generate-btn[data-bank-idx="${idx}"]`);
    if (!b) return;
    b.disabled = !!on;
    b.classList.toggle('is-generating', !!on);
    b.innerHTML = on
      ? '<span class="spinner-inline"></span>' + (label || 'Generando...')
      : 'Generar IA';
  };
  setBtnGenerating(true, 'Generando...');
  applyGeneratingLock(idx);

  try {
    showBankStatus(idx, 'Extrayendo PDF...', 'loading');
    let pdfText = '';
    try {
      pdfText = await extractTextFromPDF(bank.pdf);
      console.log('[GAULA bank IA] pdfText length=' + pdfText.length);
    } catch (e) {
      console.error('[GAULA bank IA] extractTextFromPDF falló:', e);
      showBankStatus(idx, `Error leyendo PDF — ${e.message || e}`, 'error');
      return;
    }
    if (!pdfText.trim()) {
      console.warn('[GAULA bank IA] PDF vacío después de extraer');
      showBankStatus(idx, 'PDF vacío o sin texto extraíble.', 'error');
      return;
    }
    const numPreguntas = parseInt(bank.generateCount) || 50;
    const dificultad = bank.difficulty || 'medio';
    const idioma = bank.language || 'es';
    console.log('[GAULA bank IA] params:', { numPreguntas, dificultad, idioma });

    showBankStatus(idx, 'Verificando créditos...', 'loading');
    const creditResult = await executeAction('generate_aiken', { numPreguntas });
    console.log('[GAULA bank IA] credit result:', creditResult);
    if (!creditResult.ok) throw new Error(creditResult.error || 'Sin créditos disponibles');

    const BATCH_SIZE = 25;
    const batches = Math.ceil(numPreguntas / BATCH_SIZE);
    const pdfTruncated = pdfText.substring(0, 100000);
    const aikenParts = [];

    for (let i = 0; i < batches; i++) {
      const batchSize = Math.min(BATCH_SIZE, numPreguntas - i * BATCH_SIZE);
      const generated = aikenParts.length ? aikenParts.join('\n\n').split('ANSWER:').length - 1 : 0;
      const loteLabel = `Lote ${i + 1}/${batches}`;
      setBtnGenerating(true, loteLabel);
      showBankStatus(idx, `${loteLabel} (${generated}/${numPreguntas} generadas)`, 'loading');
      const result = await callGenerateContent('generate_aiken', {
        pdfText: pdfTruncated,
        numPreguntas: batchSize,
        dificultad,
        idioma,
      });
      if (!result.ok) throw new Error(result.error);
      if (result.aikenText) aikenParts.push(result.aikenText);

      // Progreso parcial: guardar texto y actualizar UI
      const partial = aikenParts.join('\n\n');
      const normPartial = normalizeAikenText(partial);
      bank.aikenText = normPartial.text;
      bank.detectedCount = normPartial.kept;
      bank.droppedCount = normPartial.dropped;
      if (!bank.randomCount || bank.randomCount > bank.detectedCount) {
        bank.randomCount = bank.detectedCount;
      }
      renderBanksUI();
      applyGeneratingLock(idx);   // re-aplicar lock tras re-render
      saveFormState();
    }

    // Final
    const allText = aikenParts.join('\n\n');
    const norm = normalizeAikenText(allText);
    bank.aikenText = norm.text;
    bank.detectedCount = norm.kept;
    bank.droppedCount = norm.dropped;
    if (!bank.randomCount || bank.randomCount > bank.detectedCount) {
      bank.randomCount = bank.detectedCount;
    }
    renderBanksUI();
    saveFormState();
    if (norm.dropped > 0) {
      showBankStatus(idx, `${norm.kept} válidas, ${norm.dropped} descartadas.`, 'info');
    } else {
      showBankStatus(idx, `${norm.kept} preguntas generadas.`, 'success');
    }
  } catch (e) {
    console.error('[GAULA bank IA]', e);
    showBankStatus(idx, `Error IA — ${e.message}`, 'error');
  } finally {
    setBtnGenerating(false);
    removeGeneratingLock();
    console.log('[GAULA bank IA] finally idx=' + idx);
  }
}

// Wiring delegado del container de bancos (una sola vez en init).
function initMultiBanksUI() {
  const toggle = document.getElementById('quizRandomMode');
  if (toggle) {
    toggle.addEventListener('change', () => {
      const mq = rdaData[activeRda].manualQuiz;
      mq.randomMode = toggle.checked;
      toggleRandomModeUI(toggle.checked);
      if (toggle.checked) renderBanksUI();
      saveFormState();
    });
  }
  const addBtn = document.getElementById('btnAddBank');
  if (addBtn) addBtn.addEventListener('click', () => addBankRow());
  const container = document.getElementById('banksContainer');
  if (!container) return;

  // Delegación de eventos
  container.addEventListener('click', (e) => {
    const removeBtn = e.target.closest('.bank-remove-btn');
    if (removeBtn) {
      const idx = parseInt(removeBtn.dataset.bankIdx);
      removeBankRow(idx);
      return;
    }
    const pdfBtn = e.target.closest('.bank-pdf-btn');
    if (pdfBtn) {
      const idx = parseInt(pdfBtn.dataset.bankIdx);
      container.querySelector(`.bank-pdf-input[data-bank-idx="${idx}"]`)?.click();
      return;
    }
    const fileBtn = e.target.closest('.bank-file-btn');
    if (fileBtn) {
      const idx = parseInt(fileBtn.dataset.bankIdx);
      container.querySelector(`.bank-file-input[data-bank-idx="${idx}"]`)?.click();
      return;
    }
    const genBtn = e.target.closest('.bank-generate-btn');
    if (genBtn) {
      const idx = parseInt(genBtn.dataset.bankIdx);
      generateAikenForBank(idx);
      return;
    }
  });

  // Handler unificado para change e input. Selects disparan change, textarea
  // dispara ambos; preferimos change para evitar re-renders en cada keypress
  // del textarea (que rompería el cursor).
  function handleBankChange(e) {
    const t = e.target;
    if (t.matches('.bank-pdf-input')) {
      const idx = parseInt(t.dataset.bankIdx);
      const file = t.files && t.files[0];
      if (file) {
        rdaData[activeRda].manualQuiz.banks[idx].pdf = file;
        rdaData[activeRda].manualQuiz.banks[idx].pdfName = file.name;
        renderBanksUI();
        saveFormState();
      }
      return;
    }
    if (t.matches('.bank-file-input')) {
      const idx = parseInt(t.dataset.bankIdx);
      const file = t.files && t.files[0];
      if (file) loadFileToBank(file, idx);
      return;
    }
    if (!t.dataset.bankField) return;
    const idx = parseInt(t.dataset.bankIdx);
    const field = t.dataset.bankField;
    let value = t.value;
    if (field === 'generateCount' || field === 'randomCount') {
      value = parseInt(value) || 0;
    }
    setBankField(idx, field, value);
    if (field === 'randomCount') updateBanksTotal();
    if (field === 'source') {
      renderBanksUI();
      return;
    }
    // Cambio de dificultad: si pasa a/desde caso_estudio, ajustar generateCount.
    if (field === 'difficulty') {
      const mq2 = rdaData[activeRda].manualQuiz;
      const b2 = mq2.banks[idx];
      if (value === 'caso_estudio') {
        b2.generateCount = 5;
      } else if (b2.generateCount === 5) {
        b2.generateCount = 50;   // restaurar default
      }
      saveFormState();
      renderBanksUI();
      return;
    }
    if (field === 'aikenText') {
      // Re-render solo al perder foco (event=change) para no reset cursor en cada tecla
      if (e.type === 'change') {
        renderBanksUI();
        updateBanksTotal();
      }
    }
  }

  container.addEventListener('change', handleBankChange);
  container.addEventListener('input', (e) => {
    const t = e.target;
    // Solo procesamos input para textarea (aikenText): actualizamos state
    // pero NO re-renderizamos (preserva cursor). El re-render llega en change.
    if (!t.dataset.bankField) return;
    if (t.dataset.bankField !== 'aikenText') return;
    const idx = parseInt(t.dataset.bankIdx);
    setBankField(idx, 'aikenText', t.value);
  });
}

// ============================================================
// AIKEN FILE LOADER
// ============================================================

// ── Parser Aiken ──
function parseAiken(text) {
  const questions = [];
  const lines = text.split('\n').map(l => l.trimEnd());
  let current = null;

  for (const line of lines) {
    const answerMatch = line.match(/^ANSWER:\s*([A-Z])\s*$/i);
    const optionMatch = line.match(/^([A-Z])[.)]\s+(.+)$/);

    if (answerMatch) {
      if (current) {
        current.answer = answerMatch[1].toUpperCase();
        questions.push(current);
        current = null;
      }
    } else if (optionMatch && current) {
      current.options.push({ letter: optionMatch[1].toUpperCase(), text: optionMatch[2].trim() });
    } else if (line.trim() !== '') {
      if (current && current.options.length === 0) {
        current.text += ' ' + line.trim();
      } else {
        current = { text: line.trim(), options: [], answer: '' };
      }
    }
  }
  return questions;
}

function updateAikenPreview() {
  const text = document.getElementById('manualQuizAiken').value;
  const preview = document.getElementById('aikenPreview');
  const status = document.getElementById('aikenStatus');
  if (!text.trim()) {
    preview.style.display = 'none';
    status.textContent = '';
    return;
  }
  const questions = parseAiken(text);
  if (questions.length > 0) {
    const valid = questions.filter(q => q.options.length >= 2 && q.answer);
    const dropped = questions.length - valid.length;
    preview.style.display = 'block';
    // Texto con dos líneas si hay descartadas: verde + naranja
    if (dropped > 0 && valid.length > 0) {
      preview.innerHTML = `<div>${valid.length} pregunta(s) detectada(s)</div>` +
                          `<div style="color:#92400e;background:#fef3c7;border:1px solid #fcd34d;border-radius:4px;padding:2px 6px;margin-top:4px;display:inline-block">${dropped} no detectada(s) (formato inválido)</div>`;
      preview.style.borderColor = '#bbf7d0';
      preview.style.background = '#f0fdf4';
      preview.style.color = '#166534';
    } else {
      preview.textContent = `${valid.length} pregunta(s) detectada(s)`;
      preview.style.borderColor = valid.length > 0 ? '#bbf7d0' : '#fecaca';
      preview.style.background = valid.length > 0 ? '#f0fdf4' : '#fef2f2';
      preview.style.color = valid.length > 0 ? '#166534' : '#991b1b';
    }
    status.textContent = '';
  } else {
    preview.style.display = 'block';
    preview.textContent = 'No se detectaron preguntas. Verifica el formato Aiken.';
    preview.style.borderColor = '#fecaca';
    preview.style.background = '#fef2f2';
    preview.style.color = '#991b1b';
  }
}

// ── Validador XML Moodle ──
function validateMoodleXml(xmlText) {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlText, 'text/xml');
    const parseError = doc.querySelector('parsererror');
    if (parseError) return { valid: false, error: 'XML mal formado: ' + parseError.textContent.substring(0, 100) };
    const quiz = doc.querySelector('quiz');
    if (!quiz) return { valid: false, error: 'No se encontró la etiqueta <quiz>. No es un archivo Moodle XML válido.' };
    const questions = [...quiz.querySelectorAll('question')].filter(q => q.getAttribute('type') !== 'category');
    if (questions.length === 0) return { valid: false, error: 'No se encontraron preguntas dentro de <quiz>.' };
    let invalidCount = 0;
    for (const q of questions) {
      const name = q.querySelector('name > text');
      const qtext = q.querySelector('questiontext > text');
      if (!name || !qtext) invalidCount++;
    }
    if (invalidCount > 0) {
      return { valid: false, error: `${invalidCount} pregunta(s) sin nombre o texto. Revise el archivo.` };
    }
    return { valid: true, count: questions.length };
  } catch (err) {
    return { valid: false, error: 'Error al procesar XML: ' + err.message };
  }
}

function initAikenLoader() {
  const btnAiken = document.getElementById('btnLoadAikenFile');
  const aikenInput = document.getElementById('aikenFileInput');
  const btnXml = document.getElementById('btnLoadXmlFile');
  const xmlInput = document.getElementById('xmlFileInput');
  const aikenTextarea = document.getElementById('manualQuizAiken');
  const xmlFileInfo = document.getElementById('xmlFileInfo');

  // Contar preguntas en tiempo real al escribir en el textarea
  aikenTextarea.addEventListener('input', () => {
    rdaData[activeRda].manualQuiz.aikenText = aikenTextarea.value;
    saveFormState();
    updateAikenPreview();
  });

  // Cargar archivo .txt (Aiken)
  btnAiken.addEventListener('click', () => aikenInput.click());
  aikenInput.addEventListener('change', () => {
    const file = aikenInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      aikenTextarea.value = reader.result;
      rdaData[activeRda].manualQuiz.aikenText = reader.result;
      saveFormState();
      updateAikenPreview();
    };
    reader.readAsText(file);
    aikenInput.value = '';
  });

  // Cargar archivo .xml (Moodle)
  btnXml.addEventListener('click', () => xmlInput.click());
  xmlInput.addEventListener('change', () => {
    const file = xmlInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const xmlText = reader.result;
      const validation = validateMoodleXml(xmlText);
      if (validation.valid) {
        rdaData[activeRda].manualQuiz.xmlText = xmlText;
        rdaData[activeRda].manualQuiz.xmlFileName = file.name;
        xmlFileInfo.style.display = 'block';
        xmlFileInfo.textContent = `${file.name} — ${validation.count} pregunta(s) detectada(s)`;
        xmlFileInfo.style.background = '#f0fdf4';
        xmlFileInfo.style.borderColor = '#bbf7d0';
        xmlFileInfo.style.color = '#166534';
        saveFormState();
      } else {
        xmlFileInfo.style.display = 'block';
        xmlFileInfo.textContent = `Error: ${validation.error}`;
        xmlFileInfo.style.background = '#fef2f2';
        xmlFileInfo.style.borderColor = '#fecaca';
        xmlFileInfo.style.color = '#991b1b';
      }
    };
    reader.readAsText(file);
    xmlInput.value = '';
  });

  // --- Generar Aiken con IA desde PDF ---
  let _aikenPdfFile = null;
  const btnGenAiken = document.getElementById('btnGenerateAikenAi');
  const aikenPdfZone = document.getElementById('aikenPdfZone');
  const aikenPdfInput = document.getElementById('aikenPdfInput');

  btnGenAiken.addEventListener('click', () => {
    aikenPdfZone.style.display = aikenPdfZone.style.display === 'none' ? 'block' : 'none';
  });

  // Caso de estudio: fuerza generateCount a 5 y deshabilita el selector.
  // Cambiar de vuelta a otra dificultad restaura 20/50.
  const aikenDifficultySel = document.getElementById('aikenDifficulty');
  const aikenCountSel = document.getElementById('aikenQuestionCount');
  function applyCaseStudyMode() {
    if (!aikenDifficultySel || !aikenCountSel) return;
    if (aikenDifficultySel.value === 'caso_estudio') {
      // Replace options with single value=5 disabled
      aikenCountSel.innerHTML = '<option value="5" selected>5</option>';
      aikenCountSel.disabled = true;
    } else {
      // Restaurar 20 / 50
      if (aikenCountSel.disabled || aikenCountSel.options.length !== 2) {
        aikenCountSel.innerHTML = '<option value="20">20</option><option value="50" selected>50</option>';
        aikenCountSel.disabled = false;
      }
    }
  }
  if (aikenDifficultySel) aikenDifficultySel.addEventListener('change', applyCaseStudyMode);
  applyCaseStudyMode();

  aikenPdfInput.addEventListener('change', async () => {
    const file = aikenPdfInput.files[0];
    if (!file) return;
    _aikenPdfFile = file;
    document.getElementById('aikenPdfName').value = file.name;
    await _generateAikenFromPdf();
  });

  async function _generateAikenFromPdf() {
    if (!_aikenPdfFile) return;

    const statusEl = document.getElementById('aikenAiStatus');
    const numPreguntas = document.getElementById('aikenQuestionCount').value;
    const dificultad = document.getElementById('aikenDifficulty').value;
    const idioma = document.getElementById('aikenLanguage')?.value || 'es';

    btnGenAiken.disabled = true;
    btnGenAiken.textContent = 'Generando...';
    statusEl.style.display = 'block';
    statusEl.style.background = '#f5f3ff';
    statusEl.style.borderColor = '#c4b5fd';
    statusEl.style.color = '#7c3aed';
    statusEl.textContent = `Extrayendo texto del PDF...`;

    try {
      const pdfText = await extractTextFromPDF(_aikenPdfFile);
      if (!pdfText.trim()) throw new Error('El PDF está vacío o no se pudo leer.');

      statusEl.textContent = 'Verificando créditos...';
      const creditResult = await executeAction('generate_aiken', { numPreguntas });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const total = parseInt(numPreguntas);
      const BATCH_SIZE = 25;
      const batches = Math.ceil(total / BATCH_SIZE);
      const pdfTruncated = pdfText.substring(0, 100000);
      const aikenParts = [];

      for (let i = 0; i < batches; i++) {
        const batchSize = Math.min(BATCH_SIZE, total - i * BATCH_SIZE);
        const generated = aikenParts.length ? aikenParts.join('\n\n').split('ANSWER:').length - 1 : 0;
        statusEl.textContent = `Generando preguntas (${dificultad})... lote ${i + 1}/${batches} (${generated}/${total} listas)`;

        const result = await callGenerateContent('generate_aiken', {
          pdfText: pdfTruncated,
          numPreguntas: batchSize,
          dificultad,
          idioma,
        });
        if (!result.ok) throw new Error(result.error);
        if (result.aikenText) aikenParts.push(result.aikenText);

        // Guardar progreso parcial
        aikenTextarea.value = aikenParts.join('\n\n');
        rdaData[activeRda].manualQuiz.aikenText = aikenTextarea.value;
        saveFormState();
        updateAikenPreview();
      }

      statusEl.textContent = `${aikenParts.join('\n\n').split('ANSWER:').length - 1} preguntas generadas.`;
      statusEl.style.background = '#f0fdf4';
      statusEl.style.borderColor = '#bbf7d0';
      statusEl.style.color = '#166534';
    } catch (err) {
      statusEl.textContent = `Error: ${err.message}`;
      statusEl.style.background = '#fef2f2';
      statusEl.style.borderColor = '#fecaca';
      statusEl.style.color = '#991b1b';
    } finally {
      btnGenAiken.disabled = false;
      btnGenAiken.textContent = 'Generar con IA';
    }
  }
}

// ============================================================
// ACTION BUTTONS — each sends action to backend
// ============================================================

// Modal de confirmación destructiva: usuario debe escribir BORRAR para habilitar el accept.
// Retorna true si confirmó, false si canceló.
function showImportConfirmModal() {
  return new Promise(resolve => {
    const modal = document.getElementById('importConfirmModal');
    const input = document.getElementById('importConfirmInput');
    const accept = document.getElementById('importConfirmAccept');
    const cancel = document.getElementById('importConfirmCancel');
    input.value = '';
    accept.disabled = true;
    modal.style.display = 'flex';
    setTimeout(() => input.focus(), 50);

    const onInput = () => {
      accept.disabled = input.value.trim() !== 'BORRAR';
    };
    const close = (result) => {
      modal.style.display = 'none';
      input.removeEventListener('input', onInput);
      accept.removeEventListener('click', onAccept);
      cancel.removeEventListener('click', onCancel);
      input.removeEventListener('keydown', onKeyDown);
      resolve(result);
    };
    const onAccept = () => { if (!accept.disabled) close(true); };
    const onCancel = () => close(false);
    const onKeyDown = (e) => {
      if (e.key === 'Escape') close(false);
      if (e.key === 'Enter' && !accept.disabled) close(true);
    };

    input.addEventListener('input', onInput);
    accept.addEventListener('click', onAccept);
    cancel.addEventListener('click', onCancel);
    input.addEventListener('keydown', onKeyDown);
  });
}

function initActionButtons() {
  // --- STEP 1: Import Template ---
  document.getElementById('btnImportTemplate').addEventListener('click', async () => {
    const file = document.getElementById('templateFile').files[0];
    if (!file) return;
    const btn = document.getElementById('btnImportTemplate');

    // Confirmación destructiva: usuario debe escribir "BORRAR" para proceder
    const confirmed = await showImportConfirmModal();
    if (!confirmed) return;

    btn.disabled = true;
    showStatus('Importando plantilla...', 'loading', btn);

    try {
      // Verificar que estamos en una página de curso Moodle
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabUrl = tab?.url || '';
      const courseMatch = tabUrl.match(/(.+?)\/course\/view\.php\?id=(\d+)/);
      if (!courseMatch) {
        showStatus('Debes estar en la página del curso en Moodle.', 'error', btn);
        btn.disabled = false;
        return;
      }
      const moodleBase = courseMatch[1];
      const courseId = courseMatch[2];

      // Serializar archivo
      const serialized = await serializeFile(file);

      // Llamar al backend para verificar créditos y obtener el script
      const result = await executeAction('import_template', {
        courseId, moodleBase, fileName: file.name
      });

      if (!result.ok) {
        showStatus(result.error || 'Error al importar', 'error', btn);
        btn.disabled = false;
        return;
      }

      // Guardar estado inicial directamente desde el popup (como v1)
      // Esto evita la race condition: el estado queda guardado ANTES de navegar
      await chrome.storage.local.set({
        gaula_content_state: {
          action: 'import_template',
          step: 'find_restore_link',
          moodleBase,
          courseId,
          fileName: file.name,
          fileSerialized: serialized
        }
      });

      // Navegar al curso para que el executor retome con el script cacheado
      showStatus('Navegando a Restaurar. El archivo se subirá automáticamente.', 'success', btn);
      btn.disabled = false;
      chrome.tabs.update(tab.id, { url: `${moodleBase}/course/view.php?id=${courseId}` });
    } catch (e) {
      showStatus(e.message || 'Error al importar', 'error', btn);
      btn.disabled = false;
    }
  });

  // --- STEP 2: Generate with AI ---
  document.getElementById('btnGenerateAI').addEventListener('click', async () => {
    const file = document.getElementById('syllabusFile').files[0];
    if (!file) return;
    const btn = document.getElementById('btnGenerateAI');
    btn.disabled = true;
    activeProgressStep = 'Step2';
    const fileExt = (file.name.split('.').pop() || '').toLowerCase();
    const fileLabel = fileExt === 'pdf' ? 'PDF' : 'Excel';
    showProgress(0, 4, `Extrayendo texto del ${fileLabel}...`, 'Step2');

    try {
      // 1. Extraer texto del archivo (PDF o Excel) — la IA procesa ambos por igual
      const pdfText = await extractTextFromSyllabus(file);
      if (!pdfText?.trim()) throw new Error(`El ${fileLabel} está vacío o no se pudo leer.`);

      // 2. Consumir créditos
      showProgress(1, 4, 'Verificando créditos...', 'Step2');
      const creditResult = await executeAction('generate_ai', { fileName: file.name });
      if (!creditResult.ok) throw new Error(creditResult.error);

      // 3. Llamar a generate-syllabus-ai (Edge Function nueva, usa Claude)
      // No usa callGenerateContent porque la acción 'generate_ai' nunca se
      // implementó en generate-content. Fetch directo con la sesión actual.
      showProgress(2, 4, 'IA generando contenido con Claude (puede tardar ~30s)...', 'Step2');
      const _aiSession = await sendMessage({ type: 'GET_SESSION' });
      if (!_aiSession?.ok) throw new Error('Sesión expirada — vuelve a iniciar sesión');
      const _aiResp = await fetch(`${CONFIG.SUPABASE_URL}/functions/v1/generate-syllabus-ai`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${_aiSession.token}`,
          'apikey': CONFIG.SUPABASE_ANON_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pdfText,
          teacher: { name: document.getElementById('teacherName').value, title: document.getElementById('teacherTitle').value, email: document.getElementById('teacherEmail').value, desc: document.getElementById('teacherDesc').value },
          subject: { name: document.getElementById('subjectName').value, career: document.getElementById('careerName').value },
          schedule: getScheduleData(),
          notebookLmLink: document.getElementById('notebookLmLink').value,
        }),
      });
      const result = await _aiResp.json().catch(() => ({}));
      if (!_aiResp.ok || !result.ok) throw new Error(result.error || `HTTP ${_aiResp.status}`);

      // 4. Mostrar panel de edición — el inyect ocurre cuando el usuario aprueba
      showStatus('Contenido generado. Revisa, edita si quieres y aprueba abajo.', 'info', btn);
      showStep2EditPanel(result, btn);
      return;
    } catch (e) {
      showStatus(e.message || 'Error al generar', 'error', btn);
      hideProgress('Step2');
    } finally {
      btn.disabled = false;
      activeProgressStep = null;
    }
  });

  // --- STEP 2: Generate without AI (parser) ---
  document.getElementById('btnGenerateNoAI').addEventListener('click', async () => {
    const file = document.getElementById('syllabusFile').files[0];
    if (!file) return;
    const btn = document.getElementById('btnGenerateNoAI');
    // El parser sin IA está afinado para PDF — Excel rompería sus regex.
    // Para Excel, el docente debe usar "Generar con IA".
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (ext !== 'pdf') {
      showStatus('El parser sin IA solo soporta PDF. Para Excel, usa "Generar con IA".', 'error');
      return;
    }
    btn.disabled = true;
    activeProgressStep = 'Step2';
    showProgress(0, 4, 'Extrayendo texto del PDF...', 'Step2');

    try {
      // 1. Extraer texto del PDF (client-side)
      const pdfText = await extractTextFromPDF(file);
      if (!pdfText?.trim()) throw new Error('El PDF está vacío o no se pudo leer.');

      // 2. Consumir créditos
      showProgress(1, 4, 'Verificando créditos...', 'Step2');
      const creditResult = await executeAction('generate_no_ai', { fileName: file.name });
      if (!creditResult.ok) throw new Error(creditResult.error);

      // 3. Enviar texto al backend para parsear y generar HTMLs
      showProgress(2, 4, 'Parseando sílabo y generando contenido...', 'Step2');
      const result = await callGenerateContent('generate_no_ai', {
        pdfText,
        teacher: { name: document.getElementById('teacherName').value, title: document.getElementById('teacherTitle').value, email: document.getElementById('teacherEmail').value, desc: document.getElementById('teacherDesc').value },
        subject: { name: document.getElementById('subjectName').value, career: document.getElementById('careerName').value },
        schedule: getScheduleData(),
        notebookLmLink: document.getElementById('notebookLmLink').value,
      });
      if (!result.ok) throw new Error(result.error);

      // Auto-rellenar campos del formulario si el parser encontró datos
      if (result.parsedData) {
        const pd = result.parsedData;
        const fill = (id, val) => { const el = document.getElementById(id); if (el && !el.value && val) el.value = val; };
        fill('teacherName', pd.docente?.nombre);
        fill('teacherTitle', pd.docente?.titulo);
        fill('teacherEmail', pd.docente?.email);
        fill('teacherDesc', pd.docente?.resena);
        fill('subjectName', pd.asignatura);
        fill('careerName', pd.carrera);
      }

      // 4. Mostrar panel de edición — el inyect ocurre cuando el usuario aprueba
      const fmt = result.parsedData?.formato === 'A' ? 'Nuevo (DATOS INFORMATIVOS)' : 'Clásico (DATOS ACADÉMICOS)';
      showStatus(`Formato detectado: ${fmt}. Revisa, edita si quieres y aprueba abajo.`, 'info', btn);
      showStep2EditPanel(result, btn);
      return;
    } catch (e) {
      showStatus(e.message || 'Error al generar', 'error', btn);
      hideProgress('Step2');
    } finally {
      btn.disabled = false;
      activeProgressStep = null;
    }
  });

  // --- Helper: obtener tab activa y verificar que estamos en Moodle ---
  async function requireMoodleTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes('/course/view.php')) {
      throw new Error('Debes estar en la página del curso en Moodle.');
    }
    return tab;
  }

  // --- STEP 3: Upload Videos (misma lógica v1: pestañas + colapsable + mover) ---
  document.getElementById('btnUploadVideos').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const videosArrUp = critArr(rda, 'videos');
    const validVideos = videosArrUp.filter(v => v.trim());
    const btn = document.getElementById('btnUploadVideos');
    if (validVideos.length === 0) { showStatus('Agrega al menos un link de YouTube.', 'error', btn); return; }
    const badVideoIdx = videosArrUp.findIndex(v => v.trim() && !isYoutubeUrl(v));
    if (badVideoIdx !== -1) {
      const inputs = document.querySelectorAll('.video-url');
      if (inputs[badVideoIdx]) { inputs[badVideoIdx].value = ''; videosArrUp[badVideoIdx] = ''; }
      saveFormState();
      showStatus('Se eliminó un link que no es de YouTube.', 'error', btn);
      return;
    }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('upload_resources', { type: 'videos' });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const label = getRdaLabel();
      const sectionIdx = await prepareTargetSection(tab.id, activeRda, activeCriterio);

      // Generar HTML con pestañas CSS-only (como v1)
      const tabbedHtml = generateTabbedHTML(
        validVideos.map((url, i) => ({
          label: `Video ${i + 1}`,
          content: generateYoutubeIframeHTML(url, `Video ${i + 1} - ${label} ${sectionIdx}`)
        })),
        `videos_rda${sectionIdx}`
      );

      const videoTarget = 'RECURSOS'; // Auto-detectado por el content script si no existe
      showStatus('Creando videos en Moodle...', 'loading', btn);
      await sendActionWithNav(tab.id, sectionIdx, {
        action: 'edit_section_batch',
        queue: [{
          sectionType: 'video',
          htmlContent: wrapCollapsible('🎬 Videos', tabbedHtml),
          pageName: `Videos - ${label} ${sectionIdx}`,
          sectionIndex: sectionIdx,
          targetSection: videoTarget
        }],
        courseUrl: tab.url
      });
      showStatus('Videos enviados a Moodle en pestañas.', 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Upload Geneallys (misma lógica v1: pestañas + colapsable + mover) ---
  document.getElementById('btnUploadGeneallys').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const genArrUp = critArr(rda, 'geneallys');
    const valid = genArrUp.filter(v => v.trim());
    const btn = document.getElementById('btnUploadGeneallys');
    if (valid.length === 0) { showStatus('Agrega al menos un link de Genially.', 'error', btn); return; }
    const badGeniallyIdx = genArrUp.findIndex(v => v.trim() && !isGeniallyUrl(v));
    if (badGeniallyIdx !== -1) {
      const inputs = document.querySelectorAll('.geneally-url');
      if (inputs[badGeniallyIdx]) { inputs[badGeniallyIdx].value = ''; genArrUp[badGeniallyIdx] = ''; }
      saveFormState();
      showStatus('Se eliminó un link que no es de Genially.', 'error', btn);
      return;
    }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('upload_resources', { type: 'geneallys' });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const label = getRdaLabel();
      const sectionIdx = await prepareTargetSection(tab.id, activeRda, activeCriterio);

      const tabbedHtml = generateTabbedHTML(
        valid.map((url, i) => ({
          label: `Geneally ${i + 1}`,
          content: generateGeniallyIframeHTML(url, `Geneally ${i + 1} - ${label} ${sectionIdx}`)
        })),
        `geneallys_rda${sectionIdx}`
      );

      const geneallyTarget = 'RECURSOS'; // Auto-detectado por el content script si no existe
      showStatus('Creando geneallys en Moodle...', 'loading', btn);
      await sendActionWithNav(tab.id, sectionIdx, {
        action: 'edit_section_batch',
        queue: [{
          sectionType: 'geneally',
          htmlContent: wrapCollapsible('📊 Geneallys', tabbedHtml),
          pageName: `Geneallys - ${label} ${sectionIdx}`,
          sectionIndex: sectionIdx,
          targetSection: geneallyTarget
        }],
        courseUrl: tab.url
      });
      showStatus('Geneallys enviados a Moodle en pestañas.', 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Upload PPTs (lógica v1) ---
  document.getElementById('btnUploadPpts').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const pptsArrUp = critArr(rda, 'ppts');
    const validPpts = pptsArrUp.filter(f => f);
    const btn = document.getElementById('btnUploadPpts');
    if (validPpts.length === 0) { showStatus('Agrega al menos un PowerPoint.', 'error', btn); return; }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('upload_resources', { type: 'ppts' });
      if (!creditResult.ok) throw new Error(creditResult.error);

      showStatus('Subiendo presentaciones...', 'loading', btn);
      const serializedFiles = await Promise.all(validPpts.map(f => serializeFile(f)));
      const editedNames = getPptEditedNames();
      const names = editedNames.map(n => n);  // sin prefijo "Diapositiva -" porque van dentro de una carpeta
      const sectionIdx = await prepareTargetSection(tab.id, activeRda, activeCriterio);
      const label = getRdaLabel();

      // Pre-guardar archivos en chrome.storage (gaula_file_N) para que el flow
      // upload_folder los lea durante la creación de la carpeta.
      for (let i = 0; i < serializedFiles.length; i++) {
        await chrome.storage.local.set({ [`gaula_file_${i}`]: serializedFiles[i] });
      }

      // Limpiar archivos de memoria del CRITERIO ACTUAL ANTES de enviar.
      const critIdxNow = Math.max(0, Math.min(3, (activeCriterio || 1) - 1));
      rda.ppts[critIdxNow] = [null, null, null];
      if (!Array.isArray(rda._pptNames)) rda._pptNames = [];
      rda._pptNames[critIdxNow] = ['', '', ''];
      clearFileSlotUI('.ppt-input');
      await saveFormState();

      // Descripción de la carpeta — HTML temático que aparece arriba de los archivos
      // listados (que Moodle renderiza como links automáticamente al expandir la carpeta).
      const folderName = `📑 Recursos Presentaciones — ${label} ${activeRda + 1} Criterio ${activeCriterio}`;
      const folderIntro = wrapCollapsible(
        `📑 Recursos Presentaciones — ${label} ${activeRda + 1} Criterio ${activeCriterio}`,
        `<div style="padding:14px 18px;font-size:13px;line-height:1.6;color:#1e293b">
          <p style="margin:0">Presentaciones del criterio. Click en cada archivo para descargarlo.</p>
        </div>`
      );

      await sendActionWithNav(tab.id, sectionIdx, {
        action: 'upload_folder',
        folderName,
        folderIntroHtml: folderIntro,
        totalFiles: serializedFiles.length,
        fileNames: names,
        sectionIndex: sectionIdx,
        targetSection: 'RECURSOS'
      });
      showStatus(`Creando carpeta con ${validPpts.length} PPTs...`, 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Upload PDFs (lógica v1: extraer texto + subir) ---
  document.getElementById('btnUploadPdfs').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const pdfsArrUp = critArr(rda, 'pdfs');
    const validPdfs = pdfsArrUp.filter(f => f);
    const btn = document.getElementById('btnUploadPdfs');
    if (validPdfs.length === 0) { showStatus('Agrega al menos un PDF.', 'error', btn); return; }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('upload_resources', { type: 'pdfs' });
      if (!creditResult.ok) throw new Error(creditResult.error);

      // Extraer texto ANTES de subir (para IA después)
      showStatus('Extrayendo texto de PDFs...', 'loading', btn);
      let allPdfText = '';
      for (const pdf of validPdfs) {
        try {
          const text = await extractTextFromPDF(pdf);
          allPdfText += text + '\n\n';
        } catch (_) {}
      }
      rda.pdfText = allPdfText;

      showStatus('Subiendo PDFs a Moodle...', 'loading', btn);
      const serializedPdfs = await Promise.all(validPdfs.map(f => serializeFile(f)));
      const names = getPdfEditedNames();
      const sectionIdx = await prepareTargetSection(tab.id, activeRda, activeCriterio);
      const labelPdfs = getRdaLabel();

      // Pre-guardar archivos en chrome.storage.
      for (let i = 0; i < serializedPdfs.length; i++) {
        await chrome.storage.local.set({ [`gaula_file_${i}`]: serializedPdfs[i] });
      }

      // Limpiar archivos de memoria del CRITERIO ACTUAL ANTES de enviar.
      rda.pdfsUploaded = true;
      const critIdxNow2 = Math.max(0, Math.min(3, (activeCriterio || 1) - 1));
      rda.pdfs[critIdxNow2] = [null, null, null];
      if (!Array.isArray(rda._pdfNames)) rda._pdfNames = [];
      rda._pdfNames[critIdxNow2] = ['', '', ''];
      clearFileSlotUI('.pdf-input');
      document.getElementById('btnAnalyzeAi').disabled = false;
      document.getElementById('aiHelpText').textContent = `${validPdfs.length} PDFs subidos. Listo para analizar.`;
      await saveFormState();

      const folderName = `📄 Recursos PDFs — ${labelPdfs} ${activeRda + 1} Criterio ${activeCriterio}`;
      const folderIntro = wrapCollapsible(
        `📄 Recursos PDFs — ${labelPdfs} ${activeRda + 1} Criterio ${activeCriterio}`,
        `<div style="padding:14px 18px;font-size:13px;line-height:1.6;color:#1e293b">
          <p style="margin:0">Documentos PDF del criterio. Click en cada archivo para abrirlo en otra pestaña.</p>
        </div>`
      );

      await sendActionWithNav(tab.id, sectionIdx, {
        action: 'upload_folder',
        folderName,
        folderIntroHtml: folderIntro,
        totalFiles: serializedPdfs.length,
        fileNames: names,
        sectionIndex: sectionIdx,
        targetSection: 'RECURSOS'
      });
      showStatus(`Creando carpeta con ${validPdfs.length} PDFs...`, 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- Delete buttons (lógica v1: confirmación + bulk_delete) ---
  ['btnDeleteVideos', 'btnDeleteGeneallys', 'btnDeletePpts', 'btnDeletePdfs'].forEach(id => {
    const btn = document.getElementById(id);
    if (!btn) return;
    const labelMap = { btnDeleteVideos: ['video','Videos'], btnDeleteGeneallys: ['geneally','Geneallys'], btnDeletePpts: ['ppt','Diapositivas'], btnDeletePdfs: ['pdf','PDFs'] };
    btn.addEventListener('click', async () => {
      const [type, label] = labelMap[id];
      if (!confirm(`¿Borrar TODOS los "${label}" del aula actual?\nEsta acción no se puede deshacer.`)) return;
      btn.disabled = true;
      try {
        const tab = await requireMoodleTab();
        showStatus(`Borrando ${label}...`, 'loading', btn);
        const response = await sendToContentScript(tab.id, { action: 'bulk_delete', resourceType: type });
        showStatus(`${response.deleted || 0} ${label} borrados del aula.`, 'success', btn);
      } catch (e) {
        showStatus(e.message || 'Error', 'error', btn);
      }
      btn.disabled = false;
    });
  });

  // --- Replicar nota en otros criterios (gradebook calculation) ---
  // popupReplicateState vive en el closure del init; lo limpiamos al cargar
  // un nuevo árbol o al cambiar de RDA/criterio.
  const popupReplicateState = { tree: null, suggestedIdnumber: 'A?' };

  function _replEscape(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[c]));
  }

  function renderReplicateTargets() {
    const container = document.getElementById('replicateTargets');
    if (!container) return;
    if (!popupReplicateState.tree) { container.innerHTML = ''; return; }
    const criterioIdx = parseInt(document.getElementById('manualTaskCriterio').value) || 1;
    let html = '';
    popupReplicateState.tree.rdas.forEach((rda, ri) => {
      html += `<div style="margin-top:6px;font-weight:600;color:#475569">${_replEscape(rda.name)}</div>`;
      rda.criterios.forEach((cr, ci) => {
        const isCurrent = ri === activeRda && ci === (criterioIdx - 1);
        html += `<label style="display:flex;align-items:center;gap:6px;padding:3px 6px;margin-left:8px;border-radius:4px;${isCurrent ? 'background:#fef3c7;color:#92400e':''}">
          <input type="checkbox" class="replicate-target-cb" value="${_replEscape(cr.id)}" data-name="${_replEscape(cr.name)}" ${isCurrent ? 'disabled' : ''}>
          ${_replEscape(cr.name)}${isCurrent ? ' <small style="margin-left:4px">(criterio actual)</small>' : ''}
        </label>`;
      });
    });
    container.innerHTML = html;
  }

  // Reactividad: re-render del listado de criterios cuando el usuario cambia
  // el RDA o el criterio activo arriba en el popup. Sin esto, "criterio actual"
  // se queda apuntando al criterio donde estaba al cargar el árbol y el docente
  // podría marcar por error el mismo criterio para replicar.
  const _criterioHidden = document.getElementById('manualTaskCriterio');
  if (_criterioHidden) {
    new MutationObserver(() => renderReplicateTargets()).observe(_criterioHidden, {
      attributes: true, attributeFilter: ['value']
    });
  }
  // Para RDA: observar cambios de clase 'active' en cualquier .rda-tab
  document.querySelectorAll('.rda-tab').forEach(tab => {
    new MutationObserver(() => renderReplicateTargets()).observe(tab, {
      attributes: true, attributeFilter: ['class']
    });
  });

  document.getElementById('btnLoadGradeTree').addEventListener('click', async () => {
    const btn = document.getElementById('btnLoadGradeTree');
    const status = document.getElementById('replicateStatus');
    btn.disabled = true;
    status.textContent = 'Cargando criterios del aula...';
    try {
      const tab = await requireMoodleTab();
      const res = await sendToContentScript(tab.id, { action: 'fetch_grade_tree' });
      if (!res.ok || !res.tree) throw new Error(res.error || 'No se pudo leer el aula');
      popupReplicateState.tree = res.tree;
      popupReplicateState.suggestedIdnumber = res.suggestedIdnumber || 'A1';
      document.getElementById('replicateIdAuto').textContent = popupReplicateState.suggestedIdnumber;
      renderReplicateTargets();
      const total = res.tree.rdas.reduce((acc, r) => acc + r.criterios.length, 0);
      status.textContent = `${res.tree.rdas.length} RDAs · ${total} criterios disponibles. Marca los que necesites.`;
      status.style.color = '#059669';
    } catch (e) {
      status.textContent = `Error: ${e.message}`;
      status.style.color = '#dc2626';
    }
    btn.disabled = false;
  });

  // --- Limpiar copias huérfanas ---
  // Flujo en dos pasos: primer clic detecta y muestra lista con checkbox, segundo
  // clic (botón "Confirmar borrado") ejecuta. Más seguro que un confirm() ciego.
  document.getElementById('btnCleanOrphanReplicas').addEventListener('click', async () => {
    const btn = document.getElementById('btnCleanOrphanReplicas');
    const listEl = document.getElementById('replicateOrphansList');
    const status = document.getElementById('replicateStatus');
    btn.disabled = true;
    listEl.innerHTML = '';
    status.textContent = 'Buscando copias huérfanas...';
    status.style.color = '#64748b';
    try {
      const tab = await requireMoodleTab();
      const res = await sendToContentScript(tab.id, { action: 'find_orphan_replicas' });
      if (!res.ok) throw new Error(res.error || 'Error al detectar');
      const { orphans, totalReplicas } = res;
      if (!orphans || orphans.length === 0) {
        listEl.innerHTML = `<div style="padding:8px;background:#dcfce7;color:#166534;border-radius:6px">✅ No hay copias huérfanas. Total copias activas: ${totalReplicas || 0}.</div>`;
        status.textContent = '';
        btn.disabled = false;
        return;
      }
      // Render lista con checkboxes (todas marcadas por default)
      let html = `<div style="padding:8px;background:#fef3c7;color:#92400e;border-radius:6px;margin-bottom:6px">
        Se encontraron <b>${orphans.length}</b> copias cuya tarea original fue eliminada.
        Desmarca las que NO quieres borrar:
      </div>`;
      html += '<div style="max-height:200px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:6px;padding:6px;background:#fff">';
      orphans.forEach(o => {
        const dest = o.parentCategoryName || `cat ${o.parentCategoryId || '?'}`;
        html += `<label style="display:flex;align-items:flex-start;gap:6px;padding:4px 6px;border-radius:4px">
          <input type="checkbox" class="orphan-cb" value="${_replEscape(o.itemId)}" checked style="margin-top:3px">
          <div style="flex:1">
            <div style="color:#1e293b">${_replEscape(o.name)}</div>
            <div style="font-size:10px;color:#64748b">En: <b>${_replEscape(dest)}</b></div>
          </div>
        </label>`;
      });
      html += '</div>';
      html += `<button type="button" id="btnConfirmDeleteOrphans" class="btn-action" style="margin-top:8px;background:#dc2626;color:#fff;font-size:12px;padding:6px 12px">🗑️ Confirmar borrado</button>`;
      listEl.innerHTML = html;
      status.textContent = '';

      document.getElementById('btnConfirmDeleteOrphans').addEventListener('click', async () => {
        const confirmBtn = document.getElementById('btnConfirmDeleteOrphans');
        const selected = [...listEl.querySelectorAll('.orphan-cb:checked')].map(cb => cb.value);
        if (selected.length === 0) {
          status.textContent = 'No marcaste ninguna copia para borrar.';
          status.style.color = '#dc2626';
          return;
        }
        confirmBtn.disabled = true;
        confirmBtn.textContent = `Borrando ${selected.length}...`;
        try {
          const delRes = await sendToContentScript(tab.id, { action: 'delete_grade_items', itemIds: selected });
          if (!delRes.ok) throw new Error(delRes.error || 'Error al borrar');
          listEl.innerHTML = `<div style="padding:8px;background:#dcfce7;color:#166534;border-radius:6px">✅ Borradas ${delRes.deleted}/${delRes.total} copias huérfanas.</div>`;
          status.textContent = '';
        } catch (e) {
          status.textContent = `Error: ${e.message}`;
          status.style.color = '#dc2626';
          confirmBtn.disabled = false;
          confirmBtn.textContent = '🗑️ Confirmar borrado';
        }
      });
    } catch (e) {
      status.textContent = `Error: ${e.message}`;
      status.style.color = '#dc2626';
    }
    btn.disabled = false;
  });

  // --- STEP 3: Create Manual Task (lógica v1: descripción HTML + rúbrica visible + PDF) ---
  document.getElementById('btnCreateManualTask').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const mt = rda.manualTask;
    const btn = document.getElementById('btnCreateManualTask');
    if (!mt.nombre) { showStatus('Escribe un nombre para la tarea.', 'error', btn); return; }
    // Permite mismo día (desde == hasta): el content script pone desde 00:00 y
    // hasta 23:59, así que Moodle lo acepta. Solo bloquea fechas invertidas.
    if (mt.dateFrom > mt.dateTo) {
      showStatus('La fecha "Disponible hasta" no puede ser anterior a "Disponible desde".', 'error', btn);
      return;
    }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('create_task', { nombre: mt.nombre });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const label = getRdaLabel();
      const criterioIdx = parseInt(document.getElementById('manualTaskCriterio').value) || 1;
      const sectionIdx = await prepareTargetSection(tab.id, activeRda, criterioIdx);
      const gradeCatValue = await getGradeCategoryForRda(activeRda);

      // Construir rubrica JSON
      const rubricaJson = { criterios: mt.rubrica.filter(c => c.nombre).map(c => ({
        nombre: c.nombre,
        niveles: c.niveles.map(n => ({ nombre: n.nombre, puntos: n.puntos, descripcion: n.descripcion || n.nombre }))
      }))};

      // Construir HTML de descripción + rúbrica visible (wrapper temático con chevron)
      let descHtml = '';
      const taskTheme = getActiveTheme();
      const detailsParts = [];
      if (mt.descripcion) {
        detailsParts.push(`<p style="margin:0 0 12px 0;font-size:14px;color:#1e293b;">${mt.descripcion.replace(/\n/g, '<br>')}</p>`);
      }
      const validCriteria = mt.rubrica.filter(c => c.nombre);
      if (validCriteria.length > 0) {
        const colors = { 'Excelente': '#059669', 'Bueno': '#2563eb', 'Regular': '#d97706', 'Insuficiente': '#dc2626' };
        const bgColors = { 'Excelente': '#ecfdf5', 'Bueno': '#eff6ff', 'Regular': '#fffbeb', 'Insuficiente': '#fef2f2' };
        let rubricHtml = `<div style="margin-top:8px;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden;font-family:sans-serif;">
          <div style="background:${taskTheme.headerBg};color:#fff;padding:8px 12px;font-size:13px;font-weight:700;">Rúbrica de Evaluación</div>
          <table style="width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed;word-wrap:break-word;">
            <thead><tr style="background:#f1f5f9;">
              <th style="padding:6px 8px;text-align:left;border-bottom:2px solid #cbd5e1;font-size:11px;color:#475569;width:18%;">Criterio</th>
              ${validCriteria[0].niveles.map(n => `<th style="padding:6px 8px;text-align:center;border-bottom:2px solid #cbd5e1;font-size:11px;color:${colors[n.nombre] || '#475569'};">${n.nombre}<br><span style="font-weight:400;font-size:10px;">(${n.puntos} pts)</span></th>`).join('')}
            </tr></thead>
            <tbody>
              ${validCriteria.map((c, i) => `<tr style="background:${i % 2 === 0 ? '#fff' : '#f8fafc'};">
                <td style="padding:6px 8px;font-weight:600;border-bottom:1px solid #e2e8f0;color:#1e293b;">${c.nombre}</td>
                ${c.niveles.map(n => `<td style="padding:6px 8px;text-align:center;border-bottom:1px solid #e2e8f0;font-size:11px;color:#334155;background:${bgColors[n.nombre] || 'transparent'}22;">${n.descripcion || '-'}</td>`).join('')}
              </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
        detailsParts.push(rubricHtml);
      }
      if (detailsParts.length > 0) {
        descHtml = wrapCollapsible(
          `📝 Tarea — ${label} ${activeRda + 1} Criterio ${parseInt(document.getElementById('manualTaskCriterio').value) || 1}`,
          `<div style="padding:14px 18px;font-family:sans-serif">${detailsParts.join('')}</div>`
        );
      }

      // Serializar PDF adjunto
      let pdfSerialized = null;
      if (mt.pdf) pdfSerialized = await serializeFile(mt.pdf);

      // Limpiar PDF adjunto de memoria ANTES de enviar
      mt.pdf = null;
      mt.pdfName = '';
      clearTaskPdfUI();
      await saveFormState();

      // Capturar targets de replicación (si el usuario los marcó)
      const replicateTargets = Array.from(
        document.querySelectorAll('#replicateTargets input.replicate-target-cb:checked')
      ).map(cb => ({ categoryId: cb.value, name: cb.dataset.name || '' }));
      const replicateIdnumber = popupReplicateState.suggestedIdnumber && popupReplicateState.suggestedIdnumber !== 'A?'
        ? popupReplicateState.suggestedIdnumber
        : null;

      showStatus('Creando tarea en Moodle...', 'loading', btn);
      await sendActionWithNav(tab.id, sectionIdx, {
        action: 'create_assignment',
        assignments: [{
          nombre: mt.nombre,
          descripcionHtml: descHtml,
          rubricaJson: rubricaJson.criterios.length > 0 ? rubricaJson : null,
          instrucciones: mt.descripcion,
          pdfSerialized: pdfSerialized,
          dateFrom: mt.dateFrom,
          dateTo: mt.dateTo
        }],
        rdaIndex: activeRda,
        sectionIndex: sectionIdx,
        gradeCategoryValue: gradeCatValue,
        criterioIndex: parseInt(document.getElementById('manualTaskCriterio').value),
        replicateTargets,
        replicateIdnumber

      });
      showStatus(`Tarea "${mt.nombre}" creada en ${label} ${sectionIdx}.`, 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Create Manual Quiz (lógica v1: fechas, horas, Aiken, XML, categoría) ---
  document.getElementById('btnCreateManualQuiz').addEventListener('click', async () => {
    saveCurrentRdaData();
    saveManualQuizData();
    const mq = rdaData[activeRda].manualQuiz;
    const btn = document.getElementById('btnCreateManualQuiz');
    if (!mq.nombre) { showStatus('Escribe un nombre para la evaluacion.', 'error', btn); return; }

    // Validar fechas/horas
    const qHourFrom = mq.hourFrom || '0';
    const qMinFrom = mq.minFrom || '0';
    const qHourTo = mq.hourTo || '23';
    const qMinTo = mq.minTo || '55';
    if (mq.dateFrom && mq.dateTo) {
      const openDT = new Date(mq.dateFrom + 'T' + String(qHourFrom).padStart(2,'0') + ':' + String(qMinFrom).padStart(2,'0'));
      const closeDT = new Date(mq.dateTo + 'T' + String(qHourTo).padStart(2,'0') + ':' + String(qMinTo).padStart(2,'0'));
      const diffMin = (closeDT - openDT) / 60000;
      if (diffMin <= 0) { showStatus('La fecha/hora de cierre debe ser posterior a la de apertura.', 'error', btn); return; }
      if (mq.time > 0 && diffMin < mq.time) { showStatus(`La ventana disponible (${Math.floor(diffMin)} min) es menor al tiempo del quiz (${mq.time} min).`, 'error', btn); return; }
    }

    // Validación multi-banco (toggle ON)
    if (mq.randomMode) {
      const v = validateBanksPayload(mq.banks);
      if (!v.ok) { showStatus(v.errors[0], 'error', btn); return; }
    }

    btn.disabled = true;
    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('create_quiz', { nombre: mq.nombre });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const quizCriterioIdx = parseInt(document.getElementById('manualQuizCriterio')?.value) || 1;
      const sectionIdx = await prepareTargetSection(tab.id, activeRda, quizCriterioIdx);
      const gradeCatValue = await getGradeCategoryForRda(activeRda);

      showStatus('Creando evaluacion en Moodle...', 'loading', btn);
      // Banks payload solo si randomMode. Quitamos el File (no serializable) y el pdfText.
      // Normalizamos el aikenText ANTES de enviar — el user pudo haber editado el
      // textarea y dejado bloques rotos (ANSWER sin letra, etc.). Mandar texto
      // normalizado garantiza que Moodle solo reciba bloques válidos.
      const banksPayload = mq.randomMode
        ? mq.banks.map((b, i) => {
            const norm = normalizeAikenText(b.aikenText || '');
            return {
              idx: i,
              name: b.name,
              aikenText: norm.text,
              detectedCount: norm.kept,
              randomCount: parseInt(b.randomCount) || 0
            };
          })
        : null;
      // En randomMode, NO mandamos el aikenText del textarea OFF (contaminaría el state).
      // Las preguntas vienen exclusivamente de banks[].aikenText.
      const aikenPayload = mq.randomMode ? '' : (mq.aikenText || '');
      const xmlPayload = mq.randomMode ? '' : (mq.xmlContent || '');

      // Descripción temática del quiz (mismo wrapper que carpetas/tareas)
      const quizLabel = getRdaLabel();
      const quizIntroHtml = wrapCollapsible(
        `🧪 Evaluación — ${quizLabel} ${activeRda + 1} Criterio ${quizCriterioIdx}`,
        `<div style="padding:14px 18px;font-size:13px;line-height:1.6;color:#1e293b">
          <p style="margin:0 0 8px 0"><strong>${mq.nombre}</strong></p>
          ${mq.time ? `<p style="margin:0">⏱️ Tiempo límite: ${mq.time} minutos</p>` : ''}
        </div>`
      );

      await sendActionWithNav(tab.id, sectionIdx, {
        action: 'create_quiz',
        quizName: mq.nombre,
        quizIntroHtml,
        dateFrom: mq.dateFrom,
        dateTo: mq.dateTo,
        hourFrom: qHourFrom,
        minFrom: qMinFrom,
        hourTo: qHourTo,
        minTo: qMinTo,
        timeLimit: mq.time || 60,
        quizPassword: mq.password || '',
        rdaIndex: activeRda,
        sectionIndex: sectionIdx,
        gradeCategoryValue: gradeCatValue,
        criterioIndex: parseInt(document.getElementById('manualQuizCriterio').value),
        aikenText: aikenPayload,
        xmlText: xmlPayload,
        xmlFileName: mq.xmlFileName || '',
        randomMode: !!mq.randomMode,
        banks: banksPayload
      });
      showStatus(`Evaluacion "${mq.nombre}" creada.`, 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Analyze with AI (backend Edge Function) ---
  document.getElementById('btnAnalyzeAi').addEventListener('click', async () => {
    const btn = document.getElementById('btnAnalyzeAi');
    btn.disabled = true;
    saveCurrentRdaData();

    try {
      const rda = rdaData[activeRda];
      // Analizar con IA agrega TODOS los PDFs del RDA (de todos los criterios),
      // no solo el criterio actual — el análisis es por RDA, no por criterio.
      const validPdfs = flatCrits(rda, 'pdfs').filter(f => f);

      // Usar texto ya extraído o extraer ahora
      let allPdfText = rda.pdfText || '';
      if (!allPdfText.trim() && validPdfs.length > 0) {
        showStatus('Extrayendo texto de PDFs...', 'loading', btn);
        for (const pdf of validPdfs) {
          try { allPdfText += await extractTextFromPDF(pdf) + '\n\n'; } catch (_) {}
        }
        rda.pdfText = allPdfText;
      }
      if (!allPdfText.trim()) throw new Error('Sube al menos un PDF primero.');

      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('analyze_ai', { rdaIndex: activeRda + 1 });
      if (!creditResult.ok) throw new Error(creditResult.error);

      showStatus('IA analizando contenido (puede tardar ~30s)...', 'loading', btn);
      const numQuestions = parseInt(document.getElementById('questionsPerQuiz')?.value) || 10;
      const result = await callGenerateContent('analyze_ai', { pdfText: allPdfText, questionsPerQuiz: numQuestions });
      if (!result.ok) throw new Error(result.error);

      // Rellenar tareas sugeridas
      if (result.tasks && result.tasks.length > 0) {
        document.querySelectorAll('#taskPanels .ai-tab-panel').forEach((panel, i) => {
          if (!result.tasks[i]) return;
          const nameInput = panel.querySelector('.task-name');
          const descInput = panel.querySelector('.task-desc');
          if (nameInput) nameInput.value = result.tasks[i].nombre || '';
          if (descInput) descInput.value = result.tasks[i].descripcion || '';
          rda.tasks[i] = { nombre: result.tasks[i].nombre || '', descripcion: result.tasks[i].descripcion || '' };
        });
      }

      // Rellenar evaluaciones
      if (result.evals && result.evals.length > 0) {
        result.evals.forEach((ev, i) => {
          rda.evals[i] = ev;
          const preview = document.getElementById(`evalPreview${i}`);
          if (preview && ev.questions && ev.questions.length > 0) {
            preview.innerHTML = ev.questions.map((q, qi) => {
              const opts = (q.opciones || q.options || []).map((opt, j) => {
                const isCorrect = j === (q.correcta || q.correct || 0);
                return `<span style="color:${isCorrect ? '#059669' : '#64748b'}">${isCorrect ? '✓ ' : '• '}${opt}</span>`;
              }).join('<br>');
              return `<div style="margin-bottom:8px"><div style="font-weight:600;font-size:11px">${qi + 1}. ${q.pregunta || q.question || ''}</div>${opts}</div>`;
            }).join('');
          } else if (preview) {
            preview.innerHTML = `<span style="color:#dc2626">Error: ${ev.error || 'Sin preguntas'}</span>`;
          }
        });
      }

      rda.aiAnalyzed = true;
      document.getElementById('stageAiResults').style.display = 'block';
      showStatus('Análisis completo. Revisa tareas y evaluaciones, ajusta fechas y crea en Moodle.', 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- STEP 3: Create AI Tasks + Quizzes + Forum ---
  document.getElementById('btnCreateTasksQuizzes').addEventListener('click', async () => {
    saveCurrentRdaData();
    const rda = rdaData[activeRda];
    const btn = document.getElementById('btnCreateTasksQuizzes');
    btn.disabled = true;

    try {
      const tab = await requireMoodleTab();
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('create_ai_content', { rdaIndex: activeRda + 1 });
      if (!creditResult.ok) throw new Error(creditResult.error);

      const aiCriterioIdx = parseInt(document.getElementById('manualTaskCriterio')?.value) || 1;
      const sectionIdx = await prepareTargetSection(tab.id, activeRda, aiCriterioIdx);
      const gradeCatValue = await getGradeCategoryForRda(activeRda);

      // Recopilar tareas desde la UI
      const taskPanels = document.querySelectorAll('#taskPanels .ai-tab-panel');
      const assignments = [];
      taskPanels.forEach(panel => {
        const name = panel.querySelector('.task-name')?.value?.trim();
        if (!name) return;
        const desc = panel.querySelector('.task-desc')?.value || '';
        const dateFrom = panel.querySelector('.task-date-from')?.value || '';
        const dateTo = panel.querySelector('.task-date-to')?.value || '';
        assignments.push({ nombre: name, descripcionHtml: desc, instrucciones: desc, dateFrom, dateTo });
      });

      // Crear primera tarea (el content script maneja multi-página)
      if (assignments.length > 0) {
        showStatus('Creando tareas en Moodle...', 'loading', btn);
        await sendActionWithNav(tab.id, sectionIdx, {
          action: 'create_assignment',
          assignments: [assignments[0]],
          rdaIndex: activeRda,
          sectionIndex: sectionIdx,
          gradeCategoryValue: gradeCatValue,
          criterioIndex: parseInt(document.getElementById('manualTaskCriterio').value)
        });
      }

      showStatus('Tareas creándose. La extensión navegará automáticamente.', 'success', btn);
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- Generate Rubric with AI (backend Edge Function) ---
  document.getElementById('btnGenerateRubricAi').addEventListener('click', async () => {
    const btn = document.getElementById('btnGenerateRubricAi');
    btn.disabled = true;
    saveCurrentRdaData();

    try {
      let pdfText = '';
      const manualPdfFile = document.getElementById('manualTaskPdf')?.files?.[0];
      if (manualPdfFile) {
        try { pdfText = await extractTextFromPDF(manualPdfFile); } catch (_) {}
      }
      if (!pdfText.trim()) {
        pdfText = rdaData[activeRda].pdfText || '';
        if (!pdfText.trim()) {
          // Fallback: leer todos los PDFs del RDA (todos los criterios) para generar rúbrica
          const files = flatCrits(rdaData[activeRda], 'pdfs').filter(f => f);
          for (const file of files) {
            try { pdfText += await extractTextFromPDF(file) + '\n'; } catch (_) {}
          }
        }
      }

      const taskName = document.getElementById('manualTaskName')?.value || 'Tarea';
      const numCriterios = parseInt(document.getElementById('rubricCriteriaCount')?.value || '4');
      showStatus('Verificando créditos...', 'loading', btn);
      const creditResult = await executeAction('generate_rubric', { taskName });
      if (!creditResult.ok) throw new Error(creditResult.error);

      showStatus('Generando rúbrica con IA...', 'loading', btn);
      const result = await callGenerateContent('generate_rubric', { taskName, pdfText, numCriterios });
      if (!result.ok) throw new Error(result.error);

      if (result.rubricaJson && result.rubricaJson.criterios) {
        renderRubricFromJson(result.rubricaJson);
        saveFormState();
        showStatus('Rúbrica generada.', 'success', btn);
      } else {
        showStatus('No se pudo generar la rúbrica.', 'error', btn);
      }
    } catch (e) {
      showStatus(e.message || 'Error', 'error', btn);
    }
    btn.disabled = false;
  });

  // --- Quiz date/time validation ---
  ['manualQuizDateFrom', 'manualQuizDateTo', 'manualQuizHourFrom', 'manualQuizMinFrom', 'manualQuizHourTo', 'manualQuizMinTo', 'manualQuizTime'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', () => { saveManualQuizData(); validateQuizDates(); saveFormState(); });
      el.addEventListener('input', () => { saveManualQuizData(); saveFormState(); });
    }
  });

  // --- Global Stop ---
  btnStop.addEventListener('click', () => {
    sendMessage({ type: 'SEND_TO_TAB', message: { action: 'gaula_stop' } });
    btnStop.style.display = 'none';
    showStatus('Operacion detenida.', 'error');
  });

  // Stop button for Step 2
  document.getElementById('btnStopStep2')?.addEventListener('click', () => {
    sendMessage({ type: 'SEND_TO_TAB', message: { action: 'gaula_stop' } });
    document.getElementById('btnStopStep2').style.display = 'none';
    showStatus('Operacion detenida.', 'error', 'Step2');
  });
}

// ============================================================
// URL VALIDATORS
// ============================================================

function isYoutubeUrl(url) {
  return /^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(url.trim());
}

function isGeniallyUrl(url) {
  return /^https?:\/\/(view\.)?genial(\.ly|ly\.com)\//i.test(url.trim());
}

function initUrlValidation() {
  function validate(input) {
    const val = input.value.trim();
    if (!val) { input.classList.remove('url-invalid', 'url-valid'); return; }
    const isVideo = input.classList.contains('video-url');
    const ok = isVideo ? isYoutubeUrl(val) : isGeniallyUrl(val);
    input.classList.toggle('url-invalid', !ok);
    input.classList.toggle('url-valid', ok);
  }
  document.addEventListener('input', (e) => {
    if (e.target.matches('.video-url, .geneally-url')) validate(e.target);
  });
  document.addEventListener('paste', (e) => {
    if (e.target.matches('.video-url, .geneally-url')) {
      setTimeout(() => validate(e.target), 0);
    }
  });
}

// ============================================================
// HELPERS FOR FILE NAMES
// ============================================================

function truncateName(name, maxLen = 50) {
  return name.length > maxLen ? name.substring(0, maxLen) : name;
}

function getPptEditedNames() {
  const names = [];
  document.querySelectorAll('.ppt-input').forEach(input => {
    if (input.files[0]) {
      const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
      names.push(truncateName(nameEl.value || input.files[0].name.replace(/\.[^.]+$/, '')));
    }
  });
  return names;
}

function getPdfEditedNames() {
  const names = [];
  document.querySelectorAll('.pdf-input').forEach(input => {
    if (input.files[0]) {
      const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
      names.push(truncateName(nameEl.value || input.files[0].name.replace(/\.[^.]+$/, '')));
    }
  });
  return names;
}

// Limpiar visualmente los file slots (.ppt-input o .pdf-input)
function clearFileSlotUI(selector) {
  document.querySelectorAll(selector).forEach(input => {
    input.value = '';
    const nameEl = input.closest('.file-slot').querySelector('.file-slot-name');
    if (nameEl) {
      nameEl.value = 'Sin archivo';
      nameEl.classList.remove('has-file');
      nameEl.setAttribute('readonly', '');
    }
  });
}

// Limpiar visualmente el PDF adjunto de la tarea manual
function clearTaskPdfUI() {
  const pdfInput = document.getElementById('manualTaskPdf');
  if (pdfInput) pdfInput.value = '';
  const nameEl = document.getElementById('manualTaskPdfName');
  if (nameEl) {
    nameEl.value = 'Sin archivo';
    nameEl.classList.remove('has-file');
    nameEl.setAttribute('readonly', '');
  }
}

// ============================================================
// PROGRESS MONITOR
// ============================================================

function initProgressMonitor() {
  // Listen for progress updates from content script via storage
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.gaula_progress) {
      const p = changes.gaula_progress.newValue;
      if (!p) return;

      if (p.status === 'done' || p.status === 'error') {
        hideAllProgress();
        if (p.status === 'error') showStatus(p.error || 'Error', 'error');
        return;
      }

      // Show progress
      const wrapper = document.getElementById('progressWrapper');
      const label = document.getElementById('progressLabel');
      const count = document.getElementById('progressCount');
      const fill = document.getElementById('progressFill');

      wrapper.style.display = 'block';
      label.textContent = p.label || 'Procesando...';
      if (p.total > 0) {
        count.textContent = `${p.current}/${p.total}`;
        fill.style.width = `${(p.current / p.total) * 100}%`;
      }

      btnStop.style.display = 'block';
    }
  });
}

function hideAllProgress() {
  document.getElementById('progressWrapper').style.display = 'none';
  document.getElementById('progressStep2').style.display = 'none';
  document.getElementById('progressStep3').style.display = 'none';
  btnStop.style.display = 'none';
}

// ============================================================
// FORM STATE PERSISTENCE
// ============================================================

// Bug #11: Debounce para evitar escrituras excesivas a chrome.storage
let _saveFormTimeout = null;
function saveFormState() {
  if (_saveFormTimeout) clearTimeout(_saveFormTimeout);
  _saveFormTimeout = setTimeout(_saveFormStateImmediate, 300);
}

function _saveFormStateImmediate() {
  // Guardar datos del RdA activo antes de serializar
  saveCurrentRdaData();

  // Serializar rdaData sin archivos (File objects no se pueden guardar en storage)
  const rdaSerialized = rdaData.map(rda => ({
    videos: rda.videos,
    geneallys: rda.geneallys,
    forumTopic: rda.forumTopic,
    aiAnalyzed: rda.aiAnalyzed,
    pdfText: rda.pdfText,
    tasks: rda.tasks,
    evals: rda.evals,
    // Guardar nombres de archivos por CRITERIO para mostrar al reabrir
    // (los File objects no se pueden persistir en chrome.storage).
    pdfNames: (Array.isArray(rda.pdfs) ? rda.pdfs : []).map(critArr =>
      Array.isArray(critArr) ? critArr.map(f => f ? f.name : '') : ['','','']
    ),
    pptNames: (Array.isArray(rda.ppts) ? rda.ppts : []).map(critArr =>
      Array.isArray(critArr) ? critArr.map(f => f ? f.name : '') : ['','','']
    ),
    manualTask: {
      nombre: rda.manualTask.nombre,
      descripcion: rda.manualTask.descripcion,
      dateFrom: rda.manualTask.dateFrom,
      dateTo: rda.manualTask.dateTo,
      criterio: rda.manualTask.criterio || '1',
      pdfName: rda.manualTask.pdf ? rda.manualTask.pdf.name : (rda.manualTask.pdfName || ''),
      rubrica: rda.manualTask.rubrica,
    },
    manualQuiz: {
      nombre: rda.manualQuiz.nombre,
      password: rda.manualQuiz.password,
      dateFrom: rda.manualQuiz.dateFrom,
      dateTo: rda.manualQuiz.dateTo,
      criterio: rda.manualQuiz.criterio || '1',
      time: rda.manualQuiz.time,
      hourFrom: rda.manualQuiz.hourFrom || '8',
      minFrom: rda.manualQuiz.minFrom || '0',
      hourTo: rda.manualQuiz.hourTo || '23',
      minTo: rda.manualQuiz.minTo || '55',
      aikenText: rda.manualQuiz.aikenText,
      xmlContent: rda.manualQuiz.xmlContent || '',
      randomMode: !!rda.manualQuiz.randomMode,
      // Banks: serializamos sin el File pdf (no es JSON-safe).
      banks: Array.isArray(rda.manualQuiz.banks) ? rda.manualQuiz.banks.map(b => ({
        name: b.name || '',
        source: b.source || 'ai',
        pdfName: b.pdfName || (b.pdf ? b.pdf.name : ''),
        generateCount: b.generateCount || 20,
        difficulty: b.difficulty || 'medio',
        language: b.language || 'es',
        aikenText: b.aikenText || '',
        detectedCount: b.detectedCount || 0,
        droppedCount: b.droppedCount || 0,
        randomCount: b.randomCount || 0
      })) : []
    },
  }));

  const state = {
    teacherName: document.getElementById('teacherName')?.value || '',
    teacherTitle: document.getElementById('teacherTitle')?.value || '',
    teacherEmail: document.getElementById('teacherEmail')?.value || '',
    teacherDesc: document.getElementById('teacherDesc')?.value || '',
    subjectName: document.getElementById('subjectName')?.value || '',
    careerName: document.getElementById('careerName')?.value || '',
    notebookLmLink: document.getElementById('notebookLmLink')?.value || '',
    schedule: scheduleBlocks.map(b => ({ dia: b.dia, horaInicio: b.horaInicio, horaFin: b.horaFin, aula: b.aula, modalidad: b.modalidad })),
    activeRda,
    activeCriterio,
    rdaData: rdaSerialized,
  };
  return new Promise(resolve => chrome.storage.local.set({ gaula_form_state: state }, resolve));
}

function loadFormState() {
  chrome.storage.local.get('gaula_form_state', (result) => {
    const s = result.gaula_form_state;

    // Ya no hay autodetección de tipo de curso

    if (!s) return;

    // Paso 2: datos basicos
    if (s.teacherName) document.getElementById('teacherName').value = s.teacherName;
    if (s.teacherTitle) document.getElementById('teacherTitle').value = s.teacherTitle;
    if (s.teacherEmail) document.getElementById('teacherEmail').value = s.teacherEmail;
    if (s.teacherDesc) document.getElementById('teacherDesc').value = s.teacherDesc;
    if (s.subjectName) document.getElementById('subjectName').value = s.subjectName;
    if (s.careerName) document.getElementById('careerName').value = s.careerName;
    if (s.notebookLmLink) document.getElementById('notebookLmLink').value = s.notebookLmLink;
    // courseType ya no se restaura — popup es genérico

    // Horario
    if (s.schedule && s.schedule.length > 0) {
      scheduleBlocks = [];
      s.schedule.forEach(b => createScheduleBlock(b));
    }

    // Datos por RdA
    if (s.rdaData) {
      s.rdaData.forEach((saved, i) => {
        if (!rdaData[i]) return;
        // Migración v3.12 → v3.13: videos/geneallys/pdfs/ppts pasaron de array[3]
        // (criterio implícito) a matriz[criterio][slot]. Si detectamos formato
        // viejo (string en lugar de array, o array no anidado), promovemos al
        // primer criterio y dejamos los demás vacíos.
        const promoteToCritMatrix = (val, kind) => {
          const emptySlot = kind === 'file' ? null : '';
          const emptyRow = [emptySlot, emptySlot, emptySlot];
          if (!Array.isArray(val)) return [emptyRow.slice(), emptyRow.slice(), emptyRow.slice(), emptyRow.slice()];
          // Si el primer elemento es array → ya es matriz, normalizar tamaños
          if (Array.isArray(val[0])) {
            const m = [];
            for (let k = 0; k < 4; k++) {
              const row = Array.isArray(val[k]) ? val[k].slice(0, 3) : emptyRow.slice();
              while (row.length < 3) row.push(emptySlot);
              m.push(row);
            }
            return m;
          }
          // Formato viejo plano: asignamos al criterio 1
          const c1 = val.slice(0, 3);
          while (c1.length < 3) c1.push(emptySlot);
          return [c1, emptyRow.slice(), emptyRow.slice(), emptyRow.slice()];
        };
        rdaData[i].videos = promoteToCritMatrix(saved.videos, 'str');
        rdaData[i].geneallys = promoteToCritMatrix(saved.geneallys, 'str');
        rdaData[i].forumTopic = saved.forumTopic || '';
        rdaData[i].aiAnalyzed = saved.aiAnalyzed || false;
        rdaData[i].pdfText = saved.pdfText || '';
        rdaData[i].tasks = saved.tasks || [{},{},{}];
        rdaData[i].evals = saved.evals || [{},{},{}];

        // pdfs/ppts en memoria: matriz vacía (los File objects se perdieron al
        // cerrar popup). Solo restauramos los nombres en _pdfNames/_pptNames.
        rdaData[i].pdfs = promoteToCritMatrix(null, 'file');
        rdaData[i].ppts = promoteToCritMatrix(null, 'file');

        // Restaurar nombres de archivos como matriz[criterio][slot]
        if (saved.pdfNames) {
          rdaData[i]._pdfNames = Array.isArray(saved.pdfNames[0])
            ? saved.pdfNames                                          // ya matriz
            : promoteToCritMatrix(saved.pdfNames, 'str');             // legacy plano
        }
        if (saved.pptNames) {
          rdaData[i]._pptNames = Array.isArray(saved.pptNames[0])
            ? saved.pptNames
            : promoteToCritMatrix(saved.pptNames, 'str');
        }

        // Manual task
        if (saved.manualTask) {
          rdaData[i].manualTask.nombre = saved.manualTask.nombre || '';
          rdaData[i].manualTask.descripcion = saved.manualTask.descripcion || '';
          rdaData[i].manualTask.dateFrom = saved.manualTask.dateFrom || gaulaToday();
          rdaData[i].manualTask.dateTo = saved.manualTask.dateTo || gaulaNextWeek();
          rdaData[i].manualTask.pdfName = saved.manualTask.pdfName || '';
          rdaData[i].manualTask.criterio = saved.manualTask.criterio || '1';
          if (saved.manualTask.rubrica) rdaData[i].manualTask.rubrica = saved.manualTask.rubrica;
        }

        // Manual quiz
        if (saved.manualQuiz) {
          rdaData[i].manualQuiz.nombre = saved.manualQuiz.nombre || '';
          rdaData[i].manualQuiz.password = saved.manualQuiz.password || '';
          rdaData[i].manualQuiz.dateFrom = saved.manualQuiz.dateFrom || gaulaToday();
          rdaData[i].manualQuiz.dateTo = saved.manualQuiz.dateTo || gaulaToday();
          rdaData[i].manualQuiz.time = saved.manualQuiz.time || 60;
          rdaData[i].manualQuiz.hourFrom = saved.manualQuiz.hourFrom || '8';
          rdaData[i].manualQuiz.minFrom = saved.manualQuiz.minFrom || '0';
          rdaData[i].manualQuiz.hourTo = saved.manualQuiz.hourTo || '23';
          rdaData[i].manualQuiz.minTo = saved.manualQuiz.minTo || '55';
          rdaData[i].manualQuiz.criterio = saved.manualQuiz.criterio || '1';
          rdaData[i].manualQuiz.aikenText = saved.manualQuiz.aikenText || '';
          rdaData[i].manualQuiz.xmlContent = saved.manualQuiz.xmlContent || '';
          // Multi-banco
          rdaData[i].manualQuiz.randomMode = !!saved.manualQuiz.randomMode;
          if (Array.isArray(saved.manualQuiz.banks) && saved.manualQuiz.banks.length > 0) {
            rdaData[i].manualQuiz.banks = saved.manualQuiz.banks.map((b, k) => ({
              name: b.name || createEmptyBank(k).name,
              source: b.source || 'ai',
              pdf: null,                 // File no se persiste
              pdfName: b.pdfName || '',
              generateCount: b.generateCount || 20,
              difficulty: b.difficulty || 'medio',
              language: b.language || 'es',
              aikenText: b.aikenText || '',
              detectedCount: b.detectedCount || parseAikenCount(b.aikenText || ''),
              droppedCount: b.droppedCount || 0,
              randomCount: b.randomCount || 0
            }));
          } else {
            rdaData[i].manualQuiz.banks = [createEmptyBank(0)];
          }
        }
      });
    }

    // Restaurar RdA activo y cargar sus datos en la UI
    if (s.activeRda != null) {
      activeRda = s.activeRda;
      document.querySelectorAll('.rda-tab').forEach((tab, i) => tab.classList.toggle('active', i === activeRda));
      document.querySelectorAll('.rda-tab-mini').forEach((tab) => tab.classList.toggle('active', parseInt(tab.dataset.rda) - 1 === activeRda));
    }
    // Restaurar criterio activo GLOBAL (compartido recursos/tarea/quiz).
    // Sincroniza los 3 pill groups y los hidden inputs. Sin save (estamos loading).
    if (s.activeCriterio != null) {
      setActiveCriterio(s.activeCriterio, { save: false });
    }
    loadRdaData(activeRda);

    // Restaurar preview de sílabo IA si quedó pendiente (docente cerró popup
    // por error tras generar y aún no aprobó/canceló). Asincrónico, no bloquea.
    loadSyllabusPreview().then(saved => {
      if (saved && (saved.syllabusHtml || saved.bannerHtml || saved.subjectHtml)) {
        try {
          showStep2EditPanel(saved, document.getElementById('btnGenerateAI'));
          showStatus('Restauramos el preview de la última generación con IA. Revisa, edita o aprueba.', 'info');
        } catch (_) { /* panel no disponible, ignorar */ }
      }
    });
  });
}

// Save form on input changes (debounced)
let saveTimeout = null;
document.addEventListener('input', () => {
  clearTimeout(saveTimeout);
  saveTimeout = setTimeout(saveFormState, 500);
});

// Close time pickers on outside click
document.addEventListener('click', (e) => {
  if (!e.target.closest('.time-range-picker')) {
    document.querySelectorAll('.trp-dropdown').forEach(d => d.style.display = 'none');
  }
});

// ============================================================
// GENERATION HELPERS
// ============================================================

let activeProgressStep = null;

function showProgress(current, total, label, step) {
  const s = step || activeProgressStep;
  const wrapper = s ? document.getElementById(`progress${s}`) : null;
  const labelEl = s ? document.getElementById(`progressLabel${s}`) : null;
  const countEl = s ? document.getElementById(`progressCount${s}`) : null;
  const fillEl = s ? document.getElementById(`progressFill${s}`) : null;
  if (!wrapper) return;
  wrapper.style.display = 'block';
  if (labelEl) labelEl.textContent = label;
  if (countEl) countEl.textContent = `${current}/${total}`;
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;
  if (fillEl) fillEl.style.width = pct + '%';
}

function hideProgress(step) {
  const s = step || activeProgressStep;
  const wrapper = s ? document.getElementById(`progress${s}`) : null;
  const fillEl = s ? document.getElementById(`progressFill${s}`) : null;
  if (wrapper) wrapper.style.display = 'none';
  if (fillEl) fillEl.style.width = '0%';
}

function markProgressDone(step) {
  const s = step || activeProgressStep;
  const fillEl = s ? document.getElementById(`progressFill${s}`) : null;
  if (fillEl) { fillEl.style.width = '100%'; fillEl.classList.add('done'); }
}

function saveGenerated(key, data) {
  chrome.storage.local.set({ [`gaula_gen_${key}`]: data });
}

// Bug #12: Grade categories cache with TTL (30 min)
const GRADE_CAT_TTL = 30 * 60 * 1000;

async function getGradeCategoryForRda(rdaIndex) {
  return new Promise(resolve => {
    chrome.storage.local.get('gaula_grade_categories', (result) => {
      const cats = result.gaula_grade_categories || {};
      // Invalidar cache si es más viejo que TTL
      if (cats._ts && (Date.now() - cats._ts) > GRADE_CAT_TTL) {
        chrome.storage.local.remove('gaula_grade_categories');
        resolve(null);
        return;
      }
      resolve(cats[rdaIndex] || null);
    });
  });
}

// Content scripts en orden de carga (mismo que el manifest). Si el sendMessage
// falla por "Receiving end does not exist" (típico tras reload de la extensión
// sin reabrir la pestaña Moodle), los reinyectamos via chrome.scripting y
// reintentamos. El usuario no ve "Recarga la página (F5)".
const GAULA_CONTENT_SCRIPTS_POPUP = [
  'content-scripts/moodle-utils.js',
  'content-scripts/executor.js',
  'content-scripts/template-import.js',
  'content-scripts/resource-upload.js',
  'content-scripts/section-editor.js',
  'content-scripts/assignment-creator.js',
  'content-scripts/quiz-generator.js',
  'content-scripts/banner-editor.js',
  'content-scripts/forum-creator.js',
];

function _gaulaIsNoReceiver(msg) {
  return /Could not establish connection|Receiving end does not exist|message channel closed/i.test(String(msg || ''));
}

async function _gaulaInjectScripts(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: GAULA_CONTENT_SCRIPTS_POPUP });
    return true;
  } catch (e) {
    return false;
  }
}

function sendToContentScript(tabId, message) {
  const sendOnce = () => new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (response && response.ok) resolve(response);
      else reject(new Error(response?.error || 'Error en la operación'));
    });
  });
  return sendOnce().catch(async (e) => {
    if (!_gaulaIsNoReceiver(e.message)) throw e;
    // Auto-inyectar y reintentar — el usuario no ve el F5
    const ok = await _gaulaInjectScripts(tabId);
    if (!ok) throw new Error('No se pudo cargar la extensión en Moodle. Recarga la pestaña.');
    await new Promise(r => setTimeout(r, 250));
    return sendOnce();
  });
}

// ============================================================
// Resolución de sección target (Fix #1: detector tabs)
// ============================================================
// La fórmula legacy `activeRda + 1` falla en cursos con Criterios anidados
// (donde RDA 2 = section 4, no section 2). Consultamos el mapa real del DOM
// y, si es necesario, navegamos la pestaña a la sección correcta antes de operar.

async function getCourseStructure(tabId) {
  try {
    return await sendToContentScript(tabId, { action: 'get_course_structure' });
  } catch (e) {
    return null;
  }
}

// Resuelve el sectionId target dado RDA + Criterio.
// - En aulas FLAT (sin Criterios anidados): siempre usa el sectionId del RDA padre.
// - En aulas ANIDADAS (como curso 960): asume que los criterios son sections
//   consecutivos a partir del RDA padre (ej. RDA 2 sec=4 → Crit 1=4, Crit 2=5, Crit 3=6).
//   El popup solo "ve" los criterios del RDA activo en DOM, así que para los
//   demás RDAs usamos esta convención (que es como Moodle onetopic los numera).
async function resolveSectionId(tabId, activeRda, criterioIdx = 1) {
  // Evaposgrado (Opción A): el dropdown ya resolvió la sección REAL → usar su sectionId.
  if (EVAPOS_SECTIONS && EVAPOS_SECTIONS[activeRda]) {
    return EVAPOS_SECTIONS[activeRda].sectionId;
  }
  const res = await getCourseStructure(tabId);
  const struct = res?.structure;
  if (!struct?.rdas || !struct.rdas[activeRda]) {
    // Fallback legacy: aulas sin onetopic o sin tabs detectables
    return activeRda + 1;
  }
  const rda = struct.rdas[activeRda];
  if (struct.hasNestedCriterios) {
    // Caso anidado: sección = RDA.sectionId + (criterioIdx - 1)
    const offset = Math.max(0, (criterioIdx || 1) - 1);
    return rda.sectionId + offset;
  }
  // FLAT: solo el sectionId del RDA padre
  return rda.sectionId;
}

// Construye la URL de la pestaña para una sección dada (preservando el prefix
// /QUI-202601R/ y demás query params relevantes como id=courseId).
function buildSectionUrl(tabUrl, targetSectionId) {
  const u = new URL(tabUrl);
  u.searchParams.set('section', String(targetSectionId));
  u.hash = '';
  return u.toString();
}

// Wrapper "robusto" para enviar acciones al content script con navegación auto.
// Por qué existe: si chrome.tabs.update se llama desde el popup, el popup puede
// perder foco y morir → la cadena async se trunca. Delegamos al service worker
// (background.js) que persiste a través de cierres de popup.
// Si la pestaña YA está en la sección target, usa sendToContentScript directo (rápido).
async function sendActionWithNav(tabId, targetSectionId, message) {
  const tab = await chrome.tabs.get(tabId);
  if (tab?.url && tab.url.includes('/course/view.php')) {
    const currentSec = new URL(tab.url).searchParams.get('section');
    if (currentSec === String(targetSectionId)) {
      // Ya estamos en la sección correcta, dispatch directo
      return await sendToContentScript(tabId, message);
    }
  }
  // Necesita navegación → delegar al background
  const targetUrl = buildSectionUrl(tab.url, targetSectionId);
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      type: 'NAVIGATE_AND_DISPATCH',
      tabId,
      targetUrl,
      message,
    }, (resp) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (resp && resp.ok) {
        resolve(resp);
      } else {
        reject(new Error(resp?.error || 'Error en NAVIGATE_AND_DISPATCH'));
      }
    });
  });
}

// Compat: prepareTargetSection ahora SOLO resuelve, no navega.
// La navegación la hace sendActionWithNav cuando manda el mensaje.
// criterioIdx default 1 — para uploads sin selector de criterio (videos/PDFs/etc.).
async function prepareTargetSection(tabId, activeRda, criterioIdx = 1) {
  return await resolveSectionId(tabId, activeRda, criterioIdx);
}

// Call backend generate-content Edge Function via background (maneja token y retry)
async function callGenerateContent(action, payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'GENERATE_CONTENT', action, payload }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error('No se pudo conectar con el servicio.'));
        return;
      }
      if (response?.error) {
        reject(new Error(response.error));
      } else {
        resolve(response);
      }
    });
  });
}

function generateYoutubeIframeHTML(url, title) {
  let videoId = '';
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
  if (match) videoId = match[1];
  else videoId = url;
  const embedUrl = `https://www.youtube.com/embed/${videoId}`;
  return `<iframe width="640" height="360" src="${embedUrl}" title="${title}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen=""></iframe>`;
}

function generateGeniallyIframeHTML(url, title) {
  const cleanUrl = url.trim();
  return `<iframe width="640" height="480" src="${cleanUrl}" title="${title}" frameborder="0" allow="autoplay; fullscreen" allowfullscreen="" style="max-width:100%"></iframe>`;
}

// ============================================================
// TEMAS VISUALES (MVP: 6 sencillos + 1 institucional con logo PUCE)
// El tema activo aplica colores al header colapsable y al subrayado de tabs.
// ============================================================
// Logo PUCE oficial con animación SMIL: cada panel cardinal (N/E/S/O) atenúa por turnos.
// Si Moodle filtra <animate>, queda estático sin romper.
// PUCESA logo: misma brújula animada de PUCE pero el texto "PUCESA" como <text>
// (el ancho del viewBox se expande de 169.38 a 220 para acomodar las letras extra).
// Usado SOLO cuando el active tab está en eva.pucesa.edu.ec — Quito sigue usando PUCE_LOGO_SVG.
const PUCESA_LOGO_SVG = '<svg viewBox="0 0 220 64.07" xmlns="http://www.w3.org/2000/svg"><g fill="#00a0dd"><path d="m29.59,6.58c-4.35.41-8.37,1.91-11.81,4.22-.46.31-.91.64-1.35.98l1.66,1.66c.44-.33.9-.65,1.37-.95,2.06-1.33,4.34-2.34,6.77-2.96v14.38s1.16,1.16,1.16,1.16v-15.81c.76-.15,1.54-.27,2.33-.35v18.49s2.33,2.33,2.33,2.33l2.33-2.33V8.9c.79.08,1.56.2,2.33.35v15.81s1.16-1.16,1.16-1.16v-14.38c2.43.63,4.71,1.64,6.77,2.96.47.3.93.62,1.37.95l1.66-1.66c-.44-.34-.89-.66-1.35-.97-3.44-2.31-7.47-3.81-11.81-4.22l-2.45-6.58-2.45,6.58"><animate attributeName="opacity" values="1;0.35;1;1;1;1" dur="4s" repeatCount="indefinite"/></path><path d="m57.5,34.49c-.41,4.35-1.91,8.37-4.22,11.81-.31.46-.64.91-.98,1.35l-1.66-1.66c.33-.44.65-.9.95-1.37,1.33-2.06,2.34-4.34,2.96-6.77h-14.39s-1.16-1.16-1.16-1.16h15.82c.15-.76.27-1.54.35-2.33h-18.49s-2.33-2.33-2.33-2.33l2.33-2.33h18.49c-.08-.79-.2-1.56-.35-2.33h-15.82s1.16-1.16,1.16-1.16h14.39c-.63-2.43-1.64-4.71-2.96-6.77-.3-.47-.62-.93-.95-1.37l1.66-1.66c.34.44.66.89.97,1.35,2.31,3.44,3.81,7.47,4.22,11.81l6.58,2.45-6.58,2.45"><animate attributeName="opacity" values="1;1;0.35;1;1;1" dur="4s" repeatCount="indefinite"/></path><path d="m34.49,57.5c4.35-.41,8.37-1.91,11.81-4.22.46-.31.91-.64,1.35-.98l-1.66-1.66c-.44.33-.9.65-1.37.95-2.06,1.33-4.34,2.34-6.77,2.96v-14.38s-1.16-1.16-1.16-1.16v15.81c-.76.15-1.54.27-2.33.35v-18.49s-2.33-2.33-2.33-2.33l-2.33,2.33v18.49c-.79-.08-1.56-.2-2.33-.35v-15.81s-1.16,1.16-1.16,1.16v14.38c-2.43-.63-4.71-1.64-6.77-2.96-.47-.3-.93-.62-1.37-.95l-1.66,1.66c.44.34.89.66,1.35.97,3.44,2.31,7.47,3.81,11.81,4.22l2.45,6.58,2.45-6.58"><animate attributeName="opacity" values="1;1;1;0.35;1;1" dur="4s" repeatCount="indefinite"/></path><path d="m6.58,34.49c.41,4.35,1.91,8.37,4.22,11.81.31.46.64.91.98,1.35l1.66-1.66c-.33-.44-.65-.9-.95-1.37-1.33-2.06-2.34-4.34-2.96-6.77h14.39s1.16-1.16,1.16-1.16h-15.82c-.15-.76-.27-1.54-.35-2.33h18.49s2.33-2.33,2.33-2.33l-2.33-2.33H8.9c.08-.79.2-1.56.35-2.33h15.82s-1.16-1.16-1.16-1.16h-14.39c.63-2.43,1.64-4.71,2.96-6.77.3-.47.62-.93.95-1.37l-1.66-1.66c-.34.44-.66.89-.97,1.35-2.31,3.44-3.81,7.47-4.22,11.81l-6.58,2.45,6.58,2.45"><animate attributeName="opacity" values="1;1;1;1;0.35;1" dur="4s" repeatCount="indefinite"/></path></g><text x="68" y="48" fill="#fff" font-family="Helvetica, Arial, sans-serif" font-weight="900" font-size="36" letter-spacing="-1">PUCESA</text></svg>';

const PUCE_LOGO_SVG = '<svg viewBox="0 0 169.38 64.07" xmlns="http://www.w3.org/2000/svg"><g fill="#00a0dd"><path d="m29.59,6.58c-4.35.41-8.37,1.91-11.81,4.22-.46.31-.91.64-1.35.98l1.66,1.66c.44-.33.9-.65,1.37-.95,2.06-1.33,4.34-2.34,6.77-2.96v14.38s1.16,1.16,1.16,1.16v-15.81c.76-.15,1.54-.27,2.33-.35v18.49s2.33,2.33,2.33,2.33l2.33-2.33V8.9c.79.08,1.56.2,2.33.35v15.81s1.16-1.16,1.16-1.16v-14.38c2.43.63,4.71,1.64,6.77,2.96.47.3.93.62,1.37.95l1.66-1.66c-.44-.34-.89-.66-1.35-.97-3.44-2.31-7.47-3.81-11.81-4.22l-2.45-6.58-2.45,6.58"><animate attributeName="opacity" values="1;0.35;1;1;1;1" dur="4s" repeatCount="indefinite"/></path><path d="m57.5,34.49c-.41,4.35-1.91,8.37-4.22,11.81-.31.46-.64.91-.98,1.35l-1.66-1.66c.33-.44.65-.9.95-1.37,1.33-2.06,2.34-4.34,2.96-6.77h-14.39s-1.16-1.16-1.16-1.16h15.82c.15-.76.27-1.54.35-2.33h-18.49s-2.33-2.33-2.33-2.33l2.33-2.33h18.49c-.08-.79-.2-1.56-.35-2.33h-15.82s1.16-1.16,1.16-1.16h14.39c-.63-2.43-1.64-4.71-2.96-6.77-.3-.47-.62-.93-.95-1.37l1.66-1.66c.34.44.66.89.97,1.35,2.31,3.44,3.81,7.47,4.22,11.81l6.58,2.45-6.58,2.45"><animate attributeName="opacity" values="1;1;0.35;1;1;1" dur="4s" repeatCount="indefinite"/></path><path d="m34.49,57.5c4.35-.41,8.37-1.91,11.81-4.22.46-.31.91-.64,1.35-.98l-1.66-1.66c-.44.33-.9.65-1.37.95-2.06,1.33-4.34,2.34-6.77,2.96v-14.38s-1.16-1.16-1.16-1.16v15.81c-.76.15-1.54.27-2.33.35v-18.49s-2.33-2.33-2.33-2.33l-2.33,2.33v18.49c-.79-.08-1.56-.2-2.33-.35v-15.81s-1.16,1.16-1.16,1.16v14.38c-2.43-.63-4.71-1.64-6.77-2.96-.47-.3-.93-.62-1.37-.95l-1.66,1.66c.44.34.89.66,1.35.97,3.44,2.31,7.47,3.81,11.81,4.22l2.45,6.58,2.45-6.58"><animate attributeName="opacity" values="1;1;1;0.35;1;1" dur="4s" repeatCount="indefinite"/></path><path d="m6.58,34.49c.41,4.35,1.91,8.37,4.22,11.81.31.46.64.91.98,1.35l1.66-1.66c-.33-.44-.65-.9-.95-1.37-1.33-2.06-2.34-4.34-2.96-6.77h14.39s1.16-1.16,1.16-1.16h-15.82c-.15-.76-.27-1.54-.35-2.33h18.49s2.33-2.33,2.33-2.33l-2.33-2.33H8.9c.08-.79.2-1.56.35-2.33h15.82s-1.16-1.16-1.16-1.16h-14.39c.63-2.43,1.64-4.71,2.96-6.77.3-.47.62-.93.95-1.37l-1.66-1.66c-.34.44-.66.89-.97,1.35-2.31,3.44-3.81,7.47-4.22,11.81l-6.58,2.45,6.58,2.45"><animate attributeName="opacity" values="1;1;1;1;0.35;1" dur="4s" repeatCount="indefinite"/></path></g><g fill="#fff"><path d="m81.03,16.41c6.84,0,11.15,4.27,11.15,11.02s-4.31,11.06-11.15,11.06h-5.31v8.28c0,.52-.26.78-.74.78h-5.49c-.48,0-.74-.26-.74-.78v-29.58c0-.52.26-.78.74-.78h11.54Zm-.96,15.6c3.31,0,4.92-1.48,4.92-4.57s-1.61-4.57-4.92-4.57h-4.36v9.15h4.36Z"/><path d="m107.04,48.08c-7.67,0-12.11-4.36-12.11-11.98v-18.91c0-.52.26-.78.78-.78h5.53c.48,0,.78.26.78.78v18.91c0,3.53,1.79,5.36,5.01,5.36s5.1-1.83,5.1-5.36v-18.91c0-.52.26-.78.74-.78h5.58c.48,0,.74.26.74.78v18.91c0,7.62-4.49,11.98-12.15,11.98Z"/><path d="m135.83,48.17c-7.67,0-12.72-4.05-12.72-11.63v-9.1c0-7.58,5.1-11.59,12.59-11.59,3.49,0,6.84,1.05,9.32,2.79.44.26.48.61.22,1l-2.74,4.18c-.3.44-.65.48-1.09.22-1.61-1.05-3.66-1.57-5.58-1.57-3.66,0-5.62,2.09-5.62,5.23v8.54c0,3.35,2.09,5.27,5.66,5.27,2.18,0,4.31-.65,6.06-1.83.44-.3.78-.26,1.05.17l2.79,4.18c.26.39.26.74-.04.96-2.53,1.87-5.84,3.18-9.89,3.18Z"/><path d="m155.66,41.24h12.94c.48,0,.78.26.78.74v4.79c0,.52-.3.78-.78.78h-19.17c-.52,0-.78-.26-.78-.78v-29.58c0-.52.26-.78.78-.78h18.47c.52,0,.78.26.78.78v4.79c0,.48-.26.74-.78.74h-12.24v5.97h10.8c.52,0,.78.26.78.74v4.71c0,.48-.26.74-.78.74h-10.8v6.36Z"/></g></svg>';

const THEMES = [
  // ─── Sencillos (colores sólidos por área amplia) ──────────────
  { id: 'azul-institucional', group: 'sencillos', name: 'Azul institucional', headerBg: '#1a237e', activeColor: '#2563eb' },
  { id: 'verde-naturaleza',   group: 'sencillos', name: 'Verde naturaleza',   headerBg: '#166534', activeColor: '#16a34a' },
  { id: 'morado-humanidades', group: 'sencillos', name: 'Morado humanidades', headerBg: '#581c87', activeColor: '#9333ea' },
  { id: 'naranja-ingenieria', group: 'sencillos', name: 'Naranja ingeniería', headerBg: '#9a3412', activeColor: '#ea580c' },
  { id: 'rojo-medicina',      group: 'sencillos', name: 'Rojo medicina',      headerBg: '#7f1d1d', activeColor: '#dc2626' },
  { id: 'turquesa-moderno',   group: 'sencillos', name: 'Turquesa moderno',   headerBg: '#134e4a', activeColor: '#0d9488' },

  // ─── Decorativos (estéticos generales, no por carrera) ────────
  { id: 'olas-marinas',       group: 'decorativos', name: '🌊 Olas marinas',       headerBg: '#1e40af', activeColor: '#06b6d4' },
  { id: 'destellos-dorados',  group: 'decorativos', name: '✨ Destellos dorados',  headerBg: '#1e1b4b', activeColor: '#fbbf24' },
  { id: 'aurora-animada',     group: 'decorativos', name: '🌌 Aurora animada',     headerBg: '#7c3aed', activeColor: '#ec4899' },
  { id: 'geometrico-cyber',   group: 'decorativos', name: '🔷 Geométrico cyber',   headerBg: '#0f172a', activeColor: '#10b981' },
  { id: 'sakura-japones',     group: 'decorativos', name: '🌸 Sakura japonés',     headerBg: '#831843', activeColor: '#fce7f3' },
  { id: 'montanas-alpinas',   group: 'decorativos', name: '🏔️ Montañas alpinas',  headerBg: '#1e3a8a', activeColor: '#ffffff' },
  { id: 'hojas-tropicales',   group: 'decorativos', name: '🌿 Hojas tropicales',   headerBg: '#14532d', activeColor: '#fde047' },
  { id: 'constelacion',       group: 'decorativos', name: '💫 Constelación',       headerBg: '#0c0a1e', activeColor: '#fef3c7' },
  { id: 'llamas-suaves',      group: 'decorativos', name: '🔥 Llamas suaves',      headerBg: '#dc2626', activeColor: '#f59e0b' },

  // ─── Carreras (por disciplina, set principal) ─────────────────
  { id: 'medicina-ecg',          group: 'carreras', name: '❤️ Medicina — ECG',           headerBg: '#7f1d1d', activeColor: '#fee2e2' },
  { id: 'laboratorio-probetas',  group: 'carreras', name: '🧪 Laboratorio — Probetas',   headerBg: '#1e3a8a', activeColor: '#06b6d4' },
  { id: 'matematicas-simbolos',  group: 'carreras', name: '📐 Matemáticas — Símbolos',   headerBg: '#1e1b4b', activeColor: '#a78bfa' },
  { id: 'derecho-balanza',       group: 'carreras', name: '⚖️ Derecho — Balanza',        headerBg: '#422006', activeColor: '#fbbf24' },
  { id: 'arte-paleta',           group: 'carreras', name: '🎨 Arte — Paleta de pintor',  headerBg: '#18181b', activeColor: '#ec4899' },
  { id: 'arquitectura-skyline',  group: 'carreras', name: '🏙️ Arquitectura — Skyline',   headerBg: '#292524', activeColor: '#fde047' },
  { id: 'musica-equalizer',      group: 'carreras', name: '🎵 Música — Equalizer',       headerBg: '#1f2937', activeColor: '#34d399' },
  { id: 'fisica-atomos',         group: 'carreras', name: '⚛️ Física / Química — Átomos', headerBg: '#0c4a6e', activeColor: '#fbbf24' },
  { id: 'computacion-matrix',    group: 'carreras', name: '💻 Computación — Matrix',     headerBg: '#022c22', activeColor: '#10b981' },
  { id: 'geografia-vuelo',       group: 'carreras', name: '✈️ Geografía / Turismo',      headerBg: '#1e40af', activeColor: '#fbbf24' },

  // ─── Carreras alternativas (mismos disciplinas, otra metáfora) ─
  { id: 'medicina-adn',          group: 'carreras-alt', name: '🧬 Medicina alt — ADN',        headerBg: '#7f1d1d', activeColor: '#f87171' },
  { id: 'investigacion-moleculas', group: 'carreras-alt', name: '⚗️ Investigación alt — Moléculas', headerBg: '#1e3a8a', activeColor: '#22d3ee' },
  { id: 'matematicas-graficas',  group: 'carreras-alt', name: '📊 Matemáticas alt — Gráficas', headerBg: '#1e1b4b', activeColor: '#c4b5fd' },
  { id: 'derecho-martillo',      group: 'carreras-alt', name: '🔨 Derecho alt — Martillo',     headerBg: '#422006', activeColor: '#fbbf24' },
  { id: 'arte-lienzo',           group: 'carreras-alt', name: '🖼️ Arte alt — Lienzo',          headerBg: '#18181b', activeColor: '#f472b6' },
  { id: 'arquitectura-plano',    group: 'carreras-alt', name: '📐 Arquitectura alt — Plano',  headerBg: '#292524', activeColor: '#fcd34d' },
  { id: 'musica-partitura',      group: 'carreras-alt', name: '🎼 Música alt — Partitura',     headerBg: '#1f2937', activeColor: '#6ee7b7' },
  { id: 'fisica-pendulos',       group: 'carreras-alt', name: '🕰️ Física alt — Péndulos',     headerBg: '#0c4a6e', activeColor: '#fde68a' },
  { id: 'computacion-terminal',  group: 'carreras-alt', name: '⌨️ Computación alt — Terminal', headerBg: '#022c22', activeColor: '#34d399' },
  { id: 'geografia-brujula',     group: 'carreras-alt', name: '🧭 Geografía alt — Brújula',    headerBg: '#1e40af', activeColor: '#fcd34d' },

  // ─── Carreras PUCE (específicas de la oferta académica) ───────
  { id: 'enfermeria',            group: 'carreras-puce', name: '⚕️ Enfermería / Fisioterapia / Lab', headerBg: '#7f1d1d', activeColor: '#fecaca' },
  { id: 'veterinaria',           group: 'carreras-puce', name: '🐾 Medicina Veterinaria',       headerBg: '#365314', activeColor: '#bef264' },
  { id: 'nutricion',             group: 'carreras-puce', name: '🍎 Nutrición',                  headerBg: '#14532d', activeColor: '#86efac' },
  { id: 'odontologia',           group: 'carreras-puce', name: '🦷 Odontología',                headerBg: '#0e7490', activeColor: '#67e8f9' },
  { id: 'psicologia',            group: 'carreras-puce', name: '🧠 Psicología',                 headerBg: '#581c87', activeColor: '#d8b4fe' },
  { id: 'diseno-canvas',         group: 'carreras-puce', name: '🖌️ Diseño',                     headerBg: '#831843', activeColor: '#f9a8d4' },
  { id: 'ing-civil-grua',        group: 'carreras-puce', name: '🏗️ Ingeniería Civil',           headerBg: '#78350f', activeColor: '#fcd34d' },
  { id: 'antropologia-historia', group: 'carreras-puce', name: '⏳ Antropología / Historia',    headerBg: '#451a03', activeColor: '#fbbf24' },
  { id: 'negocios-finanzas',     group: 'carreras-puce', name: '📈 Administración / Finanzas',  headerBg: '#064e3b', activeColor: '#6ee7b7' },
  { id: 'marketing-negocios-internacionales', group: 'carreras-puce', name: '📣 Marketing / Neg. Internacionales', headerBg: '#7c2d12', activeColor: '#fdba74' },
  { id: 'comunicacion',          group: 'carreras-puce', name: '🎙️ Comunicación / Lenguas',     headerBg: '#1e293b', activeColor: '#7dd3fc' },
  { id: 'educacion',             group: 'carreras-puce', name: '🍎 Educación / Pedagogía',      headerBg: '#14532d', activeColor: '#fde68a' },
  { id: 'ciencias-sociales',     group: 'carreras-puce', name: '👥 Ciencias Sociales / RR.II.', headerBg: '#1e3a8a', activeColor: '#93c5fd' },
  { id: 'ciencia-de-datos',      group: 'carreras-puce', name: '📊 Ciencia de Datos / Biomédicas', headerBg: '#1e1b4b', activeColor: '#a5b4fc' },
  { id: 'linguistica-literatura', group: 'carreras-puce', name: '📚 Lingüística / Literatura',   headerBg: '#4c1d95', activeColor: '#c4b5fd' },
  { id: 'teologia-filosofia',    group: 'carreras-puce', name: '✝️ Teología / Filosofía',       headerBg: '#7c2d12', activeColor: '#fbbf24' },

  // ─── Institucional (PUCE con logo oficial animado) ────────────
  { id: 'puce-oficial',       group: 'institucional', name: '🏛️ PUCE Oficial (logo)', headerBg: '#164284', activeColor: '#00a0dd', useInstitutionalLogo: true }
];

// Etiquetas legibles de cada grupo para el optgroup del <select>.
const THEME_GROUP_LABELS = {
  'sencillos':       'Sencillos',
  'decorativos':     'Decorativos',
  'carreras':        'Por carrera',
  'carreras-alt':    'Por carrera (alternativas)',
  'carreras-puce':   'Carreras PUCE',
  'institucional':   'Institucional'
};
const DEFAULT_THEME_ID = 'azul-institucional';
let _activeThemeId = DEFAULT_THEME_ID;

function getActiveTheme() {
  return THEMES.find(t => t.id === _activeThemeId) || THEMES[0];
}
function setActiveTheme(id) {
  if (!THEMES.find(t => t.id === id)) return;
  _activeThemeId = id;
  try { chrome.storage.local.set({ gaula_active_theme: id }); } catch (_) {}
  applyThemeToPopupUI();
  updateThemePreview();
}
function loadActiveTheme() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get('gaula_active_theme', r => {
        if (r.gaula_active_theme && THEMES.find(t => t.id === r.gaula_active_theme)) {
          _activeThemeId = r.gaula_active_theme;
        }
        applyThemeToPopupUI();
        resolve(_activeThemeId);
      });
    } catch (_) { applyThemeToPopupUI(); resolve(_activeThemeId); }
  });
}

// Helper: detecta si un valor CSS de background corresponde al azul institucional
// hardcoded (#1a237e). El browser puede serializarlo como rgb(26, 35, 126) tras
// editar en contenteditable, así que aceptamos ambos.
function _isInstitutionalBlue(bg) {
  if (!bg) return false;
  const v = bg.toLowerCase().replace(/\s+/g, '');
  return v.includes('#1a237e') || v.includes('rgb(26,35,126)');
}
function _parseStylesToObj(styleStr) {
  const o = {};
  (styleStr || '').split(';').forEach(p => {
    const idx = p.indexOf(':');
    if (idx > 0) {
      const k = p.slice(0, idx).trim().toLowerCase();
      const v = p.slice(idx + 1).trim();
      if (k) o[k] = v;
    }
  });
  return o;
}
function _stringifyStyles(obj) {
  return Object.entries(obj).map(([k, v]) => `${k}:${v}`).join(';');
}

// Reescribe los banners + tabla del horario para usar tema activo. Robusto
// frente a normalización del browser (rgb() vs hex, espacios, orden).
function applyThemeToCardBanner(html) {
  if (!html) return html;
  const t = getActiveTheme();
  const themeBg = t.headerBg;
  const themeAccent = t.activeColor || themeBg;
  const iconSvg = t.iconSvg ||
    (typeof THEME_ICONS !== 'undefined' && THEME_ICONS[t.id]) || '';

  // Parse en doc detached
  const parser = new DOMParser();
  const doc = parser.parseFromString(`<div id="gaularoot">${html}</div>`, 'text/html');
  const root = doc.getElementById('gaularoot');
  if (!root) return html;

  // BANNERS (header coloreado de cada card)
  root.querySelectorAll('div').forEach(div => {
    const style = _parseStylesToObj(div.getAttribute('style'));
    const isPrevThemed = div.hasAttribute('data-gaula-themed-banner');
    const hasRoundedTop = (style['border-radius'] || '').replace(/\s+/g, ' ').match(/12px\s+12px\s+0\s*(?:px\s*)?0/);
    const hasBlueBg = _isInstitutionalBlue(style['background']);
    if (!hasRoundedTop) return;
    if (!hasBlueBg && !isPrevThemed) return;

    // Limpiar capas SVG previas
    div.querySelectorAll('[data-gaula-svg-layer]').forEach(el => el.remove());

    // Aplicar estilos
    style['position'] = 'relative';
    style['overflow'] = 'hidden';
    style['isolation'] = 'isolate';
    style['background'] = themeBg;
    div.setAttribute('style', _stringifyStyles(style));
    div.setAttribute('data-gaula-themed-banner', '1');

    // Inyectar SVG layer (z-index:-1 lo deja detrás del texto)
    if (iconSvg) {
      const layer = doc.createElement('div');
      layer.setAttribute('data-gaula-svg-layer', '1');
      layer.setAttribute('style', 'position:absolute;inset:0;z-index:-1;pointer-events:none');
      layer.innerHTML = iconSvg;
      div.insertBefore(layer, div.firstChild);
    }
  });

  // Recolorear TODO elemento con background #1a237e o #1565c0 (botones, celdas, tabla del horario, etc.)
  // #1a237e (azul oscuro institucional) → theme.headerBg
  // #1565c0 (azul medio accent) → theme.activeColor
  root.querySelectorAll('*').forEach(el => {
    const style = _parseStylesToObj(el.getAttribute('style'));
    let changed = false;
    if (_isInstitutionalBlue(style['background'])) {
      style['background'] = themeBg;
      changed = true;
    } else {
      const bg = (style['background'] || '').toLowerCase().replace(/\s+/g, '');
      if (bg.includes('#1565c0') || bg.includes('rgb(21,101,192)')) {
        style['background'] = themeAccent;
        changed = true;
      }
    }
    // Border que usa los azules institucionales
    if (style['border'] && /#(1a237e|1565c0|1255a1)/i.test(style['border'])) {
      style['border'] = style['border']
        .replace(/#1a237e/gi, themeBg)
        .replace(/#1565c0/gi, themeAccent)
        .replace(/#1255a1/gi, themeAccent);
      changed = true;
    }
    // Box-shadow usando rgba del accent azul (21,101,192) → mantener alpha, cambiar color
    if (style['box-shadow'] && /rgba\s*\(\s*21\s*,\s*101\s*,\s*192/i.test(style['box-shadow'])) {
      // Reemplazar el rgba por una sombra neutra que funciona con cualquier tema
      style['box-shadow'] = style['box-shadow'].replace(/rgba\(\s*21\s*,\s*101\s*,\s*192\s*,\s*([\d.]+)\s*\)/gi, 'rgba(0,0,0,0.18)');
      changed = true;
    }
    if (changed) el.setAttribute('style', _stringifyStyles(style));
  });

  return root.innerHTML;
}

// Banner grande (el del header con la imagen Habitat) → color del tema + iconSvg.
function applyThemeToBigBanner(html) {
  if (!html) return html;
  const t = getActiveTheme();
  const themeBg = t.headerBg;
  const iconSvg = t.iconSvg ||
    (typeof THEME_ICONS !== 'undefined' && THEME_ICONS[t.id]) || '';
  const parser = new DOMParser();
  const doc = parser.parseFromString(`<div id="gaularoot">${html}</div>`, 'text/html');
  const root = doc.getElementById('gaularoot');
  if (!root) return html;

  const banner = root.querySelector('.bannerfloat');
  if (!banner) return html;
  // Limpiar layer SVG e logo previos
  banner.querySelectorAll('[data-gaula-bigbanner-svg-layer], [data-gaula-bigbanner-puce-logo]').forEach(el => el.remove());
  const style = _parseStylesToObj(banner.getAttribute('style'));
  delete style['background-image'];
  style['position'] = 'relative';
  style['overflow'] = 'hidden';
  style['background'] = themeBg;
  // Forzar layout flex con avatar+info pegados a la izquierda
  // (sin esto el theme CSS de PUCE centra los hijos y el edificio queda encima del SVG temático).
  style['display'] = 'flex';
  style['align-items'] = 'center';
  style['justify-content'] = 'flex-start';
  style['gap'] = '20px';
  style['min-height'] = '180px';
  banner.setAttribute('style', _stringifyStyles(style));
  banner.setAttribute('data-gaula-themed-big-banner', '1');

  // Pinear avatar a la izquierda — width fijo + z-index sobre el SVG layer.
  const avatar = banner.querySelector('.avatar');
  let avatarGotThemeIcon = false;
  if (avatar) {
    const aStyle = _parseStylesToObj(avatar.getAttribute('style'));
    aStyle['position'] = 'relative';
    aStyle['z-index'] = '1';
    aStyle['flex-shrink'] = '0';
    aStyle['margin-left'] = '16px';
    aStyle['width'] = '160px';
    aStyle['height'] = 'auto';
    avatar.setAttribute('style', _stringifyStyles(aStyle));
    // Si el tema tiene arte propio (THEME_ICONS), REEMPLAZA el edificio genérico por
    // el ícono del tema (p.ej. la brújula). Así el banner refleja el tema elegido.
    // Los temas SIN arte conservan el edificio (comportamiento anterior).
    if (iconSvg) {
      const themeArt = iconSvg.replace(/<svg\b([^>]*)>/i, (m, attrs) => {
        const cleaned = attrs.replace(/\s(width|height|style)="[^"]*"/gi, '');
        return `<svg${cleaned} preserveAspectRatio="xMidYMid meet" style="width:100%;height:100%">`;
      });
      avatar.innerHTML = `<div style="width:150px;height:150px;display:flex;align-items:center;justify-content:center">${themeArt}</div>`;
      avatarGotThemeIcon = true;
    }
  }
  // Info text (FISIOTERAPIA / BIOFISICA / Tutor) — también encima del SVG, no centrado
  const info = banner.querySelector('.info');
  if (info) {
    const iStyle = _parseStylesToObj(info.getAttribute('style'));
    iStyle['position'] = 'relative';
    iStyle['z-index'] = '1';
    iStyle['flex-shrink'] = '0';
    info.setAttribute('style', _stringifyStyles(iStyle));
  }

  if (iconSvg && !avatarGotThemeIcon) {
    // Fallback (banner sin .avatar): el arte del tema va como capa central tenue.
    // Cuando hay avatar, el arte ya reemplazó al edificio arriba (más prominente).
    const layer = doc.createElement('div');
    layer.setAttribute('data-gaula-bigbanner-svg-layer', '1');
    // Gap a la izquierda (480px) para avatar + info text + margin.
    // Gap a la derecha (170px) para el logo PUCE animado.
    // El theme SVG queda en la franja central libre.
    layer.setAttribute('style', 'position:absolute;top:0;left:480px;right:170px;bottom:0;z-index:0;pointer-events:none;opacity:0.75');
    const adjustedSvg = iconSvg.replace(
      /<svg[^>]*style="[^"]*"/,
      m => m.replace(/style="[^"]*"/, 'style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none"')
    );
    layer.innerHTML = adjustedSvg;
    banner.insertBefore(layer, banner.firstChild);
  }
  // Logo institucional animado mediano centrado verticalmente en la franja derecha.
  // Cambia entre PUCE y PUCESA según el tenant del active tab.
  const pucePanel = doc.createElement('div');
  pucePanel.setAttribute('data-gaula-bigbanner-puce-logo', '1');
  pucePanel.setAttribute('style', 'position:absolute;right:24px;top:50%;transform:translateY(-50%);z-index:2;pointer-events:none');
  pucePanel.innerHTML = getInstitutionalLogoSvg().replace('<svg ', '<svg style="height:62px;width:auto" ');
  banner.appendChild(pucePanel);
  return root.innerHTML;
}

// Tenant detection (Quito vs Ambato) — cached desde el active tab al cargar el popup.
// Se usa para elegir el logo institucional correcto (PUCE vs PUCESA) en los wrappers.
let _gaulaTenant = 'quito'; // default seguro
function getInstitutionalLogoSvg() {
  return _gaulaTenant === 'ambato' ? PUCESA_LOGO_SVG : PUCE_LOGO_SVG;
}
async function detectTenant() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const url = tab?.url || '';
    if (url.includes('eva.pucesa.edu.ec')) _gaulaTenant = 'ambato';
    // Quito: campus principal + demás campus virtuales que administra Quito
    // (evaposgrado, evaenlinea, aulasvirtuales → posgrados/oferta nacional/rutas).
    else if (/(?:eva|evaposgrado|evaenlinea|aulasvirtuales)\.puce\.edu\.ec/.test(url)) _gaulaTenant = 'quito';
    // Si no es ninguno de los dos, conserva el último valor o default 'quito'
  } catch (_) {}
}

// Pinta las CSS custom props del tema activo en <body> para que el popup
// refleje en su UI (header, botones, pills, step-numbers) el tema elegido.
function applyThemeToPopupUI() {
  const t = getActiveTheme();
  const root = document.body || document.documentElement;
  if (!root) return;
  root.style.setProperty('--t-bg', t.headerBg);
  root.style.setProperty('--t-accent', t.activeColor || t.headerBg);
}

function wrapCollapsible(title, innerHtml) {
  const theme = getActiveTheme();
  const id = 'gaula_' + Math.random().toString(36).substr(2, 8);
  const chevronId = id + '_chev';
  // iconSvg: layer animado de fondo del header (carreras con SMIL).
  // logoSvg: logo institucional al lado del título (PUCE Oficial).
  // Resuelve iconSvg desde theme.iconSvg directo o (más común) THEME_ICONS[theme.id].
  // Los SVGs en THEME_ICONS ya traen position:absolute; con left/right/top/height
  // calibrados para un header tipo ~600x60, así que se usan tal cual.
  const iconSvg = theme.iconSvg ||
    (typeof THEME_ICONS !== 'undefined' && THEME_ICONS[theme.id]) || '';
  const iconLayer = iconSvg || '';
  // logoSvg en el header izquierdo: si theme.useInstitutionalLogo (PUCE Oficial)
  // → usa el logo del tenant actual (PUCE o PUCESA). Otros temas dejan el header sin logo.
  const themeLogoSvg = theme.useInstitutionalLogo ? getInstitutionalLogoSvg() : theme.logoSvg;
  const headerInner = themeLogoSvg
    ? `<span style="position:relative;z-index:1;display:inline-flex;align-items:center;gap:14px;font-weight:bold;font-size:19px">
         <span style="display:inline-flex;height:34px">${themeLogoSvg.replace('<svg ', '<svg style="height:34px;width:auto" ')}</span>
         ${title}
       </span>`
    : `<span style="position:relative;z-index:1;font-weight:bold;font-size:19px">${title}</span>`;
  // Click toggle: usamos IDs específicos (no querySelector con :last-child) porque
  // el logo SVG agrega <span> hijos al header y :last-child elegía el span equivocado,
  // sobrescribiendo el SVG con el caracter del chevron al compactar.
  // Onclick: toggle de la descripción + (si existe) el árbol de archivos de la carpeta.
  // Scope: closest('.activity') si estamos en course page inline, sino el documento entero
  // (sirve para folder view page donde no hay wrapper .activity).
  const toggleJs = `var c=document.getElementById('${id}');var b=document.getElementById('${chevronId}');var scope=this.closest('.activity')||document;var ft=scope.querySelector('.foldertree, .singlebutton');var open=c.style.display!=='none';if(open){c.style.display='none';b.textContent='▼';if(ft)ft.style.display='none';}else{c.style.display='block';b.textContent='▲';if(ft)ft.style.display='';}`;
  // Logo institucional a la derecha (siempre — refuerza branding sede actual).
  // Si el tema ya tiene logoSvg a la izquierda (PUCE Oficial), no lo duplicamos.
  const rightBrand = themeLogoSvg
    ? ''
    : `<span style="display:inline-flex;height:32px;flex-shrink:0;opacity:0.95">${getInstitutionalLogoSvg().replace('<svg ', '<svg style="height:32px;width:auto" ')}</span>`;
  return `<div style="margin:10px auto;width:100%;max-width:100%;border:1px solid #e0e0e0;border-radius:10px;overflow:hidden">
  <div onclick="${toggleJs}" style="position:relative;overflow:hidden;display:flex;justify-content:space-between;align-items:center;padding:20px 24px;background:${theme.headerBg};color:#fff;cursor:pointer;user-select:none">
    ${iconLayer}
    ${headerInner}
    <span style="position:relative;z-index:1;display:inline-flex;align-items:center;gap:16px;flex-shrink:0">
      ${rightBrand}
      <span id="${chevronId}" style="font-size:16px">▲</span>
    </span>
  </div>
  <div id="${id}" style="display:block;padding:0">
    ${innerHtml}
  </div>
</div>`;
}

function generateTabbedHTML(tabs, groupId) {
  const theme = getActiveTheme();
  groupId = groupId + '_' + Math.random().toString(36).substr(2, 6);
  const tabInputsAndLabels = tabs.map((t, i) =>
    `<input type="radio" name="${groupId}" id="${groupId}_${i}" ${i === 0 ? 'checked' : ''}><label for="${groupId}_${i}">${t.label}</label>`
  ).join('');
  const tabContents = tabs.map((t, i) =>
    `<div class="gtc gtc-${i}">${t.content}</div>`
  ).join('\n');
  let checkedRules = '';
  tabs.forEach((_, i) => {
    checkedRules += `.gt-${groupId} #${groupId}_${i}:checked + label { color:#1e293b; border-bottom-color:${theme.activeColor}; }\n`;
    checkedRules += `.gt-${groupId} #${groupId}_${i}:checked ~ .gtc-${i} { display:block !important; }\n`;
  });
  return `<style>
.gt-${groupId} { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; }
.gt-${groupId} input[type="radio"] { position:absolute; opacity:0; pointer-events:none; }
.gt-${groupId} > label { display:inline-block; padding:10px 20px; font-weight:600; font-size:14px; color:#94a3b8; cursor:pointer; transition:all 0.2s; border-bottom:2px solid transparent; margin-bottom:0; }
.gt-${groupId} > label:hover { color:#475569; }
.gt-${groupId} > .gtc { display:none; padding:20px 16px; border-top:2px solid #e2e8f0; }
${checkedRules}
</style>
<div class="gt-${groupId}">
${tabInputsAndLabels}
${tabContents}
</div>`;
}

// Render del preview del tema seleccionado en el popup (mini bloque visual).
function updateThemePreview() {
  const el = document.getElementById('themePreview');
  if (!el) return;
  const t = getActiveTheme();
  // PUCE Oficial usa el logo institucional del tenant actual (PUCE o PUCESA).
  const themeLogo = t.useInstitutionalLogo ? getInstitutionalLogoSvg() : t.logoSvg;
  const logoMini = themeLogo
    ? themeLogo.replace('<svg ', '<svg style="height:18px;width:auto;vertical-align:middle" ')
    : '';
  // iconSvg de fondo (carreras con SMIL): mismo mecanismo que wrapCollapsible.
  const iconSvg = t.iconSvg ||
    (typeof THEME_ICONS !== 'undefined' && THEME_ICONS[t.id]) || '';
  // Mini logo institucional a la derecha (sigue mostrando branding del tenant actual).
  const pucePreviewMini = themeLogo
    ? ''
    : getInstitutionalLogoSvg().replace('<svg ', '<svg style="height:16px;width:auto;vertical-align:middle" ');
  el.innerHTML = `
    <div style="position:relative;overflow:hidden;background:${t.headerBg};color:#fff;padding:8px 12px;display:flex;justify-content:space-between;align-items:center;font-size:12px">
      ${iconSvg}
      <span style="position:relative;z-index:1;display:inline-flex;align-items:center;gap:8px;font-weight:bold">${logoMini}${themeLogo ? '' : '👁️ Previsualización'}</span>
      <span style="position:relative;z-index:1;display:inline-flex;align-items:center;gap:8px;flex-shrink:0">${pucePreviewMini}<span style="font-size:11px">▲</span></span>
    </div>
    <div style="display:flex;padding:6px 10px;background:#fff;border-top:2px solid #e2e8f0;font-size:11px;gap:14px">
      <span style="color:#1e293b;font-weight:600;border-bottom:2px solid ${t.activeColor};padding-bottom:3px">Pestaña 1</span>
      <span style="color:#94a3b8">Pestaña 2</span>
      <span style="color:#94a3b8">Pestaña 3</span>
    </div>
    <div style="padding:4px 10px;background:#f8fafc;font-size:10px;color:#94a3b8;text-align:center;font-style:italic">Ejemplo — así se verá el tema en tus aulas</div>`;
}

function initThemeSelector() {
  const sel = document.getElementById('themeSelector');
  if (!sel) return;
  // Construir <optgroup>s dinámicamente desde THEMES preservando el orden
  // de aparición de cada `group` en el array (orden de declaración = orden visual).
  const groupOrder = [];
  const byGroup = {};
  THEMES.forEach(t => {
    if (!byGroup[t.group]) { byGroup[t.group] = []; groupOrder.push(t.group); }
    byGroup[t.group].push(t);
  });
  sel.innerHTML = groupOrder.map(g => {
    const label = THEME_GROUP_LABELS[g] || g;
    const opts = byGroup[g].map(t => `<option value="${t.id}">${t.name}</option>`).join('');
    return `<optgroup label="${label}">${opts}</optgroup>`;
  }).join('');
  sel.value = _activeThemeId;
  sel.addEventListener('change', () => setActiveTheme(sel.value));
  updateThemePreview();

  // Botón "Aplicar este tema al banner del curso" — genera SVG estático del tema
  // y lo sube al overviewfiles del curso (visible para estudiantes sin extensión)
  const applyBtn = document.getElementById('btnApplyThemeBanner');
  if (applyBtn) {
    applyBtn.addEventListener('click', async () => {
      try {
        applyBtn.disabled = true;
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.url?.includes('/course/view.php')) {
          showStatus('Abre la página del curso en Moodle primero.', 'error', applyBtn);
          applyBtn.disabled = false;
          return;
        }
        const m = tab.url.match(/[?&]id=(\d+)/);
        if (!m) {
          showStatus('No se detectó el ID del curso en la URL.', 'error', applyBtn);
          applyBtn.disabled = false;
          return;
        }
        const courseId = m[1];
        const theme = getActiveTheme();
        const svgString = generateThemeBannerSvg();
        const filename = `gaula-banner-tema-${theme.id}.svg`;
        const blob = new Blob([svgString], { type: 'image/svg+xml' });
        const file = new File([blob], filename, { type: 'image/svg+xml' });
        const serialized = await serializeFile(file);
        await chrome.storage.local.set({ gaula_file_0: serialized });

        showStatus(`Subiendo banner "${theme.name}" al curso...`, 'loading', applyBtn);
        await new Promise((resolve, reject) => {
          chrome.tabs.sendMessage(tab.id, {
            action: 'set_course_banner',
            courseId,
            filename
          }, (resp) => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            if (!resp || !resp.ok) return reject(new Error(resp?.error || 'Sin respuesta'));
            resolve(resp);
          });
        });
        showStatus(`Banner "${theme.name}" aplicado. La pestaña va a recargar al curso.`, 'success', applyBtn);
      } catch (e) {
        showStatus(e.message || 'Error aplicando banner', 'error', applyBtn);
      }
      applyBtn.disabled = false;
    });
  }
}

// Genera un SVG estático para usar como background del banner del curso.
// Dimensiones 1232x371 (match exacto del banner real de Moodle PUCE), aspect 3.32:1.
// Contenido: fondo color del tema + 2 instancias del iconSvg distribuidas (lados,
// evitando el centro donde Moodle pinta el card del docente) + logo PUCE top-right.
// Las animaciones SMIL del iconSvg se quitan porque no corren cuando un SVG se usa
// como background-image — pero las formas/colores estáticos sí se ven.
function generateThemeBannerSvg() {
  const t = getActiveTheme();
  const themeBg = t.headerBg;
  const W = 1232, H = 371;

  const iconRaw = (typeof THEME_ICONS !== 'undefined' && THEME_ICONS[t.id]) || '';
  // ViewBox del iconSvg original (varía por tema)
  const vbMatch = iconRaw.match(/viewBox="([^"]+)"/);
  const innerVb = vbMatch ? vbMatch[1] : '0 0 280 56';
  // Strip outer <svg> + animaciones SMIL (no corren como background-image)
  const innerContent = iconRaw
    .replace(/<svg[^>]*>/, '')
    .replace(/<\/svg>\s*$/, '')
    .replace(/<animate\b[^>]*\/?>/g, '')
    .replace(/<animateTransform\b[^>]*\/?>/g, '')
    .replace(/<animateMotion\b[^>]*\/?>/g, '');

  // Dos cópias del icon: izquierda y derecha-abajo, evitando la franja central 350-880
  // donde Moodle pinta el card del docente (con SI avatar + nombre)
  const iconLeft  = innerContent
    ? `<svg x="20"  y="50"  width="320" height="270" viewBox="${innerVb}" preserveAspectRatio="xMidYMid meet" opacity="0.55">${innerContent}</svg>`
    : '';
  const iconRight = innerContent
    ? `<svg x="870" y="110" width="340" height="240" viewBox="${innerVb}" preserveAspectRatio="xMidYMid meet" opacity="0.50">${innerContent}</svg>`
    : '';

  // Logo institucional arriba a la derecha (PUCE o PUCESA según tenant),
  // sin animaciones (no corren en background-image). Extraer viewBox del SVG fuente
  // y reposicionarlo como child SVG dentro del banner.
  const rawLogo = getInstitutionalLogoSvg();
  const logoVbMatch = rawLogo.match(/viewBox="([^"]+)"/);
  const logoVb = logoVbMatch ? logoVbMatch[1] : '0 0 169.38 64.07';
  // Calcular width preservando aspect (height = 83)
  const [, , logoVbW, logoVbH] = logoVb.split(/\s+/).map(parseFloat);
  const logoWidth = Math.round(83 * (logoVbW / logoVbH));
  // Logo PUCE SIEMPRE arriba a la IZQUIERDA: así no se corta cuando Moodle recorta
  // la tarjeta del curso por la derecha (antes salía como "...UC").
  const puceLogo = rawLogo
    .replace(/<animate\b[^>]*\/?>/g, '')
    .replace(/<animateTransform\b[^>]*\/?>/g, '')
    .replace(/<svg[^>]*>/, `<svg x="22" y="${Math.round((H - 83) / 2)}" width="${logoWidth}" height="83" viewBox="${logoVb}" preserveAspectRatio="xMidYMid meet">`);

  // Banner principal LIMPIO: solo el color del tema + el logo PUCE arriba-izquierda.
  // NO se pintan los íconos del tema (iconLeft/iconRight) aquí — quedaba recargado.
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice">
<rect width="${W}" height="${H}" fill="${themeBg}"/>
${puceLogo}
</svg>`;
}

// Inject Step 2 results (HTMLs from backend) into Moodle
// ============================================================
// PANEL DE REVISIÓN/EDICIÓN PRE-INYECCIÓN (Paso 2)
// ============================================================
// Llamado tras generar (con o sin IA). Muestra preview editable de cada
// HTML y, al aprobar, llama a injectStep2Results con el contenido editado.
// La función injectStep2Results NO se modifica.
// Persistir el preview del sílabo IA en chrome.storage. Así si el docente cierra
// el popup por error después de generar (consumió crédito IA), al reabrir
// vuelve a ver el preview con sus ediciones, en lugar de tener que regenerar.
const SYLLABUS_PREVIEW_KEY = 'gaula_syllabus_ai_preview';
function saveSyllabusPreview(state) {
  try { chrome.storage.local.set({ [SYLLABUS_PREVIEW_KEY]: state }); } catch (_) {}
}
function loadSyllabusPreview() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get(SYLLABUS_PREVIEW_KEY, r => resolve(r[SYLLABUS_PREVIEW_KEY] || null));
    } catch (_) { resolve(null); }
  });
}
function clearSyllabusPreview() {
  try { chrome.storage.local.remove(SYLLABUS_PREVIEW_KEY); } catch (_) {}
}

function showStep2EditPanel(result, originBtn) {
  const panel = document.getElementById('step2-edit-panel');
  const tabsEl = document.getElementById('step2-edit-tabs');
  const previewEl = document.getElementById('step2-edit-preview');
  const cancelBtn = document.getElementById('btn-edit-cancel');
  const approveBtn = document.getElementById('btn-edit-approve');

  if (!panel || !tabsEl || !previewEl || !cancelBtn || !approveBtn) {
    // Sin panel, fallback al comportamiento legacy: inyectar directo
    return injectStep2Results(result).catch((e) => showStatus('Error: ' + e.message, 'error', originBtn));
  }

  // Estado mutable de cada HTML — se irá actualizando con las ediciones
  const editedState = {
    bannerHtml: result.bannerHtml || '',
    syllabusHtml: result.syllabusHtml || '',
    subjectHtml: result.subjectHtml || '',
    teacherHtml: result.teacherHtml || '',
    scheduleHtml: result.scheduleHtml || '',
    tutorHtml: result.tutorHtml || null,
  };
  // Snapshot inicial en storage (al regresar al popup se restaura)
  saveSyllabusPreview(editedState);

  const tabs = [
    { key: 'syllabusHtml', label: 'Sílabo' },
    { key: 'subjectHtml', label: 'Materia' },
    { key: 'teacherHtml', label: 'Docente' },
    { key: 'scheduleHtml', label: 'Horario' },
  ];
  if (editedState.tutorHtml) tabs.push({ key: 'tutorHtml', label: 'Tutor' });
  if (editedState.bannerHtml) tabs.push({ key: 'bannerHtml', label: 'Banner' });

  let activeKey = tabs[0].key;

  function captureCurrentEdit() {
    const c = document.getElementById('step2-edit-content');
    if (c) editedState[activeKey] = c.innerHTML;
    saveSyllabusPreview(editedState);
  }

  function renderTabs() {
    tabsEl.innerHTML = '';
    tabs.forEach((t) => {
      const tab = document.createElement('button');
      tab.type = 'button';
      tab.textContent = t.label;
      const isActive = t.key === activeKey;
      tab.style.cssText =
        'padding:8px 14px;border:none;background:' + (isActive ? '#fff' : 'transparent') +
        ';color:' + (isActive ? '#1d4ed8' : '#4b5563') +
        ';font-size:12px;font-weight:' + (isActive ? '600' : '500') +
        ';cursor:pointer;border-bottom:2px solid ' + (isActive ? '#1d4ed8' : 'transparent') +
        ';white-space:nowrap;transition:background 0.15s';
      tab.addEventListener('click', () => {
        captureCurrentEdit();
        activeKey = t.key;
        renderTabs();
        renderPreview();
      });
      tabsEl.appendChild(tab);
    });
  }

  function renderPreview() {
    const raw = editedState[activeKey] || '<em style="color:#9ca3af">(sin contenido para esta sección)</em>';
    // Aplica tema al previewar, igual que en la inyección final.
    let html = raw;
    if (['syllabusHtml','subjectHtml','teacherHtml','scheduleHtml','tutorHtml'].includes(activeKey)) {
      html = applyThemeToCardBanner(raw);
    } else if (activeKey === 'bannerHtml') {
      html = applyThemeToBigBanner(raw);
    }
    previewEl.innerHTML = '<div contenteditable="true" id="step2-edit-content" spellcheck="true" style="outline:none;min-height:180px;line-height:1.5">' + html + '</div>';
    // Auto-save de ediciones (debounce 800ms para no spamear storage)
    const c = document.getElementById('step2-edit-content');
    if (c) {
      let _t;
      c.addEventListener('input', () => {
        clearTimeout(_t);
        _t = setTimeout(() => {
          editedState[activeKey] = c.innerHTML;
          saveSyllabusPreview(editedState);
        }, 800);
      });
    }
  }

  function hidePanel() {
    captureCurrentEdit();
    panel.style.display = 'none';
    cancelBtn.removeEventListener('click', onCancel);
    approveBtn.removeEventListener('click', onApprove);
  }

  function onCancel() {
    hidePanel();
    clearSyllabusPreview();
    if (originBtn) originBtn.disabled = false;
    showStatus('Inyección cancelada. Puedes generar de nuevo cuando quieras.', 'info', originBtn);
  }

  async function onApprove() {
    captureCurrentEdit();
    panel.style.display = 'none';
    cancelBtn.removeEventListener('click', onCancel);
    approveBtn.removeEventListener('click', onApprove);
    try {
      activeProgressStep = 'Step2';
      showProgress(3, 4, 'Inyectando a Moodle...', 'Step2');
      await injectStep2Results(editedState);
      markProgressDone('Step2');
      clearSyllabusPreview();   // preview ya inyectado, ya no se necesita
      showStatus('Contenido inyectado en Moodle.', 'success', originBtn);
    } catch (e) {
      // No limpiamos preview en error — el docente puede reintentar inyección
      showStatus('Error inyectando: ' + (e.message || 'desconocido'), 'error', originBtn);
    } finally {
      if (originBtn) originBtn.disabled = false;
    }
  }

  cancelBtn.addEventListener('click', onCancel);
  approveBtn.addEventListener('click', onApprove);
  renderTabs();
  renderPreview();
  panel.style.display = 'block';
  panel.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

async function injectStep2Results(result) {
  const { bannerHtml, syllabusHtml, subjectHtml, teacherHtml, scheduleHtml, tutorHtml } = result;

  // Guardar HTMLs generados en storage
  saveGenerated('banner_html', bannerHtml);
  saveGenerated('syllabus_html', syllabusHtml);
  saveGenerated('subject_html', subjectHtml);
  saveGenerated('teacher_html', teacherHtml);
  saveGenerated('schedule_html', scheduleHtml);
  if (tutorHtml) saveGenerated('tutor_html', tutorHtml);

  // Reescribir los banners azules (#1a237e) de cada card del sílabo para que:
  //  1) Tomen el headerBg del tema activo
  //  2) Reciban el iconSvg del tema (animaciones SMIL) como capa absoluta de fondo
  //  3) El h2/p queden con z-index:1 para no quedar tapados por el SVG
  // El logo PUCE NO se agrega aquí porque ya está arriba en el wrapCollapsible que envuelve todo.
  const themedSyllabus = applyThemeToCardBanner(syllabusHtml);
  const themedTeacher  = applyThemeToCardBanner(teacherHtml);
  const themedSubject  = applyThemeToCardBanner(subjectHtml);
  const themedSchedule = applyThemeToCardBanner(scheduleHtml);
  const themedTutor    = applyThemeToCardBanner(tutorHtml);
  // Banner grande (top header): aplicar el mismo tema
  const themedBanner   = applyThemeToBigBanner(bannerHtml);

  // Armar página con pestañas
  const presentationTabs = [
    { label: 'Sílabo', content: themedSyllabus },
    { label: 'Docente', content: themedTeacher },
    { label: 'Materia', content: themedSubject },
    { label: 'Horario', content: themedSchedule },
  ];
  if (tutorHtml) {
    presentationTabs.push({ label: 'Tutor', content: themedTutor });
  }
  const tabbedHtml = wrapCollapsible('Información del Curso', generateTabbedHTML(presentationTabs, 'gaula_pres'));

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) throw new Error('No se encontró pestaña activa.');
  if (!tab.url?.includes('/course/view.php')) {
    throw new Error('Debes estar en la página del curso en Moodle.');
  }

  const queue = [{
    sectionType: 'presentations',
    htmlContent: tabbedHtml,
    pageName: 'Información del Curso',
    sectionIndex: 0
  }];

  // Generar SVG temático y dejarlo pendiente en storage para que después de la cola
  // (al final del flujo) section-editor.js dispare el upload al overviewfiles del curso.
  // Esto hace el banner del tema visible a todos (incluido estudiantes sin extensión).
  try {
    const courseMatch = tab.url.match(/[?&]id=(\d+)/);
    const courseId = courseMatch ? courseMatch[1] : null;
    if (courseId) {
      const themeNow = getActiveTheme();
      const svgString = generateThemeBannerSvg();
      const bannerFilename = `gaula-banner-tema-${themeNow.id}.svg`;
      const blob = new Blob([svgString], { type: 'image/svg+xml' });
      const svgFile = new File([blob], bannerFilename, { type: 'image/svg+xml' });
      const serializedSvg = await serializeFile(svgFile);
      await chrome.storage.local.set({
        gaula_file_0: serializedSvg,
        gaula_pending_banner: { courseId, filename: bannerFilename }
      });
    }
  } catch (e) {
    console.warn('[GAULA] No se pudo preparar banner del tema:', e);
  }

  // Enviar al content script: editar banner + crear página
  const response = await new Promise((resolve) => {
    chrome.tabs.sendMessage(tab.id, {
      action: 'edit_banner',
      bannerHtml: themedBanner,
      pendingQueue: queue,
      courseUrl: tab.url
    }, (resp) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(resp || { ok: false, error: 'Sin respuesta' });
      }
    });
  });

  if (!response.ok) throw new Error(response.error);
}

// ============================================================
// SCROLL PERSISTENCE
// ============================================================
// ---- Scroll persistence (usa localStorage síncrono) ----
// El popup se destruye al cerrarlo, así que chrome.storage.local.set (async)
// no alcanza a guardar. localStorage es síncrono y persiste entre aperturas.

function saveScrollPos() {
  const pos = document.body.scrollTop || document.documentElement.scrollTop;
  localStorage.setItem('gaula_scroll_pos', String(pos));
}

// Guardar en cada scroll (debounced) + al cerrar el popup
let _scrollT = null;
document.body.addEventListener('scroll', () => {
  clearTimeout(_scrollT);
  _scrollT = setTimeout(saveScrollPos, 100);
});
document.documentElement.addEventListener('scroll', () => {
  clearTimeout(_scrollT);
  _scrollT = setTimeout(saveScrollPos, 100);
});
window.addEventListener('beforeunload', saveScrollPos);
window.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') saveScrollPos();
});

function restoreScrollPosition() {
  const pos = parseInt(localStorage.getItem('gaula_scroll_pos') || '0', 10);
  if (pos > 0) {
    requestAnimationFrame(() => {
      document.body.scrollTop = pos;
      document.documentElement.scrollTop = pos;
      // Fallback para contenido que aún se está renderizando
      setTimeout(() => {
        document.body.scrollTop = pos;
        document.documentElement.scrollTop = pos;
      }, 150);
    });
  }
}

// ============================================================
// ZOOM
// ============================================================
const ZOOM_STEPS = [80, 90, 100, 110, 120, 130, 150];
let currentZoomIdx = 2; // 100%

const BASE_WIDTH = 750; // ancho original del popup
const MAX_POPUP_WIDTH = 800; // límite máximo de Chrome

function applyZoom(level) {
  document.body.style.zoom = level + '%';
  // Ajustar ancho para que el contenido zoomeado siga cabiendo en el popup
  if (level > 100) {
    const adjusted = Math.floor(MAX_POPUP_WIDTH / (level / 100));
    document.body.style.width = adjusted + 'px';
  } else {
    document.body.style.width = BASE_WIDTH + 'px';
  }
  chrome.storage.local.set({ gaula_zoom: level });
}

document.getElementById('btnZoomIn')?.addEventListener('click', () => {
  if (currentZoomIdx < ZOOM_STEPS.length - 1) {
    currentZoomIdx++;
    applyZoom(ZOOM_STEPS[currentZoomIdx]);
  }
});

document.getElementById('btnZoomOut')?.addEventListener('click', () => {
  if (currentZoomIdx > 0) {
    currentZoomIdx--;
    applyZoom(ZOOM_STEPS[currentZoomIdx]);
  }
});

// Restaurar zoom guardado
chrome.storage.local.get('gaula_zoom', (res) => {
  if (res.gaula_zoom) {
    const idx = ZOOM_STEPS.indexOf(res.gaula_zoom);
    if (idx !== -1) {
      currentZoomIdx = idx;
      applyZoom(res.gaula_zoom);
    }
  }
});

// ============================================================
// INIT
// ============================================================
init();

// Sincroniza la versión visible en el header y en el footer del login con
// la versión real del manifest. Se actualiza solo en cada bump (3.2.0, 3.2.1…).
(function syncVersionFromManifest() {
  try {
    const v = chrome.runtime.getManifest().version;
    document.querySelectorAll('.version-tag, .version-tag-header').forEach((el) => {
      el.textContent = 'v' + v;
    });
  } catch (_) { /* fallback: deja lo que esté en el HTML */ }
})();

// ============================================================
// CHAT DE SOPORTE (docente <-> admin NEXBYTE)
// ============================================================
// Botón se inyecta en .header-right (a la izquierda de la campana).
// Click → abre panel fijo abajo a la derecha. Lee/escribe en
// support_messages. Imágenes via paste se suben a bucket support-images.
// Polling cada 5s mientras el panel esté abierto (sin realtime para no
// añadir complejidad). Aditivo, no toca lo existente.
(function initSupportChat() {
  let userId = null;
  let cachedToken = null;
  let pollIntervalId = null;
  let pendingImageBlob = null;
  let pendingImageName = null;
  let lastMessageCount = 0;
  let lastFingerprint = '';  // hash simple para evitar re-renders innecesarios
  let clearedAtIso = null;  // ISO string — solo muestra mensajes posteriores a esta fecha
  const CLEARED_KEY = 'gaula_support_cleared_at';
  const MAX_IMAGE_BYTES = 5 * 1024 * 1024;  // 5 MB tope

  function loadClearedAt() {
    return new Promise((resolve) => {
      chrome.storage.local.get(CLEARED_KEY, (res) => {
        clearedAtIso = res[CLEARED_KEY] || null;
        resolve(clearedAtIso);
      });
    });
  }

  function saveClearedAt(iso) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [CLEARED_KEY]: iso }, resolve);
    });
  }

  function decodeJwtSub(token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return payload.sub || null;
    } catch { return null; }
  }

  // Cliente "Supabase ligero" basado en fetch directo a la API REST/Storage.
  // Las RLS funcionan igual usando el JWT en Authorization header.
  async function ensureSession() {
    console.log('[support] ensureSession start');
    // CONFIG es const a nivel script (no en window). En scripts clásicos
    // const/let top-level NO se vincula a window — solo var. Accedemos directo.
    if (typeof CONFIG === 'undefined' || !CONFIG.SUPABASE_URL || !CONFIG.SUPABASE_ANON_KEY) {
      console.warn('[support] CONFIG incompleta', typeof CONFIG === 'undefined' ? 'undefined' : CONFIG);
      return null;
    }
    // Intento 1: pedirle al background la sesión
    let session = await sendMessage({ type: 'GET_SESSION' });
    console.log('[support] GET_SESSION result (1st attempt):', session);

    // Si no llegó token, esperar 600ms y reintentar (MV3 service worker puede
    // estar dormido y la primera respuesta puede ser undefined o vacía).
    if (!session?.ok || !session.token) {
      console.log('[support] retrying GET_SESSION after 600ms...');
      await new Promise((r) => setTimeout(r, 600));
      session = await sendMessage({ type: 'GET_SESSION' });
      console.log('[support] GET_SESSION result (2nd attempt):', session);
    }

    if (!session?.ok || !session.token) {
      // Fallback: leer la sesión DIRECTAMENTE de chrome.storage.local
      // (background.js guarda el access_token ahí también)
      console.log('[support] fallback: leyendo chrome.storage.local directamente');
      try {
        const stored = await new Promise((res) => chrome.storage.local.get('session', res));
        console.log('[support] storage session:', stored);
        const direct = stored?.session;
        if (direct?.access_token) {
          session = { ok: true, token: direct.access_token, user: { id: decodeJwtSub(direct.access_token) } };
          console.log('[support] sesión recuperada de storage');
        }
      } catch (e) {
        console.error('[support] storage fallback failed', e);
      }
    }

    if (!session?.ok || !session.token) {
      console.warn('[support] no hay session.token después de retry y storage', session);
      return null;
    }

    cachedToken = session.token;
    userId = session.user?.id || decodeJwtSub(session.token);
    console.log('[support] userId:', userId);
    if (!userId) {
      console.warn('[support] no se pudo determinar userId del JWT');
      return null;
    }
    return {
      url: CONFIG.SUPABASE_URL,
      anonKey: CONFIG.SUPABASE_ANON_KEY,
      token: session.token,
    };
  }

  function authHeaders(ctx, extra) {
    return Object.assign({
      'apikey': ctx.anonKey,
      'Authorization': `Bearer ${ctx.token}`,
    }, extra || {});
  }

  async function dbSelect(ctx, table, query) {
    const url = `${ctx.url}/rest/v1/${table}?${query}`;
    const res = await fetch(url, { headers: authHeaders(ctx, { 'Accept': 'application/json' }) });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`SELECT ${table} ${res.status}: ${text.slice(0, 200)}`);
    }
    return res.json();
  }

  async function dbCount(ctx, table, query) {
    const url = `${ctx.url}/rest/v1/${table}?${query}&select=id`;
    const res = await fetch(url, {
      headers: authHeaders(ctx, { 'Accept': 'application/json', 'Prefer': 'count=exact', 'Range-Unit': 'items', 'Range': '0-0' }),
    });
    if (!res.ok) return 0;
    const range = res.headers.get('content-range') || '*/0';
    const total = parseInt(range.split('/')[1], 10);
    return Number.isFinite(total) ? total : 0;
  }

  async function dbInsert(ctx, table, row) {
    const url = `${ctx.url}/rest/v1/${table}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: authHeaders(ctx, { 'Content-Type': 'application/json', 'Prefer': 'return=representation' }),
      body: JSON.stringify(row),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`INSERT ${table} ${res.status}: ${text.slice(0, 300)}`);
    }
    return res.json();
  }

  async function dbPatch(ctx, table, query, patch) {
    const url = `${ctx.url}/rest/v1/${table}?${query}`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: authHeaders(ctx, { 'Content-Type': 'application/json' }),
      body: JSON.stringify(patch),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`UPDATE ${table} ${res.status}: ${text.slice(0, 200)}`);
    }
  }

  async function storageUpload(ctx, bucket, path, blob) {
    const url = `${ctx.url}/storage/v1/object/${bucket}/${encodeURIComponent(path).replace(/%2F/g, '/')}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: authHeaders(ctx, { 'Content-Type': blob.type || 'application/octet-stream', 'x-upsert': 'false' }),
      body: blob,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`UPLOAD ${res.status}: ${text.slice(0, 200)}`);
    }
    return res.json().catch(() => ({}));
  }

  async function storageSign(ctx, bucket, path, expiresIn) {
    const url = `${ctx.url}/storage/v1/object/sign/${bucket}/${encodeURIComponent(path).replace(/%2F/g, '/')}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: authHeaders(ctx, { 'Content-Type': 'application/json' }),
      body: JSON.stringify({ expiresIn: expiresIn || 3600 }),
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      console.warn('[support] sign failed', res.status, txt);
      return null;
    }
    const data = await res.json().catch(() => null);
    // Supabase devuelve "signedURL" (mayúsculas) o "signedUrl" según versión.
    // El path típico es "/object/sign/bucket/path?token=..." — hay que
    // prepender "/storage/v1" para tener la URL completa usable.
    const signedPath = data?.signedURL || data?.signedUrl;
    if (!signedPath) {
      console.warn('[support] sign response sin signedURL', data);
      return null;
    }
    if (signedPath.startsWith('http')) return signedPath;  // ya es URL completa
    if (signedPath.startsWith('/storage/v1')) return ctx.url + signedPath;
    return ctx.url + '/storage/v1' + (signedPath.startsWith('/') ? signedPath : '/' + signedPath);
  }

  function injectSupportButton() {
    const headerRight = document.querySelector('.header-right');
    if (!headerRight || document.getElementById('support-bell-btn')) return;
    const wrap = document.createElement('div');
    wrap.id = 'support-bell-wrap';
    wrap.style.cssText = 'display:inline-flex;align-items:center;margin-right:8px';
    wrap.innerHTML = `
      <button id="support-bell-btn" type="button" aria-label="Soporte" title="Soporte NEXBYTE" style="position:relative;background:rgba(255,255,255,0.12);border:1px solid rgba(255,255,255,0.18);border-radius:50%;width:32px;height:32px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
        </svg>
        <span id="support-badge" style="display:none;position:absolute;top:-2px;right:-2px;background:#ef4444;color:#fff;font-size:10px;font-weight:700;line-height:1;padding:3px 5px;border-radius:10px;min-width:16px;text-align:center;border:2px solid rgba(15,23,42,1)"></span>
      </button>
    `;
    headerRight.insertBefore(wrap, headerRight.firstChild);
    document.getElementById('support-bell-btn').addEventListener('click', toggleSupportPanel);
  }

  async function refreshUnreadBadge() {
    const ctx = await ensureSession();
    if (!ctx) return;
    try {
      const count = await dbCount(ctx, 'support_messages',
        `user_id=eq.${userId}&sender=eq.admin&read_by_user=eq.false`);
      const badge = document.getElementById('support-badge');
      if (!badge) return;
      if (count > 0) {
        badge.textContent = count > 9 ? '9+' : String(count);
        badge.style.display = 'block';
      } else {
        badge.style.display = 'none';
      }
    } catch (e) {
      console.warn('[support] badge error', e);
    }
  }

  async function loadMessages() {
    const ctx = await ensureSession();
    const list = document.getElementById('support-messages');
    if (!ctx || !list) return;
    if (!clearedAtIso) await loadClearedAt();
    let data;
    try {
      // Filtro extra: solo mensajes después del último "Limpiar" del usuario
      const clearFilter = clearedAtIso ? `&created_at=gt.${encodeURIComponent(clearedAtIso)}` : '';
      data = await dbSelect(ctx, 'support_messages',
        `user_id=eq.${userId}${clearFilter}&order=created_at.asc&limit=200&select=id,sender,body,image_url,created_at,read_by_user`);
    } catch (e) {
      list.innerHTML = '<div style="color:#dc2626;text-align:center;padding:20px;font-size:12px">Error cargando mensajes: ' + escapeHtml(e.message) + '</div>';
      return;
    }
    if (!data || data.length === 0) {
      const emptyMsg = clearedAtIso
        ? 'Conversación limpiada de tu vista.<br><span style="font-size:10px;opacity:0.7">El equipo de soporte sigue viendo el historial completo.</span>'
        : 'No hay mensajes todavía.<br>Escribe abajo para iniciar la conversación.';
      const emptyFp = clearedAtIso ? 'empty-cleared' : 'empty';
      if (lastFingerprint !== emptyFp) {
        list.innerHTML = '<div style="color:#6b7280;text-align:center;padding:30px 20px;font-size:12px">' + emptyMsg + '</div>';
        lastFingerprint = emptyFp;
        lastMessageCount = 0;
      }
      return;
    }

    // Fingerprint = ids + read_by_user. Si no cambió, NO re-renderizamos
    // (esto evita el "salto al top" cada 5s del polling).
    const fingerprint = data.map((m) => `${m.id}:${m.read_by_user ? 1 : 0}`).join('|');
    if (fingerprint === lastFingerprint) return;

    // Si el usuario estaba scrolleado al fondo antes del re-render, lo
    // mantenemos al fondo. Si estaba arriba leyendo algo viejo, no lo movemos.
    const wasAtBottom = (list.scrollTop + list.clientHeight) >= (list.scrollHeight - 50);
    const isNew = data.length > lastMessageCount;
    lastMessageCount = data.length;
    lastFingerprint = fingerprint;

    list.innerHTML = '';
    let lastDate = '';
    for (const m of data) {
      const date = new Date(m.created_at);
      const dayStr = date.toLocaleDateString('es-EC', { day: 'numeric', month: 'short' });
      if (dayStr !== lastDate) {
        const sep = document.createElement('div');
        sep.style.cssText = 'text-align:center;margin:8px 0;font-size:10px;color:#9ca3af';
        sep.textContent = dayStr;
        list.appendChild(sep);
        lastDate = dayStr;
      }
      const isUser = m.sender === 'user';
      const bubble = document.createElement('div');
      bubble.style.cssText = 'display:flex;margin:4px 0;' + (isUser ? 'justify-content:flex-end' : 'justify-content:flex-start');
      const inner = document.createElement('div');
      inner.style.cssText = 'max-width:78%;padding:6px 10px;border-radius:12px;font-size:12px;line-height:1.4;' +
        (isUser ? 'background:#1d4ed8;color:#fff;border-bottom-right-radius:4px' : 'background:#fff;color:#111827;border:1px solid #e5e7eb;border-bottom-left-radius:4px');
      if (m.body) {
        const txt = document.createElement('div');
        txt.textContent = m.body;
        inner.appendChild(txt);
      }
      if (m.image_url) {
        const signedUrl = await storageSign(ctx, 'support-images', m.image_url, 3600);
        if (signedUrl) {
          const img = document.createElement('img');
          img.src = signedUrl;
          img.style.cssText = 'max-width:100%;border-radius:6px;margin-top:4px;cursor:pointer';
          img.addEventListener('click', () => chrome.tabs.create({ url: signedUrl }));
          inner.appendChild(img);
        }
      }
      const time = document.createElement('div');
      time.style.cssText = 'font-size:9px;opacity:0.7;margin-top:2px;text-align:right';
      time.textContent = date.toLocaleTimeString('es-EC', { hour: '2-digit', minute: '2-digit' });
      inner.appendChild(time);
      bubble.appendChild(inner);
      list.appendChild(bubble);
    }
    if (isNew || wasAtBottom) list.scrollTop = list.scrollHeight;

    const unreadAdminIds = data.filter((m) => m.sender === 'admin' && !m.read_by_user).map((m) => m.id);
    if (unreadAdminIds.length > 0) {
      try {
        await dbPatch(ctx, 'support_messages', `id=in.(${unreadAdminIds.join(',')})`, { read_by_user: true });
        refreshUnreadBadge();
      } catch (e) { console.warn('[support] mark-read error', e); }
    }
  }

  async function uploadImage(ctx, blob) {
    const ext = (blob.type || 'image/png').split('/')[1] || 'png';
    const path = `${userId}/${Date.now()}.${ext}`;
    try {
      await storageUpload(ctx, 'support-images', path, blob);
      console.log('[support] upload ok', path);
      return path;
    } catch (e) {
      console.error('[support] upload error', e);
      showChatError('Upload imagen: ' + e.message);
      return null;
    }
  }

  function showChatError(msg) {
    const list = document.getElementById('support-messages');
    if (!list) return;
    const err = document.createElement('div');
    err.style.cssText = 'background:#fee2e2;color:#991b1b;padding:8px 10px;margin:6px 0;border-radius:6px;font-size:11px;border:1px solid #fca5a5';
    err.textContent = '⚠ ' + msg;
    list.appendChild(err);
    list.scrollTop = list.scrollHeight;
  }

  async function sendMessageNow(body, imageBlob) {
    console.log('[support] sendMessageNow', { body, hasImage: !!imageBlob });
    const ctx = await ensureSession();
    if (!ctx) {
      showChatError('No hay sesión activa. Recarga la extensión y vuelve a iniciar sesión.');
      return false;
    }
    let image_url = null;
    if (imageBlob) {
      image_url = await uploadImage(ctx, imageBlob);
      if (!image_url) return false;
    }
    const payload = { user_id: userId, sender: 'user', body: body || null, image_url };
    console.log('[support] insert payload', payload);
    try {
      const data = await dbInsert(ctx, 'support_messages', payload);
      console.log('[support] insert ok', data);
      return true;
    } catch (e) {
      console.error('[support] insert error', e);
      showChatError('Error enviando: ' + e.message);
      return false;
    }
  }

  function clearPendingImage() {
    pendingImageBlob = null;
    pendingImageName = null;
    const preview = document.getElementById('support-image-preview');
    if (preview) preview.style.display = 'none';
  }

  function showPendingImage(blob, name) {
    pendingImageBlob = blob;
    pendingImageName = name || 'imagen.png';
    const preview = document.getElementById('support-image-preview');
    const nameEl = document.getElementById('support-image-name');
    if (preview && nameEl) {
      nameEl.textContent = pendingImageName + ' (' + Math.round(blob.size / 1024) + ' KB)';
      preview.style.display = 'flex';
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function startPolling() {
    if (pollIntervalId) return;
    pollIntervalId = setInterval(loadMessages, 5000);
  }
  function stopPolling() {
    if (pollIntervalId) { clearInterval(pollIntervalId); pollIntervalId = null; }
  }

  async function toggleSupportPanel() {
    const panel = document.getElementById('support-panel');
    if (!panel) return;
    const isOpen = panel.style.display === 'flex';
    if (isOpen) {
      panel.style.display = 'none';
      stopPolling();
    } else {
      panel.style.display = 'flex';
      await loadMessages();
      startPolling();
      const input = document.getElementById('support-input');
      if (input) input.focus();
    }
  }

  // Idempotencia: setupPanelHandlers puede ser llamado varias veces si el
  // tryInit interval se dispara varias veces antes del clearInterval. Cada
  // llamada añade un addEventListener — sin guard, 7 ticks = 7 inserts por click.
  let panelHandlersSetup = false;

  function setupPanelHandlers() {
    if (panelHandlersSetup) return;
    const closeBtn = document.getElementById('support-close');
    const clearBtn = document.getElementById('support-clear');
    const form = document.getElementById('support-form');
    const input = document.getElementById('support-input');
    const removeImgBtn = document.getElementById('support-image-remove');
    if (!closeBtn || !form || !input || !removeImgBtn) return;
    panelHandlersSetup = true;

    closeBtn.addEventListener('click', () => {
      document.getElementById('support-panel').style.display = 'none';
      stopPolling();
    });

    if (clearBtn) {
      clearBtn.addEventListener('click', async () => {
        const confirmed = confirm('¿Limpiar tu vista de la conversación?\n\nEl equipo de soporte sigue viendo el historial completo. Esto solo oculta los mensajes anteriores en tu lado.');
        if (!confirmed) return;
        const now = new Date().toISOString();
        await saveClearedAt(now);
        clearedAtIso = now;
        lastMessageCount = 0;
        lastFingerprint = '';
        await loadMessages();
      });
    }

    removeImgBtn.addEventListener('click', clearPendingImage);

    input.addEventListener('paste', (e) => {
      const items = e.clipboardData?.items || [];
      for (const item of items) {
        if (item.type && item.type.indexOf('image') === 0) {
          const blob = item.getAsFile();
          if (blob) {
            // Tope de tamaño: 5 MB. Imágenes más grandes son spam o ataque DoS de storage.
            if (blob.size > MAX_IMAGE_BYTES) {
              showChatError(`Imagen muy grande (${Math.round(blob.size / 1024 / 1024)} MB). Máximo permitido: 5 MB.`);
              e.preventDefault();
              return;
            }
            showPendingImage(blob, blob.name || 'pegada.png');
            e.preventDefault();
            return;
          }
        }
      }
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        form.dispatchEvent(new Event('submit', { cancelable: true }));
      }
    });

    let submitting = false;  // candado anti-doble-click adicional
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (submitting) return;
      const text = input.value.trim();
      if (!text && !pendingImageBlob) return;
      submitting = true;
      const sendBtn = document.getElementById('support-send');
      sendBtn.disabled = true;
      sendBtn.textContent = '...';
      const ok = await sendMessageNow(text, pendingImageBlob);
      sendBtn.disabled = false;
      sendBtn.textContent = 'Enviar';
      submitting = false;
      if (ok) {
        input.value = '';
        clearPendingImage();
        await loadMessages();
      }
    });
  }

  // Inicialización: cuando aparezca .header-right del screen-main, inyectar
  // botón y handlers. CLAVE: clearInterval ANTES del await, para que el
  // ticker no fire varias veces durante refreshUnreadBadge.
  let initialized = false;
  let attempts = 0;
  const tryInit = setInterval(async () => {
    attempts++;
    if (initialized) { clearInterval(tryInit); return; }
    const headerRight = document.querySelector('.header-right');
    if (headerRight) {
      initialized = true;
      clearInterval(tryInit);  // antes del await — evita ticks duplicados
      injectSupportButton();
      setupPanelHandlers();
      await refreshUnreadBadge();
    } else if (attempts > 30) {
      // 30 × 200ms = 6s. Si aún no hay header, abortar (probablemente login).
      clearInterval(tryInit);
    }
  }, 200);
})();

// ============================================================
// FOOTER DE CRÉDITOS + ANUNCIO REMOTO
// ============================================================
// Carga datos editables (créditos, anuncio) desde nexbyte.pro/extension-info.json
// Esto permite cambiar textos, links y promociones sin re-publicar la extensión.
// Si el fetch falla, los elementos quedan ocultos: el popup funciona igual que antes.
(async function loadExtensionInfoFooter() {
  try {
    const url = 'https://nexbyte.pro/extension-info.json?t=' + Math.floor(Date.now() / 60000); // cache-bust 1 min
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) return;
    const info = await res.json();

    // Anuncio (banner azul). Si announcement es null/undefined, no aparece.
    if (info.announcement && typeof info.announcement === 'string' && info.announcement.trim()) {
      const ann = document.getElementById('ext-announcement');
      if (ann) {
        ann.textContent = info.announcement;
        ann.style.display = 'block';
        if (info.product_url) {
          ann.addEventListener('click', () => chrome.tabs.create({ url: info.product_url }));
        }
      }
    }

    // Footer de créditos. Solo se muestra si hay datos válidos.
    const footer = document.getElementById('ext-credits-footer');
    const line1 = document.getElementById('ext-credits-line1');
    const line2 = document.getElementById('ext-credits-line2');
    const links = document.getElementById('ext-credits-links');
    if (!footer || !line1 || !line2 || !links) return;

    const company = info.company?.name || 'NEXBYTE';
    const author = info.author?.name || '';
    const role = info.author?.role || '';
    // Versión: SIEMPRE del manifest (única fuente de verdad), nunca del JSON
    // remoto. El campo info.version_visible queda como fallback histórico.
    let version = '';
    try { version = chrome.runtime.getManifest().version; } catch (_) {}
    if (!version) version = info.version_visible || '';
    const productUrl = info.product_url || info.company?.url || 'https://nexbyte.pro';
    const supportUrl = info.support_url || 'https://nexbyte.pro';

    line1.textContent = `Generador de Aulas ${version ? 'v' + version : ''} · ${company}`.trim();
    line2.textContent = author ? `Por ${author}${role ? ' · ' + role : ''}` : '';

    // Links abren en nueva pestaña usando chrome.tabs.create (la extension no tiene CSP de target=_blank)
    links.innerHTML = '';
    const mkLink = (label, url) => {
      const a = document.createElement('a');
      a.textContent = label;
      a.href = url;
      a.style.color = '#1d4ed8';
      a.style.textDecoration = 'none';
      a.style.cursor = 'pointer';
      a.addEventListener('click', (e) => {
        e.preventDefault();
        chrome.tabs.create({ url });
      });
      return a;
    };
    links.appendChild(mkLink('Producto ↗', productUrl));
    if (supportUrl && supportUrl !== productUrl) {
      const sep = document.createElement('span');
      sep.textContent = '·';
      sep.style.color = '#9ca3af';
      links.appendChild(sep);
      links.appendChild(mkLink('Soporte ↗', supportUrl));
    }

    footer.style.display = 'block';
  } catch (_) {
    // Silencio absoluto: si falla el fetch, el popup funciona idéntico al anterior.
  }
})();

// ============================================================
// CAMPANA DE NOTIFICACIONES
// ============================================================
// Carga `nexbyte.pro/notifications.json`, muestra badge con no-leídas,
// dropdown estilo Instagram. Estado de leídas en chrome.storage.local.
// Si el fetch falla o no hay items, la campana no aparece.
(async function loadNotificationsBell() {
  const NOTIF_URL = 'https://nexbyte.pro/notifications.json?t=' + Math.floor(Date.now() / 60000);
  const STORAGE_KEY = 'gaula_notif_read_ids';

  function getReadIds() {
    return new Promise((resolve) => {
      chrome.storage.local.get(STORAGE_KEY, (res) => {
        resolve(Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY] : []);
      });
    });
  }

  function setReadIds(ids) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [STORAGE_KEY]: ids }, resolve);
    });
  }

  function fmtDate(s) {
    try {
      const d = new Date(s);
      return d.toLocaleDateString('es-EC', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch { return s || ''; }
  }

  // Lee el plan activo del usuario (si lo hay) para filtrar items por
  // `audience`. Si no se obtiene plan o el item no tiene audience, se
  // muestra a todos — comportamiento idéntico al previo.
  async function getCurrentPlan() {
    try {
      if (typeof CONFIG === 'undefined' || !CONFIG.SUPABASE_URL) return null;
      const session = await sendMessage({ type: 'GET_SESSION' });
      if (!session?.ok || !session.token) return null;
      const userId = session.user?.id || (function () {
        try { return JSON.parse(atob(session.token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).sub; }
        catch { return null; }
      })();
      if (!userId) return null;
      const today = new Date().toISOString().split('T')[0];
      const url = `${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?user_id=eq.${userId}&status=eq.active&period_end=gte.${today}&select=plan_name&order=created_at.desc&limit=1`;
      const r = await fetch(url, { headers: { 'apikey': CONFIG.SUPABASE_ANON_KEY, 'Authorization': `Bearer ${session.token}` } });
      if (!r.ok) return null;
      const rows = await r.json();
      return rows?.[0]?.plan_name || null;
    } catch { return null; }
  }

  try {
    const res = await fetch(NOTIF_URL, { cache: 'no-store' });
    if (!res.ok) return;
    const data = await res.json();
    let items = Array.isArray(data?.items) ? data.items : [];
    if (items.length === 0) return;

    // Filtro por audiencia (si el item lo tiene)
    const userPlan = await getCurrentPlan();
    if (userPlan) {
      items = items.filter((it) => {
        if (!Array.isArray(it.audience) || it.audience.length === 0) return true;
        return it.audience.includes(userPlan);
      });
    }
    if (items.length === 0) return;

    const wrap = document.getElementById('notif-bell-wrap');
    const btn = document.getElementById('notif-bell-btn');
    const badge = document.getElementById('notif-badge');
    const dropdown = document.getElementById('notif-dropdown');
    const list = document.getElementById('notif-list');
    const markAllBtn = document.getElementById('notif-mark-all');
    if (!wrap || !btn || !badge || !dropdown || !list || !markAllBtn) return;

    // Reubicar el bell DENTRO del header-right del popup (post-login) para que
    // no choque con foto/perfil/cerrar sesión. Si no existe el header-right
    // (pantalla de login o no-sub), queda como fixed top-right (fallback).
    const headerRight = document.querySelector('.header-right');
    if (headerRight && headerRight.parentNode) {
      // Convertir el wrapper de fixed a inline-block dentro del header
      wrap.style.position = 'static';
      wrap.style.top = 'auto';
      wrap.style.right = 'auto';
      wrap.style.marginRight = '8px';
      wrap.style.display = 'inline-flex';
      wrap.style.alignItems = 'center';
      // Botón un poco más pequeño para integrarse al header
      btn.style.width = '32px';
      btn.style.height = '32px';
      btn.style.background = 'rgba(255,255,255,0.12)';
      btn.style.borderColor = 'rgba(255,255,255,0.18)';
      btn.querySelectorAll('svg').forEach(s => s.setAttribute('stroke', '#ffffff'));
      // Insertar al inicio del header-right (a la izquierda del resto)
      headerRight.insertBefore(wrap, headerRight.firstChild);
    }

    let readIds = await getReadIds();

    function render() {
      const unread = items.filter((it) => it && it.id && !readIds.includes(it.id));
      // Badge
      if (unread.length > 0) {
        badge.textContent = unread.length > 9 ? '9+' : String(unread.length);
        badge.style.display = 'block';
      } else {
        badge.style.display = 'none';
      }
      // Lista (ordenada: no-leídas primero, luego más recientes por fecha)
      const sorted = [...items].sort((a, b) => {
        const aRead = readIds.includes(a.id) ? 1 : 0;
        const bRead = readIds.includes(b.id) ? 1 : 0;
        if (aRead !== bRead) return aRead - bRead;
        return (b.date || '').localeCompare(a.date || '');
      });
      list.innerHTML = '';
      sorted.forEach((it) => {
        if (!it?.id) return;
        const isRead = readIds.includes(it.id);
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 12px;border-bottom:1px solid #f3f4f6;cursor:pointer;background:' + (isRead ? '#fff' : '#eff6ff') + ';transition:background 0.15s';
        item.onmouseenter = () => { item.style.background = '#f3f4f6'; };
        item.onmouseleave = () => { item.style.background = isRead ? '#fff' : '#eff6ff'; };

        const typeBadge = it.type === 'promo' ? '<span style="display:inline-block;font-size:9px;background:#fef3c7;color:#92400e;padding:1px 6px;border-radius:6px;margin-right:4px;text-transform:uppercase;letter-spacing:0.5px">Promo</span>'
          : it.type === 'release' ? '<span style="display:inline-block;font-size:9px;background:#dbeafe;color:#1e40af;padding:1px 6px;border-radius:6px;margin-right:4px;text-transform:uppercase;letter-spacing:0.5px">Versión</span>'
          : '';

        const titleEl = document.createElement('div');
        titleEl.style.cssText = 'font-size:13px;font-weight:600;color:#111827;margin-bottom:2px;display:flex;align-items:center;gap:4px';
        titleEl.innerHTML = (isRead ? '' : '<span style="display:inline-block;width:6px;height:6px;background:#1d4ed8;border-radius:50%;flex-shrink:0"></span>') +
          typeBadge + '<span>' + escapeHtml(it.title || '') + '</span>';

        const bodyEl = document.createElement('div');
        bodyEl.style.cssText = 'font-size:12px;color:#4b5563;line-height:1.4;margin-bottom:4px';
        bodyEl.textContent = it.body || '';

        const dateEl = document.createElement('div');
        dateEl.style.cssText = 'font-size:10px;color:#9ca3af';
        dateEl.textContent = fmtDate(it.date);

        item.appendChild(titleEl);
        item.appendChild(bodyEl);
        item.appendChild(dateEl);

        item.addEventListener('click', async () => {
          if (!isRead) {
            readIds = [...readIds, it.id];
            await setReadIds(readIds);
            render();
          }
          if (it.url) chrome.tabs.create({ url: it.url });
        });
        list.appendChild(item);
      });
    }

    function escapeHtml(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = dropdown.style.display !== 'none' && dropdown.style.display !== '';
      dropdown.style.display = open ? 'none' : 'block';
    });

    document.addEventListener('click', (e) => {
      if (!wrap.contains(e.target)) dropdown.style.display = 'none';
    });

    markAllBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      readIds = items.map((it) => it.id).filter(Boolean);
      await setReadIds(readIds);
      render();
    });

    render();
    wrap.style.display = 'block';
  } catch (_) {
    // Silencio absoluto: sin notificaciones, el popup funciona idéntico.
  }
})();


// ============================================================
// PREMIUM CTA — gating + open in new tab
// ============================================================
// Muestra el banner "Generar curso completo (Premium)" solo si la suscripción
// activa del usuario es plan_name = "premium". El click abre popup-premium.html
// como pestaña aparte (la generación tarda varios minutos y necesita persistencia).
(async function initPremiumCTA() {
  const cta = document.getElementById("premium-cta");
  const btn = document.getElementById("btn-open-premium");
  if (!cta || !btn) return;

  btn.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("popup-premium.html") });
  });

  // Reintentamos hasta que la sesión esté lista. Si en 6s no hay sesión, abortar.
  let attempts = 0;
  const tryGate = setInterval(async () => {
    attempts++;
    const headerRight = document.querySelector(".header-right");
    if (!headerRight) {
      // Aún no estamos en screen-main (login pendiente)
      if (attempts > 30) clearInterval(tryGate);
      return;
    }
    clearInterval(tryGate);

    try {
      const session = await sendMessage({ type: "GET_SESSION" });
      if (!session?.ok || !session.token) return;
      if (typeof CONFIG === "undefined") return;

      const userId = session.user?.id || (function () {
        try { return JSON.parse(atob(session.token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))).sub; }
        catch { return null; }
      })();
      if (!userId) return;

      const today = new Date().toISOString().split("T")[0];
      const url = `${CONFIG.SUPABASE_URL}/rest/v1/subscriptions?user_id=eq.${userId}&status=eq.active&period_end=gte.${today}&select=plan_name&order=created_at.desc&limit=1`;
      const res = await fetch(url, {
        headers: {
          "apikey": CONFIG.SUPABASE_ANON_KEY,
          "Authorization": `Bearer ${session.token}`,
        },
      });
      if (!res.ok) return;
      const rows = await res.json();
      const planName = rows?.[0]?.plan_name;
      if (planName === "premium") {
        cta.style.display = "block";
      }
    } catch (e) {
      console.warn("[premium-cta] fetch failed", e);
    }
  }, 200);
})();
