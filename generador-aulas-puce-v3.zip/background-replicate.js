// ============================================================
// background-replicate.js — Flujo de replicar nota en otros criterios.
// Corre en el service worker, NO en la pestaña, así sobrevive a reloads
// y navegaciones que Moodle pueda disparar al cambiar el cmidnumber.
//
// Parsing de HTML: sin DOMParser (no disponible en SW). Usamos regex para
// extraer inputs/selects/textareas de los forms Moodle.
// ============================================================

// Log persistente (mismo formato que gaulaLog del content script)
async function bgLog(msg, data) {
  try {
    const ts = new Date().toISOString().slice(11, 23);
    const entry = { ts, msg, data: data === undefined ? null : data, url: '[bg]' };
    console.log('[BG-REPL]', msg, data || '');
    const s = await chrome.storage.local.get(['gaulaReplLog']);
    const arr = Array.isArray(s.gaulaReplLog) ? s.gaulaReplLog : [];
    arr.push(entry);
    const trimmed = arr.length > 200 ? arr.slice(arr.length - 200) : arr;
    await chrome.storage.local.set({ gaulaReplLog: trimmed });
  } catch (e) { /* fail-silent */ }
}

// Construye URLSearchParams a partir del HTML del form preservando
// inputs/selects/textareas. `overrides` es un objeto {nombre: valor} que
// reemplaza/setea esos campos en el body final.
// Excluye submits/cancel salvo que se pongan explícitamente en overrides.
function bgBuildFormBody(formHtml, overrides = {}) {
  const params = new URLSearchParams();
  // Inputs
  for (const m of formHtml.matchAll(/<input\s+([^>]+?)\s*\/?>/gi)) {
    const attrs = m[1];
    const name = attrs.match(/name="([^"]+)"/)?.[1];
    if (!name) continue;
    const type = (attrs.match(/type="([^"]+)"/)?.[1] || 'text').toLowerCase();
    if (type === 'submit' || type === 'reset' || type === 'button' || type === 'image') continue;
    const value = attrs.match(/value="([^"]*)"/)?.[1] || '';
    if (type === 'checkbox') {
      if (/\schecked/i.test(attrs)) params.append(name, value || '1');
      continue;
    }
    if (type === 'radio') {
      if (/\schecked/i.test(attrs)) params.append(name, value);
      continue;
    }
    params.append(name, value);
  }
  // Selects: tomar option selected (o el primero como fallback)
  for (const m of formHtml.matchAll(/<select\s+[^>]*name="([^"]+)"[^>]*>([\s\S]*?)<\/select>/gi)) {
    const name = m[1];
    const sel = m[2].match(/<option\s+[^>]*value="([^"]*)"[^>]*\sselected[^>]*>/i)
              || m[2].match(/<option\s+selected[^>]*value="([^"]*)"/i);
    if (sel) params.append(name, sel[1]);
    else {
      const first = m[2].match(/<option\s+[^>]*value="([^"]*)"/i);
      if (first) params.append(name, first[1]);
    }
  }
  // Textareas
  for (const m of formHtml.matchAll(/<textarea\s+[^>]*name="([^"]+)"[^>]*>([\s\S]*?)<\/textarea>/gi)) {
    const decoded = m[2].replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#039;/g, "'");
    params.append(m[1], decoded);
  }
  // Aplicar overrides
  for (const [k, v] of Object.entries(overrides)) {
    params.delete(k);
    if (v !== null && v !== undefined) params.append(k, String(v));
  }
  return params;
}

// Extrae el HTML del form principal (action contiene `needle`) de un HTML.
function bgExtractForm(html, needle) {
  // Regex non-greedy para capturar el primer form cuyo action contenga el needle
  const re = new RegExp(`<form[^>]*action="[^"]*${needle}[^"]*"[^>]*>([\\s\\S]*?)</form>`, 'i');
  const m = html.match(re);
  return m ? m[1] : null;
}

// Extrae el action attribute del form
function bgExtractFormAction(html, needle) {
  const re = new RegExp(`<form[^>]*action="([^"]+${needle}[^"]*)"`, 'i');
  return html.match(re)?.[1] || null;
}

// ──────────────────────────────────────────────────────────
// HELPER: setCmIdnumber via course/modedit.php (proxy desde SW)
// ──────────────────────────────────────────────────────────
async function bgSetCmIdnumber({ baseUrl, cmid, idnumber }) {
  const url = `${baseUrl}/course/modedit.php?update=${cmid}`;
  await bgLog('bgSetCmIdnumber GET form', { cmid });
  const r = await fetch(url, { credentials: 'include' });
  if (!r.ok) return { ok: false, error: `GET HTTP ${r.status}` };
  const html = await r.text();
  const formHtml = bgExtractForm(html, 'modedit.php');
  if (!formHtml) return { ok: false, error: 'modedit form not found' };
  let action = bgExtractFormAction(html, 'modedit.php');
  if (!action) action = url;
  if (!/^https?:/.test(action)) {
    try { action = new URL(action, url).toString(); } catch (_) {}
  }
  const params = bgBuildFormBody(formHtml, {
    cmidnumber: idnumber,
    submitbutton2: 'Guardar cambios y regresar al curso'
  });
  await bgLog('bgSetCmIdnumber POST start', { bytes: params.toString().length, action });
  const resp = await fetch(action, {
    method: 'POST',
    body: params.toString(),
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    credentials: 'include',
    redirect: 'manual'
  });
  await bgLog('bgSetCmIdnumber POST done', { status: resp.status, type: resp.type });
  // Verificar
  const verifyR = await fetch(url, { credentials: 'include' });
  if (!verifyR.ok) return { ok: false, error: `verify HTTP ${verifyR.status}` };
  const vHtml = await verifyR.text();
  const idnAfter = vHtml.match(/name="cmidnumber"[^>]*value="([^"]*)"/)?.[1]
                ?? vHtml.match(/value="([^"]*)"[^>]*name="cmidnumber"/)?.[1]
                ?? '';
  if (idnAfter !== idnumber) {
    return { ok: false, error: `cmidnumber no aplicado (actual="${idnAfter}")` };
  }
  return { ok: true };
}

// ──────────────────────────────────────────────────────────
// HELPER: find grade item by name + extract cmid from row
// ──────────────────────────────────────────────────────────
async function bgFindGradeItemByName({ baseUrl, courseId, name, parentCategoryId }) {
  const url = `${baseUrl}/grade/edit/tree/index.php?id=${courseId}`;
  const r = await fetch(url, { credentials: 'include' });
  if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
  const html = await r.text();
  // Extraer cada tr id="grade-item-igN" con su contenido completo
  const wanted = name.toLowerCase().trim();
  const candidates = [];
  for (const m of html.matchAll(/<tr\s+[^>]*id="grade-item-ig(\d+)"[^>]*class="([^"]*)"[^>]*data-itemid="(\d+)"[^>]*data-itemtype="([^"]*)"[\s\S]*?>([\s\S]*?)<\/tr>/gi)) {
    const itemId = m[1];
    const classes = m[2];
    const trBody = m[5];
    // Extraer nombre del item (texto plano del inicio del tr)
    const textOnly = trBody.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    const head = textOnly.split(/\s+\d+[,.]?\d*\s+Editar|\s+Editar/)[0].trim().toLowerCase();
    if (head === wanted || head.includes(wanted)) {
      const cgs = classes.match(/\bcg(\d+)\b/g) || [];
      const directParent = cgs[cgs.length - 1]?.replace(/^cg/, '');
      // Extraer cmid del primer link a /mod/.../view.php?id=N
      let cmid = null;
      const modLink = trBody.match(/href="[^"]*\/mod\/[^"\/]+\/view\.php\?id=(\d+)/);
      if (modLink) cmid = modLink[1];
      candidates.push({ itemId, parentCategoryId: directParent, cmid });
    }
  }
  let pick = candidates[0];
  if (parentCategoryId) {
    pick = candidates.find(c => c.parentCategoryId === String(parentCategoryId)) || pick;
  }
  if (!pick) return { ok: false, error: 'item not found', candidates: candidates.slice(0, 3) };
  return { ok: true, ...pick };
}

// ──────────────────────────────────────────────────────────
// HELPER: crear grade item manual
// ──────────────────────────────────────────────────────────
async function bgCreateManualGradeItem({ baseUrl, courseId, sesskey, parentCategoryId, name, grademax, idnumber }) {
  const url = `${baseUrl}/grade/edit/tree/item.php?courseid=${courseId}`;
  const buildParams = () => {
    const p = new URLSearchParams();
    p.append('id', '0');
    p.append('courseid', String(courseId));
    p.append('itemtype', 'manual');
    p.append('sesskey', sesskey);
    p.append('_qf__edit_item_form', '1');
    p.append('mform_isexpanded_id_general', '1');
    p.append('mform_isexpanded_id_headerparent', '1');
    p.append('itemname', name);
    p.append('iteminfo', '');
    p.append('idnumber', idnumber || '');
    p.append('gradetype', '1');
    p.append('grademax', String(grademax).replace('.', ','));
    p.append('grademin', '0,00');
    p.append('gradepass', '0,00');
    p.append('display', '0');
    p.append('decimals', '-1');
    p.append('hidden', '0');
    p.append('locked', '0');
    p.append('aggregationcoef', '0,0000');
    p.append('parentcategory', String(parentCategoryId));
    p.append('submitbutton', 'Guardar cambios');
    return p;
  };
  const findCreated = async () => {
    const find = await bgFindGradeItemByName({ baseUrl, courseId, name, parentCategoryId });
    if (find.ok && find.parentCategoryId === String(parentCategoryId)) return find.itemId;
    return null;
  };
  try {
    const r = await fetch(url, {
      method: 'POST',
      body: buildParams().toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include',
      redirect: 'manual'
    });
    if (r.status >= 400 && r.status < 600) return { ok: false, error: `HTTP ${r.status}` };
    await new Promise(res => setTimeout(res, 600));
    let itemId = await findCreated();
    if (itemId) return { ok: true, itemId };
    await new Promise(res => setTimeout(res, 1200));
    itemId = await findCreated();
    if (itemId) return { ok: true, itemId, retried: true };
    return { ok: false, error: 'item creado pero no localizable' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ──────────────────────────────────────────────────────────
// HELPER: set calculation con verify + retry
// ──────────────────────────────────────────────────────────
async function bgSetGradeItemCalculation({ baseUrl, courseId, itemId, formula }) {
  const url = `${baseUrl}/grade/edit/tree/calculation.php?courseid=${courseId}&id=${itemId}`;
  const doPost = async () => {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { ok: false, error: `GET HTTP ${r.status}` };
    const html = await r.text();
    const formHtml = bgExtractForm(html, 'calculation.php');
    if (!formHtml) return { ok: false, error: 'calculation form not found' };
    let action = bgExtractFormAction(html, 'calculation.php');
    if (!action) action = url;
    if (!/^https?:/.test(action)) {
      try { action = new URL(action, url).toString(); } catch (_) {}
    }
    const params = bgBuildFormBody(formHtml, {
      calculation: formula,
      submitbutton: 'Guardar cambios'
    });
    const resp = await fetch(action, {
      method: 'POST',
      body: params.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      credentials: 'include',
      redirect: 'manual'
    });
    return { ok: resp.status === 0 || resp.ok, status: resp.status, type: resp.type };
  };
  const verify = async () => {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return '';
    const h = await r.text();
    const m = h.match(/<textarea[^>]*name="calculation"[^>]*>([\s\S]*?)<\/textarea>/);
    return (m?.[1] || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').trim();
  };
  const first = await doPost();
  if (!first.ok) return { ok: false, error: first.error || `HTTP ${first.status}` };
  await new Promise(r => setTimeout(r, 350));
  let after = await verify();
  if (after) return { ok: true, formulaSaved: after };
  await new Promise(r => setTimeout(r, 800));
  const second = await doPost();
  if (!second.ok) return { ok: false, error: second.error || `HTTP ${second.status}` };
  await new Promise(r => setTimeout(r, 500));
  after = await verify();
  if (after) return { ok: true, formulaSaved: after, retried: true };
  return { ok: false, error: 'fórmula no se guardó tras 2 intentos' };
}

// ──────────────────────────────────────────────────────────
// HELPER: borrar grade item manual
// ──────────────────────────────────────────────────────────
async function bgDeleteGradeItem({ baseUrl, courseId, sesskey, itemId }) {
  const url = `${baseUrl}/grade/edit/tree/index.php`;
  const params = new URLSearchParams();
  params.append('eid', `ig${itemId}`);
  params.append('action', 'delete');
  params.append('confirm', '1');
  params.append('sesskey', sesskey);
  params.append('id', String(courseId));
  const resp = await fetch(url, {
    method: 'POST',
    body: params.toString(),
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    credentials: 'include',
    redirect: 'manual'
  });
  return { ok: resp.status === 0 || resp.ok, status: resp.status };
}

// ──────────────────────────────────────────────────────────
// HELPER: list available idnumbers (via calculation form)
// ──────────────────────────────────────────────────────────
async function bgListAvailableIdnumbers({ baseUrl, courseId, sampleItemId }) {
  const url = `${baseUrl}/grade/edit/tree/calculation.php?courseid=${courseId}&id=${sampleItemId}`;
  const r = await fetch(url, { credentials: 'include' });
  if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
  const html = await r.text();
  const idnumbers = new Set();
  for (const m of html.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/g)) {
    const text = m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    const b = text.match(/\[\[([^\]]+)\]\]/);
    if (b) idnumbers.add(b[1]);
  }
  return { ok: true, idnumbers: [...idnumbers] };
}

async function bgResolveAvailableIdnumber({ baseUrl, courseId, sampleItemId, preferred }) {
  const res = await bgListAvailableIdnumbers({ baseUrl, courseId, sampleItemId });
  if (!res.ok) return preferred;
  const used = new Set(res.idnumbers);
  if (!used.has(preferred)) return preferred;
  const m = preferred.match(/^([A-Za-z]+)(\d+)$/);
  if (!m) return preferred;
  const prefix = m[1];
  let n = parseInt(m[2]);
  while (used.has(prefix + n) && n < 9999) n++;
  return prefix + n;
}

// ──────────────────────────────────────────────────────────
// MAIN: replicate task grade — entry point del SW
// ──────────────────────────────────────────────────────────
async function bgReplicateTaskGrade({ baseUrl, courseId, sesskey, taskName, idnumber, targets }) {
  await bgLog('BG-REPL start', { taskName, idnumber, targetCount: targets?.length, baseUrl, courseId });
  if (!courseId || !baseUrl || !sesskey) {
    await bgLog('BG-REPL FATAL missing context', { courseId, baseUrl, hasSesskey: !!sesskey });
    return { ok: false, error: 'missing context' };
  }
  if (!Array.isArray(targets) || targets.length === 0) {
    await bgLog('BG-REPL no targets, nothing to do');
    return { ok: true, summary: { total: 0, ok: 0, failed: [] } };
  }

  // 1. Encontrar la tarea
  let find;
  for (let attempt = 0; attempt < 5; attempt++) {
    find = await bgFindGradeItemByName({ baseUrl, courseId, name: taskName });
    if (find.ok && find.cmid) break;
    await bgLog('BG-REPL find attempt ' + attempt, { ok: find?.ok, cmid: find?.cmid });
    await new Promise(r => setTimeout(r, 800));
  }
  if (!find?.ok) {
    await bgLog('BG-REPL FATAL task not found', { taskName });
    return { ok: false, error: 'task not found in gradebook' };
  }
  if (!find.cmid) {
    await bgLog('BG-REPL FATAL no cmid for task', { taskName, itemId: find.itemId });
    return { ok: false, error: 'task has no cmid' };
  }
  const taskItemId = find.itemId;
  const cmid = find.cmid;
  await bgLog('BG-REPL task located', { taskItemId, cmid });

  // 2. Resolver idnumber libre + setear cmidnumber
  let finalIdnumber = await bgResolveAvailableIdnumber({ baseUrl, courseId, sampleItemId: taskItemId, preferred: idnumber });
  if (finalIdnumber !== idnumber) {
    await bgLog('BG-REPL idnumber adjusted', { preferred: idnumber, finalIdnumber });
  }
  const setIdn = await bgSetCmIdnumber({ baseUrl, cmid, idnumber: finalIdnumber });
  if (!setIdn.ok) {
    await bgLog('BG-REPL FATAL setCmIdnumber failed', { error: setIdn.error });
    return { ok: false, error: setIdn.error };
  }
  await bgLog('BG-REPL cmidnumber set', { idnumber: finalIdnumber, cmid });
  await new Promise(r => setTimeout(r, 500));

  // 3. Por cada target: crear + fórmula + rollback si falla
  const summary = { total: targets.length, ok: 0, failed: [] };
  for (let i = 0; i < targets.length; i++) {
    const target = targets[i];
    const label = target.name || `cat ${target.categoryId}`;
    await bgLog(`BG-REPL target ${i + 1}/${targets.length} START`, { label, categoryId: target.categoryId });
    try {
      const replicaName = `↻ ${taskName}`;
      const created = await bgCreateManualGradeItem({
        baseUrl, courseId, sesskey,
        parentCategoryId: target.categoryId,
        name: replicaName,
        grademax: 50,
        idnumber: ''
      });
      await bgLog(`BG-REPL target ${i + 1} create`, { ok: created.ok, itemId: created.itemId, error: created.error, retried: created.retried });
      if (!created.ok || !created.itemId) {
        summary.failed.push({ target: label, step: 'create', error: created.error });
        continue;
      }
      const calc = await bgSetGradeItemCalculation({
        baseUrl, courseId, itemId: created.itemId, formula: `=[[${finalIdnumber}]]`
      });
      await bgLog(`BG-REPL target ${i + 1} calc`, { ok: calc.ok, error: calc.error, formulaSaved: calc.formulaSaved });
      if (!calc.ok) {
        const del = await bgDeleteGradeItem({ baseUrl, courseId, sesskey, itemId: created.itemId });
        await bgLog(`BG-REPL target ${i + 1} rollback`, { ok: del.ok });
        summary.failed.push({ target: label, step: 'calc', error: calc.error });
        continue;
      }
      await bgLog(`BG-REPL target ${i + 1} OK ✓`, { label });
      summary.ok++;
    } catch (e) {
      await bgLog(`BG-REPL target ${i + 1} EXCEPTION`, { label, error: e.message });
      summary.failed.push({ target: label, step: 'exception', error: e.message });
    }
  }
  await bgLog('BG-REPL DONE summary', summary);
  return { ok: true, summary, finalIdnumber };
}
